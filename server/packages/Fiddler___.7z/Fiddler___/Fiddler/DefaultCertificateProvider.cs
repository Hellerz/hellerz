﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    internal class DefaultCertificateProvider : ICertificateProvider3, ICertificateProvider2, ICertificateProvider, ICertificateProviderInfo
    {
        private ReaderWriterLockSlim _oRWLock = new ReaderWriterLockSlim(LockRecursionPolicy.SupportsRecursion);
        private readonly string[] arrWildcardTLDs = new string[] { ".com", ".org", ".edu", ".gov", ".net" };
        private ICertificateCreator CertCreator;
        private X509Certificate2 certRoot;
        private Dictionary<string, X509Certificate2> certServerCache = new Dictionary<string, X509Certificate2>();
        private bool UseWildcards;

        internal DefaultCertificateProvider()
        {
            bool flag = false;
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.certmaker.PreferCertEnroll", true) && OSSupportsCertEnroll())
            {
                flag = true;
                this.CertCreator = CertEnrollEngine.GetEngine(this);
            }
            if (this.CertCreator == null)
            {
                this.CertCreator = MakeCertEngine.GetEngine();
            }
            if ((this.CertCreator == null) && !flag)
            {
                this.CertCreator = CertEnrollEngine.GetEngine(this);
            }
            this.UseWildcards = FiddlerApplication.Prefs.GetBoolPref("fiddler.certmaker.UseWildcards", true);
            if (this.CertCreator.GetType() == typeof(MakeCertEngine))
            {
                this.UseWildcards = false;
            }
            if (CONFIG.bDebugCertificateGeneration)
            {
                FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Using {0} for certificate generation; UseWildcards={1}.", new object[] { this.CertCreator.GetType().ToString(), this.UseWildcards });
            }
        }

        private static void _LogPrivateKeyContainer(X509Certificate2 oRoot)
        {
            try
            {
                if (oRoot != null)
                {
                    if (!oRoot.HasPrivateKey)
                    {
                        FiddlerApplication.Log.LogString("/Fiddler.CertMaker> Root Certificate located but HasPrivateKey==false!");
                    }
                    FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Root Certificate located; private key in container '{0}'", new object[] { (oRoot.PrivateKey as RSACryptoServiceProvider).CspKeyContainerInfo.UniqueKeyContainerName });
                }
                else
                {
                    FiddlerApplication.Log.LogString("/Fiddler.CertMaker> Unable to log Root Certificate private key storage as the certificate was unexpectedly null");
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Failed to identify private key location for Root Certificate. Exception: {0}", new object[] { Utilities.DescribeException(exception) });
            }
        }

        public bool CacheCertificateForHost(string sHost, X509Certificate2 oCert)
        {
            try
            {
                this.GetWriterLock();
                this.certServerCache[sHost] = oCert;
            }
            finally
            {
                this.FreeWriterLock();
            }
            return true;
        }

        public bool ClearCertificateCache()
        {
            return this.ClearCertificateCache(true);
        }

        public bool ClearCertificateCache(bool bRemoveRoot)
        {
            bool flag = true;
            try
            {
                X509Certificate2Collection certificates;
                this.GetWriterLock();
                this.certServerCache.Clear();
                this.certRoot = null;
                string sFullSubject = string.Format("CN={0}{1}", CONFIG.sMakeCertRootCN, CONFIG.sMakeCertSubjectO);
                if (bRemoveRoot)
                {
                    certificates = FindCertsBySubject(StoreName.Root, StoreLocation.CurrentUser, sFullSubject);
                    if (certificates.Count > 0)
                    {
                        X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
                        store.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadWrite);
                        try
                        {
                            store.RemoveRange(certificates);
                        }
                        catch
                        {
                            flag = false;
                        }
                        store.Close();
                    }
                }
                certificates = FindCertsByIssuer(StoreName.My, sFullSubject);
                if (certificates.Count <= 0)
                {
                    return flag;
                }
                if (!bRemoveRoot)
                {
                    X509Certificate2 rootCertificate = this.GetRootCertificate();
                    if (rootCertificate != null)
                    {
                        certificates.Remove(rootCertificate);
                        if (certificates.Count < 1)
                        {
                            return true;
                        }
                    }
                }
                X509Store store2 = new X509Store(StoreName.My, StoreLocation.CurrentUser);
                store2.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadWrite);
                try
                {
                    store2.RemoveRange(certificates);
                }
                catch
                {
                    flag = false;
                }
                store2.Close();
            }
            finally
            {
                this.FreeWriterLock();
            }
            return flag;
        }

        private X509Certificate2 CreateCert(string sHostname, bool isRoot)
        {
            if (sHostname.IndexOfAny(new char[] { '"', '\r', '\n', '\0' }) != -1)
            {
                return null;
            }
            if (!isRoot && (this.GetRootCertificate() == null))
            {
                try
                {
                    this.GetWriterLock();
                    if ((this.GetRootCertificate() == null) && !this.CreateRootCertificate())
                    {
                        FiddlerApplication.DoNotifyUser("Creation of the root certificate was not successful.", "Certificate Error");
                        return null;
                    }
                }
                finally
                {
                    this.FreeWriterLock();
                }
            }
            X509Certificate2 certificate = null;
            try
            {
                X509Certificate2 certificate2;
                this.GetWriterLock();
                if (!this.certServerCache.TryGetValue(sHostname, out certificate2))
                {
                    certificate2 = LoadCertificateFromWindowsStore(sHostname);
                }
                if (certificate2 != null)
                {
                    if (CONFIG.bDebugCertificateGeneration)
                    {
                        FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker>{1} A racing thread already successfully CreatedCert({0})", new object[] { sHostname, Thread.CurrentThread.ManagedThreadId });
                    }
                    return certificate2;
                }
                certificate = this.CertCreator.CreateCert(sHostname, isRoot);
                if (certificate != null)
                {
                    if (isRoot)
                    {
                        this.certRoot = certificate;
                    }
                    else
                    {
                        this.certServerCache[sHostname] = certificate;
                    }
                }
            }
            finally
            {
                this.FreeWriterLock();
            }
            if ((certificate == null) && !isRoot)
            {
                FiddlerApplication.Log.LogFormat("!Fiddler.CertMaker> Failed to create certificate for '{0}'.", new object[] { sHostname });
                _LogPrivateKeyContainer(this.GetRootCertificate());
            }
            return certificate;
        }

        public bool CreateRootCertificate()
        {
            return (null != this.CreateCert(CONFIG.sMakeCertRootCN, true));
        }

        private static X509Certificate2Collection FindCertsByIssuer(StoreName storeName, string sFullIssuerSubject)
        {
            X509Certificate2Collection certificates2;
            X509Store store = new X509Store(storeName, StoreLocation.CurrentUser);
            try
            {
                store.Open(OpenFlags.OpenExistingOnly);
                certificates2 = store.Certificates.Find(X509FindType.FindByIssuerDistinguishedName, sFullIssuerSubject, false);
            }
            finally
            {
                store.Close();
            }
            return certificates2;
        }

        private static X509Certificate2Collection FindCertsBySubject(StoreName storeName, StoreLocation storeLocation, string sFullSubject)
        {
            X509Certificate2Collection certificates2;
            X509Store store = new X509Store(storeName, storeLocation);
            try
            {
                store.Open(OpenFlags.OpenExistingOnly);
                certificates2 = store.Certificates.Find(X509FindType.FindBySubjectDistinguishedName, sFullSubject, false);
            }
            finally
            {
                store.Close();
            }
            return certificates2;
        }

        private void FreeReaderLock()
        {
            this._oRWLock.ExitReadLock();
        }

        private void FreeWriterLock()
        {
            this._oRWLock.ExitWriteLock();
        }

        public X509Certificate2 GetCertificateForHost(string sHostname)
        {
            X509Certificate2 certificate;
            bool flag;
            if ((this.UseWildcards && sHostname.OICEndsWithAny(this.arrWildcardTLDs)) && (Utilities.IndexOfNth(sHostname, 2, '.') > 0))
            {
                sHostname = "*." + Utilities.TrimBefore(sHostname, ".");
            }
            try
            {
                this.GetReaderLock();
                if (this.certServerCache.TryGetValue(sHostname, out certificate))
                {
                    return certificate;
                }
            }
            finally
            {
                this.FreeReaderLock();
            }
            certificate = this.LoadOrCreateCertificate(sHostname, out flag);
            if ((certificate != null) && !flag)
            {
                this.CacheCertificateForHost(sHostname, certificate);
            }
            return certificate;
        }

        public string GetConfigurationString()
        {
            if (this.CertCreator == null)
            {
                return "No Engine Loaded.";
            }
            StringBuilder builder = new StringBuilder();
            string str = Utilities.TrimBefore(this.CertCreator.GetType().ToString(), "+");
            builder.AppendFormat("Certificate Engine:\t{0}\n", str);
            if (str == "CertEnrollEngine")
            {
                builder.AppendFormat("HashAlg-Root:\t{0}\n", FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.ce.Root.SigAlg", "SHA256"));
                builder.AppendFormat("HashAlg-EE:\t{0}\n", FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.ce.EE.SigAlg", "SHA256"));
                builder.AppendFormat("KeyLen-Root:\t{0}bits\n", FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.ce.Root.KeyLength", 0x800));
                builder.AppendFormat("KeyLen-EE:\t{0}bits\n", FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.ce.EE.KeyLength", 0x800));
                builder.AppendFormat("ValidFrom:\t{0} days ago\n", FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.GraceDays", 0x16e));
                builder.AppendFormat("ValidFor:\t\t{0} days\n", FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.ValidDays", 0x721));
            }
            else
            {
                builder.AppendFormat("ValidFrom:\t{0} days ago\n", FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.GraceDays", 0x16e));
                builder.AppendFormat("HashAlg-Root:\t{0}\n", FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.Root.SigAlg", (Environment.OSVersion.Version.Major > 5) ? "SHA256" : "SHA1"));
                builder.AppendFormat("HashAlg-EE:\t{0}\n", FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.EE.SigAlg", (Environment.OSVersion.Version.Major > 5) ? "SHA256" : "SHA1"));
                builder.AppendFormat("ExtraParams-Root:\t{0}\n", FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.EE.extraparams", string.Empty));
                builder.AppendFormat("ExtraParams-EE:\t{0}\n", FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.root.extraparams", string.Empty));
            }
            return builder.ToString();
        }

        internal string GetEngineString()
        {
            if (this.CertCreator.GetType() == typeof(CertEnrollEngine))
            {
                return "CertEnroll engine";
            }
            if (this.CertCreator.GetType() == typeof(MakeCertEngine))
            {
                return "MakeCert engine";
            }
            return "Unknown engine";
        }

        private void GetReaderLock()
        {
            this._oRWLock.EnterReadLock();
        }

        public X509Certificate2 GetRootCertificate()
        {
            if (this.certRoot != null)
            {
                return this.certRoot;
            }
            X509Certificate2 oRoot = LoadCertificateFromWindowsStore(CONFIG.sMakeCertRootCN);
            if (CONFIG.bDebugCertificateGeneration)
            {
                if (oRoot != null)
                {
                    _LogPrivateKeyContainer(oRoot);
                }
                else
                {
                    FiddlerApplication.Log.LogString("DefaultCertMaker: GetRootCertificate() did not find the root in the Windows TrustStore.");
                }
            }
            this.certRoot = oRoot;
            return oRoot;
        }

        private void GetWriterLock()
        {
            this._oRWLock.EnterWriteLock();
        }

        internal static X509Certificate2 LoadCertificateFromWindowsStore(string sHostname)
        {
            X509Store store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            try
            {
                store.Open(OpenFlags.ReadOnly);
                string inStr = string.Format("CN={0}{1}", sHostname, CONFIG.sMakeCertSubjectO);
                X509Certificate2Enumerator enumerator = store.Certificates.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    X509Certificate2 current = enumerator.Current;
                    if (inStr.OICEquals(current.Subject))
                    {
                        return current;
                    }
                }
            }
            finally
            {
                store.Close();
            }
            return null;
        }

        internal X509Certificate2 LoadOrCreateCertificate(string sHostname, out bool bAttemptedCreation)
        {
            bAttemptedCreation = false;
            X509Certificate2 certificate = LoadCertificateFromWindowsStore(sHostname);
            if (certificate == null)
            {
                bAttemptedCreation = true;
                certificate = this.CreateCert(sHostname, false);
                if (certificate == null)
                {
                    FiddlerApplication.Log.LogFormat("!Fiddler.CertMaker> Tried to create cert for '{0}', but can't find it from thread {1}!", new object[] { sHostname, Thread.CurrentThread.ManagedThreadId });
                }
            }
            return certificate;
        }

        private static bool OSSupportsCertEnroll()
        {
            return ((Environment.OSVersion.Version.Major > 6) || ((Environment.OSVersion.Version.Major == 6) && (Environment.OSVersion.Version.Minor > 0)));
        }

        public bool rootCertIsTrusted(out bool bUserTrusted, out bool bMachineTrusted)
        {
            bUserTrusted = 0 < FindCertsBySubject(StoreName.Root, StoreLocation.CurrentUser, string.Format("CN={0}{1}", CONFIG.sMakeCertRootCN, CONFIG.sMakeCertSubjectO)).Count;
            bMachineTrusted = 0 < FindCertsBySubject(StoreName.Root, StoreLocation.LocalMachine, string.Format("CN={0}{1}", CONFIG.sMakeCertRootCN, CONFIG.sMakeCertSubjectO)).Count;
            if (!bUserTrusted)
            {
                return bMachineTrusted;
            }
            return true;
        }

        public void ShowConfigurationUI(IntPtr hwndOwner)
        {
            Form frmGetPrefs = new Form();
            Utilities.AdjustFontSize(frmGetPrefs, CONFIG.flFontSize);
            frmGetPrefs.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            frmGetPrefs.Size = new Size(0x109, 320);
            frmGetPrefs.MinimumSize = new Size(0x109, 150);
            frmGetPrefs.Text = "Certificate Creation Preferences";
            ComboBox oCbx = new ComboBox();
            Utilities.AdjustFontSize(oCbx, CONFIG.flFontSize);
            Label label = new Label();
            label.Size = new Size(70, 14);
            label.Text = "&Engine:";
            frmGetPrefs.Controls.Add(label);
            label.Location = new Point(5, 14);
            oCbx.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            oCbx.DropDownStyle = ComboBoxStyle.DropDownList;
            oCbx.Items.Add("MakeCert");
            if (OSSupportsCertEnroll())
            {
                oCbx.Items.Add("CertEnroll");
            }
            oCbx.Width = 160;
            frmGetPrefs.Controls.Add(oCbx);
            oCbx.Location = new Point(0x4b, 10);
            CheckBox box = new CheckBox();
            box.Text = "Clear server certs on e&xit";
            box.AutoSize = true;
            box.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.CertMaker.CleanupServerCertsOnExit", false);
            box.Location = new Point(5, 0x23);
            frmGetPrefs.Controls.Add(box);
            CheckBox cbWildcard = new CheckBox();
            cbWildcard.Text = "Use &wildcards (e.g. *.example.com)";
            cbWildcard.AutoSize = true;
            cbWildcard.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.CertMaker.UseWildcards", true);
            cbWildcard.Location = new Point(5, 0x37);
            frmGetPrefs.Controls.Add(cbWildcard);
            oCbx.SelectedIndexChanged += delegate (object o, EventArgs ea) {
                if (oCbx.SelectedIndex == 0)
                {
                    cbWildcard.Checked = false;
                }
                cbWildcard.Enabled = 0 != oCbx.SelectedIndex;
            };
            Button button = new Button();
            button.AutoSize = true;
            button.Text = "&OK";
            frmGetPrefs.Controls.Add(button);
            button.Left = (frmGetPrefs.ClientSize.Width - button.Width) - 10;
            button.Top = (frmGetPrefs.ClientSize.Height - button.Height) - 10;
            button.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            frmGetPrefs.AcceptButton = button;
            button.Click += delegate (object s2, EventArgs ea2) {
                frmGetPrefs.DialogResult = DialogResult.OK;
            };
            Button button2 = new Button();
            button2.AutoSize = true;
            button2.Text = "Cancel";
            frmGetPrefs.Controls.Add(button2);
            button2.Left = 10;
            button2.Top = (frmGetPrefs.ClientSize.Height - button2.Height) - 10;
            button2.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            frmGetPrefs.CancelButton = button2;
            TextBox box2 = new TextBox();
            frmGetPrefs.Controls.Add(box2);
            box2.BorderStyle = BorderStyle.None;
            box2.ReadOnly = true;
            box2.BackColor = frmGetPrefs.BackColor;
            box2.WordWrap = true;
            box2.Multiline = true;
            box2.Location = new Point(5, 0x4b);
            box2.Size = new Size(240, 160);
            box2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            box2.Text = string.Format("Current Configuration\r\n{0}\r\nChanges will require restart. After restart, to ensure proper trust, disable HTTPS decryption, remove old certificates, and reenable decryption.", this.GetConfigurationString().Replace("\n", "\r\n"));
            if (this.CertCreator.GetType() == typeof(MakeCertEngine))
            {
                cbWildcard.Checked = cbWildcard.Enabled = false;
                oCbx.SelectedIndex = 0;
            }
            else if (this.CertCreator.GetType() == typeof(CertEnrollEngine))
            {
                oCbx.SelectedIndex = 1;
            }
            button2.Click += delegate (object s2, EventArgs ea2) {
                frmGetPrefs.DialogResult = DialogResult.Cancel;
            };
            frmGetPrefs.StartPosition = FormStartPosition.CenterParent;
            if (DialogResult.OK == frmGetPrefs.ShowDialog(Control.FromHandle(hwndOwner)))
            {
                FiddlerApplication.Prefs.SetBoolPref("fiddler.CertMaker.CleanupServerCertsOnExit", box.Checked);
                FiddlerApplication.Prefs.SetBoolPref("fiddler.CertMaker.UseWildcards", cbWildcard.Checked);
                FiddlerApplication.Prefs.SetBoolPref("fiddler.CertMaker.PreferCertEnroll", oCbx.SelectedIndex > 0);
            }
            frmGetPrefs.Dispose();
        }

        public bool TrustRootCertificate()
        {
            X509Certificate2 rootCertificate = this.GetRootCertificate();
            if (rootCertificate == null)
            {
                FiddlerApplication.Log.LogString("!Fiddler.CertMaker> The Root certificate could not be found.");
                return false;
            }
            try
            {
                X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
                store.Open(OpenFlags.ReadWrite);
                try
                {
                    store.Add(rootCertificate);
                }
                finally
                {
                    store.Close();
                }
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("!Fiddler.CertMaker> Unable to auto-trust root: {0}", new object[] { exception });
                return false;
            }
        }

        private class CertEnrollEngine : DefaultCertificateProvider.ICertificateCreator
        {
            private object _oSharedPrivateKey;
            private ICertificateProvider3 _ParentProvider;
            private string sProviderName = "Microsoft Enhanced Cryptographic Provider v1.0";
            private System.Type typeAlternativeName;
            private System.Type typeAlternativeNames;
            private System.Type typeAlternativeNamesExt;
            private System.Type typeBasicConstraints;
            private System.Type typeEKUExt;
            private System.Type typeKUExt;
            private System.Type typeOID;
            private System.Type typeOIDS;
            private System.Type typeRequestCert;
            private System.Type typeSignerCertificate;
            private System.Type typeX500DN;
            private System.Type typeX509Enrollment;
            private System.Type typeX509Extensions;
            private System.Type typeX509PrivateKey;

            private CertEnrollEngine(ICertificateProvider3 ParentProvider)
            {
                this._ParentProvider = ParentProvider;
                this.sProviderName = FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.KeyProviderName", this.sProviderName);
                this.typeX500DN = System.Type.GetTypeFromProgID("X509Enrollment.CX500DistinguishedName", true);
                this.typeX509PrivateKey = System.Type.GetTypeFromProgID("X509Enrollment.CX509PrivateKey", true);
                this.typeOID = System.Type.GetTypeFromProgID("X509Enrollment.CObjectId", true);
                this.typeOIDS = System.Type.GetTypeFromProgID("X509Enrollment.CObjectIds.1", true);
                this.typeEKUExt = System.Type.GetTypeFromProgID("X509Enrollment.CX509ExtensionEnhancedKeyUsage");
                this.typeKUExt = System.Type.GetTypeFromProgID("X509Enrollment.CX509ExtensionKeyUsage");
                this.typeRequestCert = System.Type.GetTypeFromProgID("X509Enrollment.CX509CertificateRequestCertificate");
                this.typeX509Extensions = System.Type.GetTypeFromProgID("X509Enrollment.CX509Extensions");
                this.typeBasicConstraints = System.Type.GetTypeFromProgID("X509Enrollment.CX509ExtensionBasicConstraints");
                this.typeSignerCertificate = System.Type.GetTypeFromProgID("X509Enrollment.CSignerCertificate");
                this.typeX509Enrollment = System.Type.GetTypeFromProgID("X509Enrollment.CX509Enrollment");
                this.typeAlternativeName = System.Type.GetTypeFromProgID("X509Enrollment.CAlternativeName");
                this.typeAlternativeNames = System.Type.GetTypeFromProgID("X509Enrollment.CAlternativeNames");
                this.typeAlternativeNamesExt = System.Type.GetTypeFromProgID("X509Enrollment.CX509ExtensionAlternativeNames");
            }

            public X509Certificate2 CreateCert(string sSubjectCN, bool isRoot)
            {
                return this.InternalCreateCert(sSubjectCN, isRoot, true);
            }

            private X509Certificate2 GenerateCertificate(bool bIsRoot, string sSubjectCN, string sFullSubject, int iPrivateKeyLength, string sHashAlg, DateTime dtValidFrom, DateTime dtValidTo, X509Certificate2 oSigningCertificate)
            {
                if (bIsRoot != (null == oSigningCertificate))
                {
                    throw new ArgumentException("You must specify a Signing Certificate if and only if you are not creating a root.", "oSigningCertificate");
                }
                object target = Activator.CreateInstance(this.typeX500DN);
                object[] args = new object[] { sFullSubject, 0 };
                this.typeX500DN.InvokeMember("Encode", BindingFlags.InvokeMethod, null, target, args);
                object obj3 = Activator.CreateInstance(this.typeX500DN);
                if (!bIsRoot)
                {
                    args[0] = oSigningCertificate.Subject;
                }
                this.typeX500DN.InvokeMember("Encode", BindingFlags.InvokeMethod, null, obj3, args);
                object obj4 = null;
                if (!bIsRoot)
                {
                    obj4 = this._oSharedPrivateKey;
                }
                if (obj4 == null)
                {
                    obj4 = Activator.CreateInstance(this.typeX509PrivateKey);
                    args = new object[] { this.sProviderName };
                    this.typeX509PrivateKey.InvokeMember("ProviderName", BindingFlags.PutDispProperty, null, obj4, args);
                    args[0] = 2;
                    this.typeX509PrivateKey.InvokeMember("ExportPolicy", BindingFlags.PutDispProperty, null, obj4, args);
                    args = new object[] { bIsRoot ? 2 : 1 };
                    this.typeX509PrivateKey.InvokeMember("KeySpec", BindingFlags.PutDispProperty, null, obj4, args);
                    if (!bIsRoot)
                    {
                        args = new object[] { 0xb0 };
                        this.typeX509PrivateKey.InvokeMember("KeyUsage", BindingFlags.PutDispProperty, null, obj4, args);
                    }
                    args[0] = iPrivateKeyLength;
                    this.typeX509PrivateKey.InvokeMember("Length", BindingFlags.PutDispProperty, null, obj4, args);
                    this.typeX509PrivateKey.InvokeMember("Create", BindingFlags.InvokeMethod, null, obj4, null);
                    if (!bIsRoot)
                    {
                        this._oSharedPrivateKey = obj4;
                    }
                }
                else if (CONFIG.bDebugCertificateGeneration)
                {
                    FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Reusing PrivateKey for '{0}'", new object[] { sSubjectCN });
                }
                args = new object[1];
                object obj5 = Activator.CreateInstance(this.typeOID);
                args[0] = "1.3.6.1.5.5.7.3.1";
                this.typeOID.InvokeMember("InitializeFromValue", BindingFlags.InvokeMethod, null, obj5, args);
                object obj6 = Activator.CreateInstance(this.typeOIDS);
                args[0] = obj5;
                this.typeOIDS.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj6, args);
                object obj7 = Activator.CreateInstance(this.typeEKUExt);
                args[0] = obj6;
                this.typeEKUExt.InvokeMember("InitializeEncode", BindingFlags.InvokeMethod, null, obj7, args);
                object obj8 = Activator.CreateInstance(this.typeRequestCert);
                args = new object[] { 1, obj4, string.Empty };
                this.typeRequestCert.InvokeMember("InitializeFromPrivateKey", BindingFlags.InvokeMethod, null, obj8, args);
                args = new object[] { target };
                this.typeRequestCert.InvokeMember("Subject", BindingFlags.PutDispProperty, null, obj8, args);
                args[0] = obj3;
                this.typeRequestCert.InvokeMember("Issuer", BindingFlags.PutDispProperty, null, obj8, args);
                args[0] = dtValidFrom;
                this.typeRequestCert.InvokeMember("NotBefore", BindingFlags.PutDispProperty, null, obj8, args);
                args[0] = dtValidTo;
                this.typeRequestCert.InvokeMember("NotAfter", BindingFlags.PutDispProperty, null, obj8, args);
                object obj9 = Activator.CreateInstance(this.typeKUExt);
                args[0] = 0xb0;
                this.typeKUExt.InvokeMember("InitializeEncode", BindingFlags.InvokeMethod, null, obj9, args);
                object obj10 = this.typeRequestCert.InvokeMember("X509Extensions", BindingFlags.GetProperty, null, obj8, null);
                args = new object[1];
                if (!bIsRoot)
                {
                    args[0] = obj9;
                    this.typeX509Extensions.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj10, args);
                }
                args[0] = obj7;
                this.typeX509Extensions.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj10, args);
                if (!bIsRoot && FiddlerApplication.Prefs.GetBoolPref("fiddler.certmaker.AddSubjectAltName", true))
                {
                    object obj11 = Activator.CreateInstance(this.typeAlternativeName);
                    IPAddress address = Utilities.IPFromString(sSubjectCN);
                    if (address == null)
                    {
                        args = new object[] { 3, sSubjectCN };
                        this.typeAlternativeName.InvokeMember("InitializeFromString", BindingFlags.InvokeMethod, null, obj11, args);
                    }
                    else
                    {
                        args = new object[] { 8, 1, Convert.ToBase64String(address.GetAddressBytes()) };
                        this.typeAlternativeName.InvokeMember("InitializeFromRawData", BindingFlags.InvokeMethod, null, obj11, args);
                    }
                    object obj12 = Activator.CreateInstance(this.typeAlternativeNames);
                    args = new object[] { obj11 };
                    this.typeAlternativeNames.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj12, args);
                    Marshal.ReleaseComObject(obj11);
                    if ((address != null) && (AddressFamily.InterNetworkV6 == address.AddressFamily))
                    {
                        obj11 = Activator.CreateInstance(this.typeAlternativeName);
                        args = new object[] { 3, "[" + sSubjectCN + "]" };
                        this.typeAlternativeName.InvokeMember("InitializeFromString", BindingFlags.InvokeMethod, null, obj11, args);
                        args = new object[] { obj11 };
                        this.typeAlternativeNames.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj12, args);
                        Marshal.ReleaseComObject(obj11);
                    }
                    object obj13 = Activator.CreateInstance(this.typeAlternativeNamesExt);
                    args = new object[] { obj12 };
                    this.typeAlternativeNamesExt.InvokeMember("InitializeEncode", BindingFlags.InvokeMethod, null, obj13, args);
                    args = new object[] { obj13 };
                    this.typeX509Extensions.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj10, args);
                }
                if (bIsRoot)
                {
                    object obj14 = Activator.CreateInstance(this.typeBasicConstraints);
                    args = new object[] { "true", "0" };
                    this.typeBasicConstraints.InvokeMember("InitializeEncode", BindingFlags.InvokeMethod, null, obj14, args);
                    args = new object[] { obj14 };
                    this.typeX509Extensions.InvokeMember("Add", BindingFlags.InvokeMethod, null, obj10, args);
                }
                else
                {
                    object obj15 = Activator.CreateInstance(this.typeSignerCertificate);
                    args = new object[] { 0, 0, 12, oSigningCertificate.Thumbprint };
                    this.typeSignerCertificate.InvokeMember("Initialize", BindingFlags.InvokeMethod, null, obj15, args);
                    args = new object[] { obj15 };
                    this.typeRequestCert.InvokeMember("SignerCertificate", BindingFlags.PutDispProperty, null, obj8, args);
                }
                object obj16 = Activator.CreateInstance(this.typeOID);
                args = new object[] { 1, 0, 0, sHashAlg };
                this.typeOID.InvokeMember("InitializeFromAlgorithmName", BindingFlags.InvokeMethod, null, obj16, args);
                args = new object[] { obj16 };
                this.typeRequestCert.InvokeMember("HashAlgorithm", BindingFlags.PutDispProperty, null, obj8, args);
                this.typeRequestCert.InvokeMember("Encode", BindingFlags.InvokeMethod, null, obj8, null);
                object obj17 = Activator.CreateInstance(this.typeX509Enrollment);
                args[0] = obj8;
                this.typeX509Enrollment.InvokeMember("InitializeFromRequest", BindingFlags.InvokeMethod, null, obj17, args);
                if (bIsRoot)
                {
                    args[0] = "DO_NOT_TRUST_FiddlerRoot-CE";
                    this.typeX509Enrollment.InvokeMember("CertificateFriendlyName", BindingFlags.PutDispProperty, null, obj17, args);
                }
                args[0] = 0;
                object obj18 = this.typeX509Enrollment.InvokeMember("CreateRequest", BindingFlags.InvokeMethod, null, obj17, args);
                args = new object[] { 2, obj18, 0, string.Empty };
                this.typeX509Enrollment.InvokeMember("InstallResponse", BindingFlags.InvokeMethod, null, obj17, args);
                args = new object[] { null, 0, 1 };
                string s = string.Empty;
                try
                {
                    s = (string) this.typeX509Enrollment.InvokeMember("CreatePFX", BindingFlags.InvokeMethod, null, obj17, args);
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("!Failed to CreatePFX: {0}", new object[] { Utilities.DescribeException(exception) });
                    return null;
                }
                return new X509Certificate2(Convert.FromBase64String(s), string.Empty, X509KeyStorageFlags.Exportable);
            }

            internal static DefaultCertificateProvider.ICertificateCreator GetEngine(ICertificateProvider3 ParentProvider)
            {
                try
                {
                    return new DefaultCertificateProvider.CertEnrollEngine(ParentProvider);
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("Failed to initialize CertEnrollEngine: {0}", new object[] { Utilities.DescribeException(exception) });
                }
                return null;
            }

            private X509Certificate2 InternalCreateCert(string sSubjectCN, bool isRoot, bool switchToMTAIfNeeded)
            {
                if (switchToMTAIfNeeded && (Thread.CurrentThread.GetApartmentState() != ApartmentState.MTA))
                {
                    if (CONFIG.bDebugCertificateGeneration)
                    {
                        FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Caller was in ApartmentState: {0}; hopping to Threadpool", new object[] { Thread.CurrentThread.GetApartmentState().ToString() });
                    }
                    X509Certificate2 newCert = null;
                    ManualResetEvent oMRE = new ManualResetEvent(false);
                    ThreadPool.QueueUserWorkItem(delegate (object o) {
                        newCert =this.InternalCreateCert(sSubjectCN,isRoot, false);
                        oMRE.Set();
                    });
                    oMRE.WaitOne();
                    oMRE.Close();
                    return newCert;
                }
                string sFullSubject = string.Format("CN={0}{1}", sSubjectCN, CONFIG.sMakeCertSubjectO);
                if (CONFIG.bDebugCertificateGeneration)
                {
                    FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Invoking CertEnroll for Subject: {0}; Thread's ApartmentState: {1}", new object[] { sFullSubject, Thread.CurrentThread.GetApartmentState().ToString() });
                }
                string stringPref = FiddlerApplication.Prefs.GetStringPref(isRoot ? "fiddler.certmaker.ce.Root.SigAlg" : "fiddler.certmaker.ce.EE.SigAlg", "SHA256");
                int num = -FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.GraceDays", 0x16e);
                int num2 = FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.ValidDays", 0x721);
                X509Certificate2 certificate = null;
                try
                {
                    if (isRoot)
                    {
                        int iPrivateKeyLength = FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.ce.Root.KeyLength", 0x800);
                        certificate = this.GenerateCertificate(true, sSubjectCN, sFullSubject, iPrivateKeyLength, stringPref, DateTime.Now.AddDays((double) num), DateTime.Now.AddDays((double) num2), null);
                    }
                    else
                    {
                        int num4 = FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.ce.EE.KeyLength", 0x800);
                        certificate = this.GenerateCertificate(false, sSubjectCN, sFullSubject, num4, stringPref, DateTime.Now.AddDays((double) num), DateTime.Now.AddDays((double) num2), this._ParentProvider.GetRootCertificate());
                    }
                    if (CONFIG.bDebugCertificateGeneration)
                    {
                        FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Finished CertEnroll for '{0}'. Returning {1}", new object[] { sFullSubject, (certificate != null) ? "cert" : "null" });
                    }
                    return certificate;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("!ERROR: Failed to generate Certificate using CertEnroll. {0}", new object[] { Utilities.DescribeException(exception) });
                }
                return null;
            }
        }

        private interface ICertificateCreator
        {
            X509Certificate2 CreateCert(string sSubject, bool isRoot);
        }

        private class MakeCertEngine : DefaultCertificateProvider.ICertificateCreator
        {
            private string _sDefaultHash = "sha1";
            private string _sMakeCertLocation;

            private MakeCertEngine()
            {
                if (Environment.OSVersion.Version.Major > 5)
                {
                    this._sDefaultHash = "sha256";
                }
                this._sMakeCertLocation = CONFIG.GetPath("MakeCert");
                if (!System.IO.File.Exists(this._sMakeCertLocation))
                {
                    FiddlerApplication.Log.LogFormat("Cannot locate:\n\t\"{0}\"\n\nPlease move makecert.exe to the Fiddler installation directory.", new object[] { this._sMakeCertLocation });
                    throw new FileNotFoundException("Cannot locate: \"" + this._sMakeCertLocation + "\". Please move makecert.exe to the Fiddler installation directory.");
                }
            }

            public X509Certificate2 CreateCert(string sHostname, bool isRoot)
            {
                X509Certificate2 certificate = null;
                int num;
                string str2;
                string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.DateFormatString", "MM/dd/yyyy");
                int num2 = -FiddlerApplication.Prefs.GetInt32Pref("fiddler.certmaker.GraceDays", 0x16e);
                DateTime time = DateTime.Now.AddDays((double) num2);
                if (isRoot)
                {
                    str2 = string.Format(CONFIG.sMakeCertParamsRoot, new object[] { sHostname, CONFIG.sMakeCertSubjectO, CONFIG.sMakeCertRootCN, FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.Root.SigAlg", this._sDefaultHash), time.ToString(stringPref, CultureInfo.InvariantCulture), FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.Root.extraparams", string.Empty) });
                }
                else
                {
                    str2 = string.Format(CONFIG.sMakeCertParamsEE, new object[] { sHostname, CONFIG.sMakeCertSubjectO, CONFIG.sMakeCertRootCN, FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.EE.SigAlg", this._sDefaultHash), time.ToString(stringPref, CultureInfo.InvariantCulture), FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.EE.extraparams", string.Empty) });
                }
                if (CONFIG.bDebugCertificateGeneration)
                {
                    FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker> Invoking makecert.exe with arguments: {0}", new object[] { str2 });
                }
                string str = Utilities.GetExecutableOutput(this._sMakeCertLocation, str2, out num);
                if (CONFIG.bDebugCertificateGeneration)
                {
                    FiddlerApplication.Log.LogFormat("/Fiddler.CertMaker>{3}-CreateCert({0}) => ({1}){2}", new object[] { sHostname, num, (num == 0) ? "." : ("\r\n" + str), Thread.CurrentThread.ManagedThreadId });
                }
                if (num == 0)
                {
                    int num3 = 6;
                    do
                    {
                        certificate = DefaultCertificateProvider.LoadCertificateFromWindowsStore(sHostname);
                        Thread.Sleep((int) (50 * (6 - num3)));
                        if (CONFIG.bDebugCertificateGeneration && (certificate == null))
                        {
                            FiddlerApplication.Log.LogFormat("!WARNING: Couldn't find certificate for {0} on try #{1}", new object[] { sHostname, 6 - num3 });
                        }
                        num3--;
                    }
                    while ((certificate == null) && (num3 >= 0));
                }
                if (certificate == null)
                {
                    string sMessage = string.Format("Creation of the interception certificate failed.\n\nmakecert.exe returned {0}.\n\n{1}", num, str);
                    FiddlerApplication.Log.LogFormat("Fiddler.CertMaker> [{0} {1}] Returned Error: {2} ", new object[] { this._sMakeCertLocation, str2, sMessage });
                    if (CONFIG.bDebugCertificateGeneration)
                    {
                        FiddlerApplication.DoNotifyUser(sMessage, "Unable to Generate Certificate");
                    }
                }
                return certificate;
            }

            internal static DefaultCertificateProvider.ICertificateCreator GetEngine()
            {
                try
                {
                    return new DefaultCertificateProvider.MakeCertEngine();
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("!Failed to initialize MakeCertEngine: {0}", new object[] { Utilities.DescribeException(exception) });
                }
                return null;
            }
        }
    }
}

