﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    public class Logger
    {
        public EventHandler<LogEventArgs> OnLogString;
        private List<string> queueStartupMessages;

      

        public Logger(bool bQueueStartup)
        {
            this.queueStartupMessages = bQueueStartup ? new List<string>() : null;
        }

        internal void FlushStartupMessages()
        {
            if (this.queueStartupMessages != null)
            {
                EventHandler<LogEventArgs> onLogString = this.OnLogString;
                if (onLogString != null)
                {
                    List<string> queueStartupMessages = this.queueStartupMessages;
                    this.queueStartupMessages = null;
                    foreach (string str in queueStartupMessages)
                    {
                        LogEventArgs e = new LogEventArgs(str);
                        onLogString(this, e);
                    }
                }
                else
                {
                    this.queueStartupMessages = null;
                }
            }
        }

        public void LogFormat(string format, params object[] args)
        {
            this.LogString(string.Format(format, args));
        }

        public void LogString(string sMsg)
        {
            if (!string.IsNullOrEmpty(sMsg))
            {
                FiddlerApplication.DebugSpew(sMsg);
                if (this.queueStartupMessages != null)
                {
                    List<string> list;
                    bool lockTaken = false;
                    try
                    {
                        Monitor.Enter(list = this.queueStartupMessages, ref lockTaken);
                        this.queueStartupMessages.Add(sMsg);
                    }
                    finally
                    {
                        if (lockTaken)
                        {
                            Monitor.Exit(queueStartupMessages);
                        }
                    }
                }
                else
                {
                    EventHandler<LogEventArgs> onLogString = this.OnLogString;
                    if (onLogString != null)
                    {
                        LogEventArgs e = new LogEventArgs(sMsg);
                        onLogString(this, e);
                    }
                }
            }
        }
    }
}

