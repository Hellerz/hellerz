﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Net;
    using System.Net.Sockets;
    using System.Security;
    using System.Text;
    using System.Threading;

    internal class DNSResolver
    {
        private static readonly int COUNT_MAX_A_RECORDS = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.dns.MaxAddressCount", 5);
        private static readonly Dictionary<string, DNSCacheEntry> dictAddresses = new Dictionary<string, DNSCacheEntry>();
        internal static long MSEC_DNS_CACHE_LIFETIME = ((long) FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.dnscache", 0x249f0));

        static DNSResolver()
        {
            FiddlerApplication.Janitor.assignWork(new SimpleEventHandler(DNSResolver.ScavengeCache), 0x7530);
        }

        private static void AssignIPEPList(ServerChatter.MakeConnectionExecutionState _esState, IPAddress[] _arrIPs)
        {
            List<IPEndPoint> list = new List<IPEndPoint>(_arrIPs.Length);
            foreach (IPAddress address in _arrIPs)
            {
                list.Add(new IPEndPoint(address, _esState.iServerPort));
            }
            _esState.arrIPEPDest = list.ToArray();
        }

        internal static void ClearCache()
        {
            Dictionary<string, DNSCacheEntry> dictionary;
            bool lockTaken = false;
            try
            {
                Monitor.Enter(dictionary = dictAddresses, ref lockTaken);
                dictAddresses.Clear();
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(dictAddresses);
                }
            }
        }

        internal static string GetAllInfo(string sHostname)
        {
            IPHostEntry hostEntry;
            try
            {
                hostEntry = Dns.GetHostEntry(sHostname);
            }
            catch (Exception exception)
            {
                return string.Format("FiddlerDNS> DNS Lookup for \"{0}\" failed because '{1}'\n", sHostname, Utilities.DescribeException(exception));
            }
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("FiddlerDNS> DNS Lookup for \"{0}\":\r\n", sHostname);
            builder.AppendFormat("CNAME:\t{0}\n", hostEntry.HostName);
            builder.AppendFormat("Aliases:\t{0}\n", string.Join(";", hostEntry.Aliases));
            builder.AppendLine("Addresses:");
            foreach (IPAddress address in hostEntry.AddressList)
            {
                builder.AppendFormat("\t{0}\r\n", address.ToString());
            }
            return builder.ToString();
        }

        internal static string GetCanonicalName(string sHostname)
        {
            try
            {
                return Dns.GetHostEntry(sHostname).HostName;
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Failed to retrieve CNAME for \"{0}\", because '{1}'", new object[] { sHostname, Utilities.DescribeException(exception) });
                return string.Empty;
            }
        }

        public static IPAddress GetIPAddress(string sRemoteHost, bool bCheckCache)
        {
            return GetIPAddressList(sRemoteHost, bCheckCache, null)[0];
        }

        public static IPAddress[] GetIPAddressList(string sRemoteHost, bool bCheckCache, SessionTimers oTimers)
        {
            IPAddress[] arrResult = null;
            Stopwatch stopwatch = Stopwatch.StartNew();
            IPAddress address = Utilities.IPFromString(sRemoteHost);
            if (address != null)
            {
                arrResult = new IPAddress[] { address };
                if (oTimers != null)
                {
                    oTimers.DNSTime = (int) stopwatch.ElapsedMilliseconds;
                }
                return arrResult;
            }
            sRemoteHost = sRemoteHost.ToLower();
            if (bCheckCache)
            {
                Dictionary<string, DNSCacheEntry> dictionary;
                bool lockTaken = false;
                try
                {
                    DNSCacheEntry entry;
                    Monitor.Enter(dictionary = dictAddresses, ref lockTaken);
                    if (dictAddresses.TryGetValue(sRemoteHost, out entry))
                    {
                        if (entry.iLastLookup > (Utilities.GetTickCount() - MSEC_DNS_CACHE_LIFETIME))
                        {
                            arrResult = entry.arrAddressList;
                        }
                        else
                        {
                            dictAddresses.Remove(sRemoteHost);
                        }
                    }
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(dictAddresses);
                    }
                }
            }
            if (arrResult == null)
            {
                if ((sRemoteHost.OICEndsWith(".onion") || sRemoteHost.OICEndsWith(".i2p")) && !FiddlerApplication.Prefs.GetBoolPref("fiddler.network.dns.ResolveOnionHosts", false))
                {
                    throw new SecurityException("Hostnames ending in '.onion' and '.i2p' cannot be resolved by DNS. You must send such requests through a TOR or i2p gateway, e.g. oSession[\"X-OverrideGateway\"] = \"socks=127.0.0.1:9150\";");
                }
                try
                {
                    arrResult = Dns.GetHostAddresses(sRemoteHost);
                }
                catch
                {
                    if (oTimers != null)
                    {
                        oTimers.DNSTime = (int) stopwatch.ElapsedMilliseconds;
                    }
                    throw;
                }
                arrResult = trimAddressList(arrResult);
                if (arrResult.Length < 1)
                {
                    throw new Exception("No valid IPv4 addresses were found for this host.");
                }
                if (arrResult.Length > 0)
                {
                    Dictionary<string, DNSCacheEntry> dictionary2;
                    bool flag2 = false;
                    try
                    {
                        Monitor.Enter(dictionary2 = dictAddresses, ref flag2);
                        if (!dictAddresses.ContainsKey(sRemoteHost))
                        {
                            dictAddresses.Add(sRemoteHost, new DNSCacheEntry(arrResult));
                        }
                    }
                    finally
                    {
                        if (flag2)
                        {
                            Monitor.Exit(dictAddresses);
                        }
                    }
                }
            }
            if (oTimers != null)
            {
                oTimers.DNSTime = (int) stopwatch.ElapsedMilliseconds;
            }
            return arrResult;
        }

        public static string InspectCache()
        {
            Dictionary<string, DNSCacheEntry> dictionary;
            FiddlerApplication.oTelemetry.TrackEvent("Actions.InspectDNSCache");
            StringBuilder builder = new StringBuilder(0x2000);
            builder.AppendFormat("DNSResolver Cache\nfiddler.network.timeouts.dnscache: {0}ms\nContents\n--------\n", MSEC_DNS_CACHE_LIFETIME);
            bool lockTaken = false;
            try
            {
                Monitor.Enter(dictionary = dictAddresses, ref lockTaken);
                foreach (KeyValuePair<string, DNSCacheEntry> pair in dictAddresses)
                {
                    StringBuilder builder2 = new StringBuilder();
                    builder2.Append(" [");
                    foreach (IPAddress address in pair.Value.arrAddressList)
                    {
                        builder2.Append(address.ToString());
                        builder2.Append(", ");
                    }
                    builder2.Remove(builder2.Length - 2, 2);
                    builder2.Append("]");
                    builder.AppendFormat("\tHostName: {0}, Age: {1}ms, AddressList:{2}\n", pair.Key, Utilities.GetTickCount() - pair.Value.iLastLookup, builder2.ToString());
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(dictAddresses);
                }
            }
            builder.Append("--------\n");
            return builder.ToString();
        }

        internal static bool ResolveWentAsync(ServerChatter.MakeConnectionExecutionState _es, SessionTimers oTimers, AsyncCallback callbackAsync)
        {
            if (_es == null)
            {
                throw new ArgumentNullException("_es");
            }
            if (callbackAsync == null)
            {
                throw new ArgumentNullException("callbackAsync");
            }
            if (_es.sServerHostname == null)
            {
                throw new InvalidOperationException("_es.sServerHostname must not be null");
            }
            string sRemoteHost = _es.sServerHostname;
            IPAddress[] arrAddressList = null;
            Stopwatch oSW = Stopwatch.StartNew();
            IPAddress address = Utilities.IPFromString(sRemoteHost);
            if (address != null)
            {
                arrAddressList = new IPAddress[] { address };
                if (oTimers != null)
                {
                    oTimers.DNSTime = (int) oSW.ElapsedMilliseconds;
                }
                AssignIPEPList(_es, arrAddressList);
                return false;
            }
            sRemoteHost = sRemoteHost.ToLower();
            bool flag = false;
            try
            {
                DNSCacheEntry entry;
                Monitor.Enter( dictAddresses, ref flag);
                if (dictAddresses.TryGetValue(sRemoteHost, out entry))
                {
                    if (entry.iLastLookup > (Utilities.GetTickCount() - MSEC_DNS_CACHE_LIFETIME))
                    {
                        arrAddressList = entry.arrAddressList;
                    }
                    else
                    {
                        dictAddresses.Remove(sRemoteHost);
                    }
                }
            }
            finally
            {
                if (flag)
                {
                    Monitor.Exit(dictAddresses);
                }
            }
            if (arrAddressList != null)
            {
                if (oTimers != null)
                {
                    oTimers.DNSTime = (int) oSW.ElapsedMilliseconds;
                }
                AssignIPEPList(_es, arrAddressList);
                Interlocked.Increment(ref COUNTERS.DNSCACHE_HITS);
                return false;
            }
            if ((sRemoteHost.OICEndsWith(".onion") || sRemoteHost.OICEndsWith(".i2p")) && !FiddlerApplication.Prefs.GetBoolPref("fiddler.network.dns.ResolveOnionHosts", false))
            {
                throw new SecurityException("Hostnames ending in '.onion' and '.i2p' cannot be resolved by DNS. You must send such requests through a TOR or i2p gateway, e.g. oSession[\"X-OverrideGateway\"] = \"socks=127.0.0.1:9150\";");
            }
            Interlocked.Increment(ref COUNTERS.ASYNC_DNS);
            Interlocked.Increment(ref COUNTERS.TOTAL_ASYNC_DNS);
            Dns.BeginGetHostAddresses(sRemoteHost, delegate (IAsyncResult iar) {
                Interlocked.Decrement(ref COUNTERS.ASYNC_DNS);
                try
                {
                    SessionTimers asyncState = iar.AsyncState as SessionTimers;
                    if (asyncState != null)
                    {
                        asyncState.DNSTime = (int) oSW.ElapsedMilliseconds;
                        Interlocked.Add(ref COUNTERS.TOTAL_ASYNC_DNS_MS, oSW.ElapsedMilliseconds);
                    }
                    IPAddress[] arrIPs = trimAddressList(Dns.EndGetHostAddresses(iar));
                    if (arrIPs.Length < 1)
                    {
                        throw new Exception("No valid addresses were found for this hostname");
                    }
                    bool lockTaken = false;
                    try
                    {
                        Monitor.Enter(dictAddresses, ref lockTaken);
                        if (!dictAddresses.ContainsKey(sRemoteHost))
                        {
                            dictAddresses.Add(sRemoteHost, new DNSCacheEntry(arrIPs));
                        }
                    }
                    finally
                    {
                        if (lockTaken)
                        {
                            Monitor.Exit(dictAddresses);
                        }
                    }
                    AssignIPEPList(_es, arrIPs);
                }
                catch (Exception exception)
                {
                    _es.lastException = exception;
                }
                callbackAsync(iar);
            }, oTimers);
            return true;
        }

        public static void ScavengeCache()
        {
            if (dictAddresses.Count >= 1)
            {
                Dictionary<string, DNSCacheEntry> dictionary;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Scavenging DNS Cache...");
                }
                List<string> list = new List<string>();
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(dictionary = dictAddresses, ref lockTaken);
                    foreach (KeyValuePair<string, DNSCacheEntry> pair in dictAddresses)
                    {
                        if (pair.Value.iLastLookup < (Utilities.GetTickCount() - MSEC_DNS_CACHE_LIFETIME))
                        {
                            list.Add(pair.Key);
                        }
                    }
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("Expiring " + list.Count.ToString() + " of " + dictAddresses.Count.ToString() + " DNS Records.");
                    }
                    foreach (string str in list)
                    {
                        dictAddresses.Remove(str);
                    }
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(dictAddresses);
                    }
                }
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Done scavenging DNS Cache...");
                }
            }
        }

        private static IPAddress[] trimAddressList(IPAddress[] arrResult)
        {
            List<IPAddress> list = new List<IPAddress>();
            for (int i = 0; i < arrResult.Length; i++)
            {
                if (!list.Contains(arrResult[i]) && (CONFIG.bEnableIPv6 || (arrResult[i].AddressFamily == AddressFamily.InterNetwork)))
                {
                    list.Add(arrResult[i]);
                    if (COUNT_MAX_A_RECORDS == list.Count)
                    {
                        break;
                    }
                }
            }
            return list.ToArray();
        }

        private class DNSCacheEntry
        {
            internal IPAddress[] arrAddressList;
            internal long iLastLookup = Utilities.GetTickCount();

            internal DNSCacheEntry(IPAddress[] arrIPs)
            {
                this.arrAddressList = arrIPs;
            }
        }
    }
}

