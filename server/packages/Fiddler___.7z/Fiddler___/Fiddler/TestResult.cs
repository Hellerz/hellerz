﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public class TestResult
    {

        internal TestResult(Session sessionOriginal, Session sessionRerun, bool passed)
        {
            this.sessOriginal = sessionOriginal;
            this.sessRerun = sessionRerun;
            this.IsPassing = passed;
        }

        public override string ToString()
        {
            return ((this.IsPassing ? "PASS - " : "FAIL - ") + this.sessOriginal.RequestMethod + " " + this.sessOriginal.fullUrl);
        }

        public bool IsPassing
        {
            
            get
            {
                return this.IsPassing;
            }
            internal 
            set
            {
                this.IsPassing = value;
            }
        }

        public Session sessOriginal
        {
            
            get
            {
                return this.sessOriginal;
            }
            internal 
            set
            {
                this.sessOriginal = value;
            }
        }

        public Session sessRerun
        {
            
            get
            {
                return this.sessRerun;
            }
            internal 
            set
            {
                this.sessRerun = value;
            }
        }
    }
}

