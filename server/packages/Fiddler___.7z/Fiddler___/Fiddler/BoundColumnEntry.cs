﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    internal class BoundColumnEntry
    {
        internal bool _bIsNumeric;
        internal getColumnStringDelegate _delFn;
        internal int _iColNum;
        internal string _sSessionFlagName;

        internal BoundColumnEntry(getColumnStringDelegate delFn, int iColNum, bool bIsNumeric)
        {
            this._bIsNumeric = bIsNumeric;
            this._delFn = delFn;
            this._iColNum = iColNum;
        }

        internal BoundColumnEntry(string sSessionFlagName, int iColNum, bool bIsNumeric)
        {
            this._bIsNumeric = bIsNumeric;
            this._sSessionFlagName = sSessionFlagName;
            this._iColNum = iColNum;
        }

        internal ColumnDataSource DataSource
        {
            [CompilerGenerated]
            get
            {
                return this.DataSource;
            }
            [CompilerGenerated]
            set
            {
                this.DataSource = value;
            }
        }
    }
}

