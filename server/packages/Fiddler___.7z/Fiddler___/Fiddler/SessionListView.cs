﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Runtime.InteropServices;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;

    public class SessionListView : ListView
    {
        private bool _bLastAltLeftClickedItemWasAlreadySelected;
        internal string[] _emptyBoundColumns = new string[0];
        private string _emptyText;
        private Point _ptContextHeaderPopup;
        private int _uiAsyncUpdateInterval;
        private static Dictionary<string, BoundColumnEntry> dictBoundColumns = new Dictionary<string, BoundColumnEntry>();
        public EventHandler ItemShowProperties;
        public SimpleEventHandler OnSessionsAdded;
        private List<ListViewItem> qLVIsToAdd;
        private System.Windows.Forms.Timer timer_LVIAddQueue;
        private WeakReference wrCurrentItem;
        private WeakReference wrPriorItem;

        [Description("Fired when the user hits ALT+Enter with a single item selected")]
        

        public SessionListView()
        {
            if (!base.DesignMode)
            {
                this.DoubleBuffered = true;
                base.FontChanged += new EventHandler(this.SessionListView_FontChanged);
                base.MouseClick += new MouseEventHandler(this.SessionListView_MouseClick);
            }
            this.EmptyText = "No Sessions captured\n(or all were hidden by filters)";
            base.ListViewItemSorter = new ListViewItemComparer(this);
            base.ColumnClick += new ColumnClickEventHandler(this.OnColumnClick);
            base.MouseDown += new MouseEventHandler(this.SessionListView_MouseDown);
        }

        private void _DoSearchColumns(int iCol, bool bNumeric, string sWhatFor)
        {
            if (bNumeric)
            {
                SearchNumericColumn(iCol, sWhatFor);
            }
            else
            {
                SearchTextColumn(iCol, sWhatFor);
            }
            if (this.SelectedCount > 0)
            {
                if (base.SelectedIndices.Count > 0)
                {
                    base.EnsureVisible(base.SelectedIndices[0]);
                }
                base.Focus();
            }
            else
            {
                FiddlerApplication.UI.sbpInfo.Text = "No Web Sessions matched your query.";
            }
        }

        private void _EnsureHeaderContextMenu()
        {
            EventHandler handler = null;
            EventHandler handler2 = null;
            if (this.ContextMenuStrip == null)
            {
                this.ContextMenuStrip = new ContextMenuStrip();
                this.ContextMenuStrip.ShowImageMargin = false;
                ToolStripLabel label = new ToolStripLabel("-");
                label.Font = new Font(label.Font, FontStyle.Bold);
                label.Enabled = false;
                this.ContextMenuStrip.Items.Add(label);
                this.ContextMenuStrip.Items.Add("&Search this column...").Click += new EventHandler(this.HeaderSearchClick);
                this.ContextMenuStrip.Items.Add("&Flag duplicates").Click += new EventHandler(this.HeaderFlagDupesClick);
                this.ContextMenuStrip.Items.Add("&Hide this column").Click += new EventHandler(this.HideThisColumn);
                this.ContextMenuStrip.Items.Add("-");
                if (handler == null)
                {
                    handler = delegate (object s, EventArgs ea) {
                        try
                        {
                            foreach (ColumnHeader header in base.Columns)
                            {
                                if (header.Width < 40)
                                {
                                    header.Width = 40;
                                }
                            }
                        }
                        catch (Exception)
                        {
                        }
                    };
                }
                this.ContextMenuStrip.Items.Add("Ensure all columns are &visible").Click += handler;
                if (handler2 == null)
                {
                    handler2 = delegate (object s, EventArgs ea) {
                        using (UICustomizeColumns columns = new UICustomizeColumns())
                        {
                            columns.Location = base.PointToScreen(new Point(30, FiddlerApplication.UI.lvSessions.Top + 30));
                            columns.ShowDialog(FiddlerApplication.UI);
                        }
                    };
                }
                this.ContextMenuStrip.Items.Add("&Customize columns...").Click += handler2;
            }
        }

        private int _GetHoveredColHeaderIndex()
        {
            IntPtr hWnd = LVNative.SendLVMessage(base.Handle, 0x101f, IntPtr.Zero, IntPtr.Zero);
            if (hWnd == IntPtr.Zero)
            {
                return -1;
            }
            LVNative.HDHITTESTINFO lParam = new LVNative.HDHITTESTINFO();
            lParam.pt = base.PointToClient(this._ptContextHeaderPopup);
            lParam.pt.Offset(this.GetHorizontalScrollOffset(), 0);
            LVNative.SendHeaderHitTestMessage(hWnd, 0x1206, IntPtr.Zero, ref lParam);
            return lParam.iItem;
        }

        internal void ActivatePreviousItem()
        {
            if (this.wrPriorItem != null)
            {
                ListViewItem target = this.wrPriorItem.Target as ListViewItem;
                if (target != null)
                {
                    base.SelectedItems.Clear();
                    target.Selected = true;
                    target.Focused = true;
                }
            }
        }

        internal bool AddBoundColumn(BindUIColumn oBUIC, getColumnStringDelegate oDel)
        {
            return this.AssignColumn(oBUIC._colName, oBUIC._iDisplayOrder, oBUIC._iColWidth, null, oBUIC._bSortColumnNumerically, ColumnDataSource.BoundToScript, oDel);
        }

        public bool AddBoundColumn(string sColumnTitle, int iWidth, getColumnStringDelegate delFn)
        {
            return this.AssignColumn(sColumnTitle, -1, iWidth, null, false, ColumnDataSource.Unknown, delFn);
        }

        [CodeDescription("Add a bound column with the specified title & width, displaying the specified FlagName")]
        public bool AddBoundColumn(string sColumnTitle, int iWidth, string sSessionFlagName)
        {
            return this.AddBoundColumn(sColumnTitle, -1, iWidth, sSessionFlagName, ColumnDataSource.Unknown);
        }

        [CodeDescription("Add a bound column with the specified title, relative order, and width, with value bound to the result of the specified getColumnStringDelegate function.")]
        public bool AddBoundColumn(string sColumnTitle, int iRelativeOrder, int iWidth, getColumnStringDelegate delFn)
        {
            return this.AssignColumn(sColumnTitle, iRelativeOrder, iWidth, null, false, ColumnDataSource.Unknown, delFn);
        }

        [CodeDescription("Add a bound column with the specified title, relative order, and width, displaying the specified FlagName")]
        public bool AddBoundColumn(string sColumnTitle, int iRelativeOrder, int iWidth, string sSessionFlagName)
        {
            return this.AddBoundColumn(sColumnTitle, iRelativeOrder, iWidth, sSessionFlagName, ColumnDataSource.Unknown);
        }

        [CodeDescription("Add a bound column with the specified title, relative order, and width, with value bound to the result of the specified getColumnStringDelegate function.")]
        public bool AddBoundColumn(string sColumnTitle, int iRelativeOrder, int iWidth, bool bSortColumnNumerically, getColumnStringDelegate delFn)
        {
            return this.AssignColumn(sColumnTitle, iRelativeOrder, iWidth, null, bSortColumnNumerically, ColumnDataSource.Unknown, delFn);
        }

        internal bool AddBoundColumn(string sColumnTitle, int iRelativeOrder, int iWidth, string sSessionFlagName, ColumnDataSource oCDS)
        {
            getColumnStringDelegate delFn = null;
            getColumnStringDelegate delegate3 = null;
            if (string.IsNullOrEmpty(sSessionFlagName))
            {
                return false;
            }
            if (sSessionFlagName.IndexOf(' ') > -1)
            {
                FiddlerApplication.Log.LogFormat("!Warning: Attempted to AddBoundColumn with '{0}' as the source. This value appears invalid.", new object[] { sSessionFlagName });
            }
            bool bSortColumnNumerically = sColumnTitle.StartsWith("#") || sColumnTitle.EndsWith("#");
            if (sSessionFlagName.OICStartsWith("@request."))
            {
                if (delFn == null)
                {
                    delFn = delegate (Session oSession) {
                        if ((oSession != null) && Utilities.HasHeaders(oSession.oRequest))
                        {
                            return oSession.oRequest.headers.AllValues(sSessionFlagName.Substring(9));
                        }
                        return string.Empty;
                    };
                }
                return this.AssignColumn(sColumnTitle, iRelativeOrder, iWidth, null, bSortColumnNumerically, oCDS, delFn);
            }
            if (!sSessionFlagName.OICStartsWith("@response."))
            {
                return this.AssignColumn(sColumnTitle, iRelativeOrder, iWidth, sSessionFlagName, bSortColumnNumerically, oCDS, null);
            }
            if (delegate3 == null)
            {
                delegate3 = delegate (Session oSession) {
                    if ((oSession != null) && Utilities.HasHeaders(oSession.oResponse))
                    {
                        return oSession.oResponse.headers.AllValues(sSessionFlagName.Substring(10));
                    }
                    return string.Empty;
                };
            }
            return this.AssignColumn(sColumnTitle, iRelativeOrder, iWidth, null, bSortColumnNumerically, oCDS, delegate3);
        }

        internal bool AddBoundColumn(string sColumnTitle, int iRelativeOrder, int iWidth, bool bSortColumnNumerically, ColumnDataSource oCDS, getColumnStringDelegate delFn)
        {
            return this.AssignColumn(sColumnTitle, iRelativeOrder, iWidth, null, bSortColumnNumerically, oCDS, delFn);
        }

        private bool AssignColumn(string sColumnTitle, int iRelativeDisplayOrder, int iWidth, string sSessionFlagName, bool bSortColumnNumerically, ColumnDataSource oCDS, getColumnStringDelegate delFn)
        {
            BoundColumnEntry entry;
            if (string.IsNullOrEmpty(sColumnTitle))
            {
                return false;
            }
            if ((delFn == null) && string.IsNullOrEmpty(sSessionFlagName))
            {
                return false;
            }
            ColumnHeader header = null;
            if (sColumnTitle.IndexOfAny(new char[] { '~', '\x00a7' }) > -1)
            {
                sColumnTitle = sColumnTitle.Replace('~', '-').Replace('\x00a7', '$');
            }
            if (dictBoundColumns.ContainsKey(sColumnTitle))
            {
                entry = dictBoundColumns[sColumnTitle];
                entry._delFn = delFn;
                entry._sSessionFlagName = sSessionFlagName;
                if (iWidth > -1)
                {
                    header = this.FindColumnByTitle(sColumnTitle);
                    if (header != null)
                    {
                        header.Width = iWidth;
                    }
                }
                if (iRelativeDisplayOrder > -1)
                {
                    if (header == null)
                    {
                        header = this.FindColumnByTitle(sColumnTitle);
                    }
                    if (header != null)
                    {
                        header.DisplayIndex = iRelativeDisplayOrder;
                    }
                }
                entry.DataSource = oCDS;
                return true;
            }
            header = base.Columns.Add(sColumnTitle, iWidth);
            if (bSortColumnNumerically)
            {
                header.TextAlign = HorizontalAlignment.Right;
            }
            if ((header != null) && (iRelativeDisplayOrder > -1))
            {
                header.DisplayIndex = iRelativeDisplayOrder;
            }
            int index = header.Index;
            if (delFn != null)
            {
                entry = new BoundColumnEntry(delFn, index, bSortColumnNumerically);
            }
            else
            {
                entry = new BoundColumnEntry(sSessionFlagName, index, bSortColumnNumerically);
            }
            entry.DataSource = oCDS;
            dictBoundColumns.Add(sColumnTitle, entry);
            this._emptyBoundColumns = new string[dictBoundColumns.Count];
            for (int i = 0; i < this._emptyBoundColumns.Length; i++)
            {
                this._emptyBoundColumns[i] = string.Empty;
            }
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            try
            {
                if ((disposing && !base.DesignMode) && (this.timer_LVIAddQueue != null))
                {
                    this.timer_LVIAddQueue.Tick -= new EventHandler(this.timerLVIAddQueue_Tick);
                    this.timer_LVIAddQueue.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        private void DoSessionsAdded(bool bWasAtBottom)
        {
            if (CONFIG.bAutoScroll && (!CONFIG.bSmartScroll || bWasAtBottom))
            {
                int index = base.Items.Count - 1;
                if (index > -1)
                {
                    base.EnsureVisible(index);
                }
            }
            if (this.OnSessionsAdded != null)
            {
                this.OnSessionsAdded();
            }
        }

        public void EnsureColumnIsVisible(string sTitle)
        {
            foreach (ColumnHeader header in base.Columns)
            {
                if (header.Text.OICEquals(sTitle) && (header.Width < 80))
                {
                    header.Width = 80;
                }
            }
        }

        public void EnsureItemIsVisible(ListViewItem oLVI)
        {
            if (oLVI.Index > -1)
            {
                oLVI.EnsureVisible();
            }
        }

        internal static void FillBoundColumns(Session oSession, ListViewItem oLVI)
        {
            foreach (BoundColumnEntry entry in dictBoundColumns.Values)
            {
                while (oLVI.SubItems.Count <= entry._iColNum)
                {
                    oLVI.SubItems.Add(string.Empty);
                }
                if (entry._sSessionFlagName != null)
                {
                    oLVI.SubItems[entry._iColNum].Text = oSession[entry._sSessionFlagName];
                }
                else
                {
                    try
                    {
                        string str = entry._delFn(oSession);
                        if (str != null)
                        {
                            oLVI.SubItems[entry._iColNum].Text = str;
                        }
                        continue;
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.Log.LogFormat("Exception thrown when filling Bound Column:\n{0}", new object[] { exception });
                        continue;
                    }
                }
            }
        }

        internal ColumnHeader FindColumnByTitle(string sColumnTitle)
        {
            for (int i = 0; i < base.Columns.Count; i++)
            {
                if (sColumnTitle.OICEquals(base.Columns[i].Text))
                {
                    return base.Columns[i];
                }
            }
            return null;
        }

        internal void FlushUpdates()
        {
            if ((this.qLVIsToAdd != null) && (this.qLVIsToAdd.Count > 0))
            {
                this.timerLVIAddQueue_Tick(null, null);
            }
        }

        private int GetHorizontalScrollOffset()
        {
            LVNative.SCROLLINFO structure = new LVNative.SCROLLINFO();
            structure.cbSize = (int) Marshal.SizeOf(structure);
            structure.fMask = 4;
            if (LVNative.GetScrollInfo(base.Handle, 0, ref structure))
            {
                return structure.nPos;
            }
            return 0;
        }

        public int GetSubItemIndexFromPoint(Point ptClient)
        {
            LVNative.LVHITTESTINFO lParam = new LVNative.LVHITTESTINFO();
            lParam.pt_x = ptClient.X;
            lParam.pt_y = ptClient.Y;
            if (-1 < ((int) LVNative.SendHitTestMessage(new HandleRef(this, base.Handle), 0x1039, IntPtr.Zero, lParam)))
            {
                return lParam.iSubItem;
            }
            return -1;
        }

        private void HeaderFlagDupesClick(object sender, EventArgs eA)
        {
            try
            {
                if (this.TotalItemCount() >= 2)
                {
                    int num = this._GetHoveredColHeaderIndex();
                    if (num < 0)
                    {
                        MessageBox.Show("Please right-click on a column header to search that column", "No Column Hovered");
                    }
                    else
                    {
                        Dictionary<string, ListViewItem> dictionary = new Dictionary<string, ListViewItem>();
                        Color color = Utilities.ParseColor(FiddlerApplication.Prefs.GetStringPref("fiddler.ui.Colors.ColumnDuplicate", "GreenYellow"));
                        foreach (ListViewItem item in base.Items)
                        {
                            if (item.SubItems.Count > num)
                            {
                                ListViewItem item2;
                                string text = item.SubItems[num].Text;
                                if (dictionary.TryGetValue(text, out item2))
                                {
                                    item.BackColor = color;
                                    item2.BackColor = color;
                                }
                                else
                                {
                                    dictionary.Add(text, item);
                                    if (item.BackColor == color)
                                    {
                                        item.BackColor = this.BackColor;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void HeaderSearchClick(object sender, EventArgs eA)
        {
            if (this.TotalItemCount() < 1)
            {
                MessageBox.Show("No WebSessions to search", "Failed");
            }
            else
            {
                int iCol = this._GetHoveredColHeaderIndex();
                if (iCol < 0)
                {
                    MessageBox.Show("Please right-click on a column header to search that column", "No Column Hovered");
                }
                else
                {
                    bool bNumeric = isColumnNumeric(iCol);
                    string sPrompt = bNumeric ? "Specify an exact number, an inequality (>4k), or a range (0-42k):" : "Specify either a partial string, or use an EXACT: or REGEX: prefix:";
                    string sWhatFor = frmPrompt.GetUserString("Search " + base.Columns[iCol].Text, sPrompt, string.Empty, true, bNumeric ? frmPrompt.PromptIcon.Numbers : frmPrompt.PromptIcon.Default);
                    if (sWhatFor != null)
                    {
                        this._DoSearchColumns(iCol, bNumeric, sWhatFor);
                    }
                }
            }
        }

        private void HideThisColumn(object sender, EventArgs eA)
        {
            int num = this._GetHoveredColHeaderIndex();
            if (num < 0)
            {
                MessageBox.Show("Please right-click on a column header to hide that column", "No Column Hovered");
            }
            else
            {
                BoundColumnEntry entry;
                base.Columns[num].Width = 0;
                string text = base.Columns[num].Text;
                if (dictBoundColumns.TryGetValue(text, out entry))
                {
                    switch (entry.DataSource)
                    {
                        case ColumnDataSource.BoundByWizard:
                            if (!CONFIG.bIsViewOnly)
                            {
                                if (DialogResult.Yes == MessageBox.Show(string.Format("The '{0}' column has been hidden.\n\nWould you like to remove this column entirely next time Fiddler starts?", text), "Delete Column?", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                                {
                                    UICustomizeColumns.DeleteColumn(text);
                                }
                                return;
                            }
                            return;

                        case ColumnDataSource.BoundToScript:
                            MessageBox.Show(string.Format("The '{0}' column has been hidden.\n\nTo delete it entirely, edit your FiddlerScript by clicking Rules > Customize Rules.", text), "Column Hidden");
                            return;
                    }
                }
            }
        }

        internal static bool isColumnNumeric(int iCol)
        {
            if (iCol <= 10)
            {
                if (((iCol == 0) || (iCol == 1)) || (iCol == 5))
                {
                    return true;
                }
            }
            else
            {
                foreach (BoundColumnEntry entry in dictBoundColumns.Values)
                {
                    if (entry._iColNum == iCol)
                    {
                        return entry._bIsNumeric;
                    }
                }
            }
            return false;
        }

        public bool IsScrolledToBottom()
        {
            LVNative.SCROLLINFO structure = new LVNative.SCROLLINFO();
            structure.cbSize = (int) Marshal.SizeOf(structure);
            structure.fMask = 7;
            if (LVNative.GetScrollInfo(base.Handle, 1, ref structure))
            {
                return (structure.nPos >= ((structure.nMax - structure.nPage) - ((long) 6L)));
            }
            return true;
        }

        private void OnColumnClick(object sender, ColumnClickEventArgs e)
        {
            ListViewItemComparer listViewItemSorter = (ListViewItemComparer) base.ListViewItemSorter;
            listViewItemSorter.Column = e.Column;
            switch (e.Column)
            {
                case 0:
                case 5:
                    listViewItemSorter.CompareAs = ListViewItemComparer.CompareType.asInt;
                    break;

                case 1:
                    listViewItemSorter.CompareAs = ListViewItemComparer.CompareType.asString;
                    break;

                default:
                    listViewItemSorter.CompareAs = isColumnNumeric(e.Column) ? ListViewItemComparer.CompareType.asDouble : ListViewItemComparer.CompareType.asString;
                    break;
            }
            base.BeginUpdate();
            base.Sort();
            if (base.SelectedIndices.Count > 0)
            {
                base.EnsureVisible(base.SelectedIndices[0]);
            }
            base.EndUpdate();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            LVNative.DontSelectBorderImage(this);
            if ((!base.DesignMode && (Environment.OSVersion.Version.Major > 5)) && FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ExplorerStyle", false))
            {
                SetWindowTheme(base.Handle, "Explorer", null);
            }
        }

        protected virtual void OnItemShowProperties(EventArgs e)
        {
            EventHandler itemShowProperties = this.ItemShowProperties;
            if (itemShowProperties != null)
            {
                itemShowProperties(this, e);
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if ((keyData != (Keys.Alt | Keys.Return)) || ((this.SelectedCount != 1) && (this.SelectedCount != 2)))
            {
                return base.ProcessCmdKey(ref msg, keyData);
            }
            this.OnItemShowProperties(EventArgs.Empty);
            return true;
        }

        internal void QueueItem(ListViewItem lvi)
        {
            if (this._uiAsyncUpdateInterval > 0)
            {
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(this.qLVIsToAdd, ref lockTaken);
                    this.qLVIsToAdd.Add(lvi);
                    this.timer_LVIAddQueue.Enabled = true;
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(qLVIsToAdd);
                    }
                }
            }
            else
            {
                bool bWasAtBottom = false;
                if (CONFIG.bAutoScroll && CONFIG.bSmartScroll)
                {
                    bWasAtBottom = this.IsScrolledToBottom();
                }
                base.Items.Add(lvi);
                this.DoSessionsAdded(bWasAtBottom);
            }
        }

        internal void RemoveOrDequeue(ListViewItem lvi)
        {
            if (lvi.Index > -1)
            {
                lvi.Remove();
            }
            else
            {
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(this.qLVIsToAdd, ref lockTaken);
                    this.qLVIsToAdd.Remove(lvi);
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(qLVIsToAdd);
                    }
                }
            }
        }

        internal void RemoveRange(List<int> listLVIs)
        {
            if (listLVIs.Count >= 1)
            {
                for (int i = listLVIs.Count - 1; i >= 0; i--)
                {
                    base.Items.RemoveAt(listLVIs[i]);
                }
            }
        }

        internal void RemoveSelected()
        {
            int selectedCount = this.SelectedCount;
            if (selectedCount >= 1)
            {
                if ((base.Items.Count > 0x3e8) && (selectedCount > 10))
                {
                    int[] numArray = new int[selectedCount];
                    int index = 0;
                    foreach (int num3 in base.SelectedIndices)
                    {
                        numArray[index++] = num3;
                    }
                    for (index = numArray.Length - 1; index >= 0; index--)
                    {
                        base.Items.RemoveAt(numArray[index]);
                    }
                }
                else
                {
                    foreach (ListViewItem item in base.SelectedItems)
                    {
                        item.Remove();
                    }
                }
            }
        }

        internal void RemoveUnselected()
        {
            int num = base.Items.Count - this.SelectedCount;
            if (num >= 1)
            {
                for (int i = base.Items.Count - 1; (num > 0) && (i >= 0); i--)
                {
                    if (!base.Items[i].Selected)
                    {
                        base.Items.RemoveAt(i);
                        num--;
                    }
                }
            }
        }

        internal void SearchColumn(string sColumnName, string sFind)
        {
            int iCol = -1;
            foreach (ColumnHeader header in base.Columns)
            {
                if (sColumnName.OICEquals(header.Text))
                {
                    iCol = header.Index;
                    break;
                }
            }
            if (iCol < 0)
            {
                FiddlerApplication.UI.SetStatusText(string.Format("Column '{0}' was not found.", sColumnName));
            }
            else
            {
                bool bNumeric = isColumnNumeric(iCol);
                this._DoSearchColumns(iCol, bNumeric, sFind);
            }
        }

        private static void SearchNumericColumn(int iCol, string sWhatFor)
        {
            doesSessionMatchCriteriaDelegate oDel = null;
            sWhatFor = sWhatFor.Trim().ToLower().Replace("k", "000");
            if (sWhatFor.StartsWith(">"))
            {
                doesSessionMatchCriteriaDelegate delegate2 = null;
                double flMinValue;
                if (double.TryParse(sWhatFor.Substring(1), out flMinValue))
                {
                    if (delegate2 == null)
                    {
                        delegate2 = delegate (Session oS) {
                            double num;
                            return (((oS.ViewItem != null) && (oS.ViewItem.SubItems.Count > iCol)) && double.TryParse(oS.ViewItem.SubItems[iCol].Text, out num)) && (num > flMinValue);
                        };
                    }
                    FiddlerApplication.UI.actSelectSessionsMatchingCriteria(delegate2);
                }
            }
            else if (sWhatFor.StartsWith("<"))
            {
                doesSessionMatchCriteriaDelegate delegate3 = null;
                double flMaxValue;
                if (double.TryParse(sWhatFor.Substring(1), out flMaxValue))
                {
                    if (delegate3 == null)
                    {
                        delegate3 = delegate (Session oS) {
                            double num;
                            return (((oS.ViewItem != null) && (oS.ViewItem.SubItems.Count > iCol)) && double.TryParse(oS.ViewItem.SubItems[iCol].Text, out num)) && (num < flMaxValue);
                        };
                    }
                    FiddlerApplication.UI.actSelectSessionsMatchingCriteria(delegate3);
                }
            }
            else if (sWhatFor.LastIndexOf('-') > 0)
            {
                doesSessionMatchCriteriaDelegate delegate4 = null;
                double flLowValue;
                double flHighValue;
                int length = sWhatFor.LastIndexOf('-');
                if (sWhatFor[length - 1] == '-')
                {
                    length--;
                }
                string s = sWhatFor.Substring(0, length);
                string str4 = sWhatFor.Substring(length + 1);
                if (double.TryParse(s, out flLowValue) && double.TryParse(str4, out flHighValue))
                {
                    if (flLowValue > flHighValue)
                    {
                        double num2 = flHighValue;
                        flHighValue = flLowValue;
                        flLowValue = num2;
                    }
                    if (delegate4 == null)
                    {
                        delegate4 = delegate (Session oS) {
                            double num;
                            if (((oS.ViewItem == null) || (oS.ViewItem.SubItems.Count <= iCol)) || !double.TryParse(oS.ViewItem.SubItems[iCol].Text, out num))
                            {
                                return false;
                            }
                            return (num >= flLowValue) && (num <= flHighValue);
                        };
                    }
                    FiddlerApplication.UI.actSelectSessionsMatchingCriteria(delegate4);
                }
            }
            else
            {
                double flValue;
                if (double.TryParse(sWhatFor, out flValue))
                {
                    if (oDel == null)
                    {
                        oDel = delegate (Session oS) {
                            double num;
                            return (((oS.ViewItem != null) && (oS.ViewItem.SubItems.Count > iCol)) && double.TryParse(oS.ViewItem.SubItems[iCol].Text, out num)) && (num == flValue);
                        };
                    }
                    FiddlerApplication.UI.actSelectSessionsMatchingCriteria(oDel);
                }
            }
        }

        private static void SearchTextColumn(int iCol, string sWhatFor)
        {
            bool bExact = false;
            Regex reSearchFor = null;
            if (sWhatFor.OICStartsWith("EXACT:"))
            {
                bExact = true;
                sWhatFor = sWhatFor.Substring(6);
            }
            else if (sWhatFor.OICStartsWith("REGEX:"))
            {
                RegexOptions options = RegexOptions.Singleline | RegexOptions.ExplicitCapture;
                try
                {
                    reSearchFor = new Regex(sWhatFor.Substring(6), options);
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception, "Invalid Regular Expression", "Sorry, the provided regular expression could not be parsed.");
                    return;
                }
            }
            FiddlerApplication.UI.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                if ((oS.ViewItem == null) || (oS.ViewItem.SubItems.Count <= iCol))
                {
                    return false;
                }
                if (reSearchFor != null)
                {
                    return reSearchFor.IsMatch(oS.ViewItem.SubItems[iCol].Text);
                }
                if (bExact)
                {
                    return sWhatFor.Equals(oS.ViewItem.SubItems[iCol].Text);
                }
                return oS.ViewItem.SubItems[iCol].Text.OICContains(sWhatFor);
            });
        }

        private void SessionListView_FontChanged(object sender, EventArgs e)
        {
            if (this.TotalItemCount() >= 1)
            {
                foreach (ListViewItem item in base.Items)
                {
                    if (item.Font.Size != this.Font.Size)
                    {
                        item.Font = new Font(item.Font.FontFamily, this.Font.Size, item.Font.Style);
                    }
                }
            }
        }

        private void SessionListView_MouseClick(object sender, MouseEventArgs e)
        {
            if ((MouseButtons.Left == e.Button) && (Keys.Alt == (Control.ModifierKeys & Keys.Alt)))
            {
                ListViewItem itemAt = base.GetItemAt(e.Location.X, e.Location.Y);
                int iX = this.GetSubItemIndexFromPoint(e.Location);
                if ((iX >= 0) && (itemAt.SubItems.Count >= iX))
                {
                    doesSessionMatchCriteriaDelegate oDel = null;
                    doesSessionMatchCriteriaDelegate delegate3 = null;
                    string sSearchVal = itemAt.SubItems[iX].Text;
                    int iImageIndex = (iX == 0) ? itemAt.ImageIndex : -1;
                    bool bReplaceSelection = Keys.Control != (Control.ModifierKeys & Keys.Control);
                    if (this._bLastAltLeftClickedItemWasAlreadySelected && !bReplaceSelection)
                    {
                        if (oDel == null)
                        {
                            oDel = delegate (Session oS) {
                                ListViewItem viewItem = oS.ViewItem;
                                if (viewItem == null)
                                {
                                    return false;
                                }
                                if (!viewItem.Selected)
                                {
                                    return false;
                                }
                                if (iImageIndex >= 0)
                                {
                                    return viewItem.ImageIndex != iImageIndex;
                                }
                                return !string.Equals(viewItem.SubItems[iX].Text, sSearchVal);
                            };
                        }
                        FiddlerApplication.UI.actSelectSessionsMatchingCriteria(false, 0, oDel);
                    }
                    else
                    {
                        if (delegate3 == null)
                        {
                            delegate3 = delegate (Session oS) {
                                ListViewItem viewItem = oS.ViewItem;
                                if (viewItem == null)
                                {
                                    return false;
                                }
                                if (!bReplaceSelection & viewItem.Selected)
                                {
                                    return true;
                                }
                                if (viewItem.SubItems.Count <= iX)
                                {
                                    return false;
                                }
                                if (iImageIndex >= 0)
                                {
                                    return viewItem.ImageIndex == iImageIndex;
                                }
                                return string.Equals(viewItem.SubItems[iX].Text, sSearchVal);
                            };
                        }
                        FiddlerApplication.UI.actSelectSessionsMatchingCriteria(bReplaceSelection, 0, delegate3);
                    }
                }
            }
        }

        private void SessionListView_MouseDown(object sender, MouseEventArgs e)
        {
            MouseButtons button = e.Button;
            if (button != MouseButtons.Left)
            {
                if (button != MouseButtons.XButton1)
                {
                    if (button != MouseButtons.XButton2)
                    {
                        return;
                    }
                }
                else
                {
                    this.ActivatePreviousItem();
                    return;
                }
                FiddlerApplication.UI.actDoSelectNextFindResult(true);
            }
            else
            {
                this._bLastAltLeftClickedItemWasAlreadySelected = false;
                if ((Control.ModifierKeys & Keys.Alt) == Keys.Alt)
                {
                    ListViewItem itemAt = base.GetItemAt(e.Location.X, e.Location.Y);
                    this._bLastAltLeftClickedItemWasAlreadySelected = (itemAt != null) && itemAt.Selected;
                }
            }
        }

        [CodeDescription("Set the named column's order and width. To set only one, pass -1 for the other parameter.")]
        public bool SetColumnOrderAndWidth(string sColumnTitle, int iOrder, int iWidth)
        {
            ColumnHeader header = this.FindColumnByTitle(sColumnTitle);
            if (header == null)
            {
                return false;
            }
            if (iOrder > -1)
            {
                header.DisplayIndex = iOrder;
            }
            if (iWidth > -1)
            {
                header.Width = iWidth;
            }
            this.Refresh();
            return true;
        }

        [DllImport("uxtheme.dll", CharSet=CharSet.Unicode, ExactSpelling=true)]
        public static extern int SetWindowTheme(IntPtr hWnd, string pszSubAppName, string pszSubIdList);
        internal void StoreActiveItem()
        {
            this.wrPriorItem = this.wrCurrentItem;
            if (base.SelectedItems.Count == 1)
            {
                this.wrCurrentItem = new WeakReference(base.SelectedItems[0]);
            }
        }

        private void timerLVIAddQueue_Tick(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing)
            {
                ListViewItem[] itemArray;
                bool bWasAtBottom = false;
                if (CONFIG.bAutoScroll && CONFIG.bSmartScroll)
                {
                    bWasAtBottom = this.IsScrolledToBottom();
                }
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(this.qLVIsToAdd, ref lockTaken);
                    itemArray = this.qLVIsToAdd.ToArray();
                    this.qLVIsToAdd.Clear();
                    this.timer_LVIAddQueue.Enabled = false;
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(qLVIsToAdd);
                    }
                }
                if (itemArray.Length > 0)
                {
                    int iTrimTo = FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.rules.keeponly", 0);
                    if (iTrimTo > 0)
                    {
                        FiddlerApplication.UI._internalTrimSessionList(iTrimTo, false);
                    }
                    base.Items.AddRange(itemArray);
                    itemArray = null;
                    this.DoSessionsAdded(bWasAtBottom);
                }
            }
        }

        public int TotalItemCount()
        {
            int count = base.Items.Count;
            if (this.qLVIsToAdd != null)
            {
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(this.qLVIsToAdd, ref lockTaken);
                    count += this.qLVIsToAdd.Count;
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(qLVIsToAdd);
                    }
                }
            }
            return count;
        }

        internal void UnstoreActiveItem()
        {
            this.wrCurrentItem = this.wrPriorItem;
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x7b:
                {
                    this._ptContextHeaderPopup = Cursor.Position;
                    Utilities.RECT lpRect = new Utilities.RECT();
                    IntPtr hWnd = LVNative.SendLVMessage(base.Handle, 0x101f, IntPtr.Zero, IntPtr.Zero);
                    if ((!(hWnd != IntPtr.Zero) || !Utilities.GetWindowRect(hWnd, ref lpRect)) || ((this._ptContextHeaderPopup.Y < lpRect.Top) || (this._ptContextHeaderPopup.Y > lpRect.Bottom)))
                    {
                        goto Label_0251;
                    }
                    this._EnsureHeaderContextMenu();
                    this.ContextMenuStrip.Items[1].Enabled = this.TotalItemCount() > 0;
                    int num = this._GetHoveredColHeaderIndex();
                    if (num < 0)
                    {
                        this.ContextMenuStrip.Items[0].Visible = false;
                        this.ContextMenuStrip.Items[1].Visible = false;
                        this.ContextMenuStrip.Items[2].Visible = false;
                        this.ContextMenuStrip.Items[3].Visible = false;
                    }
                    else
                    {
                        this.ContextMenuStrip.Items[0].Text = string.Format("{0} Column", base.Columns[num].Text);
                        this.ContextMenuStrip.Items[0].Visible = true;
                        this.ContextMenuStrip.Items[1].Visible = true;
                        this.ContextMenuStrip.Items[2].Visible = true;
                        this.ContextMenuStrip.Items[3].Visible = true;
                    }
                    this.ContextMenuStrip.Show(this._ptContextHeaderPopup);
                    return;
                }
                case 0x204e:
                {
                    LVNative.NMHDR lParam = (LVNative.NMHDR) m.GetLParam(typeof(LVNative.NMHDR));
                    if ((-187 == lParam.code) && (base.Handle == lParam.hwndFrom))
                    {
                        LVNative.NMLVEMPTYMARKUP structure = (LVNative.NMLVEMPTYMARKUP) m.GetLParam(typeof(LVNative.NMLVEMPTYMARKUP));
                        structure.szMarkup = this._emptyText;
                        structure.dwFlags = 1;
                        Marshal.StructureToPtr(structure, m.LParam, true);
                        m.Result = (IntPtr) 1;
                        return;
                    }
                    break;
                }
            }
        Label_0251:
            base.WndProc(ref m);
        }

        public string EmptyText
        {
            get
            {
                return this._emptyText;
            }
            set
            {
                this._emptyText = value;
                if (base.IsHandleCreated)
                {
                    base.RecreateHandle();
                }
            }
        }

        public int SelectedCount
        {
            get
            {
                return (int) LVNative.SendLVMessage(base.Handle, 0x1032, IntPtr.Zero, IntPtr.Zero);
            }
        }

        internal int uiAsyncUpdateInterval
        {
            get
            {
                return this._uiAsyncUpdateInterval;
            }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                if (value > 0x1388)
                {
                    value = 0x1388;
                }
                if ((value > 0) != (this._uiAsyncUpdateInterval > 0))
                {
                    if (value > 0)
                    {
                        if (this.timer_LVIAddQueue == null)
                        {
                            this.timer_LVIAddQueue = new System.Windows.Forms.Timer();
                            this.timer_LVIAddQueue.Interval = value;
                            this.timer_LVIAddQueue.Tick += new EventHandler(this.timerLVIAddQueue_Tick);
                            this.qLVIsToAdd = new List<ListViewItem>();
                        }
                    }
                    else
                    {
                        this.FlushUpdates();
                    }
                }
                this._uiAsyncUpdateInterval = value;
                if (value > 0)
                {
                    this.timer_LVIAddQueue.Interval = value;
                }
            }
        }

        public ListViewItem[] UnselectedItems
        {
            get
            {
                List<ListViewItem> list = new List<ListViewItem>();
                foreach (ListViewItem item in base.Items)
                {
                    if (!item.Selected)
                    {
                        list.Add(item);
                    }
                }
                return list.ToArray();
            }
        }
    }
}

