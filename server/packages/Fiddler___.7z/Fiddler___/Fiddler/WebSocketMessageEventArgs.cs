﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public class WebSocketMessageEventArgs : EventArgs
    {
        public WebSocketMessageEventArgs(WebSocketMessage _inMsg)
        {
            this.oWSM = _inMsg;
        }

        public WebSocketMessage oWSM
        {
            
            get
            {
                return this.oWSM;
            }
            private 
            set
            {
                this.oWSM = value;
            }
        }
    }
}

