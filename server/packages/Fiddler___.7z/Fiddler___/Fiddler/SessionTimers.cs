﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using System.Text;

    public class SessionTimers
    {
        private static bool _EnabledHighResTimers;
        public DateTime ClientBeginRequest;
        public DateTime ClientBeginResponse;
        public DateTime ClientConnected;
        public DateTime ClientDoneRequest;
        public DateTime ClientDoneResponse;
        public int DNSTime;
        public DateTime FiddlerBeginRequest;
        public DateTime FiddlerGotRequestHeaders;
        public DateTime FiddlerGotResponseHeaders;
        public int GatewayDeterminationTime;
        public int HTTPSHandshakeTime;
        public DateTime ServerBeginResponse;
        public DateTime ServerConnected;
        public DateTime ServerDoneResponse;
        public DateTime ServerGotRequest;
        public int TCPConnectTime;
        private NetTimestamps tsClientReads;
        private NetTimestamps tsServerReads;

        internal SessionTimers Clone()
        {
            return (SessionTimers) base.MemberwiseClone();
        }

        [DllImport("winmm.dll", EntryPoint="timeBeginPeriod")]
        private static extern int MM_timeBeginPeriod(int iMS);
        [DllImport("winmm.dll", EntryPoint="timeEndPeriod")]
        private static extern int MM_timeEndPeriod(int iMS);
        public override string ToString()
        {
            return this.ToString(false);
        }

        public string ToString(bool bMultiLine)
        {
            if (bMultiLine)
            {
                return string.Format("ClientConnected:\t{0:HH:mm:ss.fff}\r\nClientBeginRequest:\t{1:HH:mm:ss.fff}\r\nGotRequestHeaders:\t{2:HH:mm:ss.fff}\r\nClientDoneRequest:\t{3:HH:mm:ss.fff}\r\nDetermine Gateway:\t{4,0}ms\r\nDNS Lookup: \t\t{5,0}ms\r\nTCP/IP Connect:\t{6,0}ms\r\nHTTPS Handshake:\t{7,0}ms\r\nServerConnected:\t{8:HH:mm:ss.fff}\r\nFiddlerBeginRequest:\t{9:HH:mm:ss.fff}\r\nServerGotRequest:\t{10:HH:mm:ss.fff}\r\nServerBeginResponse:\t{11:HH:mm:ss.fff}\r\nGotResponseHeaders:\t{12:HH:mm:ss.fff}\r\nServerDoneResponse:\t{13:HH:mm:ss.fff}\r\nClientBeginResponse:\t{14:HH:mm:ss.fff}\r\nClientDoneResponse:\t{15:HH:mm:ss.fff}\r\n\r\n{16}", new object[] { 
                    this.ClientConnected, this.ClientBeginRequest, this.FiddlerGotRequestHeaders, this.ClientDoneRequest, this.GatewayDeterminationTime, this.DNSTime, this.TCPConnectTime, this.HTTPSHandshakeTime, this.ServerConnected, this.FiddlerBeginRequest, this.ServerGotRequest, this.ServerBeginResponse, this.FiddlerGotResponseHeaders, this.ServerDoneResponse, this.ClientBeginResponse, this.ClientDoneResponse, 
                    (TimeSpan.Zero < (this.ClientDoneResponse - this.ClientBeginRequest)) ? string.Format("\tOverall Elapsed:\t{0:h\\:mm\\:ss\\.fff}\r\n", (TimeSpan) (this.ClientDoneResponse - this.ClientBeginRequest)) : string.Empty
                 });
            }
            return string.Format("ClientConnected: {0:HH:mm:ss.fff}, ClientBeginRequest: {1:HH:mm:ss.fff}, GotRequestHeaders: {2:HH:mm:ss.fff}, ClientDoneRequest: {3:HH:mm:ss.fff}, Determine Gateway: {4,0}ms, DNS Lookup: {5,0}ms, TCP/IP Connect: {6,0}ms, HTTPS Handshake: {7,0}ms, ServerConnected: {8:HH:mm:ss.fff},FiddlerBeginRequest: {9:HH:mm:ss.fff}, ServerGotRequest: {10:HH:mm:ss.fff}, ServerBeginResponse: {11:HH:mm:ss.fff}, GotResponseHeaders: {12:HH:mm:ss.fff}, ServerDoneResponse: {13:HH:mm:ss.fff}, ClientBeginResponse: {14:HH:mm:ss.fff}, ClientDoneResponse: {15:HH:mm:ss.fff}{16}", new object[] { 
                this.ClientConnected, this.ClientBeginRequest, this.FiddlerGotRequestHeaders, this.ClientDoneRequest, this.GatewayDeterminationTime, this.DNSTime, this.TCPConnectTime, this.HTTPSHandshakeTime, this.ServerConnected, this.FiddlerBeginRequest, this.ServerGotRequest, this.ServerBeginResponse, this.FiddlerGotResponseHeaders, this.ServerDoneResponse, this.ClientBeginResponse, this.ClientDoneResponse, 
                (TimeSpan.Zero < (this.ClientDoneResponse - this.ClientBeginRequest)) ? string.Format(@", Overall Elapsed: {0:h\:mm\:ss\.fff}", (TimeSpan) (this.ClientDoneResponse - this.ClientBeginRequest)) : string.Empty
             });
        }

        public NetTimestamps ClientReads
        {
            get
            {
                if (this.tsClientReads == null)
                {
                    this.tsClientReads = new NetTimestamps();
                }
                return this.tsClientReads;
            }
            internal set
            {
                this.tsClientReads = value;
            }
        }

        public static bool EnableHighResolutionTimers
        {
            get
            {
                return _EnabledHighResTimers;
            }
            set
            {
                if (value != _EnabledHighResTimers)
                {
                    if (value)
                    {
                        _EnabledHighResTimers = MM_timeBeginPeriod(1) == 0;
                    }
                    else
                    {
                        _EnabledHighResTimers = MM_timeEndPeriod(1) != 0;
                    }
                }
            }
        }

        public NetTimestamps ServerReads
        {
            get
            {
                if (this.tsServerReads == null)
                {
                    this.tsServerReads = new NetTimestamps();
                }
                return this.tsServerReads;
            }
            internal set
            {
                this.tsServerReads = value;
            }
        }

        public class NetTimestamps
        {
            private List<NetTimestamp> listTimeAndSize = new List<NetTimestamp>();

            public void AddRead(long tsRead, int bytesRead)
            {
                this.listTimeAndSize.Add(new NetTimestamp(tsRead, bytesRead));
            }

            internal static SessionTimers.NetTimestamps FromCopy(SessionTimers.NetTimestamps oExistingTS)
            {
                SessionTimers.NetTimestamps timestamps = new SessionTimers.NetTimestamps();
                if (oExistingTS != null)
                {
                    timestamps.listTimeAndSize.AddRange(oExistingTS.listTimeAndSize);
                }
                return timestamps;
            }

            public NetTimestamp[] ToArray()
            {
                return this.listTimeAndSize.ToArray();
            }

            public NetTimestamp[] ToFoldedArray(int iMSFold)
            {
                List<NetTimestamp> list = new List<NetTimestamp>();
                foreach (NetTimestamp timestamp in this.listTimeAndSize)
                {
                    if ((list.Count < 1) || ((list[list.Count - 1].tsRead + iMSFold) < timestamp.tsRead))
                    {
                        list.Add(timestamp);
                    }
                    int count = list[list.Count - 1].cbRead + timestamp.cbRead;
                    list.RemoveAt(list.Count - 1);
                    list.Add(new NetTimestamp(timestamp.tsRead, count));
                }
                return list.ToArray();
            }

            public override string ToString()
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendFormat("There were {0} reads.\n<table>", this.listTimeAndSize.Count);
                foreach (NetTimestamp timestamp in this.listTimeAndSize)
                {
                    builder.AppendFormat("<tr><td>{0}<td>{1:N0}</td><tr>\n", timestamp.tsRead, timestamp.cbRead);
                }
                builder.AppendFormat("</table>", new object[0]);
                return builder.ToString();
            }

            public int Count
            {
                get
                {
                    return this.listTimeAndSize.Count;
                }
            }

            [StructLayout(LayoutKind.Sequential)]
            public struct NetTimestamp
            {
                public readonly long tsRead;
                public readonly int cbRead;
                public NetTimestamp(long tsReadMS, int count)
                {
                    this.tsRead = tsReadMS;
                    this.cbRead = count;
                }
            }
        }
    }
}

