﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;

    internal static class ProcessHelper
    {
        private static bool bDisambiguateWWAHostApps = false;
        private static readonly Dictionary<int, ProcessNameCacheEntry> dictProcessNames = new Dictionary<int, ProcessNameCacheEntry>();
        private const int ERROR_INSUFFICIENT_BUFFER = 0x7a;
        private const int ERROR_SUCCESS = 0;
        private const int MSEC_PROCESSNAME_CACHE_LIFETIME = 0x7530;
        private const int QueryLimitedInformation = 0x1000;

        static ProcessHelper()
        {
            FiddlerApplication.Janitor.assignWork(new SimpleEventHandler(ProcessHelper.ScavengeCache), 0xea60);
            if (Utilities.IsWin8OrLater() && FiddlerApplication.Prefs.GetBoolPref("fiddler.ProcessInfo.DecorateWithAppName", true))
            {
                bDisambiguateWWAHostApps = true;
            }
        }

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr hHandle);
        [DllImport("kernel32.dll")]
        internal static extern int GetApplicationUserModelId(IntPtr hProcess, ref int AppModelIDLength, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder sbAppUserModelID);
        internal static string GetProcessName(int iPID)
        {
            try
            {
                ProcessNameCacheEntry entry;
                Dictionary<int, ProcessNameCacheEntry> dictionary2;
                if (dictProcessNames.TryGetValue(iPID, out entry))
                {
                    Dictionary<int, ProcessNameCacheEntry> dictionary;
                    if (entry.ulLastLookup > (Utilities.GetTickCount() - ((long) 0x7530L)))
                    {
                        return entry.sProcessName;
                    }
                    bool flag = false;
                    try
                    {
                        Monitor.Enter(dictionary = dictProcessNames, ref flag);
                        dictProcessNames.Remove(iPID);
                    }
                    finally
                    {
                        if (flag)
                        {
                            Monitor.Exit(dictProcessNames);
                        }
                    }
                }
                string str = Process.GetProcessById(iPID).ProcessName.ToLower();
                if (string.IsNullOrEmpty(str))
                {
                    return string.Empty;
                }
                if (bDisambiguateWWAHostApps && str.OICEquals("WWAHost"))
                {
                    try
                    {
                        IntPtr hProcess = OpenProcess(0x1000, false, iPID);
                        if (IntPtr.Zero != hProcess)
                        {
                            int appModelIDLength = 130;
                            StringBuilder sbAppUserModelID = new StringBuilder((int) appModelIDLength);
                            int num2 = GetApplicationUserModelId(hProcess, ref appModelIDLength, sbAppUserModelID);
                            if (num2 == 0)
                            {
                                str = string.Format("{0}!{1}", str, sbAppUserModelID);
                            }
                            else if (0x7a == num2)
                            {
                                sbAppUserModelID = new StringBuilder((int) appModelIDLength);
                                if (GetApplicationUserModelId(hProcess, ref appModelIDLength, sbAppUserModelID) == 0)
                                {
                                    str = string.Format("{0}!{1}", str, sbAppUserModelID);
                                }
                            }
                            CloseHandle(hProcess);
                        }
                    }
                    catch
                    {
                    }
                }
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(dictionary2 = dictProcessNames, ref lockTaken);
                    if (!dictProcessNames.ContainsKey(iPID))
                    {
                        dictProcessNames.Add(iPID, new ProcessNameCacheEntry(str));
                    }
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(dictProcessNames);
                    }
                }
                return str;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        [DllImport("kernel32.dll")]
        internal static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);
        internal static void ScavengeCache()
        {
            Dictionary<int, ProcessNameCacheEntry> dictionary;
            bool lockTaken = false;
            try
            {
                Monitor.Enter(dictionary = dictProcessNames, ref lockTaken);
                List<int> list = new List<int>();
                foreach (KeyValuePair<int, ProcessNameCacheEntry> pair in dictProcessNames)
                {
                    if (pair.Value.ulLastLookup < (Utilities.GetTickCount() - ((long) 0x7530L)))
                    {
                        list.Add(pair.Key);
                    }
                }
                foreach (int num in list)
                {
                    dictProcessNames.Remove(num);
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(dictProcessNames);
                }
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct ProcessNameCacheEntry
        {
            internal readonly long ulLastLookup;
            internal readonly string sProcessName;
            internal ProcessNameCacheEntry(string _sProcessName)
            {
                this.ulLastLookup = Utilities.GetTickCount();
                this.sProcessName = _sProcessName;
            }
        }
    }
}

