﻿using System.ComponentModel;

namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    public class Inspectors : IDisposable
    {
        private List<string> __slHideList;
        private Hashtable m_RequestInspectors;
        private Hashtable m_ResponseInspectors;
        private TabControl m_tabsRequest;
        private TabControl m_tabsResponse;
        private frmViewer m_Viewer;
        private Hashtable m_WSMInspectors;

        internal Inspectors(TabControl oRequestTabs, TabControl oResponseTabs, frmViewer oMain)
        {
            this.m_tabsRequest = oRequestTabs;
            this.m_tabsResponse = oResponseTabs;
            this.m_Viewer = oMain;
            this.m_RequestInspectors = new Hashtable();
            this.m_ResponseInspectors = new Hashtable();
            this.m_WSMInspectors = new Hashtable();
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.inspectors.HideList", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                this.__slHideList = new List<string>(stringPref.Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries));
            }
            else
            {
                this.__slHideList = null;
            }
            if (CONFIG.bLoadInspectors)
            {
                this.ScanInspectors();
            }
        }

        private static void _AddInspectorsToTabControl(TabControl oTC, Hashtable m_Inspectors, string sTypeOfInspector, InspectorFlags flagsToExclude)
        {
            List<TabPage> list = new List<TabPage>();
            foreach (DictionaryEntry entry in m_Inspectors)
            {
                try
                {
                    Inspector2 inspector = entry.Value as Inspector2;
                    if ((flagsToExclude == InspectorFlags.None) || ((inspector.GetFlags() & flagsToExclude) == InspectorFlags.None))
                    {
                        Inspector2 inspector2 = (Inspector2) Activator.CreateInstance(inspector.GetType());
                        TabPage o = new TabPage();
                        o.Font = new Font(o.Font.FontFamily, CONFIG.flFontSize);
                        o.Tag = inspector2;
                        inspector2.AddToTab(o);
                        list.Add(o);
                    }
                    continue;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("[Fiddler] Failure initializing {0} Inspector: {1}\n{2}", new object[] { sTypeOfInspector, exception.Message, exception.StackTrace });
                    continue;
                }
            }
            InspectorComparer comparer = new InspectorComparer();
            list.Sort(comparer);
            oTC.TabPages.AddRange(list.ToArray());
        }

        private void _CreateSyntaxViewAd()
        {
            TabPage oAdPage = new TabPage("Get SyntaxView");
            oAdPage.Font = new Font(oAdPage.Font.FontFamily, CONFIG.flFontSize);
            oAdPage.SuspendLayout();
            LinkLabel label = new LinkLabel();
            label.AutoSize = true;
            label.Padding = new Padding(8, 4, 8, 4);
            label.Text = "Remove this page";
            label.Location = new Point(20, 110);
            label.LinkBehavior = LinkBehavior.HoverUnderline;
            label.LinkClicked += delegate (object sender, LinkLabelLinkClickedEventArgs e) {
                FiddlerApplication.Prefs.SetBoolPref("fiddler.inspectors.response.AdvertiseSyntaxView", false);
                oAdPage.Dispose();
            };
            label.Dock = DockStyle.Top;
            oAdPage.Controls.Add(label);
            LinkLabel label2 = new LinkLabel();
            label2.AutoSize = true;
            label2.Padding = new Padding(8, 4, 8, 4);
            label2.Text = "Learn more about Inspector add-ons...";
            label2.Location = new Point(20, 90);
            label2.LinkBehavior = LinkBehavior.HoverUnderline;
            label2.LinkClicked += delegate (object sender, LinkLabelLinkClickedEventArgs e) {
                Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("SYNTAXVIEWLEARN"));
            };
            label2.Dock = DockStyle.Top;
            oAdPage.Controls.Add(label2);
            LinkLabel label3 = new LinkLabel();
            label3.Font = new Font(label3.Font.FontFamily, CONFIG.flFontSize + 2f);
            label3.AutoSize = true;
            label3.Padding = new Padding(8, 4, 8, 4);
            label3.Location = new Point(20, 0x41);
            label3.Text = "Download and Install SyntaxView now...";
            label3.LinkBehavior = LinkBehavior.HoverUnderline;
            label3.LinkClicked += delegate (object sender, LinkLabelLinkClickedEventArgs e) {
                Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("SYNTAXVIEWINSTALL"));
            };
            label3.Dock = DockStyle.Top;
            oAdPage.Controls.Add(label3);
            Label label4 = new Label();
            label4.Font = new Font(label4.Font.FontFamily, 11f);
            label4.Padding = new Padding(8);
            label4.Height = 70;
            label4.MinimumSize = new Size(200, 40);
            label4.Text = "The SyntaxView Inspector displays syntax-highlighted HTML, Script, CSS, and XML. If you're a web developer, you'll want this add-on. ";
            label4.Dock = DockStyle.Top;
            oAdPage.Controls.Add(label4);
            oAdPage.ResumeLayout();
            this.m_tabsResponse.TabPages.Add(oAdPage);
        }

        internal static DictionaryEntry _FindBestInspector(Session oS, Hashtable m_Inspectors, out int iScore)
        {
            DictionaryEntry entry = new DictionaryEntry(null, null);
            int num = -1;
            foreach (DictionaryEntry entry2 in m_Inspectors)
            {
                int num2 = ((Inspector2) entry2.Value).ScoreForSession(oS);
                if (num2 > num)
                {
                    entry = entry2;
                    num = num2;
                }
            }
            iScore = num;
            return entry;
        }

        private static DictionaryEntry _FindBestInspectorForContentType(string sContentType, Hashtable m_Inspectors)
        {
            sContentType = Utilities.TrimAfter(sContentType, ';');
            DictionaryEntry entry = new DictionaryEntry(null, null);
            int num = -1;
            foreach (DictionaryEntry entry2 in m_Inspectors)
            {
                int num2 = ((Inspector2) entry2.Value).ScoreForContentType(sContentType);
                if (num2 > num)
                {
                    entry = entry2;
                    num = num2;
                }
            }
            return entry;
        }

        internal void AddRequestInspectorsToTabControl(TabControl oTC, InspectorFlags flagsToExclude)
        {
            _AddInspectorsToTabControl(oTC, this.m_RequestInspectors, "Request", flagsToExclude);
        }

        internal void AddResponseInspectorsToTabControl(TabControl oTC, InspectorFlags flagsToExclude)
        {
            _AddInspectorsToTabControl(oTC, this.m_ResponseInspectors, "Response", flagsToExclude);
        }

        internal void AddWSMInspectorsToTabControl(TabControl oTC, InspectorFlags flagsToExclude)
        {
            _AddInspectorsToTabControl(oTC, this.m_WSMInspectors, "WebSocket", flagsToExclude);
        }

        internal void AnnounceFontSizeChange(float flSizeInPoints)
        {
            foreach (Inspector2 inspector in this.m_RequestInspectors.Values)
            {
                try
                {
                    inspector.SetFontSize(flSizeInPoints);
                    continue;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception);
                    continue;
                }
            }
            foreach (Inspector2 inspector2 in this.m_ResponseInspectors.Values)
            {
                try
                {
                    inspector2.SetFontSize(flSizeInPoints);
                    continue;
                }
                catch (Exception exception2)
                {
                    FiddlerApplication.ReportException(exception2);
                    continue;
                }
            }
        }

        private void CreateAllInspectors()
        {
            try
            {
                TabPage key;
                List<TabPage> list = new List<TabPage>();
                List<TabPage> list2 = new List<TabPage>();
                foreach (DictionaryEntry entry in this.m_RequestInspectors)
                {
                    try
                    {
                        key = (TabPage) entry.Key;
                        ((Inspector2) entry.Value).AddToTab(key);
                        list.Add(key);
                        key.Validating += new CancelEventHandler(this.m_Viewer.actValidateRequest);
                        key.CausesValidation = true;
                        continue;
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure initializing Request Inspector:  {0}\n{1}", exception.Message, exception.StackTrace), "Initialization Error");
                        continue;
                    }
                }
                bool flag = false;
                foreach (DictionaryEntry entry2 in this.m_ResponseInspectors)
                {
                    try
                    {
                        key = (TabPage) entry2.Key;
                        ((Inspector2) entry2.Value).AddToTab(key);
                        if (key.Text.Contains("SyntaxView"))
                        {
                            flag = true;
                        }
                        list2.Add(key);
                        key.Validating += new CancelEventHandler(this.m_Viewer.actValidateResponse);
                        key.CausesValidation = true;
                        continue;
                    }
                    catch (Exception exception2)
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure initializing Response Inspector:  {0}\n{1}", exception2.Message, exception2.StackTrace), "Initialization Error");
                        continue;
                    }
                }
                if (!flag && FiddlerApplication.Prefs.GetBoolPref("fiddler.inspectors.response.AdvertiseSyntaxView", true))
                {
                    this._CreateSyntaxViewAd();
                }
                list.Sort(new InspectorComparer());
                list2.Sort(new InspectorComparer());
                this.m_tabsRequest.TabPages.AddRange(list.ToArray());
                this.m_tabsResponse.TabPages.AddRange(list2.ToArray());
            }
            catch (Exception exception3)
            {
                FiddlerApplication.DoNotifyUser(string.Format("Failure loading Inspectors: {0}", exception3.Message), "Error");
            }
        }

        public void Dispose()
        {
            foreach (TabPage page in this.m_RequestInspectors.Keys)
            {
                page.Tag = null;
                if (page.Parent != null)
                {
                    ((TabControl) page.Parent).TabPages.Remove(page);
                }
                page.Dispose();
            }
            foreach (TabPage page2 in this.m_ResponseInspectors.Keys)
            {
                page2.Tag = null;
                if (page2.Parent != null)
                {
                    ((TabControl) page2.Parent).TabPages.Remove(page2);
                }
                page2.Dispose();
            }
            this.m_RequestInspectors.Clear();
            this.m_ResponseInspectors.Clear();
        }

        internal DictionaryEntry FindBestRequestInspector(Session oS, out int iScore)
        {
            return _FindBestInspector(oS, this.m_RequestInspectors, out iScore);
        }

        public DictionaryEntry FindBestRequestInspectorForContentType(string sContentType)
        {
            return _FindBestInspectorForContentType(sContentType, this.m_RequestInspectors);
        }

        internal DictionaryEntry FindBestResponseInspector(Session oS, out int iScore)
        {
            return _FindBestInspector(oS, this.m_ResponseInspectors, out iScore);
        }

        public DictionaryEntry FindBestResponseInspectorForContentType(string sContentType)
        {
            return _FindBestInspectorForContentType(sContentType, this.m_ResponseInspectors);
        }

        private bool isSuppressedInspector(System.Type t)
        {
            if (this.__slHideList == null)
            {
                return false;
            }
            return this.__slHideList.Contains(t.FullName);
        }

        private void LoadInspectorsFromAssembly(string sPath, bool bNoisyLogging)
        {
            Assembly assembly;
            try
            {
                if (!CONFIG.bRunningOnCLRv4)
                {
                    throw new Exception("Not reachable");
                }
                assembly = Assembly.UnsafeLoadFrom(sPath);
            }
            catch (Exception exception)
            {
                FiddlerApplication.LogAddonException(exception, "Failed to load " + sPath);
                return;
            }
            try
            {
                if (!Utilities.FiddlerMeetsVersionRequirement(assembly, "Inspectors"))
                {
                    FiddlerApplication.Log.LogFormat("Assembly {0} did not specify a RequiredVersionAttribute. Skipping check for Inspectors.", new object[] { sPath });
                }
                else
                {
                    foreach (System.Type type in assembly.GetExportedTypes())
                    {
                        if ((!type.IsAbstract && type.IsClass) && type.IsSubclassOf(typeof(Inspector2)))
                        {
                            try
                            {
                                if (this.isSuppressedInspector(type))
                                {
                                    if (bNoisyLogging)
                                    {
                                        FiddlerApplication.Log.LogFormat("    ! Hiding {0} because it appears in fiddler.inspectors.HideList", new object[] { type.FullName });
                                    }
                                }
                                else
                                {
                                    Inspector2 inspector = (Inspector2) Activator.CreateInstance(type);
                                    TabPage key = new TabPage();
                                    key.Font = new Font(key.Font.FontFamily, CONFIG.flFontSize);
                                    key.Tag = inspector;
                                    if (inspector is IRequestInspector2)
                                    {
                                        this.m_RequestInspectors.Add(key, inspector);
                                        if (bNoisyLogging)
                                        {
                                            FiddlerApplication.Log.LogFormat("    Class {0} is a Request inspector.", new object[] { type.FullName });
                                        }
                                    }
                                    else if (inspector is IResponseInspector2)
                                    {
                                        this.m_ResponseInspectors.Add(key, inspector);
                                        if (bNoisyLogging)
                                        {
                                            FiddlerApplication.Log.LogFormat("    Class {0} is a Response inspector.", new object[] { type.FullName });
                                        }
                                        if (inspector is IWSMInspector)
                                        {
                                            this.m_WSMInspectors.Add(key, inspector);
                                        }
                                    }
                                    else if (bNoisyLogging)
                                    {
                                        FiddlerApplication.Log.LogFormat("    ! Class {0} is neither a Request or Response inspector. ?!?!", new object[] { type.FullName });
                                    }
                                }
                            }
                            catch (Exception exception2)
                            {
                                FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure loading {0} inspector from {1}: {2}\n\n{3}", new object[] { type.Name, sPath, exception2.Message, exception2.StackTrace }), "Inspector Failed");
                            }
                        }
                    }
                }
            }
            catch (Exception exception3)
            {
                if (bNoisyLogging)
                {
                    FiddlerApplication.Log.LogFormat("[Fiddler] Failure loading inspectors from {0}: {1}", new object[] { sPath, exception3.Message });
                }
            }
        }

        internal void ScanInspectors()
        {
            this.ScanPathForInspectors(CONFIG.GetPath("Inspectors"));
            this.ScanPathForInspectors(CONFIG.GetPath("Inspectors_User"));
            this.CreateAllInspectors();
        }

        private void ScanPathForInspectors(string sPath)
        {
            this.ScanPathForInspectors(sPath, false);
        }

        internal void ScanPathForInspectors(string sPath, bool bIsSubfolder)
        {
            bool boolPref = FiddlerApplication.Prefs.GetBoolPref("fiddler.debug.extensions.verbose", false);
            if (boolPref)
            {
                FiddlerApplication.Log.LogFormat("Searching for Inspectors under {0}", new object[] { sPath });
            }
            if (Directory.Exists(sPath))
            {
                try
                {
                    if (!bIsSubfolder)
                    {
                        foreach (DirectoryInfo info in new DirectoryInfo(sPath).GetDirectories("*.ext"))
                        {
                            this.ScanPathForInspectors(info.FullName, true);
                        }
                    }
                    foreach (FileInfo info2 in new DirectoryInfo(sPath).GetFiles(bIsSubfolder ? "Fiddler*.dll" : "*.dll"))
                    {
                        if (bIsSubfolder || (!Utilities.IsNotExtension(info2.Name) && !info2.Name.OICEquals("samples.dll")))
                        {
                            if (boolPref)
                            {
                                FiddlerApplication.Log.LogFormat("Looking for Inspectors inside {0}", new object[] { info2.FullName.ToString() });
                            }
                            this.LoadInspectorsFromAssembly(info2.FullName, boolPref);
                        }
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("[Fiddler] Failure loading inspectors. {0}", new object[] { exception.Message });
                }
            }
        }

        [Obsolete("This property will be removed in a future version")]
        public Hashtable RequestInspectors
        {
            get
            {
                return this.m_RequestInspectors;
            }
        }

        [Obsolete("This property will be removed in a future version")]
        public Hashtable ResponseInspectors
        {
            get
            {
                return this.m_ResponseInspectors;
            }
        }
    }
}

