﻿namespace Fiddler
{
    using System;
    using System.Drawing;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    internal static class LVNative
    {
        internal const int HDM_FIRST = 0x1200;
        internal const int HDM_HITTEST = 0x1206;
        internal const int LVCF_FMT = 1;
        internal const int LVCFMT_SORTDOWN = 0x200;
        internal const int LVCFMT_SORTUP = 0x400;
        internal const int LVM_FIRST = 0x1000;
        internal const int LVM_GETCOLUMN = 0x105f;
        internal const int LVM_GETHEADER = 0x101f;
        internal const int LVM_GETSELECTEDCOUNT = 0x1032;
        internal const int LVM_SETCOLUMN = 0x1060;
        private const int LVM_SETEXTENDEDLISTVIEWSTYLE = 0x1036;
        internal const int LVM_SUBITEMHITTEST = 0x1039;
        internal const int LVN_FIRST = -100;
        internal const int LVN_GETEMPTYMARKUP = -187;
        private const int LVS_EX_BORDERSELECT = 0x8000;

        internal static void DontSelectBorderImage(ListView lvTarget)
        {
            SendLVMessage(lvTarget.Handle, 0x1036, (IntPtr) 0x8000, (IntPtr) 0x8000);
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool GetScrollInfo(IntPtr hwnd, int fnBar, ref SCROLLINFO lpsi);
        [DllImport("user32.dll", EntryPoint="SendMessage")]
        internal static extern int SendHeaderHitTestMessage(IntPtr hWnd, int uMsg, IntPtr wParam, ref HDHITTESTINFO lParam);
        [DllImport("user32.dll", EntryPoint="SendMessage", CharSet=CharSet.Auto)]
        internal static extern IntPtr SendHitTestMessage(HandleRef hWnd, int msg, IntPtr wParam, LVHITTESTINFO lParam);
        [DllImport("user32.dll", EntryPoint="SendMessage", CharSet=CharSet.Auto)]
        internal static extern IntPtr SendLVColMessage(IntPtr hWnd, int msg, int wParam, ref LV_COLUMN lParam);
        [DllImport("user32.dll", EntryPoint="SendMessage")]
        internal static extern IntPtr SendLVMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        internal struct HDHITTESTINFO
        {
            public Point pt;
            public int flags;
            public int iItem;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct LV_COLUMN
        {
            public int mask;
            public int fmt;
            public int cx;
            public string pszText;
            public int cchTextMax;
            public int iSubItem;
            public int iImage;
            public int iOrder;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
        internal class LVHITTESTINFO
        {
            public int pt_x;
            public int pt_y;
            public int flags;
            public int iItem;
            public int iSubItem;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct NMHDR
        {
            public IntPtr hwndFrom;
            public IntPtr idFrom;
            public int code;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
        public struct NMLVEMPTYMARKUP
        {
            public LVNative.NMHDR hdr;
            public int dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=0x824)]
            public string szMarkup;
        }

        internal enum ScrollBarDirection
        {
            SB_HORZ,
            SB_VERT,
            SB_CTL,
            SB_BOTH
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct SCROLLINFO
        {
            public int cbSize;
            public int fMask;
            public int nMin;
            public int nMax;
            public int nPage;
            public int nPos;
            public int nTrackPos;
        }

        [Flags]
        internal enum ScrollInfoMask
        {
            SIF_ALL = 0x17,
            SIF_DISABLENOSCROLL = 8,
            SIF_PAGE = 2,
            SIF_POS = 4,
            SIF_RANGE = 1,
            SIF_TRACKPOS = 0x10
        }
    }
}

