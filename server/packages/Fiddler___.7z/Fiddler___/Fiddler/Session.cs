﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;
    using System.Xml;

    [DebuggerDisplay("Session #{m_requestID}, {m_state}, {fullUrl}, [{BitFlags}]")]
    public class Session
    {
        public ITunnel __oTunnel;
        private string __sResponseFileToStream;
        internal Form __ViewForm;
        private WebRequest __WebRequestForAuth;
        private bool _bAllowClientPipeReuse;
        private SessionFlags _bitFlags;
        private bool _bypassGateway;
        private int _LocalProcessID;
        private ProcessingStates _pState;
        public bool bBufferResponse;
        private bool bLeakedResponseAlready;
        private static bool bTrySPNTokenObject = true;
        private static int cRequests;
        [CodeDescription("IP Address of the client for this session.")]
        public string m_clientIP;
        [CodeDescription("Client port attached to Fiddler.")]
        public int m_clientPort;
        [CodeDescription("IP Address of the server for this session.")]
        public string m_hostIP;
        private int m_requestID;
        private SessionStates m_state;
        private Session nextSession;
        [CodeDescription("Fiddler-internal flags set on the session.")]
        public readonly StringDictionary oFlags;
        public EventHandler<EventArgs> OnCompleteTransaction;
        public EventHandler<ContinueTransactionEventArgs> OnContinueTransaction;
        public EventHandler<StateChangeEventArgs> OnStateChanged;
        [CodeDescription("Object representing the HTTP Request.")]
        public ClientChatter oRequest;
        [CodeDescription("Object representing the HTTP Response.")]
        public ServerChatter oResponse;
        private AutoResetEvent oSyncEvent;
        [CodeDescription("Contains the bytes of the request body.")]
        public byte[] requestBodyBytes;
        [CodeDescription("Contains the bytes of the response body.")]
        public byte[] responseBodyBytes;
        public SessionTimers Timers;
        [CodeDescription("ListViewItem object associated with this session in the Session list.")]
        public ListViewItem ViewItem;

        public Session(Session toDeepCopy) : this((HTTPRequestHeaders) toDeepCopy.RequestHeaders.Clone(), Utilities.Dupe(toDeepCopy.requestBodyBytes))
        {
            this._AssignID();
            this.SetBitFlag(toDeepCopy._bitFlags, true);
            foreach (string str in toDeepCopy.oFlags.Keys)
            {
                this.oFlags[str] = toDeepCopy.oFlags[str];
            }
            this.oResponse.headers = (HTTPResponseHeaders) toDeepCopy.ResponseHeaders.Clone();
            this.responseBodyBytes = Utilities.Dupe(toDeepCopy.responseBodyBytes);
            this.state = SessionStates.Done;
            this.Timers = toDeepCopy.Timers.Clone();
        }

        public Session(SessionData oSD) : this(oSD.arrRequest, oSD.arrResponse, SessionFlags.None)
        {
            this.LoadMetadata(new MemoryStream(oSD.arrMetadata));
            if ((oSD.arrWebSocketMessages != null) && (oSD.arrWebSocketMessages.Length > 0))
            {
                WebSocket.LoadWebSocketMessagesFromStream(this, new MemoryStream(oSD.arrWebSocketMessages));
            }
        }

        internal Session(ClientPipe clientPipe, ServerPipe serverPipe)
        {
            EventHandler<StateChangeEventArgs> handler = null;
            this.bBufferResponse = FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.bufferresponses", true);
            this.Timers = new SessionTimers();
            this._bAllowClientPipeReuse = true;
            this.oFlags = new StringDictionary();
            if (CONFIG.bDebugSpew)
            {
                if (handler == null)
                {
                    handler = delegate (object s, StateChangeEventArgs ea) {
                        FiddlerApplication.DebugSpew("onstatechange>#{0} moving from state '{1}' to '{2}' {3}", new object[] { this.id.ToString(), ea.oldState, ea.newState, Environment.StackTrace });
                    };
                }
                this.OnStateChanged += handler;
            }
            if (clientPipe != null)
            {
                this.Timers.ClientConnected = clientPipe.dtAccepted;
                this.m_clientIP = (clientPipe.Address == null) ? null : clientPipe.Address.ToString();
                this.m_clientPort = clientPipe.Port;
                this.oFlags["x-clientIP"] = this.m_clientIP;
                this.oFlags["x-clientport"] = this.m_clientPort.ToString();
                if (clientPipe.LocalProcessID != 0)
                {
                    this._LocalProcessID = clientPipe.LocalProcessID;
                    this.oFlags["x-ProcessInfo"] = string.Format("{0}:{1}", clientPipe.LocalProcessName, this._LocalProcessID);
                    if ((FiddlerApplication._iShowOnlyPID != 0) && (FiddlerApplication._iShowOnlyPID != this._LocalProcessID))
                    {
                        this.oFlags["ui-hide"] = "Toolbar>ProcessFilter";
                    }
                }
            }
            else
            {
                this.Timers.ClientConnected = DateTime.Now;
            }
            if (CONFIG.iShowProcessFilter == ProcessFilterCategories.HideAll)
            {
                this.oFlags["ui-hide"] = "StatusBar>HideAll";
            }
            this.oResponse = new ServerChatter(this);
            this.oRequest = new ClientChatter(this);
            this.oRequest.pipeClient = clientPipe;
            this.oResponse.pipeServer = serverPipe;
        }

        public Session(HTTPRequestHeaders oRequestHeaders, byte[] arrRequestBody)
        {
            EventHandler<StateChangeEventArgs> handler = null;
            this.bBufferResponse = FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.bufferresponses", true);
            this.Timers = new SessionTimers();
            this._bAllowClientPipeReuse = true;
            this.oFlags = new StringDictionary();
            if (oRequestHeaders == null)
            {
                throw new ArgumentNullException("oRequestHeaders", "oRequestHeaders must not be null when creating a new Session.");
            }
            if (arrRequestBody == null)
            {
                arrRequestBody = Utilities.emptyByteArray;
            }
            if (CONFIG.bDebugSpew)
            {
                if (handler == null)
                {
                    handler = delegate (object s, StateChangeEventArgs ea) {
                        FiddlerApplication.DebugSpew("onstatechange>#{0} moving from state '{1}' to '{2}' {3}", new object[] { this.id.ToString(), ea.oldState, ea.newState, Environment.StackTrace });
                    };
                }
                this.OnStateChanged += handler;
            }
            this.Timers.ClientConnected = this.Timers.ClientBeginRequest = this.Timers.FiddlerGotRequestHeaders = DateTime.Now;
            this.m_clientIP = null;
            this.m_clientPort = 0;
            this.oFlags["x-clientIP"] = this.m_clientIP;
            this.oFlags["x-clientport"] = this.m_clientPort.ToString();
            this.oResponse = new ServerChatter(this);
            this.oRequest = new ClientChatter(this);
            this.oRequest.pipeClient = null;
            this.oResponse.pipeServer = null;
            this.oRequest.headers = oRequestHeaders;
            this.requestBodyBytes = arrRequestBody;
            this.m_state = SessionStates.AutoTamperRequestBefore;
        }

        public Session(byte[] arrRequest, byte[] arrResponse) : this(arrRequest, arrResponse, SessionFlags.None)
        {
        }

        public Session(byte[] arrRequest, byte[] arrResponse, SessionFlags oSF)
        {
            HTTPHeaderParseWarnings warnings;
            int num;
            int num2;
            int num3;
            int num4;
            this.bBufferResponse = FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.bufferresponses", true);
            this.Timers = new SessionTimers();
            this._bAllowClientPipeReuse = true;
            this.oFlags = new StringDictionary();
            if (Utilities.IsNullOrEmpty(arrRequest))
            {
                arrRequest = Encoding.ASCII.GetBytes("GET http://MISSING-REQUEST/? HTTP/0.0\r\nHost:MISSING-REQUEST\r\nX-Fiddler-Generated: Request Data was missing\r\n\r\n");
            }
            if (Utilities.IsNullOrEmpty(arrResponse))
            {
                arrResponse = Encoding.ASCII.GetBytes("HTTP/1.1 0 FIDDLER GENERATED - RESPONSE DATA WAS MISSING\r\n\r\n");
            }
            this.state = SessionStates.Done;
            this.m_requestID = Interlocked.Increment(ref cRequests);
            this.BitFlags = oSF;
            if (!Parser.FindEntityBodyOffsetFromArray(arrRequest, out num, out num2, out warnings))
            {
                throw new InvalidDataException("Request corrupt, unable to find end of headers.");
            }
            if (!Parser.FindEntityBodyOffsetFromArray(arrResponse, out num3, out num4, out warnings))
            {
                throw new InvalidDataException("Response corrupt, unable to find end of headers.");
            }
            this.requestBodyBytes = new byte[arrRequest.Length - num2];
            this.responseBodyBytes = new byte[arrResponse.Length - num4];
            Buffer.BlockCopy(arrRequest, num2, this.requestBodyBytes, 0, this.requestBodyBytes.Length);
            Buffer.BlockCopy(arrResponse, num4, this.responseBodyBytes, 0, this.responseBodyBytes.Length);
            string sData = CONFIG.oHeaderEncoding.GetString(arrRequest, 0, num) + "\r\n\r\n";
            string sHeaders = CONFIG.oHeaderEncoding.GetString(arrResponse, 0, num3) + "\r\n\r\n";
            this.oRequest = new ClientChatter(this, sData);
            this.oResponse = new ServerChatter(this, sHeaders);
        }

        internal void _AssignID()
        {
            this.m_requestID = Interlocked.Increment(ref cRequests);
        }

        private void _BuildConnectionEstablishedReply()
        {
            this.SetBitFlag(SessionFlags.ResponseGeneratedByFiddler, true);
            this.oResponse.headers = new HTTPResponseHeaders();
            this.oResponse.headers.HTTPVersion = this.oRequest.headers.HTTPVersion;
            this.oResponse.headers.SetStatus(200, "Connection Established");
            this.oResponse.headers.Add("FiddlerGateway", "Direct");
            this.oResponse.headers.Add("StartTime", DateTime.Now.ToString("HH:mm:ss.fff"));
            this.oResponse.headers.Add("Connection", "close");
            this.responseBodyBytes = Utilities.emptyByteArray;
        }

        private void _BuildReceiveFailureReply(string sErrorBody)
        {
            this.oResponse.headers = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
            this.oResponse.headers.SetStatus(0x1f8, "Fiddler - Receive Failure while streaming");
            this.oResponse.headers.Add("Date", DateTime.UtcNow.ToString("r"));
            this.oResponse.headers.Add("Content-Type", "text/html; charset=UTF-8");
            this.oResponse.headers.Add("Connection", "close");
            this.oResponse.headers.Add("Cache-Control", "no-cache, must-revalidate");
            this.oResponse.headers.Add("Timestamp", DateTime.Now.ToString("HH:mm:ss.fff"));
            this.responseBodyBytes = Encoding.ASCII.GetBytes(sErrorBody);
        }

        private void _createNextSession(bool bForceClientServerPipeAffinity)
        {
            if (((this.oResponse != null) && (this.oResponse.pipeServer != null)) && ((bForceClientServerPipeAffinity || (this.oResponse.pipeServer.ReusePolicy == PipeReusePolicy.MarriedToClientPipe)) || this.oFlags.ContainsKey("X-ClientServerPipeAffinity")))
            {
                this.nextSession = new Session(this.oRequest.pipeClient, this.oResponse.pipeServer);
                this.oResponse.pipeServer = null;
            }
            else
            {
                this.nextSession = new Session(this.oRequest.pipeClient, null);
            }
        }

        private void _EnsureStateAtLeast(SessionStates ss)
        {
            if (this.m_state < ss)
            {
                this.m_state = ss;
            }
        }

        private bool _executeObtainRequest()
        {
            if (this.state > SessionStates.ReadingRequest)
            {
                this.Timers.ClientBeginRequest = this.Timers.FiddlerGotRequestHeaders = this.Timers.ClientDoneRequest = DateTime.Now;
                this._AssignID();
            }
            else
            {
                this.state = SessionStates.ReadingRequest;
                if (!this.oRequest.ReadRequest())
                {
                    this._HandleFailedReadRequest();
                    return false;
                }
                this.Timers.ClientDoneRequest = DateTime.Now;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Request for Session #{0} for read from {1}.", new object[] { this.m_requestID, this.oRequest.pipeClient });
                }
                try
                {
                    this.requestBodyBytes = this.oRequest.TakeEntity();
                }
                catch (Exception exception)
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, true, false, "Failed to obtain request body. " + Utilities.DescribeException(exception));
                    this.CloseSessionPipes(true);
                    this.state = SessionStates.Aborted;
                    return false;
                }
            }
            this._replaceVirtualHostnames();
            if (this.isHTTPS)
            {
                this.SetBitFlag(SessionFlags.IsHTTPS, true);
                this.SetBitFlag(SessionFlags.IsFTP, false);
            }
            else if (this.isFTP)
            {
                this.SetBitFlag(SessionFlags.IsFTP, true);
                this.SetBitFlag(SessionFlags.IsHTTPS, false);
            }
            this._smValidateRequest();
            this.state = SessionStates.AutoTamperRequestBefore;
            if (CONFIG.bReportHTTPLintErrors)
            {
                this.ExecuteHTTPLintOnRequest();
            }
            this.ExecuteBasicRequestManipulations();
            FiddlerApplication.DoBeforeRequest(this);
            FiddlerApplication.oExtensions.DoAutoTamperRequestBefore(this);
            if (FiddlerApplication._AutoResponder.IsEnabled)
            {
                FiddlerApplication._AutoResponder.DoMatchBeforeRequestTampering(this);
            }
            if ((this.ViewItem != null) || !this.ShouldBeHidden())
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.updateSession), new object[] { this });
            }
            if (this.m_state >= SessionStates.Done)
            {
                this.FinishUISession();
                return false;
            }
            return true;
        }

        private static string _GetSPNForUri(Uri uriTarget)
        {
            string dnsSafeHost;
            int num = FiddlerApplication.Prefs.GetInt32Pref("fiddler.auth.SPNMode", 3);
            switch (num)
            {
                case 0:
                    return null;

                case 1:
                    dnsSafeHost = uriTarget.DnsSafeHost;
                    break;

                default:
                    dnsSafeHost = uriTarget.DnsSafeHost;
                    if ((num == 3) || (((uriTarget.HostNameType != UriHostNameType.IPv6) && (uriTarget.HostNameType != UriHostNameType.IPv4)) && (dnsSafeHost.IndexOf('.') == -1)))
                    {
                        string canonicalName = DNSResolver.GetCanonicalName(uriTarget.DnsSafeHost);
                        if (!string.IsNullOrEmpty(canonicalName))
                        {
                            dnsSafeHost = canonicalName;
                        }
                    }
                    break;
            }
            dnsSafeHost = "HTTP/" + dnsSafeHost;
            if (((uriTarget.Port != 80) && (uriTarget.Port != 0x1bb)) && FiddlerApplication.Prefs.GetBoolPref("fiddler.auth.SPNIncludesPort", false))
            {
                dnsSafeHost = dnsSafeHost + ":" + uriTarget.Port.ToString();
            }
            return dnsSafeHost;
        }

        private string _GetSuggestedFilenameExt()
        {
            string str = Utilities.FileExtensionForMIMEType(this.oResponse.MIMEType);
            if (str == ".txt")
            {
                if (Utilities.HasMagicBytes(this.responseBodyBytes, "PK"))
                {
                    return ".zip";
                }
                if (Utilities.HasMagicBytes(this.responseBodyBytes, "MZ"))
                {
                    return ".exe";
                }
                if (Utilities.HasMagicBytes(this.responseBodyBytes, "7z"))
                {
                    return ".7z";
                }
                if (Utilities.HasMagicBytes(this.responseBodyBytes, "Rar!"))
                {
                    return ".rar";
                }
                if (Utilities.HasMagicBytes(this.responseBodyBytes, "%PDF-"))
                {
                    return ".pdf";
                }
                if (Utilities.HasMagicBytes(this.responseBodyBytes, "BM"))
                {
                    return ".bmp";
                }
            }
            return str;
        }

        private bool _handledAsAutomaticAuth()
        {
            if ((!this._isResponseAuthChallenge() || !this.oFlags.ContainsKey("x-AutoAuth")) || this.oFlags.ContainsKey("x-AutoAuth-Failed"))
            {
                this.__WebRequestForAuth = null;
                return false;
            }
            try
            {
                return this._PerformInnerAuth();
            }
            catch (TypeLoadException exception)
            {
                FiddlerApplication.Log.LogFormat("!Warning: Automatic authentication failed. You should installl the latest .NET Framework 2.0/3.5 Service Pack from WindowsUpdate.\n" + exception, new object[0]);
                return false;
            }
        }

        private bool _handledAsAutomaticRedirect()
        {
            string str;
            int num;
            if (((this.oResponse.headers.HTTPResponseCode < 300) || (this.oResponse.headers.HTTPResponseCode > 0x134)) || ((this.HTTPMethodIs("CONNECT") || !this.oFlags.ContainsKey("x-Builder-MaxRedir")) || !this.oResponse.headers.Exists("Location")))
            {
                return false;
            }
            if (!isRedirectableURI(this.fullUrl, this.oResponse["Location"], out str))
            {
                return false;
            }
            this.nextSession = new Session(this.oRequest.pipeClient, null);
            this.nextSession.propagateProcessInfo(this);
            this.nextSession.oRequest.headers = (HTTPRequestHeaders) this.oRequest.headers.Clone();
            str = Utilities.TrimAfter(str, '#');
            try
            {
                this.nextSession.fullUrl = new Uri(str).AbsoluteUri;
            }
            catch (UriFormatException exception)
            {
                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("Redirect's Location header was malformed.\nLocation: {0}\n\n{1}", str, exception));
                this.nextSession.fullUrl = str;
            }
            if ((this.oResponse.headers.HTTPResponseCode == 0x133) || (this.oResponse.headers.HTTPResponseCode == 0x134))
            {
                this.nextSession.requestBodyBytes = Utilities.Dupe(this.requestBodyBytes);
            }
            else
            {
                if (!this.nextSession.HTTPMethodIs("HEAD"))
                {
                    this.nextSession.RequestMethod = "GET";
                }
                this.nextSession.oRequest.headers.RemoveRange(new string[] { "Content-Type", "Content-Length", "Transfer-Encoding", "Content-Encoding", "Expect" });
                this.nextSession.requestBodyBytes = Utilities.emptyByteArray;
            }
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.reissue.UpdateHeadersOnAutoRedirectedRequest", true))
            {
                this.nextSession.oRequest.headers.RemoveRange(new string[] { "Accept", "Pragma", "Connection", "X-Download-Initiator", "Range", "If-Modified-Since", "If-Unmodified-Since", "Unless-Modified-Since", "If-Range", "If-Match", "If-None-Match" });
                this.nextSession.oRequest.headers.RemoveRange(new string[] { "Authorization", "Proxy-Authorization", "Cookie", "Cookie2" });
            }
            this.nextSession.SetBitFlag(SessionFlags.RequestGeneratedByFiddler, true);
            if (this.oFlags.ContainsKey("x-From-Builder"))
            {
                this.nextSession.oFlags["x-From-Builder"] = this.oFlags["x-From-Builder"] + " > +Redir";
            }
            if (this.oFlags.ContainsKey("x-AutoAuth"))
            {
                this.nextSession.oFlags["x-AutoAuth"] = this.oFlags["x-AutoAuth"];
            }
            if (this.oFlags.ContainsKey("x-Builder-Inspect"))
            {
                this.nextSession.oFlags["x-Builder-Inspect"] = this.oFlags["x-Builder-Inspect"];
            }
            if (int.TryParse(this.oFlags["x-Builder-MaxRedir"], out num))
            {
                num--;
                if (num > 0)
                {
                    this.nextSession.oFlags["x-Builder-MaxRedir"] = num.ToString();
                }
            }
            this.FireContinueTransaction(this, this.nextSession, ContinueTransactionReason.Redirect);
            this.oResponse.releaseServerPipe();
            this.nextSession.state = SessionStates.AutoTamperRequestBefore;
            this.state = SessionStates.Done;
            this.FinishUISession();
            return true;
        }

        private void _HandleFailedReadRequest()
        {
            if (this.oRequest.headers == null)
            {
                this.oFlags["ui-hide"] = "stealth-NewOrReusedClosedWithoutRequest";
            }
            try
            {
                this.requestBodyBytes = this.oRequest.TakeEntity();
            }
            catch (Exception exception)
            {
                this.oFlags["X-FailedToReadRequestBody"] = Utilities.DescribeException(exception);
            }
            if (this.oResponse != null)
            {
                this.oResponse._detachServerPipe();
            }
            this.CloseSessionPipes(true);
            this.state = SessionStates.Aborted;
        }

        private bool _HasRequestBody()
        {
            return !Utilities.IsNullOrEmpty(this.requestBodyBytes);
        }

        private bool _HasResponseBody()
        {
            return !Utilities.IsNullOrEmpty(this.responseBodyBytes);
        }

        private bool _innerReplaceInResponse(string sSearchFor, string sReplaceWith, bool bReplaceAll, bool bCaseSensitive)
        {
            Encoding encoding;
            string str;
            string str2;
            if (this._HasResponseBody())
            {
                encoding = Utilities.getResponseBodyEncoding(this);
                str = encoding.GetString(this.responseBodyBytes);
                if (bReplaceAll)
                {
                    str2 = str.Replace(sSearchFor, sReplaceWith);
                    goto Label_0079;
                }
                int index = str.IndexOf(sSearchFor, bCaseSensitive ? StringComparison.InvariantCulture : StringComparison.InvariantCultureIgnoreCase);
                if (index == 0)
                {
                    str2 = sReplaceWith + str.Substring(sSearchFor.Length);
                    goto Label_0079;
                }
                if (index > 0)
                {
                    str2 = str.Substring(0, index) + sReplaceWith + str.Substring(index + sSearchFor.Length);
                    goto Label_0079;
                }
            }
            return false;
        Label_0079:
            if (str != str2)
            {
                this.responseBodyBytes = encoding.GetBytes(str2);
                this.oResponse["Content-Length"] = this.responseBodyBytes.LongLength.ToString();
                return true;
            }
            return false;
        }

        private bool _isDirectRequestToFiddler()
        {
            if (this.port != CONFIG.ListenPort)
            {
                return false;
            }
            if (!this.host.OICEquals(CONFIG.sFiddlerListenHostPort))
            {
                string sHost = this.hostname.ToLowerInvariant();
                if (((sHost == "localhost") || (sHost == "localhost.")) || (sHost == CONFIG.sAlternateHostname))
                {
                    return true;
                }
                if (sHost.StartsWith("[") && sHost.EndsWith("]"))
                {
                    sHost = sHost.Substring(1, sHost.Length - 2);
                }
                IPAddress address = Utilities.IPFromString(sHost);
                if (address != null)
                {
                    try
                    {
                        if (IPAddress.IsLoopback(address))
                        {
                            return true;
                        }
                        foreach (IPAddress address2 in Dns.GetHostAddresses(string.Empty))
                        {
                            if (address2.Equals(address))
                            {
                                return true;
                            }
                        }
                    }
                    catch (Exception)
                    {
                    }
                    return false;
                }
                if (!sHost.StartsWith(CONFIG.sMachineName))
                {
                    return false;
                }
                if (sHost.Length != CONFIG.sMachineName.Length)
                {
                    return (sHost == (CONFIG.sMachineName + "." + CONFIG.sMachineDomain));
                }
            }
            return true;
        }

        private bool _isNTLMType2()
        {
            if (!this.oFlags.ContainsKey("x-SuppressProxySupportHeader"))
            {
                this.oResponse.headers["Proxy-Support"] = "Session-Based-Authentication";
            }
            if (0x197 == this.oResponse.headers.HTTPResponseCode)
            {
                if (this.oRequest.headers["Proxy-Authorization"].Length < 1)
                {
                    return false;
                }
                if (!this.oResponse.headers.Exists("Proxy-Authenticate") || (this.oResponse.headers["Proxy-Authenticate"].Length < 6))
                {
                    return false;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(this.oRequest.headers["Authorization"]))
                {
                    return false;
                }
                if (!this.oResponse.headers.Exists("WWW-Authenticate") || (this.oResponse.headers["WWW-Authenticate"].Length < 6))
                {
                    return false;
                }
            }
            return true;
        }

        private bool _isResponseAuthChallenge()
        {
            if (0x191 == this.oResponse.headers.HTTPResponseCode)
            {
                if (!this.oResponse.headers.ExistsAndContains("WWW-Authenticate", "NTLM") && !this.oResponse.headers.ExistsAndContains("WWW-Authenticate", "Negotiate"))
                {
                    return this.oResponse.headers.ExistsAndContains("WWW-Authenticate", "Digest");
                }
                return true;
            }
            if (0x197 != this.oResponse.headers.HTTPResponseCode)
            {
                return false;
            }
            if (!this.oResponse.headers.ExistsAndContains("Proxy-Authenticate", "NTLM") && !this.oResponse.headers.ExistsAndContains("Proxy-Authenticate", "Negotiate"))
            {
                return this.oResponse.headers.ExistsAndContains("Proxy-Authenticate", "Digest");
            }
            return true;
        }

        private bool _isResponseMultiStageAuthChallenge()
        {
            if (!Utilities.HasHeaders(this.oResponse))
            {
                return false;
            }
            return (((0x191 == this.oResponse.headers.HTTPResponseCode) && this.oResponse.headers["WWW-Authenticate"].OICStartsWith("N")) || ((0x197 == this.oResponse.headers.HTTPResponseCode) && this.oResponse.headers["Proxy-Authenticate"].OICStartsWith("N")));
        }

        private static string _MakeSafeFilename(string sFilename)
        {
            char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
            if (sFilename.IndexOfAny(invalidFileNameChars) < 0)
            {
                return Utilities.TrimTo(sFilename, 160);
            }
            StringBuilder builder = new StringBuilder(sFilename);
            for (int i = 0; i < builder.Length; i++)
            {
                if (Array.IndexOf<char>(invalidFileNameChars, sFilename[i]) > -1)
                {
                    builder[i] = '-';
                }
            }
            return Utilities.TrimTo(builder.ToString(), 160);
        }

        private bool _mayCompressRequest()
        {
            return ((this._HasRequestBody() && !this.oRequest.headers.Exists("Content-Encoding")) && !this.oRequest.headers.Exists("Transfer-Encoding"));
        }

        private bool _mayCompressResponse()
        {
            return ((this._HasResponseBody() && !this.oResponse.headers.Exists("Content-Encoding")) && !this.oResponse.headers.Exists("Transfer-Encoding"));
        }

        private bool _MayRetryWhenReceiveFailed()
        {
            if ((!this.oResponse.bServerSocketReused || (this.state == SessionStates.Aborted)) || this.oResponse.bLeakedHeaders)
            {
                return false;
            }
            if (this.isAnyFlagSet(SessionFlags.RequestBodyDropped))
            {
                return false;
            }
            switch (CONFIG.RetryOnReceiveFailure)
            {
                case RetryMode.Never:
                    return false;

                case RetryMode.IdempotentOnly:
                    return Utilities.HTTPMethodIsIdempotent(this.RequestMethod);
            }
            return true;
        }

        private bool _MayReuseMyClientPipe()
        {
            if (((!CONFIG.bReuseClientSockets || !this._bAllowClientPipeReuse) || (this.oResponse.headers.ExistsAndEquals("Connection", "close") || this.oRequest.headers.ExistsAndEquals("Connection", "close"))) || (this.oResponse.headers.ExistsAndEquals("Proxy-Connection", "close") || this.oRequest.headers.ExistsAndEquals("Proxy-Connection", "close")))
            {
                return false;
            }
            if (!(this.oResponse.headers.HTTPVersion == "HTTP/1.1"))
            {
                return this.oResponse.headers.ExistsAndContains("Connection", "Keep-Alive");
            }
            return true;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private bool _PerformInnerAuth()
        {
            bool flag = 0x197 == this.oResponse.headers.HTTPResponseCode;
            if ((flag && this.isHTTPS) && FiddlerApplication.Prefs.GetBoolPref("fiddler.security.ForbidServer407", true))
            {
                return false;
            }
            try
            {
                ICredentials defaultCredentials;
                int num;
                string fullUrl = this.oFlags["X-AutoAuth-URL"];
                if (string.IsNullOrEmpty(fullUrl))
                {
                    if (flag)
                    {
                        fullUrl = this.fullUrl;
                    }
                    else
                    {
                        fullUrl = this.fullUrl;
                    }
                }
                Uri requestUri = new Uri(fullUrl);
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Performing automatic authentication to {0} in response to {1}", new object[] { requestUri, this.oResponse.headers.HTTPResponseCode });
                }
                if (this.__WebRequestForAuth == null)
                {
                    this.__WebRequestForAuth = WebRequest.Create(requestUri);
                }
                System.Type type = this.__WebRequestForAuth.GetType();
                type.InvokeMember("Async", BindingFlags.SetProperty | BindingFlags.NonPublic | BindingFlags.Instance, null, this.__WebRequestForAuth, new object[] { false });
                object target = type.InvokeMember("ServerAuthenticationState", BindingFlags.GetProperty | BindingFlags.NonPublic | BindingFlags.Instance, null, this.__WebRequestForAuth, new object[0]);
                if (target == null)
                {
                    throw new ApplicationException("Auth state is null");
                }
                System.Type type2 = target.GetType();
                type2.InvokeMember("ChallengedUri", BindingFlags.SetField | BindingFlags.NonPublic | BindingFlags.Instance, null, target, new object[] { requestUri });
                string str2 = this.oFlags["X-AutoAuth-SPN"];
                if ((str2 == null) && !flag)
                {
                    str2 = _GetSPNForUri(requestUri);
                }
                if (str2 != null)
                {
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("Authenticating to '{0}' with ChallengedSpn='{1}'", new object[] { requestUri, str2 });
                    }
                    bool flag2 = false;
                    if (bTrySPNTokenObject)
                    {
                        try
                        {
                            object obj3 = Activator.CreateInstance(Assembly.GetAssembly(typeof(AuthenticationManager)).GetType("System.Net.SpnToken", true), BindingFlags.CreateInstance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, new string[] { str2 }, CultureInfo.InvariantCulture);
                            type2.InvokeMember("ChallengedSpn", BindingFlags.SetField | BindingFlags.NonPublic | BindingFlags.Instance, null, target, new object[] { obj3 });
                            flag2 = true;
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.DebugSpew(Utilities.DescribeException(exception));
                            bTrySPNTokenObject = false;
                        }
                    }
                    if (!flag2)
                    {
                        type2.InvokeMember("ChallengedSpn", BindingFlags.SetField | BindingFlags.NonPublic | BindingFlags.Instance, null, target, new object[] { str2 });
                    }
                }
                try
                {
                    if ((this.oResponse.pipeServer != null) && this.oResponse.pipeServer.bIsSecured)
                    {
                        TransportContext context = this.oResponse.pipeServer._GetTransportContext();
                        if (context != null)
                        {
                            type2.InvokeMember("_TransportContext", BindingFlags.SetField | BindingFlags.NonPublic | BindingFlags.Instance, null, target, new object[] { context });
                        }
                    }
                }
                catch (Exception exception2)
                {
                    FiddlerApplication.Log.LogFormat("Cannot get TransportContext. You may need to upgrade to a later .NET Framework. {0}", new object[] { exception2.Message });
                }
                string challenge = flag ? this.oResponse["Proxy-Authenticate"] : this.oResponse["WWW-Authenticate"];
                if (this.oFlags["x-AutoAuth"].Contains(":"))
                {
                    string sString = Utilities.TrimAfter(this.oFlags["x-AutoAuth"], ':');
                    string domain = null;
                    if (sString.Contains(@"\"))
                    {
                        domain = Utilities.TrimAfter(sString, '\\');
                        defaultCredentials = new NetworkCredential(Utilities.TrimBefore(sString, '\\'), Utilities.TrimBefore(this.oFlags["x-AutoAuth"], ':'), domain);
                    }
                    else
                    {
                        defaultCredentials = new NetworkCredential(sString, Utilities.TrimBefore(this.oFlags["x-AutoAuth"], ':'));
                    }
                }
                else
                {
                    defaultCredentials = CredentialCache.DefaultCredentials;
                }
                this.__WebRequestForAuth.Method = this.RequestMethod;
                Authorization authorization = AuthenticationManager.Authenticate(challenge, this.__WebRequestForAuth, defaultCredentials);
                if (authorization == null)
                {
                    throw new Exception("AuthenticationManager.Authenticate returned null.");
                }
                string message = authorization.Message;
                this.nextSession = new Session(this.oRequest.pipeClient, this.oResponse.pipeServer);
                this.nextSession.propagateProcessInfo(this);
                this.FireContinueTransaction(this, this.nextSession, ContinueTransactionReason.Authenticate);
                if (!authorization.Complete)
                {
                    this.nextSession.__WebRequestForAuth = this.__WebRequestForAuth;
                }
                this.__WebRequestForAuth = null;
                this.nextSession.requestBodyBytes = this.requestBodyBytes;
                this.nextSession.oRequest.headers = (HTTPRequestHeaders) this.oRequest.headers.Clone();
                this.nextSession.oRequest.headers[flag ? "Proxy-Authorization" : "Authorization"] = message;
                this.nextSession.SetBitFlag(SessionFlags.RequestGeneratedByFiddler, true);
                if (this.oFlags.ContainsKey("x-From-Builder"))
                {
                    this.nextSession.oFlags["x-From-Builder"] = this.oFlags["x-From-Builder"] + " > +Auth";
                }
                if (int.TryParse(this.oFlags["x-AutoAuth-Retries"], out num))
                {
                    num--;
                    if (num > 0)
                    {
                        this.nextSession.oFlags["x-AutoAuth"] = this.oFlags["x-AutoAuth"];
                        this.nextSession.oFlags["x-AutoAuth-Retries"] = num.ToString();
                    }
                    else
                    {
                        this.nextSession.oFlags["x-AutoAuth-Failed"] = "true";
                    }
                }
                else
                {
                    this.nextSession.oFlags["x-AutoAuth-Retries"] = "5";
                    this.nextSession.oFlags["x-AutoAuth"] = this.oFlags["x-AutoAuth"];
                }
                if (this.oFlags.ContainsKey("x-Builder-Inspect"))
                {
                    this.nextSession.oFlags["x-Builder-Inspect"] = this.oFlags["x-Builder-Inspect"];
                }
                if (this.oFlags.ContainsKey("x-Builder-MaxRedir"))
                {
                    this.nextSession.oFlags["x-Builder-MaxRedir"] = this.oFlags["x-Builder-MaxRedir"];
                }
                this.state = SessionStates.Done;
                this.nextSession.state = SessionStates.AutoTamperRequestBefore;
                this.FinishUISession();
                return true;
            }
            catch (Exception exception3)
            {
                FiddlerApplication.Log.LogFormat("Automatic authentication of Session #{0} was unsuccessful. {1}\n{2}", new object[] { this.id, Utilities.DescribeException(exception3), exception3.StackTrace });
                this.__WebRequestForAuth = null;
                return false;
            }
        }

        private void _replaceVirtualHostnames()
        {
            if (!this.hostname.OICEndsWith(".fiddler"))
            {
                return;
            }
            string sHost = this.hostname.ToLowerInvariant();
            string str2 = sHost;
            if (str2 == null)
            {
                return;
            }
            if (!(str2 == "ipv4.fiddler"))
            {
                if (!(str2 == "localhost.fiddler"))
                {
                    if (!(str2 == "ipv6.fiddler"))
                    {
                        return;
                    }
                    this.hostname = "[::1]";
                    goto Label_0074;
                }
            }
            else
            {
                this.hostname = "127.0.0.1";
                goto Label_0074;
            }
            this.hostname = "localhost";
        Label_0074:
            this.oFlags["x-UsedVirtualHost"] = sHost;
            this.bypassGateway = true;
            if (this.HTTPMethodIs("CONNECT"))
            {
                this.oFlags["x-OverrideCertCN"] = Utilities.StripIPv6LiteralBrackets(sHost);
            }
        }

        private void _returnEchoServiceResponse()
        {
            if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.echoservice.enabled", true))
            {
                if ((this.oRequest != null) && (this.oRequest.pipeClient != null))
                {
                    this.oRequest.pipeClient.EndWithRST();
                }
                this.state = SessionStates.Aborted;
            }
            else
            {
                FiddlerApplication.oTelemetry.TrackEvent("Scenarios.ReturnEchoServiceResponse");
                if (this.HTTPMethodIs("CONNECT"))
                {
                    this.oRequest.FailSession(0x195, "Method Not Allowed", "This endpoint does not support HTTP CONNECTs. Try GET or POST instead.");
                }
                else
                {
                    int iResponseCode = 200;
                    Action<Session> delLastChance = null;
                    if ((this.PathAndQuery.Length == 4) && Regex.IsMatch(this.PathAndQuery, @"/\d{3}"))
                    {
                        iResponseCode = int.Parse(this.PathAndQuery.Substring(1));
                        if (Utilities.IsRedirectStatus(iResponseCode))
                        {
                            delLastChance = delegate (Session s) {
                                s.oResponse["Location"] = "/200";
                            };
                        }
                    }
                    StringBuilder builder = new StringBuilder();
                    builder.AppendFormat("<!doctype html>\n<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>", new object[0]);
                    if (iResponseCode != 200)
                    {
                        builder.AppendFormat("[{0}] - ", iResponseCode);
                    }
                    builder.Append("Fiddler Echo Service</title></head><body style=\"font-family: arial,sans-serif;\"><h1>Fiddler Echo Service</h1><br /><pre>");
                    builder.Append(Utilities.HtmlEncode(this.oRequest.headers.ToString(true, true)));
                    if ((this.requestBodyBytes != null) && (this.requestBodyBytes.LongLength > 0L))
                    {
                        builder.Append(Utilities.HtmlEncode(Encoding.UTF8.GetString(this.requestBodyBytes)));
                    }
                    builder.Append("</pre>");
                    builder.AppendFormat("This page returned a <b>HTTP/{0}</b> response <br />", iResponseCode);
                    if (this.oFlags.ContainsKey("X-ProcessInfo"))
                    {
                        builder.AppendFormat("Originating Process Information: <code>{0}</code><br />", this.oFlags["X-ProcessInfo"]);
                    }
                    builder.Append("<hr />");
                    if (this.fullUrl.Contains("troubleshooter.cgi"))
                    {
                        builder.Append("<h3>Alternate hostname test</h3>\n");
                        builder.Append("<iframe src='http://ipv4.fiddler:" + CONFIG.ListenPort.ToString() + "/' width=300></iframe>");
                        builder.Append("<iframe src='http://ipv6.fiddler:" + CONFIG.ListenPort.ToString() + "/' width=300></iframe>");
                        builder.Append("<iframe src='http://localhost.fiddler:" + CONFIG.ListenPort.ToString() + "/' width=300></iframe>");
                        builder.Append("<img src='http://www.example.com/' width=0 height=0 />");
                    }
                    else
                    {
                        builder.Append("<ul><li>To configure Fiddler as a reverse proxy instead of seeing this page, see <a href='" + CONFIG.GetRedirUrl("REVERSEPROXY") + "'>Reverse Proxy Setup</a><li>You can download the <a href=\"FiddlerRoot.cer\">FiddlerRoot certificate</a></ul>");
                    }
                    builder.Append("</body></html>");
                    this.oRequest.BuildAndReturnResponse(iResponseCode, "Fiddler Generated", builder.ToString(), delLastChance);
                    this.state = SessionStates.Aborted;
                }
            }
        }

        private void _returnPACFileResponse()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Scenarios.ReturnPACFile");
            this.utilCreateResponseAndBypassServer();
            this.oResponse.headers["Content-Type"] = "application/x-ns-proxy-autoconfig";
            this.oResponse.headers["Cache-Control"] = "max-age=60";
            this.oResponse.headers["Connection"] = "close";
            this.utilSetResponseBody(FiddlerApplication.oProxy._GetPACScriptText(FiddlerApplication.oProxy.IsAttached));
            this.state = SessionStates.Aborted;
            FiddlerApplication.DoResponseHeadersAvailable(this);
            this.ReturnResponse(false);
        }

        private static void _returnRootCert(Session oS)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Scenarios.EchoService.ReturnRootCert");
            oS.utilCreateResponseAndBypassServer();
            oS.oResponse.headers["Connection"] = "close";
            oS.oResponse.headers["Cache-Control"] = "max-age=0";
            byte[] buffer = CertMaker.getRootCertBytes();
            if (buffer != null)
            {
                oS.oResponse.headers["Content-Type"] = "application/x-x509-ca-cert";
                oS.responseBodyBytes = buffer;
                oS.oResponse.headers["Content-Length"] = oS.responseBodyBytes.Length.ToString();
            }
            else
            {
                oS.responseCode = 0x194;
                oS.oResponse.headers["Content-Type"] = "text/html; charset=UTF-8";
                oS.utilSetResponseBody("No root certificate was found. Have you enabled HTTPS traffic decryption in Fiddler yet?".PadRight(0x200, ' '));
            }
            FiddlerApplication.DoResponseHeadersAvailable(oS);
            oS.ReturnResponse(false);
        }

        private void _ReturnSelfGeneratedCONNECTTunnel(string sHostname)
        {
            this.SetBitFlag(SessionFlags.IsDecryptingTunnel | SessionFlags.ResponseGeneratedByFiddler, true);
            this.oResponse.headers = new HTTPResponseHeaders();
            this.oResponse.headers.SetStatus(200, "DecryptEndpoint Created");
            this.oResponse.headers.Add("Timestamp", DateTime.Now.ToString("HH:mm:ss.fff"));
            this.oResponse.headers.Add("FiddlerGateway", "AutoResponder");
            this.oResponse.headers.Add("Connection", "close");
            this.responseBodyBytes = Encoding.UTF8.GetBytes("This is a Fiddler-generated response to the client's request for a CONNECT tunnel.\n\n");
            this.oFlags["ui-backcolor"] = "Lavender";
            this.oFlags.Remove("x-no-decrypt");
            FiddlerApplication.DoBeforeResponse(this);
            FiddlerApplication.oExtensions.DoAutoTamperResponseBefore(this);
            FiddlerApplication.oExtensions.DoAutoTamperResponseAfter(this);
            this.state = SessionStates.Done;
            FiddlerApplication.DoAfterSessionComplete(this);
            if (CONFIG.bUseSNIForCN && !this.oFlags.ContainsKey("x-OverrideCertCN"))
            {
                string str = this.oFlags["https-Client-SNIHostname"];
                if (!string.IsNullOrEmpty(str) && (str != sHostname))
                {
                    this.oFlags["x-OverrideCertCN"] = this.oFlags["https-Client-SNIHostname"];
                }
            }
            string str2 = this.oFlags["x-OverrideCertCN"] ?? Utilities.StripIPv6LiteralBrackets(sHostname);
            if ((this.oRequest.pipeClient == null) || !this.oRequest.pipeClient.SecureClientPipe(str2, this.oResponse.headers))
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.finishSession), new object[] { this });
                this.CloseSessionPipes(false);
            }
            else
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.finishSession), new object[] { this });
                Session session = new Session(this.oRequest.pipeClient, null);
                this.oRequest.pipeClient = null;
                session.oFlags["x-serversocket"] = "AUTO-RESPONDER-GENERATED";
                session.Execute(null);
            }
        }

        private void _returnUpstreamPACFileResponse()
        {
            this.utilCreateResponseAndBypassServer();
            this.oResponse.headers["Content-Type"] = "application/x-ns-proxy-autoconfig";
            this.oResponse.headers["Connection"] = "close";
            this.oResponse.headers["Cache-Control"] = "max-age=300";
            string str = FiddlerApplication.oProxy._GetUpstreamPACScriptText();
            if (string.IsNullOrEmpty(str))
            {
                this.responseCode = 0x194;
            }
            this.utilSetResponseBody(str);
            this.state = SessionStates.Aborted;
            this.ReturnResponse(false);
        }

        private void _smCheckForAutoReply()
        {
            if (FiddlerApplication._AutoResponder.IsEnabled && (this.m_state < SessionStates.AutoTamperResponseBefore))
            {
                FiddlerApplication._AutoResponder.DoMatchAfterRequestTampering(this);
            }
        }

        private void _smDropRequestBody()
        {
            this.oFlags["x-RequestBodyLength"] = this.requestBodyBytes.Length.ToString("N0");
            this.requestBodyBytes = Utilities.emptyByteArray;
            this.SetBitFlag(SessionFlags.RequestBodyDropped, true);
        }

        private void _smInitiateRPCStreaming()
        {
            this.responseBodyBytes = this.oResponse.TakeEntity();
            try
            {
                this.oRequest.pipeClient.Send(this.oResponse.headers.ToByteArray(true, true));
                this.oRequest.pipeClient.Send(this.responseBodyBytes);
                this.SetBitFlag(SessionFlags.ResponseBodyDropped, true);
                this.responseBodyBytes = Utilities.emptyByteArray;
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.finishSession), new object[] { this });
                (this.__oTunnel as GenericTunnel).BeginResponseStreaming();
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Failed to create RPC Tunnel {0}", new object[] { Utilities.DescribeException(exception) });
            }
        }

        private bool _smIsResponseAutoHandled()
        {
            if (Utilities.HasHeaders(this.oResponse))
            {
                if (this._handledAsAutomaticRedirect())
                {
                    return true;
                }
                if (this._handledAsAutomaticAuth())
                {
                    return true;
                }
            }
            return false;
        }

        private bool _smReplyWithFile()
        {
            if (!this.oFlags.ContainsKey("x-replywithfile"))
            {
                return false;
            }
            this.oResponse = new ServerChatter(this, "HTTP/1.1 200 OK\r\nServer: Fiddler\r\n\r\n");
            if (this.LoadResponseFromFile(this.oFlags["x-replywithfile"]) && this.isAnyFlagSet(SessionFlags.ResponseGeneratedByFiddler))
            {
                FiddlerApplication.DoResponseHeadersAvailable(this);
            }
            this.oFlags["x-repliedwithfile"] = this.oFlags["x-replywithfile"];
            this.oFlags.Remove("x-replywithfile");
            return true;
        }

        private void _smValidateRequest()
        {
            if ((Utilities.IsNullOrEmpty(this.requestBodyBytes) && Utilities.HTTPMethodRequiresBody(this.RequestMethod)) && !this.isAnyFlagSet(SessionFlags.IsRPCTunnel | SessionFlags.RequestStreamed))
            {
                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, true, false, "This HTTP method requires a request body.");
            }
            string str = this.oFlags["X-Original-Host"];
            if (str != null)
            {
                if (str.Length < 1)
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, "HTTP/1.1 Request was missing the required HOST header.");
                }
                else
                {
                    if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.network.SetHostHeaderFromURL", true))
                    {
                        this.oFlags["X-OverrideHost"] = this.oFlags["X-URI-Host"];
                    }
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, string.Format("The Request's Host header did not match the URL's host component.\n\nURL Host:\t{0}\nHeader Host:\t{1}", this.oFlags["X-URI-Host"], this.oFlags["X-Original-Host"]));
                }
            }
        }

        private void _smValidateRequestPort()
        {
            if ((this.port < 0) || (this.port > 0xffff))
            {
                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, true, false, "HTTP Request specified an invalid port number.");
            }
        }

        internal void Abort()
        {
            try
            {
                if (this.isAnyFlagSet(SessionFlags.IsWebSocketTunnel | SessionFlags.IsDecryptingTunnel | SessionFlags.IsBlindTunnel))
                {
                    if (this.__oTunnel != null)
                    {
                        this.__oTunnel.CloseTunnel();
                        this.oFlags["x-Fiddler-Aborted"] = "true";
                        this.state = SessionStates.Aborted;
                    }
                }
                else if (this.m_state < SessionStates.Done)
                {
                    this.CloseSessionPipes(true);
                    this.oFlags["x-Fiddler-Aborted"] = "true";
                    this.state = SessionStates.Aborted;
                    this.ThreadResume();
                }
            }
            catch (Exception)
            {
            }
        }

        private bool AcceptHTTPSRequest(X509Certificate2 oCert)
        {
            try
            {
                if (CONFIG.bUseSNIForCN)
                {
                    byte[] buffer = new byte[0x400];
                    int count = this.oRequest.pipeClient.GetRawSocket().Receive(buffer, SocketFlags.Peek);
                    HTTPSClientHello hello = new HTTPSClientHello();
                    if (hello.LoadFromStream(new MemoryStream(buffer, 0, count, false)))
                    {
                        this.oFlags["https-Client-SessionID"] = hello.SessionID;
                        if (!string.IsNullOrEmpty(hello.ServerNameIndicator))
                        {
                            FiddlerApplication.DebugSpew("Secure Endpoint request with SNI of '{0}'", new object[] { hello.ServerNameIndicator });
                            this.oFlags["https-Client-SNIHostname"] = hello.ServerNameIndicator;
                            oCert = CertMaker.FindCert(hello.ServerNameIndicator);
                        }
                    }
                }
                if (!this.oRequest.pipeClient.SecureClientPipeDirect(oCert))
                {
                    FiddlerApplication.Log.LogString("Failed to secure client connection when acting as Secure Endpoint.");
                    return false;
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Failed to secure client connection when acting as Secure Endpoint: {0}", new object[] { exception.ToString() });
            }
            return true;
        }

        public void actInspectInNewWindow()
        {
            this.actInspectInNewWindow(null);
        }

        [CodeDescription("Inspect this Session in a new window. Specify title of tab to activate [Request, Response, Properties]. Use > to delimit a subtab, e.g. Response>XML")]
        public void actInspectInNewWindow(string sActiveTab)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.InspectInNewWindow");
            if ((this.__ViewForm == null) || this.__ViewForm.IsDisposed)
            {
                this.__ViewForm = new UIViewSession(this, sActiveTab);
                this.__ViewForm.Show();
            }
            else
            {
                this.__ViewForm.BringToFront();
            }
        }

        public static Session BuildFromData(bool bClone, HTTPRequestHeaders headersRequest, byte[] arrRequestBody, HTTPResponseHeaders headersResponse, byte[] arrResponseBody, SessionFlags oSF)
        {
            if (headersRequest == null)
            {
                headersRequest = new HTTPRequestHeaders();
                headersRequest.HTTPMethod = "GET";
                headersRequest.HTTPVersion = "HTTP/1.1";
                headersRequest.UriScheme = "http";
                headersRequest.Add("Host", "localhost");
                headersRequest.RequestPath = "/" + DateTime.Now.Ticks.ToString();
            }
            else if (bClone)
            {
                headersRequest = (HTTPRequestHeaders) headersRequest.Clone();
            }
            if (headersResponse == null)
            {
                headersResponse = new HTTPResponseHeaders();
                headersResponse.SetStatus(200, "OK");
                headersResponse.HTTPVersion = "HTTP/1.1";
                headersResponse.Add("Connection", "close");
            }
            else if (bClone)
            {
                headersResponse = (HTTPResponseHeaders) headersResponse.Clone();
            }
            if (arrRequestBody == null)
            {
                arrRequestBody = Utilities.emptyByteArray;
            }
            else if (bClone)
            {
                arrRequestBody = (byte[]) arrRequestBody.Clone();
            }
            if (arrResponseBody == null)
            {
                arrResponseBody = Utilities.emptyByteArray;
            }
            else if (bClone)
            {
                arrResponseBody = (byte[]) arrResponseBody.Clone();
            }
            Session session = new Session(headersRequest, arrRequestBody);
            session._AssignID();
            session.SetBitFlag(oSF, true);
            session.oResponse.headers = headersResponse;
            session.responseBodyBytes = arrResponseBody;
            session.state = SessionStates.Done;
            return session;
        }

        private void CloseSessionPipes(bool bNullThemToo)
        {
            if (CONFIG.bDebugSpew)
            {
                FiddlerApplication.DebugSpew("CloseSessionPipes() for Session #{0}", new object[] { this.id });
            }
            if ((this.oRequest != null) && (this.oRequest.pipeClient != null))
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Closing client pipe...", new object[] { this.id });
                }
                this.oRequest.pipeClient.End();
                if (bNullThemToo)
                {
                    this.oRequest.pipeClient = null;
                }
            }
            if ((this.oResponse != null) && (this.oResponse.pipeServer != null))
            {
                FiddlerApplication.DebugSpew("Closing server pipe...", new object[] { this.id });
                this.oResponse.pipeServer.End();
                if (bNullThemToo)
                {
                    this.oResponse.pipeServer = null;
                }
            }
        }

        public bool COMETPeek()
        {
            if (this.state != SessionStates.ReadingResponse)
            {
                return false;
            }
            try
            {
                this.responseBodyBytes = this.oResponse._PeekAtBody();
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
                return false;
            }
        }

        internal static void CreateAndExecute(object oParams)
        {
            try
            {
                DateTime now = DateTime.Now;
                ProxyExecuteParams proxyParams = (ProxyExecuteParams) oParams;
                TimeSpan span = (TimeSpan) (now - proxyParams.dtConnectionAccepted);
                Interlocked.Add(ref COUNTERS.TOTAL_DELAY_ACCEPT_CONNECTION, (long) span.TotalMilliseconds);
                Interlocked.Increment(ref COUNTERS.CONNECTIONS_ACCEPTED);
                Socket oSocket = proxyParams.oSocket;
                ClientPipe clientPipe = new ClientPipe(oSocket, proxyParams.dtConnectionAccepted);
                Session oSession = new Session(clientPipe, null);
                FiddlerApplication.DoAfterSocketAccept(oSession, oSocket);
                if ((proxyParams.oServerCert == null) || oSession.AcceptHTTPSRequest(proxyParams.oServerCert))
                {
                    oSession.Execute(null);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        internal void EnsureID()
        {
            if (this.m_requestID == 0)
            {
                this.m_requestID = Interlocked.Increment(ref cRequests);
            }
        }

        internal void Execute(object objThreadState)
        {
            try
            {
                this.InnerExecute();
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Uncaught Exception in Session #" + this.id.ToString());
            }
        }

        private void ExecuteBasicRequestManipulations()
        {
            if ((!FiddlerApplication.isClosing && (FiddlerApplication._frmMain != null)) && !this.isFlagSet(SessionFlags.Ignored))
            {
                if (((this._LocalProcessID > 0) && (FiddlerApplication._iShowOnlyPID != 0)) && (FiddlerApplication._iShowOnlyPID != this._LocalProcessID))
                {
                    this.oFlags["ui-hide"] = "Toolbar>ProcessFilter";
                }
                if (CONFIG.iShowProcessFilter != ProcessFilterCategories.All)
                {
                    if (CONFIG.iShowProcessFilter == ProcessFilterCategories.HideAll)
                    {
                        this.oFlags["ui-hide"] = "StatusBar>HideAll";
                    }
                    else
                    {
                        string str = this.oFlags["x-ProcessInfo"];
                        bool flag = !string.IsNullOrEmpty(str) && Utilities.IsBrowserProcessName(str);
                        if (((CONFIG.iShowProcessFilter == ProcessFilterCategories.Browsers) && !flag) || ((CONFIG.iShowProcessFilter == ProcessFilterCategories.NonBrowsers) && flag))
                        {
                            this.oFlags["ui-hide"] = "StatusBar>ProcessFilter";
                        }
                    }
                }
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.hideimages", false) && Utilities.HasImageFileExtension(this.url.ToLowerInvariant()))
                {
                    this.oFlags["ui-hide"] = "Rules>HideImages";
                }
                if (this.HTTPMethodIs("CONNECT") && FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.hideconnects", false))
                {
                    this.oFlags["ui-hide"] = "stealth-Rules>HideConnects";
                }
                if (!this.isAnyFlagSet(SessionFlags.IsRPCTunnel | SessionFlags.RequestStreamed))
                {
                    if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.removeencoding", false))
                    {
                        this.utilDecodeRequest(true);
                    }
                    if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ephemeral.rules.breakonrequest", false) && (CONFIG.bBreakOnImages || !Utilities.HasImageFileExtension(this.PathAndQuery.ToLowerInvariant())))
                    {
                        this.oFlags["x-breakrequest"] = "SINGLESTEP";
                    }
                    if ((FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ephemeral.rules.requireproxyauth", false) && !this.oRequest.headers.ExistsAndContains("Proxy-Authorization", "Basic " + FiddlerApplication.Prefs.GetStringPref("fiddler.proxy.creds", "MTox"))) && ((this.oRequest.pipeClient == null) || !this.oRequest.pipeClient.bIsSecured))
                    {
                        this.responseBodyBytes = Encoding.ASCII.GetBytes("<html><body>[Fiddler] Proxy Authentication Required.<BR>".PadRight(0x200, ' ') + "</body></html>");
                        this.oResponse.headers = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
                        this.oResponse.headers.SetStatus(0x197, "Proxy Auth Required");
                        this.oResponse.headers.Add("Connection", "close");
                        bool flag2 = "MTox" == FiddlerApplication.Prefs.GetStringPref("fiddler.proxy.creds", "MTox");
                        this.oResponse.headers.Add("Proxy-Authenticate", string.Format("Basic realm=\"FiddlerProxy{0}\"", flag2 ? " (user: 1, pass: 1)" : string.Empty));
                        this.oResponse.headers.Add("Content-Type", "text/html");
                        FiddlerApplication.DoResponseHeadersAvailable(this);
                        this.ReturnResponse(false);
                    }
                }
            }
        }

        private void ExecuteBasicResponseManipulations()
        {
            if (!FiddlerApplication.isClosing && !this.isFlagSet(SessionFlags.Ignored))
            {
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.removeencoding", false))
                {
                    this.utilDecodeResponse(true);
                }
                if ((FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ephemeral.rules.forcegzip", false) && this.oRequest.headers.ExistsAndContains("Accept-Encoding", "gzip")) && !this.oResponse.headers.ExistsAndContains("Content-Type", "image/"))
                {
                    this.utilGZIPResponse();
                }
            }
        }

        internal void ExecuteBasicResponseManipulationsUsingHeadersOnly()
        {
            if (!FiddlerApplication.isClosing && !this.isFlagSet(SessionFlags.Ignored))
            {
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.rules.hideimages", false) && this.oResponse.headers.ExistsAndContains("Content-Type", "image/"))
                {
                    this.oFlags["ui-hide"] = "IMAGESKIP";
                }
                if ((FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ephemeral.rules.breakonresponse", false) && (this.responseCode != 0x191)) && (CONFIG.bBreakOnImages || (!this.oResponse.headers.ExistsAndContains("Content-Type", "image/") && !Utilities.HasImageFileExtension(this.PathAndQuery.ToLowerInvariant()))))
                {
                    this.oFlags["x-breakresponse"] = "SINGLESTEP";
                }
            }
        }

        private void ExecuteHTTPLintOnRequest()
        {
            if (this.oRequest.headers != null)
            {
                if (this.fullUrl.Length > 0x823)
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, string.Format("[HTTPLint #M001] Request URL was {0} characters. WinINET-based clients encounter problems when dealing with URLs longer than 2083 characters.", this.fullUrl.Length));
                }
                if (this.fullUrl.Contains("#"))
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, "[HTTPLint #H002] Request URL contained '#'. URL Fragments should not be sent to the server.");
                }
                if (this.oRequest.headers.ByteCount() > 0x3e80)
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, string.Format("[HTTPLint #M003] Request headers were {0:N0} bytes long. Many servers will reject requests this large.", this.oRequest.headers.ByteCount()));
                }
                string str = this.oRequest["Referer"];
                if (!string.IsNullOrEmpty(str))
                {
                    if (str.Contains("#"))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, "[HTTPLint #M004] Referer Header contained '#'. URL Fragments should not be sent to the server.");
                    }
                    if (!this.isHTTPS && !str.StartsWith("http:"))
                    {
                        try
                        {
                            Uri uri = new Uri(str);
                            if ((uri.AbsolutePath != "/") || (uri.Query != string.Empty))
                            {
                                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInRequest, false, false, "[HTTPLint #H005] Referer Header leaked a private URL on an unsecure request: '" + str + "' Referrer Policy may be in use.");
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        private void ExecuteHTTPLintOnResponse()
        {
            if ((this.responseBodyBytes != null) && (this.oResponse.headers != null))
            {
                if (this.oResponse.headers.Exists("Content-Encoding"))
                {
                    if (this.oResponse.headers.ExistsAndContains("Content-Encoding", ",") && !this.oResponse.headers.ExistsAndContains("Content-Encoding", "sdch"))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #M006] Response appears to specify multiple encodings: '{0}'. This will prevent decoding in Internet Explorer.", this.oResponse.headers["Content-Encoding"]));
                    }
                    if ((this.oResponse.headers.ExistsAndContains("Content-Encoding", "gzip") && (this.oRequest != null)) && ((this.oRequest.headers != null) && !this.oRequest.headers.ExistsAndContains("Accept-Encoding", "gzip")))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #H008] Illegal response. Response specified Content-Encoding: gzip, but request did not specify GZIP in Accept-Encoding.");
                    }
                    if ((this.oResponse.headers.ExistsAndContains("Content-Encoding", "deflate") && (this.oRequest != null)) && ((this.oRequest.headers != null) && !this.oRequest.headers.ExistsAndContains("Accept-Encoding", "deflate")))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #H008] Illegal response. Response specified Content-Encoding: Deflate, but request did not specify Deflate in Accept-Encoding.");
                    }
                    if ((this.oResponse.headers.ExistsAndContains("Content-Encoding", "br") && (this.oRequest != null)) && ((this.oRequest.headers != null) && !this.oRequest.headers.ExistsAndContains("Accept-Encoding", "br")))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #H008] Illegal response. Response specified Content-Encoding: br, but request did not specify br (Brotli) in Accept-Encoding.");
                    }
                    if (this.oResponse.headers.ExistsAndContains("Content-Encoding", "chunked"))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #H009] Response specified Content-Encoding: chunked, but Chunked is a Transfer-Encoding.");
                    }
                }
                if (this.oResponse.headers.ExistsAndContains("Transfer-Encoding", "chunked"))
                {
                    if ((Utilities.HasHeaders(this.oRequest) && "HTTP/1.0".OICEquals(this.oRequest.headers.HTTPVersion)) || "HTTP/1.0".OICEquals(this.oResponse.headers.HTTPVersion))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #H010] Invalid response. Responses to HTTP/1.0 clients MUST NOT specify a Transfer-Encoding.");
                    }
                    if (this.oResponse.headers.Exists("Content-Length"))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #M011] Invalid response headers. Messages MUST NOT include both a Content-Length header field and a non-identity transfer-coding.");
                    }
                    if (!this.isAnyFlagSet(SessionFlags.ResponseBodyDropped))
                    {
                        long outStartOfLatestChunk = 0L;
                        long length = this.responseBodyBytes.Length;
                        if (!Utilities.IsChunkedBodyComplete(this, this.responseBodyBytes, 0L, (long) this.responseBodyBytes.Length, out outStartOfLatestChunk, out length))
                        {
                            FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, true, true, "[HTTPLint #M012] The HTTP Chunked response body was incomplete; most likely lacking the final 0-size chunk.");
                        }
                    }
                }
                List<HTTPHeaderItem> list = this.oResponse.headers.FindAll("ETAG");
                if (list.Count > 1)
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #H013] Response contained {0} ETag headers", list.Count));
                }
                if (list.Count > 0)
                {
                    string str = list[0].Value;
                    if (!str.EndsWith("\"") || (!str.StartsWith("\"") && !str.StartsWith("W/\"")))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #L014] ETag values must be a quoted string. Response ETag: {0}", str));
                    }
                }
                if ((!this.oResponse.headers.Exists("Date") && (this.responseCode > 0xc7)) && ((this.responseCode < 500) && !this.HTTPMethodIs("CONNECT")))
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #L015] With rare exceptions, servers MUST include a DATE response header. RFC7231 Section 7.1.1.2");
                }
                if (((this.responseCode > 0x12b) && (this.responseCode != 0x130)) && (this.responseCode < 0x18f))
                {
                    if (0x134 == this.responseCode)
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #M016] Server returned a HTTP/308 redirect. Most clients do not handle HTTP/308; instead use a HTTP/307 with a Cache-Control header.");
                    }
                    if (this.oResponse.headers.Exists("Location"))
                    {
                        if (this.oResponse["Location"].StartsWith("/"))
                        {
                            FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #L017] HTTP Location header must specify a fully-qualified URL. Location: {0}", this.oResponse["Location"]));
                        }
                    }
                    else
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #H018] HTTP/3xx redirect response headers lacked a Location header.");
                    }
                }
                string inStr = this.oResponse.headers["Content-Type"];
                if (inStr.OICContains("utf8"))
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #M019] Content-Type header specified CharSet=UTF8; for better compatibility, use CharSet=UTF-8 instead.");
                }
                if (inStr.OICContains("image/jpg"))
                {
                    FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #L026] Content-Type header specified 'image/jpg'; correct type is 'image/jpeg'.");
                }
                string str3 = this.oResponse.headers.AllValues("Cache-Control");
                if (str3.OICContains("pre-check") || str3.OICContains("post-check"))
                {
                    if (str3.OICContains("no-cache"))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #L024] The pre-check and post-check tokens are meaningless when Cache-Control: no-cache is specified.");
                    }
                    else
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #L025] Cache-Control header contained non-standard tokens. pre-check and post-check are poorly supported and almost never used properly.");
                    }
                }
                List<HTTPHeaderItem> list2 = this.oResponse.headers.FindAll("Set-Cookie");
                if (list2.Count > 0)
                {
                    if (this.hostname.Contains("_"))
                    {
                        FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, "[HTTPLint #M020] Response sets a cookie, and server's hostname contains '_'. Internet Explorer does not permit cookies to be set on hostnames containing underscores. See http://support.microsoft.com/kb/316112");
                    }
                    foreach (HTTPHeaderItem item in list2)
                    {
                        string commaTokenValue = Utilities.GetCommaTokenValue(Utilities.TrimBefore(item.Value, ";"), "domain");
                        if (!Utilities.IsNullOrWhiteSpace(commaTokenValue))
                        {
                            commaTokenValue = commaTokenValue.Trim();
                            if (commaTokenValue.StartsWith("."))
                            {
                                commaTokenValue = commaTokenValue.Substring(1);
                            }
                            if (!this.hostname.EndsWith(commaTokenValue))
                            {
                                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #H021] Illegal DOMAIN in Set-Cookie. Cookie from '{0}' specified 'domain={1}'", this.hostname, commaTokenValue));
                            }
                        }
                        string str6 = Utilities.TrimAfter(item.Value, ';');
                        foreach (char ch in str6)
                        {
                            if (ch == ',')
                            {
                                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #L022] Illegal comma in cookie. Set-Cookie: {0}.", str6));
                            }
                            else if (ch >= '\x0080')
                            {
                                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, false, false, string.Format("[HTTPLint #M023] Non-ASCII character found in Set-Cookie: {0}. Some browsers (Safari) may corrupt this cookie.", str6));
                            }
                        }
                    }
                }
            }
        }

        internal void ExecuteOnThreadPool()
        {
            ThreadPool.UnsafeQueueUserWorkItem(new WaitCallback(this.Execute), DateTime.Now);
        }

        internal void ExecuteWhenDataAvailable()
        {
            AsyncCallback callback = null;
            if (this.m_state > SessionStates.ReadingRequest)
            {
                this.ExecuteOnThreadPool();
            }
            else if ((this.oRequest != null) && (this.oRequest.pipeClient != null))
            {
                if (this.oRequest.pipeClient.HasDataAvailable())
                {
                    this.ExecuteOnThreadPool();
                }
                else
                {
                    Socket oSock = this.oRequest.pipeClient.GetRawSocket();
                    if (oSock != null)
                    {
                        SocketError error;
                        oSock.ReceiveTimeout = ClientPipe._timeoutIdle;
                        Interlocked.Increment(ref COUNTERS.ASYNC_WAIT_CLIENT_REUSE);
                        Interlocked.Increment(ref COUNTERS.TOTAL_ASYNC_WAIT_CLIENT_REUSE);
                        if (callback == null)
                        {
                            callback = delegate (IAsyncResult arOutcome) {
                                Interlocked.Decrement(ref COUNTERS.ASYNC_WAIT_CLIENT_REUSE);
                                int num = 0;
                                try
                                {
                                    num = oSock.EndReceive(arOutcome, out error);
                                }
                                catch (Exception exception)
                                {
                                    if (CONFIG.bDebugSpew)
                                    {
                                        FiddlerApplication.DebugSpew("! SocketReuse EndReceive threw {0} for {1}", new object[] { Utilities.DescribeException(exception), (oSock.RemoteEndPoint as IPEndPoint).Port });
                                    }
                                    num = -1;
                                }
                                if (num < 1)
                                {
                                    if (this.oRequest.pipeClient != null)
                                    {
                                        this.oRequest.pipeClient.End();
                                    }
                                }
                                else
                                {
                                    this.Execute(null);
                                }
                            };
                        }
                        oSock.BeginReceive(new byte[1], 0, 1, SocketFlags.Peek, out error, callback, null);
                        if ((error != SocketError.Success) && (error != SocketError.IOPending))
                        {
                            Interlocked.Decrement(ref COUNTERS.ASYNC_WAIT_CLIENT_REUSE);
                            if (this.oRequest.pipeClient != null)
                            {
                                this.oRequest.pipeClient.End();
                            }
                        }
                    }
                }
            }
        }

        internal void FinishUISession()
        {
            if ((!FiddlerApplication.isClosing && (FiddlerApplication._frmMain != null)) && ((this.ViewItem != null) || !this.ShouldBeHidden()))
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.finishSession), new object[] { this });
            }
        }

        private void FireCompleteTransaction()
        {
            EventHandler<EventArgs> onCompleteTransaction = this.OnCompleteTransaction;
            this.OnContinueTransaction = null;
            this.OnCompleteTransaction = null;
            if (onCompleteTransaction != null)
            {
                onCompleteTransaction(this, new EventArgs());
            }
        }

        private void FireContinueTransaction(Session oOrig, Session oNew, ContinueTransactionReason oReason)
        {
            EventHandler<ContinueTransactionEventArgs> onContinueTransaction = this.OnContinueTransaction;
            if (this.OnCompleteTransaction != null)
            {
                oNew.OnCompleteTransaction = this.OnCompleteTransaction;
                this.OnCompleteTransaction = null;
            }
            this.OnContinueTransaction = null;
            if (onContinueTransaction != null)
            {
                ContinueTransactionEventArgs e = new ContinueTransactionEventArgs(oOrig, oNew, oReason);
                onContinueTransaction(this, e);
            }
        }

        public string GetRedirectTargetURL()
        {
            if (Utilities.IsRedirectStatus(this.responseCode) && Utilities.HasHeaders(this.oResponse))
            {
                return GetRedirectTargetURL(this.fullUrl, this.oResponse["Location"]);
            }
            return null;
        }

        public static string GetRedirectTargetURL(string sBase, string sLocation)
        {
            int index = sLocation.IndexOf(":");
            if ((index < 0) || (sLocation.IndexOfAny(new char[] { '/', '?', '#' }) < index))
            {
                try
                {
                    Uri baseUri = new Uri(sBase);
                    Uri uri2 = new Uri(baseUri, sLocation);
                    return uri2.ToString();
                }
                catch (UriFormatException)
                {
                    return null;
                }
            }
            return sLocation;
        }

        [CodeDescription("Return a string generated from the request body, decoding it and converting from a codepage if needed. Possibly expensive due to decompression and will throw on malformed content. Throws on errors.")]
        public string GetRequestBodyAsString()
        {
            byte[] requestBodyBytes;
            if (!this._HasRequestBody() || !Utilities.HasHeaders(this.oRequest))
            {
                return string.Empty;
            }
            if (this.oRequest.headers.ExistsAny(new string[] { "Content-Encoding", "Transfer-Encoding" }))
            {
                requestBodyBytes = Utilities.Dupe(this.requestBodyBytes);
                Utilities.utilDecodeHTTPBody(this.oRequest.headers, ref requestBodyBytes);
            }
            else
            {
                requestBodyBytes = this.requestBodyBytes;
            }
            Encoding oDefaultEncoding = Utilities.getEntityBodyEncoding(this.oRequest.headers, requestBodyBytes);
            return Utilities.GetStringFromArrayRemovingBOM(requestBodyBytes, oDefaultEncoding);
        }

        [CodeDescription("Returns the Encoding of the requestBodyBytes")]
        public Encoding GetRequestBodyEncoding()
        {
            return Utilities.getEntityBodyEncoding(this.oRequest.headers, this.requestBodyBytes);
        }

        [CodeDescription("Return a string generated from the response body, decoding it and converting from a codepage if needed. Possibly expensive due to decompression and will throw on malformed content. Throws on errors.")]
        public string GetResponseBodyAsString()
        {
            byte[] responseBodyBytes;
            if (!this._HasResponseBody() || !Utilities.HasHeaders(this.oResponse))
            {
                return string.Empty;
            }
            if (this.oResponse.headers.ExistsAny(new string[] { "Content-Encoding", "Transfer-Encoding" }))
            {
                responseBodyBytes = Utilities.Dupe(this.responseBodyBytes);
                Utilities.utilDecodeHTTPBody(this.oResponse.headers, ref responseBodyBytes);
            }
            else
            {
                responseBodyBytes = this.responseBodyBytes;
            }
            Encoding oDefaultEncoding = Utilities.getEntityBodyEncoding(this.oResponse.headers, responseBodyBytes);
            return Utilities.GetStringFromArrayRemovingBOM(responseBodyBytes, oDefaultEncoding);
        }

        [CodeDescription("Returns the Encoding of the responseBodyBytes")]
        public Encoding GetResponseBodyEncoding()
        {
            return Utilities.getResponseBodyEncoding(this);
        }

        [CodeDescription("Return a string md5, sha1, sha256, sha384, or sha512 hash of an unchunked and decompressed copy of the response body. Throws on errors.")]
        public string GetResponseBodyHash(string sHashAlg)
        {
            if (((!"md5".OICEquals(sHashAlg) && !"sha1".OICEquals(sHashAlg)) && (!"sha256".OICEquals(sHashAlg) && !"sha384".OICEquals(sHashAlg))) && !"sha512".OICEquals(sHashAlg))
            {
                throw new NotImplementedException("Hash algorithm " + sHashAlg + " is not implemented");
            }
            if (!this._HasResponseBody() || !Utilities.HasHeaders(this.oResponse))
            {
                return string.Empty;
            }
            byte[] arrBody = Utilities.Dupe(this.responseBodyBytes);
            Utilities.utilDecodeHTTPBody(this.oResponse.headers, ref arrBody);
            if (sHashAlg.OICEquals("sha256"))
            {
                return Utilities.GetSHA256Hash(arrBody);
            }
            if (sHashAlg.OICEquals("sha1"))
            {
                return Utilities.GetSHA1Hash(arrBody);
            }
            if (sHashAlg.OICEquals("sha512"))
            {
                return Utilities.GetSHA512Hash(arrBody);
            }
            if (sHashAlg.OICEquals("sha384"))
            {
                return Utilities.GetSHA384Hash(arrBody);
            }
            if (!sHashAlg.OICEquals("md5"))
            {
                throw new Exception("Unknown failure");
            }
            return Utilities.GetMD5Hash(arrBody);
        }

        [CodeDescription("Return a base64 string md5, sha1, sha256, sha384, or sha512 hash of an unchunked and decompressed copy of the response body. Throws on errors.")]
        public string GetResponseBodyHashAsBase64(string sHashAlgorithm)
        {
            if (!this._HasResponseBody() || !Utilities.HasHeaders(this.oResponse))
            {
                return string.Empty;
            }
            byte[] arrBody = Utilities.Dupe(this.responseBodyBytes);
            Utilities.utilDecodeHTTPBody(this.oResponse.headers, ref arrBody);
            return Utilities.GetHashAsBase64(sHashAlgorithm, arrBody);
        }

        [CodeDescription("Returns TRUE if the Session's target hostname (no port) matches sTestHost (case-insensitively).")]
        public bool HostnameIs(string sTestHost)
        {
            if (this.oRequest == null)
            {
                return false;
            }
            int length = this.oRequest.host.LastIndexOf(':');
            if ((length > -1) && (length > this.oRequest.host.LastIndexOf(']')))
            {
                return (0 == string.Compare(this.oRequest.host, 0, sTestHost, 0, length, StringComparison.OrdinalIgnoreCase));
            }
            return this.oRequest.host.OICEquals(sTestHost);
        }

        [CodeDescription("Returns TRUE if the Session's HTTP Method is available and matches the target method.")]
        public bool HTTPMethodIs(string sTestFor)
        {
            return this.RequestMethod.OICEquals(sTestFor);
        }

        [CodeDescription("Sets the SessionFlags.Ignore bit for this Session, hiding it and ignoring its traffic.")]
        public void Ignore()
        {
            this.SetBitFlag(SessionFlags.Ignored, true);
            if (this.HTTPMethodIs("CONNECT"))
            {
                this.oFlags["x-no-decrypt"] = "IgnoreFlag";
                this.oFlags["x-no-parse"] = "IgnoreFlag";
            }
            else
            {
                this.oFlags["log-drop-response-body"] = "IgnoreFlag";
                this.oFlags["log-drop-request-body"] = "IgnoreFlag";
            }
            this.bBufferResponse = false;
        }

        private void InnerExecute()
        {
            if ((this.oRequest != null) && (this.oResponse != null))
            {
                this.RunStateMachine();
            }
        }

        public bool isAnyFlagSet(SessionFlags FlagsToTest)
        {
            return (SessionFlags.None != (this._bitFlags & FlagsToTest));
        }

        public bool isFlagSet(SessionFlags FlagsToTest)
        {
            return (FlagsToTest == (this._bitFlags & FlagsToTest));
        }

        private static bool isRedirectableURI(string sBase, string sLocation, out string sTarget)
        {
            sTarget = GetRedirectTargetURL(sBase, sLocation);
            if (sTarget == null)
            {
                return false;
            }
            return sTarget.OICStartsWithAny(new string[] { "http://", "https://", "ftp://" });
        }

        public bool LoadMetadata(Stream strmMetadata)
        {
            string str = XmlConvert.ToString(true);
            SessionFlags none = SessionFlags.None;
            string str2 = null;
            try
            {
                int num3;
                XmlTextReader reader = new XmlTextReader(strmMetadata);
                reader.WhitespaceHandling = WhitespaceHandling.None;
                while (reader.Read())
                {
                    long num;
                    string str4;
                    if ((reader.NodeType == XmlNodeType.Element) && ((str4 = reader.Name) != null))
                    {
                        if (!(str4 == "Session"))
                        {
                            if (str4 == "SessionFlag")
                            {
                                goto Label_00F1;
                            }
                            if (str4 == "SessionTimers")
                            {
                                goto Label_0117;
                            }
                            if (str4 == "TunnelInfo")
                            {
                                goto Label_0328;
                            }
                            if (str4 == "PipeInfo")
                            {
                                goto Label_0372;
                            }
                        }
                        else
                        {
                            if (reader.GetAttribute("Aborted") != null)
                            {
                                this.m_state = SessionStates.Aborted;
                            }
                            if (reader.GetAttribute("BitFlags") != null)
                            {
                                this.BitFlags = (SessionFlags) int.Parse(reader.GetAttribute("BitFlags"), NumberStyles.HexNumber);
                            }
                            if (reader.GetAttribute("SID") != null)
                            {
                                str2 = reader.GetAttribute("SID");
                            }
                        }
                    }
                    continue;
                Label_00F1:
                    this.oFlags.Add(reader.GetAttribute("N"), reader.GetAttribute("V"));
                    continue;
                Label_0117:
                    this.Timers.ClientConnected = XmlConvert.ToDateTime(reader.GetAttribute("ClientConnected"), XmlDateTimeSerializationMode.RoundtripKind);
                    string attribute = reader.GetAttribute("ClientBeginRequest");
                    if (attribute != null)
                    {
                        this.Timers.ClientBeginRequest = XmlConvert.ToDateTime(attribute, XmlDateTimeSerializationMode.RoundtripKind);
                    }
                    attribute = reader.GetAttribute("GotRequestHeaders");
                    if (attribute != null)
                    {
                        this.Timers.FiddlerGotRequestHeaders = XmlConvert.ToDateTime(attribute, XmlDateTimeSerializationMode.RoundtripKind);
                    }
                    this.Timers.ClientDoneRequest = XmlConvert.ToDateTime(reader.GetAttribute("ClientDoneRequest"), XmlDateTimeSerializationMode.RoundtripKind);
                    attribute = reader.GetAttribute("GatewayTime");
                    if (attribute != null)
                    {
                        this.Timers.GatewayDeterminationTime = XmlConvert.ToInt32(attribute);
                    }
                    attribute = reader.GetAttribute("DNSTime");
                    if (attribute != null)
                    {
                        this.Timers.DNSTime = XmlConvert.ToInt32(attribute);
                    }
                    attribute = reader.GetAttribute("TCPConnectTime");
                    if (attribute != null)
                    {
                        this.Timers.TCPConnectTime = XmlConvert.ToInt32(attribute);
                    }
                    attribute = reader.GetAttribute("HTTPSHandshakeTime");
                    if (attribute != null)
                    {
                        this.Timers.HTTPSHandshakeTime = XmlConvert.ToInt32(attribute);
                    }
                    attribute = reader.GetAttribute("ServerConnected");
                    if (attribute != null)
                    {
                        this.Timers.ServerConnected = XmlConvert.ToDateTime(attribute, XmlDateTimeSerializationMode.RoundtripKind);
                    }
                    attribute = reader.GetAttribute("FiddlerBeginRequest");
                    if (attribute != null)
                    {
                        this.Timers.FiddlerBeginRequest = XmlConvert.ToDateTime(attribute, XmlDateTimeSerializationMode.RoundtripKind);
                    }
                    this.Timers.ServerGotRequest = XmlConvert.ToDateTime(reader.GetAttribute("ServerGotRequest"), XmlDateTimeSerializationMode.RoundtripKind);
                    attribute = reader.GetAttribute("ServerBeginResponse");
                    if (attribute != null)
                    {
                        this.Timers.ServerBeginResponse = XmlConvert.ToDateTime(attribute, XmlDateTimeSerializationMode.RoundtripKind);
                    }
                    attribute = reader.GetAttribute("GotResponseHeaders");
                    if (attribute != null)
                    {
                        this.Timers.FiddlerGotResponseHeaders = XmlConvert.ToDateTime(attribute, XmlDateTimeSerializationMode.RoundtripKind);
                    }
                    this.Timers.ServerDoneResponse = XmlConvert.ToDateTime(reader.GetAttribute("ServerDoneResponse"), XmlDateTimeSerializationMode.RoundtripKind);
                    this.Timers.ClientBeginResponse = XmlConvert.ToDateTime(reader.GetAttribute("ClientBeginResponse"), XmlDateTimeSerializationMode.RoundtripKind);
                    this.Timers.ClientDoneResponse = XmlConvert.ToDateTime(reader.GetAttribute("ClientDoneResponse"), XmlDateTimeSerializationMode.RoundtripKind);
                    continue;
                Label_0328:
                    num = 0L;
                    long result = 0L;
                    if (long.TryParse(reader.GetAttribute("BytesEgress"), out num) && long.TryParse(reader.GetAttribute("BytesIngress"), out result))
                    {
                        this.__oTunnel = new MockTunnel(num, result);
                    }
                    continue;
                Label_0372:
                    this.bBufferResponse = str != reader.GetAttribute("Streamed");
                    if (!this.bBufferResponse)
                    {
                        none |= SessionFlags.ResponseStreamed;
                    }
                    if (str == reader.GetAttribute("CltReuse"))
                    {
                        none |= SessionFlags.ClientPipeReused;
                    }
                    if (str == reader.GetAttribute("Reused"))
                    {
                        none |= SessionFlags.ServerPipeReused;
                    }
                    if (this.oResponse != null)
                    {
                        this.oResponse.m_bWasForwarded = str == reader.GetAttribute("Forwarded");
                        if (this.oResponse.m_bWasForwarded)
                        {
                            none |= SessionFlags.SentToGateway;
                        }
                    }
                }
                if (this.BitFlags == SessionFlags.None)
                {
                    this.BitFlags = none;
                }
                if (this.Timers.ClientBeginRequest.Ticks < 1L)
                {
                    this.Timers.ClientBeginRequest = this.Timers.ClientConnected;
                }
                if (this.Timers.FiddlerBeginRequest.Ticks < 1L)
                {
                    this.Timers.FiddlerBeginRequest = this.Timers.ServerGotRequest;
                }
                if (this.Timers.FiddlerGotRequestHeaders.Ticks < 1L)
                {
                    this.Timers.FiddlerGotRequestHeaders = this.Timers.ClientBeginRequest;
                }
                if (this.Timers.FiddlerGotResponseHeaders.Ticks < 1L)
                {
                    this.Timers.FiddlerGotResponseHeaders = this.Timers.ServerBeginResponse;
                }
                if ((this.m_clientPort == 0) && this.oFlags.ContainsKey("X-ClientPort"))
                {
                    int.TryParse(this.oFlags["X-ClientPort"], out this.m_clientPort);
                }
                if (this.oFlags.ContainsKey("X-ProcessInfo") && int.TryParse(Utilities.TrimBefore(this.oFlags["X-ProcessInfo"], ':'), out num3))
                {
                    this._LocalProcessID = num3;
                }
                if (str2 != null)
                {
                    if (CONFIG.bReloadSessionIDAsFlag || this.oFlags.ContainsKey("ui-comments"))
                    {
                        this.oFlags["x-OriginalSessionID"] = str2;
                    }
                    else
                    {
                        this.oFlags["ui-comments"] = string.Format("[#{0}]", str2);
                    }
                }
                reader.Close();
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
                return false;
            }
        }

        [CodeDescription("Replace HTTP request headers and body using the specified file.")]
        public bool LoadRequestBodyFromFile(string sFilename)
        {
            if (!Utilities.HasHeaders(this.oRequest))
            {
                return false;
            }
            sFilename = Utilities.EnsurePathIsAbsolute(CONFIG.GetPath("Requests"), sFilename);
            return this.oRequest.ReadRequestBodyFromFile(sFilename);
        }

        private bool LoadResponse(Stream strmResponse, string sResponseFile, string sOptionalContentTypeHint)
        {
            bool flag2;
            bool flag = string.IsNullOrEmpty(sResponseFile);
            this.oResponse = new ServerChatter(this, "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n");
            this.responseBodyBytes = Utilities.emptyByteArray;
            this.bBufferResponse = true;
            this.BitFlags |= SessionFlags.ResponseGeneratedByFiddler;
            this.oFlags["x-Fiddler-Generated"] = flag ? "LoadResponseFromStream" : "LoadResponseFromFile";
            if (flag)
            {
                flag2 = this.oResponse.ReadResponseFromStream(strmResponse, sOptionalContentTypeHint);
            }
            else
            {
                flag2 = this.oResponse.ReadResponseFromFile(sResponseFile, sOptionalContentTypeHint);
            }
            if (this.HTTPMethodIs("HEAD"))
            {
                this.responseBodyBytes = Utilities.emptyByteArray;
            }
            this._EnsureStateAtLeast(SessionStates.AutoTamperResponseBefore);
            return flag2;
        }

        [CodeDescription("Replace HTTP response headers and body using the specified file.")]
        public bool LoadResponseFromFile(string sFilename)
        {
            sFilename = Utilities.GetFirstLocalResponse(sFilename);
            try
            {
                FileInfo info = new FileInfo(sFilename);
                if (info.Length > CONFIG._cb_STREAM_LARGE_FILES)
                {
                    this.SetBitFlag(SessionFlags.ResponseBodyDropped | SessionFlags.ResponseGeneratedByFiddler, true);
                    this.oFlags["x-Fiddler-Generated"] = "StreamResponseFromFile";
                    this.oResponse.GenerateHeadersForLocalFile(sFilename);
                    this.__sResponseFileToStream = sFilename;
                    this.responseBodyBytes = Utilities.emptyByteArray;
                    return true;
                }
            }
            catch (Exception)
            {
            }
            string sOptionalContentTypeHint = Utilities.ContentTypeForFilename(sFilename);
            return this.LoadResponse(null, sFilename, sOptionalContentTypeHint);
        }

        public bool LoadResponseFromStream(Stream strmResponse, string sOptionalContentTypeHint)
        {
            return this.LoadResponse(strmResponse, null, sOptionalContentTypeHint);
        }

        public void PoisonClientPipe()
        {
            this._bAllowClientPipeReuse = false;
        }

        public void PoisonServerPipe()
        {
            if (this.oResponse != null)
            {
                this.oResponse._PoisonPipe();
            }
        }

        internal void propagateProcessInfo(Session sessionFrom)
        {
            if (this._LocalProcessID == 0)
            {
                if (sessionFrom == null)
                {
                    this._LocalProcessID = FiddlerApplication.iPID;
                    this.oFlags["x-ProcessInfo"] = FiddlerApplication.sProcessInfo;
                }
                else
                {
                    this._LocalProcessID = sessionFrom._LocalProcessID;
                    if (sessionFrom.oFlags.ContainsKey("x-ProcessInfo"))
                    {
                        this.oFlags["x-ProcessInfo"] = sessionFrom.oFlags["x-ProcessInfo"];
                    }
                }
            }
        }

        private void RefreshMyInspectors()
        {
            if (!FiddlerApplication.isClosing && (FiddlerApplication._frmMain != null))
            {
                if (FiddlerApplication._frmMain.InvokeRequired)
                {
                    FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.actRefreshInspectorsIfNeeded), new object[] { this });
                }
                else
                {
                    FiddlerApplication._frmMain.actRefreshInspectorsIfNeeded(this);
                }
            }
        }

        [CodeDescription("Update the currently displayed session information in the Web Sessions List.")]
        public void RefreshUI()
        {
            if (!FiddlerApplication.isClosing && (FiddlerApplication._frmMain != null))
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.finishSession), new object[] { this });
            }
        }

        [CodeDescription("Reset the SessionID counter to 0. This method can lead to confusing UI, so use sparingly.")]
        internal static void ResetSessionCounter()
        {
            Interlocked.Exchange(ref cRequests, 0);
        }

        internal bool ReturnResponse(bool bForceClientServerPipeAffinity)
        {
            this.state = SessionStates.SendingResponse;
            bool flag = false;
            this.Timers.ClientBeginResponse = this.Timers.ClientDoneResponse = DateTime.Now;
            try
            {
                if (this.oRequest.pipeClient == null)
                {
                    goto Label_0616;
                }
                if (this.oFlags.ContainsKey("response-trickle-delay"))
                {
                    int num = int.Parse(this.oFlags["response-trickle-delay"]);
                    this.oRequest.pipeClient.TransmitDelay = num;
                }
                this.oRequest.pipeClient.Send(this.oResponse.headers.ToByteArray(true, true));
                if ((this.responseBodyBytes == Utilities.emptyByteArray) && !string.IsNullOrEmpty(this.__sResponseFileToStream))
                {
                    using (FileStream stream = System.IO.File.OpenRead(this.__sResponseFileToStream))
                    {
                        int num2;
                        byte[] buffer = new byte[0x10000];
                        while ((num2 = stream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            this.oRequest.pipeClient.Send(buffer, 0, num2);
                        }
                        goto Label_0111;
                    }
                }
                this.oRequest.pipeClient.Send(this.responseBodyBytes);
            Label_0111:
                this.Timers.ClientDoneResponse = DateTime.Now;
                if ((((this.responseCode == 0x65) && Utilities.HasHeaders(this.oRequest)) && (this.oRequest.headers.ExistsAndContains("Upgrade", "WebSocket") && Utilities.HasHeaders(this.oResponse))) && this.oResponse.headers.ExistsAndContains("Upgrade", "WebSocket"))
                {
                    FiddlerApplication.DebugSpew("Upgrading Session #{0} to Websocket", new object[] { this.id });
                    WebSocket.CreateTunnel(this);
                    this.state = SessionStates.Done;
                    this.FinishUISession();
                    return true;
                }
                if (((this.responseCode == 200) && this.HTTPMethodIs("CONNECT")) && (this.oRequest.pipeClient != null))
                {
                    bForceClientServerPipeAffinity = true;
                    if (this.isAnyFlagSet(SessionFlags.Ignored) || (this.oFlags.ContainsKey("x-no-decrypt") && this.oFlags.ContainsKey("x-no-parse")))
                    {
                        StringDictionary dictionary;
                        StringDictionary dictionary2;
                        this.oFlags["x-CONNECT-Peek"] = "Skipped";
                        (dictionary = this.oFlags)["x-no-decrypt"] = dictionary["x-no-decrypt"] + "Skipped";
                        (dictionary2 = this.oFlags)["x-no-parse"] = dictionary2["x-no-parse"] + "Skipped";
                        FiddlerApplication.DebugSpew("Session #{0} set to act like a blind tunnel", new object[] { this.id });
                        CONNECTTunnel.CreateTunnel(this);
                        flag = true;
                        goto Label_0661;
                    }
                    FiddlerApplication.DebugSpew("Returned Session #{0} CONNECT's 200 response to client; sniffing for client data in tunnel", new object[] { this.id });
                    Socket rawSocket = this.oRequest.pipeClient.GetRawSocket();
                    if (rawSocket != null)
                    {
                        byte[] buffer2 = new byte[0x400];
                        int iMaxByteCount = rawSocket.Receive(buffer2, SocketFlags.Peek);
                        if (iMaxByteCount == 0)
                        {
                            this.oFlags["x-CONNECT-Peek"] = "After the client received notice of the established CONNECT, it failed to send any data.";
                            this.requestBodyBytes = Encoding.UTF8.GetBytes("After the client received notice of the established CONNECT, it failed to send any data.\n");
                            if (this.isFlagSet(SessionFlags.SentToGateway))
                            {
                                this.PoisonServerPipe();
                            }
                            this.PoisonClientPipe();
                            this.oRequest.pipeClient.End();
                            flag = true;
                            goto Label_0661;
                        }
                        if (CONFIG.bDebugSpew)
                        {
                            FiddlerApplication.DebugSpew("Peeking at the first bytes from CONNECT'd client session {0} yielded:\n{1}", new object[] { this.id, Utilities.ByteArrayToHexView(buffer2, 0x20, iMaxByteCount) });
                        }
                        if ((buffer2[0] == 0x16) || (buffer2[0] == 0x80))
                        {
                            FiddlerApplication.DebugSpew("Session [{0}] looks like a HTTPS tunnel!", new object[] { this.id });
                            try
                            {
                                HTTPSClientHello hello = new HTTPSClientHello();
                                if (hello.LoadFromStream(new MemoryStream(buffer2, 0, iMaxByteCount, false)))
                                {
                                    this.requestBodyBytes = Encoding.UTF8.GetBytes(hello.ToString() + "\n");
                                    this["https-Client-SessionID"] = hello.SessionID;
                                    if (!string.IsNullOrEmpty(hello.ServerNameIndicator))
                                    {
                                        this["https-Client-SNIHostname"] = hello.ServerNameIndicator;
                                    }
                                }
                            }
                            catch (Exception)
                            {
                            }
                            CONNECTTunnel.CreateTunnel(this);
                            flag = true;
                            goto Label_0661;
                        }
                        if ((iMaxByteCount > 4) && ((((((buffer2[0] == 0x47) && (buffer2[1] == 0x45)) && ((buffer2[2] == 0x54) && (buffer2[3] == 0x20))) || (((buffer2[0] == 80) && (buffer2[1] == 0x4f)) && ((buffer2[2] == 0x53) && (buffer2[3] == 0x54)))) || (((buffer2[0] == 80) && (buffer2[1] == 0x55)) && ((buffer2[2] == 0x54) && (buffer2[3] == 0x20)))) || ((((buffer2[0] == 0x48) && (buffer2[1] == 0x45)) && (buffer2[2] == 0x41)) && (buffer2[3] == 0x44))))
                        {
                            FiddlerApplication.DebugSpew("Session [{0}] looks like it's going to be an unencrypted WebSocket tunnel!", new object[] { this.id });
                            this.SetBitFlag(SessionFlags.IsRPCTunnel, true);
                        }
                        else
                        {
                            FiddlerApplication.DebugSpew("Session [{0}] CONNECT Peek yielded unknown protocol!", new object[] { this.id });
                            this.oFlags["x-CONNECT-Peek"] = BitConverter.ToString(buffer2, 0, Math.Min(iMaxByteCount, 0x10));
                            this.oFlags["x-no-decrypt"] = "PeekYieldedUnknownProtocol";
                            CONNECTTunnel.CreateTunnel(this);
                            flag = true;
                            goto Label_0661;
                        }
                    }
                }
                if (bForceClientServerPipeAffinity || this._MayReuseMyClientPipe())
                {
                    FiddlerApplication.DebugSpew("Creating next session with pipes from {0}.", new object[] { this.id });
                    this._createNextSession(bForceClientServerPipeAffinity);
                    flag = true;
                }
                else
                {
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("fiddler.network.clientpipereuse> Closing client socket since bReuseClientSocket was false after returning [{0}]", new object[] { this.url });
                    }
                    this.oRequest.pipeClient.End();
                    flag = true;
                }
                goto Label_0661;
            Label_0616:
                flag = true;
            }
            catch (Exception exception)
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Write to client failed for Session #{0}; exception was {1}", new object[] { this.id, exception.ToString() });
                }
                this.state = SessionStates.Aborted;
                this.PoisonClientPipe();
            }
        Label_0661:
            this.oRequest.pipeClient = null;
            if (flag)
            {
                this.state = SessionStates.Done;
                try
                {
                    this.FinishUISession();
                }
                catch (Exception)
                {
                }
            }
            FiddlerApplication.DoAfterSessionComplete(this);
            if (this.oFlags.ContainsKey("log-drop-response-body") && !Utilities.IsNullOrEmpty(this.responseBodyBytes))
            {
                this.oFlags["x-ResponseBodyFinalLength"] = this.responseBodyBytes.LongLength.ToString("N0");
                this.SetBitFlag(SessionFlags.ResponseBodyDropped, true);
                this.responseBodyBytes = Utilities.emptyByteArray;
            }
            if (this.oFlags.ContainsKey("log-drop-request-body") && !Utilities.IsNullOrEmpty(this.requestBodyBytes))
            {
                this.oFlags["x-RequestBodyFinalLength"] = this.requestBodyBytes.LongLength.ToString("N0");
                this.SetBitFlag(SessionFlags.RequestBodyDropped, true);
                this.requestBodyBytes = Utilities.emptyByteArray;
            }
            return flag;
        }

        internal void RunStateMachine()
        {
            WaitOrTimerCallback callBack = null;
            AsyncCallback onDone = null;
            WaitOrTimerCallback callback3 = null;
            bool flag = false;
        Label_000B:
            switch (this._pState)
            {
                case ProcessingStates.GetRequestStart:
                    if (this._executeObtainRequest())
                    {
                        this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    }
                    else
                    {
                        this._pState = ProcessingStates.Finished;
                    }
                    goto Label_0C14;

                case ProcessingStates.PauseForRequestTampering:
                    if ((this.isAnyFlagSet(SessionFlags.IsRPCTunnel | SessionFlags.RequestStreamed | SessionFlags.Ignored) || !this.oFlags.ContainsKey("x-breakrequest")) || (this.oFlags.ContainsKey("ui-hide") || (this.m_state > SessionStates.HandTamperRequest)))
                    {
                        goto Label_0BB3;
                    }
                    this.state = SessionStates.HandTamperRequest;
                    FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.updateSession), new object[] { this });
                    Utilities.DoFlash(FiddlerApplication._frmMain.Handle);
                    FiddlerApplication._frmMain.notifyIcon.ShowBalloonTip(0x1388, "Fiddler Breakpoint", "Fiddler is paused at a request breakpoint", ToolTipIcon.Warning);
                    this.oSyncEvent = new AutoResetEvent(false);
                    if (callBack == null)
                    {
                        callBack = delegate (object oState, bool bTimedOut) {
                            this._pState = ProcessingStates.ResumeFromRequestTampering;
                            this.RunStateMachine();
                        };
                    }
                    ThreadPool.UnsafeRegisterWaitForSingleObject(this.oSyncEvent, callBack, null, -1, true);
                    flag = true;
                    goto Label_0C14;

                case ProcessingStates.ResumeFromRequestTampering:
                    this._EnsureStateAtLeast(SessionStates.AutoTamperRequestAfter);
                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    goto Label_0C14;

                case ProcessingStates.GetRequestEnd:
                    FiddlerApplication.oExtensions.DoAutoTamperRequestAfter(this);
                    if (this.m_state < SessionStates.Done)
                    {
                        this._smCheckForAutoReply();
                        if (this.HTTPMethodIs("CONNECT"))
                        {
                            this.isTunnel = true;
                            if (this.oFlags.ContainsKey("x-replywithtunnel"))
                            {
                                this._ReturnSelfGeneratedCONNECTTunnel(this.hostname);
                                this._pState = ProcessingStates.Finished;
                                goto Label_0C14;
                            }
                        }
                        if (this.m_state >= SessionStates.ReadingResponse)
                        {
                            if (this.isAnyFlagSet(SessionFlags.ResponseGeneratedByFiddler))
                            {
                                FiddlerApplication.DoResponseHeadersAvailable(this);
                            }
                            this.ExecuteBasicResponseManipulationsUsingHeadersOnly();
                            this._pState = ProcessingStates.ReadResponseEnd;
                        }
                        else
                        {
                            this._smValidateRequestPort();
                            if (this._smReplyWithFile())
                            {
                                this._pState = ProcessingStates.ReadResponseEnd;
                            }
                            else
                            {
                                if (this._isDirectRequestToFiddler())
                                {
                                    if (this.oRequest.headers.RequestPath.OICEndsWith(".pac"))
                                    {
                                        if (this.oRequest.headers.RequestPath.OICEndsWith("/proxy.pac"))
                                        {
                                            this._returnPACFileResponse();
                                            this._pState = ProcessingStates.Finished;
                                            goto Label_0C14;
                                        }
                                        if (this.oRequest.headers.RequestPath.OICEndsWith("/UpstreamProxy.pac"))
                                        {
                                            this._returnUpstreamPACFileResponse();
                                            this._pState = ProcessingStates.Finished;
                                            goto Label_0C14;
                                        }
                                    }
                                    if (this.oRequest.headers.RequestPath.OICEndsWith("/fiddlerroot.cer"))
                                    {
                                        _returnRootCert(this);
                                        this._pState = ProcessingStates.Finished;
                                        goto Label_0C14;
                                    }
                                    if (CONFIG.iReverseProxyForPort == 0)
                                    {
                                        this._returnEchoServiceResponse();
                                        this._pState = ProcessingStates.Finished;
                                        goto Label_0C14;
                                    }
                                    this.oFlags.Add("X-ReverseProxy", "1");
                                    this.host = string.Format("{0}:{1}", CONFIG.sReverseProxyHostname, CONFIG.iReverseProxyForPort);
                                }
                                if (this._pState == ProcessingStates.GetRequestEnd)
                                {
                                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                                }
                            }
                        }
                        goto Label_0C14;
                    }
                    return;

                case ProcessingStates.ConnectStart:
                    this.state = SessionStates.SendingRequest;
                    if (!this.isFTP || this.isFlagSet(SessionFlags.SentToGateway))
                    {
                        if (onDone == null)
                        {
                            onDone = delegate (IAsyncResult unused) {
                                if (this.state >= SessionStates.Done)
                                {
                                    this._pState = ProcessingStates.Finished;
                                }
                                else
                                {
                                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                                }
                                this.RunStateMachine();
                            };
                        }
                        this.oResponse.BeginAsyncConnectToHost(onDone);
                        flag = true;
                    }
                    else
                    {
                        this._pState = ProcessingStates.ReadResponseStart;
                    }
                    goto Label_0C14;

                case ProcessingStates.SendRequestStart:
                {
                    this._EnsureStateAtLeast(SessionStates.SendingRequest);
                    bool flag2 = false;
                    try
                    {
                        this.oResponse.SendRequest();
                        flag2 = true;
                    }
                    catch (Exception exception)
                    {
                        if (this.oResponse._MayRetryWhenSendFailed())
                        {
                            StringDictionary dictionary;
                            this.oResponse.pipeServer = null;
                            (dictionary = this.oFlags)["x-RetryOnFailedSend"] = dictionary["x-RetryOnFailedSend"] + "*";
                            FiddlerApplication.DebugSpew("[{0}] ServerSocket Reuse failed during SendRequest(). Restarting fresh.", new object[] { this.id });
                            this._pState = ProcessingStates.ConnectStart;
                            goto Label_0C14;
                        }
                        FiddlerApplication.DebugSpew("SendRequest() failed: {0}", new object[] { Utilities.DescribeException(exception) });
                        this.oRequest.FailSession(0x1f8, "Fiddler - Send Failure", "[Fiddler] SendRequest() failed: " + Utilities.DescribeException(exception));
                    }
                    if ((this.oFlags.ContainsKey("log-drop-request-body") && !Utilities.IsNullOrEmpty(this.requestBodyBytes)) && !this.isAnyFlagSet(SessionFlags.IsRPCTunnel | SessionFlags.RequestStreamed))
                    {
                        this._smDropRequestBody();
                    }
                    if (!flag2)
                    {
                        this.CloseSessionPipes(true);
                        this.state = SessionStates.Aborted;
                        this._pState = ProcessingStates.Finished;
                    }
                    else if (this.isFlagSet(SessionFlags.RequestStreamed) && !this.oResponse.StreamRequestBody())
                    {
                        this.CloseSessionPipes(true);
                        this.state = SessionStates.Aborted;
                        this._pState = ProcessingStates.Finished;
                    }
                    else
                    {
                        this.Timers.ServerGotRequest = DateTime.Now;
                        if (this.isFlagSet(SessionFlags.IsRPCTunnel))
                        {
                            bool bStreamResponse = false;
                            GenericTunnel.CreateTunnel(this, bStreamResponse);
                            if (bStreamResponse)
                            {
                                this._pState = ProcessingStates.Finished;
                                goto Label_0C14;
                            }
                        }
                        this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    }
                    goto Label_0C14;
                }
                case ProcessingStates.ReadResponseStart:
                    this.state = SessionStates.ReadingResponse;
                    if ((this.ViewItem != null) || !this.ShouldBeHidden())
                    {
                        FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.updateSession), new object[] { this });
                    }
                    if (this.HTTPMethodIs("CONNECT") && !this.oResponse.m_bWasForwarded)
                    {
                        this._BuildConnectionEstablishedReply();
                        break;
                    }
                    if (this.oResponse.ReadResponse())
                    {
                        if ((200 == this.responseCode) && this.isFlagSet(SessionFlags.IsRPCTunnel))
                        {
                            this._smInitiateRPCStreaming();
                            this._pState = ProcessingStates.Finished;
                            goto Label_0C14;
                        }
                        if (this.isAnyFlagSet(SessionFlags.ResponseBodyDropped))
                        {
                            this.responseBodyBytes = Utilities.emptyByteArray;
                            this.oResponse.FreeResponseDataBuffer();
                        }
                        else
                        {
                            long num;
                            this.responseBodyBytes = this.oResponse.TakeEntity();
                            if ((this.oResponse.headers.Exists("Content-Length") && !this.HTTPMethodIs("HEAD")) && (long.TryParse(this.oResponse.headers["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num) && (num != this.responseBodyBytes.LongLength)))
                            {
                                FiddlerApplication.HandleHTTPError(this, SessionFlags.ProtocolViolationInResponse, true, true, string.Format("Content-Length mismatch: Response Header indicated {0:N0} bytes, but server sent {1:N0} bytes.", num, this.responseBodyBytes.LongLength));
                            }
                        }
                        break;
                    }
                    if (this._MayRetryWhenReceiveFailed())
                    {
                        StringDictionary dictionary2;
                        FiddlerApplication.DebugSpew("[{0}] ServerSocket Reuse failed. Restarting fresh.", new object[] { this.id });
                        (dictionary2 = this.oFlags)["x-RetryOnFailedReceive"] = dictionary2["x-RetryOnFailedReceive"] + "*";
                        this.oResponse.Initialize(true);
                        this._pState = ProcessingStates.ConnectStart;
                    }
                    else
                    {
                        FiddlerApplication.DebugSpew("Failed to read server response and retry is forbidden. Aborting Session #{0}", new object[] { this.id });
                        this.oResponse.FreeResponseDataBuffer();
                        if (this.state != SessionStates.Aborted)
                        {
                            string str = string.Empty;
                            if (!Utilities.IsNullOrEmpty(this.responseBodyBytes))
                            {
                                str = Encoding.UTF8.GetString(this.responseBodyBytes);
                            }
                            str = string.Format("[Fiddler] ReadResponse() failed: The server did not return a complete response for this request. Server returned {0:N0} bytes. {1}", this.oResponse.m_responseTotalDataCount, str);
                            if (!this.oResponse.bLeakedHeaders)
                            {
                                this.oRequest.FailSession(0x1f8, "Fiddler - Receive Failure", str);
                            }
                            else
                            {
                                try
                                {
                                    this._BuildReceiveFailureReply(str);
                                    this.oRequest.pipeClient.EndWithRST();
                                }
                                catch
                                {
                                }
                            }
                        }
                        this.CloseSessionPipes(true);
                        this.state = SessionStates.Aborted;
                        this._pState = ProcessingStates.Finished;
                    }
                    goto Label_0C14;

                case ProcessingStates.ReadResponseEnd:
                    if (!this.isFlagSet(SessionFlags.ResponseBodyDropped))
                    {
                        this.oFlags["x-ResponseBodyTransferLength"] = (this.responseBodyBytes == null) ? "0" : this.responseBodyBytes.LongLength.ToString("N0");
                    }
                    this.state = SessionStates.AutoTamperResponseBefore;
                    if (CONFIG.bReportHTTPLintErrors)
                    {
                        this.ExecuteHTTPLintOnResponse();
                    }
                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    goto Label_0C14;

                case ProcessingStates.RunResponseRulesStart:
                    this.ExecuteBasicResponseManipulations();
                    FiddlerApplication.DoBeforeResponse(this);
                    FiddlerApplication.oExtensions.DoAutoTamperResponseBefore(this);
                    if (!this._smIsResponseAutoHandled())
                    {
                        if ((this.m_state >= SessionStates.Done) || this.isFlagSet(SessionFlags.ResponseStreamed))
                        {
                            this.FinishUISession();
                            if (this.isFlagSet(SessionFlags.ResponseStreamed) && this.oFlags.ContainsKey("log-drop-response-body"))
                            {
                                this.SetBitFlag(SessionFlags.ResponseBodyDropped, true);
                                this.responseBodyBytes = Utilities.emptyByteArray;
                            }
                            this.bLeakedResponseAlready = true;
                        }
                        if (this.bLeakedResponseAlready)
                        {
                            this._EnsureStateAtLeast(SessionStates.Done);
                            FiddlerApplication.DoAfterSessionComplete(this);
                            this._pState = ProcessingStates.ReturnBufferedResponseStart;
                        }
                        else
                        {
                            if (this.oFlags.ContainsKey("x-replywithfile"))
                            {
                                this.LoadResponseFromFile(this.oFlags["x-replywithfile"]);
                                this.oFlags["x-replacedwithfile"] = this.oFlags["x-replywithfile"];
                                this.oFlags.Remove("x-replywithfile");
                            }
                            this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                        }
                    }
                    else
                    {
                        this._pState = ProcessingStates.Finished;
                    }
                    goto Label_0C14;

                case ProcessingStates.PauseForResponseTampering:
                    if ((!this.oFlags.ContainsKey("x-breakresponse") || this.oFlags.ContainsKey("ui-hide")) || this.isFlagSet(SessionFlags.Ignored))
                    {
                        goto Label_0BB3;
                    }
                    this.state = SessionStates.HandTamperResponse;
                    FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.updateSession), new object[] { this });
                    Utilities.DoFlash(FiddlerApplication._frmMain.Handle);
                    FiddlerApplication._frmMain.notifyIcon.ShowBalloonTip(0x1388, "Fiddler Breakpoint", "Fiddler is paused at a response breakpoint", ToolTipIcon.Warning);
                    this.oSyncEvent = new AutoResetEvent(false);
                    if (callback3 == null)
                    {
                        callback3 = delegate (object oState, bool bTimedOut) {
                            this._pState = ProcessingStates.ResumeFromResponseTampering;
                            this.RunStateMachine();
                        };
                    }
                    ThreadPool.UnsafeRegisterWaitForSingleObject(this.oSyncEvent, callback3, null, -1, true);
                    flag = true;
                    goto Label_0C14;

                case ProcessingStates.ResumeFromResponseTampering:
                    if (this.oSyncEvent != null)
                    {
                        this.oSyncEvent.Close();
                        this.oSyncEvent = null;
                    }
                    if (this.m_state >= SessionStates.Done)
                    {
                        this._pState = ProcessingStates.Finished;
                    }
                    else
                    {
                        this.state = SessionStates.AutoTamperResponseAfter;
                        FiddlerApplication.oExtensions.DoAutoTamperResponseAfter(this);
                        this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    }
                    goto Label_0C14;

                case ProcessingStates.ReturnBufferedResponseStart:
                {
                    bool bForceClientServerPipeAffinity = false;
                    if (this._isResponseMultiStageAuthChallenge())
                    {
                        bForceClientServerPipeAffinity = this._isNTLMType2();
                    }
                    if (this.m_state >= SessionStates.Done)
                    {
                        this.FinishUISession();
                        this.bLeakedResponseAlready = true;
                    }
                    if (!this.bLeakedResponseAlready)
                    {
                        this.ReturnResponse(bForceClientServerPipeAffinity);
                    }
                    if (this.bLeakedResponseAlready && (this.oRequest.pipeClient != null))
                    {
                        if (bForceClientServerPipeAffinity || this._MayReuseMyClientPipe())
                        {
                            this._createNextSession(bForceClientServerPipeAffinity);
                        }
                        else
                        {
                            this.oRequest.pipeClient.End();
                        }
                        this.oRequest.pipeClient = null;
                    }
                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    goto Label_0C14;
                }
                case ProcessingStates.ReturnBufferedResponseEnd:
                    this.oResponse.releaseServerPipe();
                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    goto Label_0C14;

                case ProcessingStates.DoAfterSessionEventStart:
                    this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
                    goto Label_0C14;

                case ProcessingStates.Finished:
                    this._EnsureStateAtLeast(SessionStates.Done);
                    if (this.nextSession != null)
                    {
                        this.nextSession.ExecuteWhenDataAvailable();
                        this.nextSession = null;
                    }
                    flag = true;
                    goto Label_0C14;

                default:
                    goto Label_0BB3;
            }
            this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
            goto Label_0C14;
        Label_0BB3:
            if (this._pState > ProcessingStates.Finished)
            {
                FiddlerApplication.Log.LogFormat("! CRITICAL ERROR: State machine will live forever... Session {0} with state {1} has pState {2}", new object[] { this.id, this.state, this._pState });
                flag = true;
            }
            this._pState = (ProcessingStates) ((byte) (((int) this._pState) + 1));
        Label_0C14:
            if (!flag)
            {
                goto Label_000B;
            }
        }

        public bool SaveMetadata(string sFilename)
        {
            try
            {
                FileStream strmMetadata = new FileStream(sFilename, FileMode.Create, FileAccess.Write);
                this.WriteMetadataToStream(strmMetadata);
                strmMetadata.Close();
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
                return false;
            }
        }

        public void SaveRequest(string sFilename, bool bHeadersOnly)
        {
            this.SaveRequest(sFilename, bHeadersOnly, false);
        }

        public void SaveRequest(string sFilename, bool bHeadersOnly, bool bIncludeSchemeAndHostInPath)
        {
            Utilities.EnsureOverwritable(sFilename);
            using (FileStream stream = new FileStream(sFilename, FileMode.Create, FileAccess.Write))
            {
                if (this.oRequest.headers != null)
                {
                    byte[] buffer = this.oRequest.headers.ToByteArray(true, true, bIncludeSchemeAndHostInPath, this.oFlags["X-OverrideHost"]);
                    stream.Write(buffer, 0, buffer.Length);
                    if (!bHeadersOnly && (this.requestBodyBytes != null))
                    {
                        stream.Write(this.requestBodyBytes, 0, this.requestBodyBytes.Length);
                    }
                }
            }
        }

        [CodeDescription("Save HTTP request body to specified location.")]
        public bool SaveRequestBody(string sFilename)
        {
            try
            {
                Utilities.WriteArrayToFile(sFilename, this.requestBodyBytes);
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception.Message + "\n\n" + sFilename, "Save Failed");
                return false;
            }
        }

        public void SaveResponse(string sFilename, bool bHeadersOnly)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(sFilename));
            FileStream stream = new FileStream(sFilename, FileMode.Create, FileAccess.Write);
            if (this.oResponse.headers != null)
            {
                byte[] buffer = this.oResponse.headers.ToByteArray(true, true);
                stream.Write(buffer, 0, buffer.Length);
                if (!bHeadersOnly && (this.responseBodyBytes != null))
                {
                    stream.Write(this.responseBodyBytes, 0, this.responseBodyBytes.Length);
                }
            }
            stream.Close();
        }

        [CodeDescription("Save HTTP response body to Fiddler Captures folder.")]
        public bool SaveResponseBody()
        {
            string path = CONFIG.GetPath("Captures");
            StringBuilder builder = new StringBuilder();
            builder.Append(this.SuggestedFilename);
            while (System.IO.File.Exists(path + builder.ToString()))
            {
                builder.Insert(0, this.id.ToString() + "_");
            }
            builder.Insert(0, path);
            return this.SaveResponseBody(builder.ToString());
        }

        [CodeDescription("Save HTTP response body to specified location.")]
        public bool SaveResponseBody(string sFilename)
        {
            try
            {
                Utilities.WriteArrayToFile(sFilename, this.responseBodyBytes);
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception.Message + "\n\n" + sFilename, "Save Failed");
                return false;
            }
        }

        public void SaveSession(string sFilename, bool bHeadersOnly)
        {
            Utilities.EnsureOverwritable(sFilename);
            using (FileStream stream = new FileStream(sFilename, FileMode.Create, FileAccess.Write))
            {
                this.WriteToStream(stream, bHeadersOnly);
            }
        }

        internal void SetBitFlag(SessionFlags FlagsToSet, bool b)
        {
            if (b)
            {
                this.BitFlags = this._bitFlags | FlagsToSet;
            }
            else
            {
                this.BitFlags = this._bitFlags & ~FlagsToSet;
            }
        }

        internal bool ShouldBeHidden()
        {
            if (!FiddlerApplication.isClosing)
            {
                if (this.isFlagSet(SessionFlags.Ignored))
                {
                    return true;
                }
                if (!this.oFlags.ContainsKey("ui-hide"))
                {
                    return false;
                }
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.filters.ephemeral.debugmode", false))
                {
                    this.oFlags["ui-strikeout"] = "filterdebug";
                    this.oFlags["ui-comments"] = string.Format("Hidden due to {0}. {1}", this.oFlags["ui-hide"], this.oFlags["ui-comments"]);
                    return false;
                }
                if (CONFIG.bReportHTTPErrors && this.isAnyFlagSet(SessionFlags.ProtocolViolationInResponse | SessionFlags.ProtocolViolationInRequest))
                {
                    return false;
                }
                if (this.isFlagSet(SessionFlags.RequestGeneratedByFiddler) && !this.oFlags["ui-hide"].Contains("stealth"))
                {
                    return false;
                }
            }
            return true;
        }

        public void ThreadResume()
        {
            if (this.oSyncEvent != null)
            {
                try
                {
                    this.oSyncEvent.Set();
                }
                catch (Exception)
                {
                }
            }
        }

        public string ToHTMLFragment(bool HeadersOnly)
        {
            if (!Utilities.HasHeaders(this.oRequest))
            {
                return string.Empty;
            }
            StringBuilder builder = new StringBuilder();
            builder.Append("<span class='REQUEST'>");
            builder.Append(Utilities.HtmlEncode(this.oRequest.headers.ToString(true, true, true)).Replace("\r\n", "<br />"));
            if (!HeadersOnly && !Utilities.IsNullOrEmpty(this.requestBodyBytes))
            {
                Encoding requestBodyEncoding = this.GetRequestBodyEncoding();
                builder.Append(Utilities.HtmlEncode(requestBodyEncoding.GetString(this.requestBodyBytes)).Replace("\r\n", "<br />"));
            }
            builder.Append("</span><br />");
            if (Utilities.HasHeaders(this.oResponse))
            {
                builder.Append("<span class='RESPONSE'>");
                builder.Append(Utilities.HtmlEncode(this.oResponse.headers.ToString(true, true)).Replace("\r\n", "<br />"));
                if (!HeadersOnly && !Utilities.IsNullOrEmpty(this.responseBodyBytes))
                {
                    Encoding encoding2 = Utilities.getResponseBodyEncoding(this);
                    builder.Append(Utilities.HtmlEncode(encoding2.GetString(this.responseBodyBytes)).Replace("\r\n", "<br />"));
                }
                builder.Append("</span>");
            }
            return builder.ToString();
        }

        public override string ToString()
        {
            return this.ToString(false);
        }

        public string ToString(bool HeadersOnly)
        {
            if (!Utilities.HasHeaders(this.oRequest))
            {
                return string.Empty;
            }
            StringBuilder builder = new StringBuilder();
            builder.Append(this.oRequest.headers.ToString(true, true, true));
            if (!HeadersOnly && !Utilities.IsNullOrEmpty(this.requestBodyBytes))
            {
                Encoding requestBodyEncoding = this.GetRequestBodyEncoding();
                builder.Append(requestBodyEncoding.GetString(this.requestBodyBytes));
            }
            builder.Append("\r\n");
            if (Utilities.HasHeaders(this.oResponse))
            {
                builder.Append(this.oResponse.headers.ToString(true, true));
                if (!HeadersOnly && !Utilities.IsNullOrEmpty(this.responseBodyBytes))
                {
                    Encoding encoding2 = Utilities.getResponseBodyEncoding(this);
                    builder.Append(encoding2.GetString(this.responseBodyBytes));
                }
                builder.Append("\r\n");
            }
            return builder.ToString();
        }

        public void UNSTABLE_SetBitFlag(SessionFlags FlagsToSet, bool b)
        {
            this.SetBitFlag(FlagsToSet, b);
        }

        [CodeDescription("Returns true if request URI contains the specified string. Case-insensitive.")]
        public bool uriContains(string sLookfor)
        {
            return this.fullUrl.OICContains(sLookfor);
        }

        [CodeDescription("Copy an existing Session's response to this Session, bypassing the server if not already contacted")]
        public void utilAssignResponse(Session oFromSession)
        {
            this.utilAssignResponse(oFromSession.oResponse.headers, oFromSession.responseBodyBytes);
        }

        [CodeDescription("Copy an existing response to this Session, bypassing the server if not already contacted")]
        public void utilAssignResponse(HTTPResponseHeaders oRH, byte[] arrBody)
        {
            if (this.oResponse == null)
            {
                this.oResponse = new ServerChatter(this, "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n");
            }
            if (oRH == null)
            {
                this.oResponse.headers = new HTTPResponseHeaders();
                this.oResponse.headers.SetStatus(200, "Fiddler-Generated");
            }
            else
            {
                this.oResponse.headers = (HTTPResponseHeaders) oRH.Clone();
            }
            this.responseBodyBytes = arrBody ?? Utilities.emptyByteArray;
            this.oFlags["x-Fiddler-Generated"] = "utilAssignResponse";
            this.BitFlags |= SessionFlags.ResponseGeneratedByFiddler;
            this.bBufferResponse = true;
            this.state = SessionStates.AutoTamperResponseBefore;
        }

        [CodeDescription("Use BZIP2 to compress the response body. Throws exceptions to caller.")]
        public bool utilBZIP2Response()
        {
            if (!this._mayCompressResponse())
            {
                return false;
            }
            this.responseBodyBytes = Utilities.bzip2Compress(this.responseBodyBytes);
            this.oResponse.headers["Content-Encoding"] = "bzip2";
            this.oResponse.headers["Content-Length"] = (this.responseBodyBytes == null) ? "0" : this.responseBodyBytes.LongLength.ToString();
            return true;
        }

        [CodeDescription("Apply Transfer-Encoding: chunked to the response, if possible.")]
        public bool utilChunkResponse(int iSuggestedChunkCount)
        {
            if ((((!Utilities.HasHeaders(this.oRequest) || !"HTTP/1.1".OICEquals(this.oRequest.headers.HTTPVersion)) || (this.HTTPMethodIs("HEAD") || this.HTTPMethodIs("CONNECT"))) || ((!Utilities.HasHeaders(this.oResponse) || !Utilities.HTTPStatusAllowsBody(this.oResponse.headers.HTTPResponseCode)) || ((this.responseBodyBytes != null) && (this.responseBodyBytes.LongLength > 0x7fffffffL)))) || this.oResponse.headers.Exists("Transfer-Encoding"))
            {
                return false;
            }
            this.responseBodyBytes = Utilities.doChunk(this.responseBodyBytes, iSuggestedChunkCount);
            this.oResponse.headers.Remove("Content-Length");
            this.oResponse.headers["Transfer-Encoding"] = "chunked";
            return true;
        }

        [CodeDescription("Call inside OnBeforeRequest to create a Response object and bypass the server.")]
        public void utilCreateResponseAndBypassServer()
        {
            if (this.state > SessionStates.SendingRequest)
            {
                throw new InvalidOperationException("Too late, we're already talking to the server.");
            }
            if (this.isFlagSet(SessionFlags.RequestStreamed))
            {
                this.oResponse.StreamRequestBody();
            }
            this.oResponse = new ServerChatter(this, "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n");
            this.responseBodyBytes = Utilities.emptyByteArray;
            this.oFlags["x-Fiddler-Generated"] = "utilCreateResponseAndBypassServer";
            this.BitFlags |= SessionFlags.ResponseGeneratedByFiddler;
            this.bBufferResponse = true;
            this.state = SessionStates.AutoTamperResponseBefore;
        }

        [CodeDescription("Removes chunking and HTTP Compression from the Request. Adds or updates Content-Length header.")]
        public bool utilDecodeRequest()
        {
            return this.utilDecodeRequest(false);
        }

        public bool utilDecodeRequest(bool bSilent)
        {
            if (!Utilities.HasHeaders(this.oRequest) || (!this.oRequest.headers.Exists("Transfer-Encoding") && !this.oRequest.headers.Exists("Content-Encoding")))
            {
                return false;
            }
            try
            {
                Utilities.utilTryDecode(this.oRequest.headers, ref this.requestBodyBytes, bSilent);
            }
            catch (Exception exception)
            {
                if (!bSilent)
                {
                    FiddlerApplication.ReportException(exception, "utilDecodeRequest failed for Session #" + this.id.ToString(), "The HTTP request body was malformed.");
                }
                this.oFlags["x-UtilDecodeRequest"] = Utilities.DescribeException(exception);
                this.oFlags["ui-backcolor"] = "LightYellow";
                return false;
            }
            return true;
        }

        [CodeDescription("Removes chunking and HTTP Compression from the response. Adds or updates Content-Length header.")]
        public bool utilDecodeResponse()
        {
            return this.utilDecodeResponse(false);
        }

        public bool utilDecodeResponse(bool bSilent)
        {
            if (!Utilities.HasHeaders(this.oResponse) || (!this.oResponse.headers.Exists("Transfer-Encoding") && !this.oResponse.headers.Exists("Content-Encoding")))
            {
                return false;
            }
            try
            {
                Utilities.utilTryDecode(this.oResponse.headers, ref this.responseBodyBytes, bSilent);
            }
            catch (Exception exception)
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("utilDecodeResponse failed. The HTTP response body was malformed. " + Utilities.DescribeException(exception));
                }
                if (!bSilent)
                {
                    FiddlerApplication.ReportException(exception, "utilDecodeResponse failed for Session #" + this.id.ToString(), "The HTTP response body was malformed.");
                }
                this.oFlags["x-UtilDecodeResponse"] = Utilities.DescribeException(exception);
                this.oFlags["ui-backcolor"] = "LightYellow";
                return false;
            }
            return true;
        }

        [CodeDescription("Use DEFLATE to compress the response body. Throws exceptions to caller.")]
        public bool utilDeflateResponse()
        {
            if (!this._mayCompressResponse())
            {
                return false;
            }
            this.responseBodyBytes = Utilities.DeflaterCompress(this.responseBodyBytes);
            this.oResponse.headers["Content-Encoding"] = "deflate";
            this.oResponse.headers["Content-Length"] = (this.responseBodyBytes == null) ? "0" : this.responseBodyBytes.LongLength.ToString();
            return true;
        }

        [CodeDescription("Find a string in the request body. Return its index or -1.")]
        public int utilFindInRequest(string sSearchFor, bool bCaseSensitive)
        {
            if (!this._HasRequestBody())
            {
                return -1;
            }
            return Utilities.getEntityBodyEncoding(this.oRequest.headers, this.requestBodyBytes).GetString(this.requestBodyBytes).IndexOf(sSearchFor, bCaseSensitive ? StringComparison.InvariantCulture : StringComparison.InvariantCultureIgnoreCase);
        }

        [CodeDescription("Find a string in the response body. Return its index or -1. Note, you should call utilDecodeResponse first!")]
        public int utilFindInResponse(string sSearchFor, bool bCaseSensitive)
        {
            if (!this._HasResponseBody())
            {
                return -1;
            }
            return Utilities.getResponseBodyEncoding(this).GetString(this.responseBodyBytes).IndexOf(sSearchFor, bCaseSensitive ? StringComparison.InvariantCulture : StringComparison.InvariantCultureIgnoreCase);
        }

        [CodeDescription("Use GZIP to compress the request body. Throws exceptions to caller.")]
        public bool utilGZIPRequest()
        {
            if (!this._mayCompressRequest())
            {
                return false;
            }
            this.requestBodyBytes = Utilities.GzipCompress(this.requestBodyBytes);
            this.oRequest.headers["Content-Encoding"] = "gzip";
            this.oRequest.headers["Content-Length"] = (this.requestBodyBytes == null) ? "0" : this.requestBodyBytes.LongLength.ToString();
            return true;
        }

        [CodeDescription("Use GZIP to compress the response body. Throws exceptions to caller.")]
        public bool utilGZIPResponse()
        {
            if (!this._mayCompressResponse())
            {
                return false;
            }
            this.responseBodyBytes = Utilities.GzipCompress(this.responseBodyBytes);
            this.oResponse.headers["Content-Encoding"] = "gzip";
            this.oResponse.headers["Content-Length"] = (this.responseBodyBytes == null) ? "0" : this.responseBodyBytes.LongLength.ToString();
            return true;
        }

        [CodeDescription("Prepend a string to the response body. Updates Content-Length header. Note, you should call utilDecodeResponse first!")]
        public void utilPrependToResponseBody(string sString)
        {
            if (this.responseBodyBytes == null)
            {
                this.responseBodyBytes = Utilities.emptyByteArray;
            }
            Encoding encoding = Utilities.getResponseBodyEncoding(this);
            this.responseBodyBytes = Utilities.JoinByteArrays(encoding.GetBytes(sString), this.responseBodyBytes);
            this.oResponse.headers["Content-Length"] = this.responseBodyBytes.LongLength.ToString();
        }

        [CodeDescription("Perform a case-sensitive string replacement on the request body (not URL!). Updates Content-Length header. Returns TRUE if replacements occur.")]
        public bool utilReplaceInRequest(string sSearchFor, string sReplaceWith)
        {
            if (this._HasRequestBody() && Utilities.HasHeaders(this.oRequest))
            {
                string requestBodyAsString = this.GetRequestBodyAsString();
                string sString = requestBodyAsString.Replace(sSearchFor, sReplaceWith);
                if (requestBodyAsString != sString)
                {
                    this.utilSetRequestBody(sString);
                    return true;
                }
            }
            return false;
        }

        [CodeDescription("Perform a case-sensitive string replacement on the response body. Updates Content-Length header. Note, you should call utilDecodeResponse first!  Returns TRUE if replacements occur.")]
        public bool utilReplaceInResponse(string sSearchFor, string sReplaceWith)
        {
            return this._innerReplaceInResponse(sSearchFor, sReplaceWith, true, true);
        }

        [CodeDescription("Perform a single case-sensitive string replacement on the response body. Updates Content-Length header. Note, you should call utilDecodeResponse first! Returns TRUE if replacements occur.")]
        public bool utilReplaceOnceInResponse(string sSearchFor, string sReplaceWith, bool bCaseSensitive)
        {
            return this._innerReplaceInResponse(sSearchFor, sReplaceWith, false, bCaseSensitive);
        }

        [CodeDescription("Perform a regex-based replacement on the response body. Specify RegEx Options via leading Inline Flags, e.g. (?im) for case-Insensitive Multi-line. Updates Content-Length header. Note, you should call utilDecodeResponse first!  Returns TRUE if replacements occur.")]
        public bool utilReplaceRegexInResponse(string sSearchForRegEx, string sReplaceWithExpression)
        {
            if (this._HasResponseBody())
            {
                Encoding encoding = Utilities.getResponseBodyEncoding(this);
                string input = encoding.GetString(this.responseBodyBytes);
                string s = Regex.Replace(input, sSearchForRegEx, sReplaceWithExpression, RegexOptions.Singleline | RegexOptions.ExplicitCapture);
                if (input != s)
                {
                    this.responseBodyBytes = encoding.GetBytes(s);
                    this.oResponse["Content-Length"] = this.responseBodyBytes.LongLength.ToString();
                    return true;
                }
            }
            return false;
        }

        [CodeDescription("Replaces the request body with sString. Sets Content-Length header & removes Transfer-Encoding/Content-Encoding")]
        public void utilSetRequestBody(string sString)
        {
            if (sString == null)
            {
                sString = string.Empty;
            }
            this.oRequest.headers.Remove("Transfer-Encoding");
            this.oRequest.headers.Remove("Content-Encoding");
            this.requestBodyBytes = Utilities.getEntityBodyEncoding(this.oRequest.headers, null).GetBytes(sString);
            this.oRequest["Content-Length"] = this.requestBodyBytes.LongLength.ToString();
        }

        [CodeDescription("Replaces the response body with sString. Sets Content-Length header & removes Transfer-Encoding/Content-Encoding")]
        public void utilSetResponseBody(string sString)
        {
            if (sString == null)
            {
                sString = string.Empty;
            }
            this.oResponse.headers.Remove("Transfer-Encoding");
            this.oResponse.headers.Remove("Content-Encoding");
            this.responseBodyBytes = Utilities.getResponseBodyEncoding(this).GetBytes(sString);
            this.oResponse["Content-Length"] = this.responseBodyBytes.LongLength.ToString();
        }

        public void WriteMetadataToStream(Stream strmMetadata)
        {
            XmlTextWriter writer = new XmlTextWriter(strmMetadata, Encoding.UTF8);
            writer.Formatting = Formatting.Indented;
            writer.WriteStartDocument();
            writer.WriteStartElement("Session");
            writer.WriteAttributeString("SID", this.id.ToString());
            writer.WriteAttributeString("BitFlags", ((int) this.BitFlags).ToString("x"));
            if (this.m_state == SessionStates.Aborted)
            {
                writer.WriteAttributeString("Aborted", XmlConvert.ToString(true));
            }
            writer.WriteStartElement("SessionTimers");
            writer.WriteAttributeString("ClientConnected", XmlConvert.ToString(this.Timers.ClientConnected, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ClientBeginRequest", XmlConvert.ToString(this.Timers.ClientBeginRequest, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("GotRequestHeaders", XmlConvert.ToString(this.Timers.FiddlerGotRequestHeaders, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ClientDoneRequest", XmlConvert.ToString(this.Timers.ClientDoneRequest, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("GatewayTime", XmlConvert.ToString(this.Timers.GatewayDeterminationTime));
            writer.WriteAttributeString("DNSTime", XmlConvert.ToString(this.Timers.DNSTime));
            writer.WriteAttributeString("TCPConnectTime", XmlConvert.ToString(this.Timers.TCPConnectTime));
            writer.WriteAttributeString("HTTPSHandshakeTime", XmlConvert.ToString(this.Timers.HTTPSHandshakeTime));
            writer.WriteAttributeString("ServerConnected", XmlConvert.ToString(this.Timers.ServerConnected, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("FiddlerBeginRequest", XmlConvert.ToString(this.Timers.FiddlerBeginRequest, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ServerGotRequest", XmlConvert.ToString(this.Timers.ServerGotRequest, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ServerBeginResponse", XmlConvert.ToString(this.Timers.ServerBeginResponse, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("GotResponseHeaders", XmlConvert.ToString(this.Timers.FiddlerGotResponseHeaders, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ServerDoneResponse", XmlConvert.ToString(this.Timers.ServerDoneResponse, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ClientBeginResponse", XmlConvert.ToString(this.Timers.ClientBeginResponse, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteAttributeString("ClientDoneResponse", XmlConvert.ToString(this.Timers.ClientDoneResponse, XmlDateTimeSerializationMode.RoundtripKind));
            writer.WriteEndElement();
            writer.WriteStartElement("PipeInfo");
            if (!this.bBufferResponse)
            {
                writer.WriteAttributeString("Streamed", XmlConvert.ToString(true));
            }
            if ((this.oRequest != null) && this.oRequest.bClientSocketReused)
            {
                writer.WriteAttributeString("CltReuse", XmlConvert.ToString(true));
            }
            if (this.oResponse != null)
            {
                if (this.oResponse.bServerSocketReused)
                {
                    writer.WriteAttributeString("Reused", XmlConvert.ToString(true));
                }
                if (this.oResponse.bWasForwarded)
                {
                    writer.WriteAttributeString("Forwarded", XmlConvert.ToString(true));
                }
            }
            writer.WriteEndElement();
            if (this.isTunnel && (this.__oTunnel != null))
            {
                writer.WriteStartElement("TunnelInfo");
                writer.WriteAttributeString("BytesEgress", XmlConvert.ToString(this.__oTunnel.EgressByteCount));
                writer.WriteAttributeString("BytesIngress", XmlConvert.ToString(this.__oTunnel.IngressByteCount));
                writer.WriteEndElement();
            }
            writer.WriteStartElement("SessionFlags");
            foreach (string str in this.oFlags.Keys)
            {
                writer.WriteStartElement("SessionFlag");
                writer.WriteAttributeString("N", str);
                writer.WriteAttributeString("V", this.oFlags[str]);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Flush();
        }

        public bool WriteRequestToStream(bool bHeadersOnly, bool bIncludeProtocolAndHostWithPath, Stream oFS)
        {
            return this.WriteRequestToStream(bHeadersOnly, bIncludeProtocolAndHostWithPath, false, oFS);
        }

        public bool WriteRequestToStream(bool bHeadersOnly, bool bIncludeProtocolAndHostWithPath, bool bEncodeIfBinary, Stream oFS)
        {
            if (!Utilities.HasHeaders(this.oRequest))
            {
                return false;
            }
            bool flag = ((bEncodeIfBinary && !bHeadersOnly) && (this.requestBodyBytes != null)) && Utilities.arrayContainsNonText(this.requestBodyBytes);
            HTTPRequestHeaders headers = this.oRequest.headers;
            if (flag)
            {
                headers = (HTTPRequestHeaders) headers.Clone();
                headers["Fiddler-Encoding"] = "base64";
            }
            byte[] buffer = headers.ToByteArray(true, true, bIncludeProtocolAndHostWithPath, this.oFlags["X-OverrideHost"]);
            oFS.Write(buffer, 0, buffer.Length);
            if (flag)
            {
                byte[] bytes = Encoding.ASCII.GetBytes(Convert.ToBase64String(this.requestBodyBytes));
                oFS.Write(bytes, 0, bytes.Length);
                return true;
            }
            if (!bHeadersOnly && !Utilities.IsNullOrEmpty(this.requestBodyBytes))
            {
                oFS.Write(this.requestBodyBytes, 0, this.requestBodyBytes.Length);
            }
            return true;
        }

        public bool WriteResponseToStream(Stream oFS, bool bHeadersOnly)
        {
            if (!Utilities.HasHeaders(this.oResponse))
            {
                return false;
            }
            byte[] buffer = this.oResponse.headers.ToByteArray(true, true);
            oFS.Write(buffer, 0, buffer.Length);
            if (!bHeadersOnly && !Utilities.IsNullOrEmpty(this.responseBodyBytes))
            {
                oFS.Write(this.responseBodyBytes, 0, this.responseBodyBytes.Length);
            }
            return true;
        }

        [CodeDescription("Write the session (or session headers) to the specified stream")]
        public bool WriteToStream(Stream oFS, bool bHeadersOnly)
        {
            try
            {
                this.WriteRequestToStream(bHeadersOnly, true, oFS);
                oFS.WriteByte(13);
                oFS.WriteByte(10);
                this.WriteResponseToStream(oFS, bHeadersOnly);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        internal bool WriteWebSocketMessagesToStream(Stream oFS)
        {
            WebSocket socket = this.__oTunnel as WebSocket;
            if (socket == null)
            {
                return false;
            }
            return socket.WriteWebSocketMessageListToStream(oFS);
        }

        [CodeDescription("Returns TRUE if this session state>ReadingResponse and oResponse not null.")]
        public bool bHasResponse
        {
            get
            {
                return ((((this.state > SessionStates.ReadingResponse) && (this.oResponse != null)) && (this.oResponse.headers != null)) && (null != this.responseBodyBytes));
            }
        }

        public bool bHasWebSocketMessages
        {
            get
            {
                if (!this.isAnyFlagSet(SessionFlags.IsWebSocketTunnel) || this.HTTPMethodIs("CONNECT"))
                {
                    return false;
                }
                WebSocket socket = this.__oTunnel as WebSocket;
                if (socket == null)
                {
                    return false;
                }
                return (socket.MessageCount > 0);
            }
        }

        public SessionFlags BitFlags
        {
            get
            {
                return this._bitFlags;
            }
            internal set
            {
                if (CONFIG.bDebugSpew && (value != this._bitFlags))
                {
                    FiddlerApplication.DebugSpew("Session #{0} bitflags adjusted from {1} to {2} @ {3}", new object[] { this.id, this._bitFlags, value, Environment.StackTrace });
                }
                this._bitFlags = value;
            }
        }

        [CodeDescription("Set to true in OnBeforeRequest if this request should bypass the gateway")]
        public bool bypassGateway
        {
            get
            {
                return this._bypassGateway;
            }
            set
            {
                this._bypassGateway = value;
            }
        }

        [CodeDescription("Returns the Address used by the client to communicate to Fiddler.")]
        public string clientIP
        {
            get
            {
                if (this.m_clientIP != null)
                {
                    return this.m_clientIP;
                }
                return "0.0.0.0";
            }
        }

        [CodeDescription("Returns the port used by the client to communicate to Fiddler.")]
        public int clientPort
        {
            get
            {
                return this.m_clientPort;
            }
        }

        [CodeDescription("Retrieves the complete URI, including protocol/scheme, in the form http://www.host.com/filepath?query.")]
        public string fullUrl
        {
            get
            {
                if (!Utilities.HasHeaders(this.oRequest))
                {
                    return string.Empty;
                }
                return string.Format("{0}://{1}", this.oRequest.headers.UriScheme, this.url);
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Must specify a complete URI");
                }
                string str = Utilities.TrimAfter(value, "://").ToLowerInvariant();
                string str2 = Utilities.TrimBefore(value, "://");
                if (((str != "http") && (str != "https")) && (str != "ftp"))
                {
                    throw new ArgumentException("URI scheme must be http, https, or ftp");
                }
                this.oRequest.headers.UriScheme = str;
                this.url = str2;
            }
        }

        [CodeDescription("Gets/Sets the host to which this request is targeted. MAY include IPv6 literal brackets. MAY include a trailing port#.")]
        public string host
        {
            get
            {
                if (this.oRequest == null)
                {
                    return string.Empty;
                }
                return this.oRequest.host;
            }
            set
            {
                if (this.oRequest != null)
                {
                    this.oRequest.host = value;
                }
            }
        }

        [CodeDescription("Gets/Sets the hostname to which this request is targeted; does NOT include any port# but will include IPv6-literal brackets for IPv6 literals.")]
        public string hostname
        {
            get
            {
                string host = this.oRequest.host;
                if (host.Length < 1)
                {
                    return string.Empty;
                }
                int length = host.LastIndexOf(':');
                if ((length > -1) && (length > host.LastIndexOf(']')))
                {
                    return host.Substring(0, length);
                }
                return this.oRequest.host;
            }
            set
            {
                int startIndex = value.LastIndexOf(':');
                if ((startIndex > -1) && (startIndex > value.LastIndexOf(']')))
                {
                    throw new ArgumentException("Do not specify a port when setting hostname; use host property instead.");
                }
                string str = this.HTTPMethodIs("CONNECT") ? this.PathAndQuery : this.host;
                startIndex = str.LastIndexOf(':');
                if ((startIndex > -1) && (startIndex > str.LastIndexOf(']')))
                {
                    this.host = value + str.Substring(startIndex);
                }
                else
                {
                    this.host = value;
                }
            }
        }

        [CodeDescription("Returns the sequential number of this request.")]
        public int id
        {
            get
            {
                return this.m_requestID;
            }
        }

        [CodeDescription("When true, this session was conducted using the FTP protocol.")]
        public bool isFTP
        {
            get
            {
                if (!Utilities.HasHeaders(this.oRequest))
                {
                    return false;
                }
                return "FTP".OICEquals(this.oRequest.headers.UriScheme);
            }
        }

        [CodeDescription("When true, this session was conducted using the HTTPS protocol.")]
        public bool isHTTPS
        {
            get
            {
                if (!Utilities.HasHeaders(this.oRequest))
                {
                    return false;
                }
                return "HTTPS".OICEquals(this.oRequest.headers.UriScheme);
            }
        }

        public bool isTunnel
        {
            [CompilerGenerated]
            get
            {
                return this.isTunnel;
            }
            internal
            set
            {
                this.isTunnel = value;
            }
        }

        [CodeDescription("Indexer property into session flags collection. oSession[\"Flagname\"] returns string value (or null if missing!).")]
        public string this[string sFlag]
        {
            get
            {
                return this.oFlags[sFlag];
            }
            set
            {
                if (value == null)
                {
                    this.oFlags.Remove(sFlag);
                }
                else
                {
                    this.oFlags[sFlag] = value;
                }
            }
        }

        [CodeDescription("Indexer property into SESSION flags, REQUEST headers, and RESPONSE headers. e.g. oSession[\"Request\", \"Host\"] returns string value for the Request host header. If null, returns String.Empty")]
        public string this[string sCollection, string sName]
        {
            get
            {
                if ("SESSION".OICEquals(sCollection))
                {
                    string str = this.oFlags[sName];
                    return (str ?? string.Empty);
                }
                if ("REQUEST".OICEquals(sCollection))
                {
                    if (!Utilities.HasHeaders(this.oRequest))
                    {
                        return string.Empty;
                    }
                    return this.oRequest[sName];
                }
                if (!"RESPONSE".OICEquals(sCollection))
                {
                    return "undefined";
                }
                if (!Utilities.HasHeaders(this.oResponse))
                {
                    return string.Empty;
                }
                return this.oResponse[sName];
            }
        }

        [CodeDescription("Get the Process Info the application which made this request, or String.Empty if it cannot be determined.")]
        public string LocalProcess
        {
            get
            {
                if (!this.oFlags.ContainsKey("X-ProcessInfo"))
                {
                    return string.Empty;
                }
                return this.oFlags["X-ProcessInfo"];
            }
        }

        [CodeDescription("Get the process ID of the application which made this request, or 0 if it cannot be determined.")]
        public int LocalProcessID
        {
            get
            {
                return this._LocalProcessID;
            }
        }

        [CodeDescription("Returns the path and query part of the URL. (For a CONNECT request, returns the host:port to be connected.)")]
        public string PathAndQuery
        {
            get
            {
                HTTPRequestHeaders headers = this.oRequest.headers;
                if (headers == null)
                {
                    return string.Empty;
                }
                return headers.RequestPath;
            }
            set
            {
                this.oRequest.headers.RequestPath = value;
            }
        }

        [CodeDescription("Returns the server port to which this request is targeted.")]
        public int port
        {
            get
            {
                string str;
                string sHostPort = this.HTTPMethodIs("CONNECT") ? this.oRequest.headers.RequestPath : this.oRequest.host;
                int iPort = this.isHTTPS ? 0x1bb : (this.isFTP ? 0x15 : 80);
                Utilities.CrackHostAndPort(sHostPort, out str, ref iPort);
                return iPort;
            }
            set
            {
                if ((value < 0) || (value > 0xffff))
                {
                    throw new ArgumentException("A valid target port value (0-65535) must be specified.");
                }
                this.host = string.Format("{0}:{1}", this.hostname, value);
            }
        }

        [CodeDescription("Gets or Sets the Request body bytes; Setter fixes up headers.")]
        public byte[] RequestBody
        {
            get
            {
                return (this.requestBodyBytes ?? Utilities.emptyByteArray);
            }
            set
            {
                if (value == null)
                {
                    value = Utilities.emptyByteArray;
                }
                this.oRequest.headers.Remove("Transfer-Encoding");
                this.oRequest.headers.Remove("Content-Encoding");
                this.requestBodyBytes = value;
                this.oRequest.headers["Content-Length"] = value.LongLength.ToString();
            }
        }

        [CodeDescription("Gets Request Headers, or empty headers if headers do not exist")]
        public HTTPRequestHeaders RequestHeaders
        {
            get
            {
                HTTPRequestHeaders headers = null;
                if (Utilities.HasHeaders(this.oRequest))
                {
                    headers = this.oRequest.headers;
                }
                if (headers == null)
                {
                    headers = new HTTPRequestHeaders("/", null);
                }
                return headers;
            }
        }

        [CodeDescription("Gets or Sets the request's Method (e.g. GET, POST, etc).")]
        public string RequestMethod
        {
            get
            {
                if (!Utilities.HasHeaders(this.oRequest))
                {
                    return string.Empty;
                }
                return this.oRequest.headers.HTTPMethod;
            }
            set
            {
                if (Utilities.HasHeaders(this.oRequest))
                {
                    this.oRequest.headers.HTTPMethod = value;
                }
            }
        }

        [CodeDescription("Gets or Sets the Response body bytes; Setter fixes up headers.")]
        public byte[] ResponseBody
        {
            get
            {
                return (this.responseBodyBytes ?? Utilities.emptyByteArray);
            }
            set
            {
                if (value == null)
                {
                    value = Utilities.emptyByteArray;
                }
                this.oResponse.headers.Remove("Transfer-Encoding");
                this.oResponse.headers.Remove("Content-Encoding");
                this.responseBodyBytes = value;
                this.oResponse.headers["Content-Length"] = value.LongLength.ToString();
            }
        }

        [CodeDescription("Gets or Sets the HTTP Status code of the server's response")]
        public int responseCode
        {
            get
            {
                if (Utilities.HasHeaders(this.oResponse))
                {
                    return this.oResponse.headers.HTTPResponseCode;
                }
                return 0;
            }
            set
            {
                if (Utilities.HasHeaders(this.oResponse))
                {
                    this.oResponse.headers.SetStatus(value, "Fiddled");
                }
            }
        }

        [CodeDescription("Gets Response Headers, or empty headers if headers do not exist")]
        public HTTPResponseHeaders ResponseHeaders
        {
            get
            {
                HTTPResponseHeaders headers = null;
                if (Utilities.HasHeaders(this.oResponse))
                {
                    headers = this.oResponse.headers;
                }
                if (headers == null)
                {
                    headers = new HTTPResponseHeaders(0, "HEADERS NOT SET", null);
                }
                return headers;
            }
        }

        [CodeDescription("Enumerated state of the current session.")]
        public SessionStates state
        {
            get
            {
                return this.m_state;
            }
            set
            {
                SessionStates state = this.m_state;
                this.m_state = value;
                if (this.m_state == SessionStates.Aborted)
                {
                    this.oFlags["X-Aborted-When"] = state.ToString();
                    this.FinishUISession();
                }
                else if (((state == SessionStates.HandTamperRequest) || (state == SessionStates.HandTamperResponse)) || ((this.m_state == SessionStates.HandTamperRequest) || (this.m_state == SessionStates.HandTamperResponse)))
                {
                    this.RefreshMyInspectors();
                }
                if (!this.isFlagSet(SessionFlags.Ignored))
                {
                    EventHandler<StateChangeEventArgs> onStateChanged = this.OnStateChanged;
                    if (onStateChanged != null)
                    {
                        StateChangeEventArgs e = new StateChangeEventArgs(state, value);
                        onStateChanged(this, e);
                    }
                }
                if (this.m_state >= SessionStates.Done)
                {
                    this.OnStateChanged = null;
                    this.FireCompleteTransaction();
                }
            }
        }

        [CodeDescription("Gets a path-less filename suitable for saving the Response entity. Uses Content-Disposition if available.")]
        public string SuggestedFilename
        {
            get
            {
                if (!Utilities.HasHeaders(this.oResponse))
                {
                    return (this.id.ToString() + ".txt");
                }
                if (Utilities.IsNullOrEmpty(this.responseBodyBytes))
                {
                    string format = "{0}_Status{1}.txt";
                    return string.Format(format, this.id.ToString(), this.responseCode.ToString());
                }
                string tokenValue = this.oResponse.headers.GetTokenValue("Content-Disposition", "filename*");
                if (((tokenValue != null) && (tokenValue.Length > 7)) && tokenValue.OICStartsWith("utf-8''"))
                {
                    return Utilities.UrlDecode(tokenValue.Substring(7));
                }
                tokenValue = this.oResponse.headers.GetTokenValue("Content-Disposition", "filename");
                if (tokenValue != null)
                {
                    return _MakeSafeFilename(tokenValue);
                }
                string sFilename = Utilities.TrimBeforeLast(Utilities.TrimAfter(this.url, '?'), '/');
                if (((sFilename.Length > 0) && (sFilename.Length < 0x40)) && (sFilename.Contains(".") && (sFilename.LastIndexOf('.') == sFilename.IndexOf('.'))))
                {
                    string inStr = _MakeSafeFilename(sFilename);
                    string toMatch = string.Empty;
                    if ((this.url.Contains("?") || (inStr.Length < 1)) || inStr.OICEndsWithAny(new string[] { ".aspx", ".php", ".jsp", ".asp", ".asmx", ".cgi", ".cfm", ".ashx" }))
                    {
                        toMatch = this._GetSuggestedFilenameExt();
                        if (inStr.OICEndsWith(toMatch))
                        {
                            toMatch = string.Empty;
                        }
                    }
                    string str6 = FiddlerApplication.Prefs.GetBoolPref("fiddler.session.prependIDtosuggestedfilename", false) ? "{0}_{1}{2}" : "{1}{2}";
                    return string.Format(str6, this.id.ToString(), inStr, toMatch);
                }
                StringBuilder builder = new StringBuilder(0x20);
                builder.Append(this.id);
                builder.Append("_");
                builder.Append(this._GetSuggestedFilenameExt());
                return builder.ToString();
            }
        }

        public long TunnelEgressByteCount
        {
            get
            {
                if (this.__oTunnel != null)
                {
                    return this.__oTunnel.EgressByteCount;
                }
                return 0L;
            }
        }

        public long TunnelIngressByteCount
        {
            get
            {
                if (this.__oTunnel != null)
                {
                    return this.__oTunnel.IngressByteCount;
                }
                return 0L;
            }
        }

        public bool TunnelIsOpen
        {
            get
            {
                return ((this.__oTunnel != null) && this.__oTunnel.IsOpen);
            }
        }

        [CodeDescription("Gets or sets the URL (without protocol) being requested from the server, in the form www.host.com/filepath?query.")]
        public string url
        {
            get
            {
                if (this.HTTPMethodIs("CONNECT"))
                {
                    return this.PathAndQuery;
                }
                return (this.host + this.PathAndQuery);
            }
            set
            {
                if (value.OICStartsWithAny(new string[] { "http://", "https://", "ftp://" }))
                {
                    throw new ArgumentException("If you wish to specify a protocol, use the fullUrl property instead. Input was: " + value);
                }
                if (this.HTTPMethodIs("CONNECT"))
                {
                    this.host = this.PathAndQuery = value;
                }
                else
                {
                    int length = value.IndexOfAny(new char[] { '/', '?' });
                    if (length > -1)
                    {
                        this.host = value.Substring(0, length);
                        this.PathAndQuery = value.Substring(length);
                    }
                    else
                    {
                        this.host = value;
                        this.PathAndQuery = "/";
                    }
                }
            }
        }
    }
}

