﻿namespace Fiddler
{
    using System;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using System.Net.Security;
    using System.Net.Sockets;
    using System.Security.Authentication;
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Windows.Forms;

    public class ServerPipe : BasePipe
    {
        internal static bool _bEatTLSAlerts = FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.DropSNIAlerts", false);
        protected bool _bIsConnectedToGateway;
        private bool _bIsConnectedViaSOCKS;
        private X509Certificate2 _certServer;
        private int _iMarriedToPID;
        private bool _isAuthenticated;
        private PipeReusePolicy _reusePolicy;
        private string _ServerCertChain;
        protected string _sPoolKey;
        internal static int _timeoutReceiveInitial = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.receive.initial", -1);
        internal static int _timeoutReceiveReused = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.receive.reuse", -1);
        internal static int _timeoutSendInitial = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.send.initial", -1);
        internal static int _timeoutSendReused = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.send.reuse", -1);
        internal DateTime dtConnected;
        private static StringCollection slAcceptableBadCertificates;
        internal long ulLastPooled;

        internal ServerPipe(Socket oSocket, string sName, bool bConnectedToGateway, string sPoolingKey) : base(oSocket, sName)
        {
            this.dtConnected = DateTime.Now;
            this._bIsConnectedToGateway = bConnectedToGateway;
            this.sPoolKey = sPoolingKey;
        }

        private static X509Certificate _GetDefaultCertificate()
        {
            if (FiddlerApplication.oDefaultClientCertificate != null)
            {
                return FiddlerApplication.oDefaultClientCertificate;
            }
            X509Certificate certificate = null;
            if (System.IO.File.Exists(CONFIG.GetPath("DefaultClientCertificate")))
            {
                certificate = X509Certificate.CreateFromCertFile(CONFIG.GetPath("DefaultClientCertificate"));
                if (certificate == null)
                {
                    return null;
                }
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.cacheclientcert", true))
                {
                    FiddlerApplication.oDefaultClientCertificate = certificate;
                }
            }
            return certificate;
        }

        internal TransportContext _GetTransportContext()
        {
            if (base._httpsStream != null)
            {
                return base._httpsStream.TransportContext;
            }
            return null;
        }

        private X509Certificate AttachClientCertificate(Session oS, object sender, string targetHost, X509CertificateCollection localCertificates, X509Certificate remoteCertificate, string[] acceptableIssuers)
        {
            MethodInvoker oDel = null;
            if (CONFIG.bDebugSpew)
            {
                FiddlerApplication.Log.LogFormat("fiddler.network.https.clientcertificate>AttachClientCertificate {0} - {1}, {2} local certs, {3} acceptable issuers.", new object[] { targetHost, (remoteCertificate != null) ? remoteCertificate.Subject.ToString() : "NoRemoteCert", (localCertificates != null) ? localCertificates.Count.ToString() : "(null)", (acceptableIssuers != null) ? acceptableIssuers.Length.ToString() : "(null)" });
            }
            if (localCertificates.Count > 0)
            {
                this.MarkAsAuthenticated(oS.LocalProcessID);
                oS.oFlags["x-client-cert"] = localCertificates[0].Subject + " Serial#" + localCertificates[0].GetSerialNumberString();
                return localCertificates[0];
            }
            if (FiddlerApplication.ClientCertificateProvider != null)
            {
                X509Certificate certificate = FiddlerApplication.ClientCertificateProvider(oS, targetHost, localCertificates, remoteCertificate, acceptableIssuers);
                if (certificate == null)
                {
                    return null;
                }
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Session #{0} Attaching client certificate '{1}' when connecting to host '{2}'", new object[] { oS.id, certificate.Subject, targetHost });
                }
                this.MarkAsAuthenticated(oS.LocalProcessID);
                oS.oFlags["x-client-cert"] = certificate.Subject + " Serial#" + certificate.GetSerialNumberString();
                return certificate;
            }
            bool flag = (remoteCertificate != null) || (acceptableIssuers.Length > 0);
            X509Certificate certificate2 = _GetDefaultCertificate();
            if (certificate2 != null)
            {
                if (flag)
                {
                    this.MarkAsAuthenticated(oS.LocalProcessID);
                }
                oS.oFlags["x-client-cert"] = certificate2.Subject + " Serial#" + certificate2.GetSerialNumberString();
                return certificate2;
            }
            if (flag)
            {
                FiddlerApplication.Log.LogFormat("The server [{0}] requested a client certificate, but no client certificate was available.", new object[] { targetHost });
                if (CONFIG.bShowDefaultClientCertificateNeededPrompt && FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.clientcertificate.ephemeral.prompt-for-missing", true))
                {
                    FiddlerApplication.Prefs.SetBoolPref("fiddler.network.https.clientcertificate.ephemeral.prompt-for-missing", false);
                    if (oDel == null)
                    {
                        oDel = delegate {
                            FiddlerApplication.DoNotifyUser("The server [" + targetHost + "] requests a client certificate.\nPlease save a client certificate using the filename:\n\n" + CONFIG.GetPath("DefaultClientCertificate"), "Client Certificate Requested");
                        };
                    }
                    FiddlerApplication.UIInvokeAsync(oDel, null);
                }
            }
            return null;
        }

        private static bool ConfirmServerCertificate(Session oS, string sExpectedCN, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            CertificateValidity oValidity = CertificateValidity.Default;
            FiddlerApplication.CheckOverrideCertificatePolicy(oS, sExpectedCN, certificate, chain, sslPolicyErrors, ref oValidity);
            switch (oValidity)
            {
                case CertificateValidity.ForceInvalid:
                    return false;

                case CertificateValidity.ForceValid:
                    return true;
            }
            if (((oValidity != CertificateValidity.ConfirmWithUser) && ((sslPolicyErrors == SslPolicyErrors.None) || CONFIG.IgnoreServerCertErrors)) || oS.oFlags.ContainsKey("X-IgnoreCertErrors"))
            {
                return true;
            }
            if (((sslPolicyErrors & SslPolicyErrors.RemoteCertificateNameMismatch) == SslPolicyErrors.RemoteCertificateNameMismatch) && oS.oFlags.ContainsKey("X-IgnoreCertCNMismatch"))
            {
                sslPolicyErrors &= ~SslPolicyErrors.RemoteCertificateNameMismatch;
                if (sslPolicyErrors == SslPolicyErrors.None)
                {
                    return true;
                }
            }
            if ((slAcceptableBadCertificates != null) && slAcceptableBadCertificates.Contains(sExpectedCN + certificate.GetSerialNumberString()))
            {
                return true;
            }
            if (CONFIG.QuietMode)
            {
                return false;
            }
            string str = null;
            if (((sslPolicyErrors & SslPolicyErrors.RemoteCertificateChainErrors) == SslPolicyErrors.RemoteCertificateChainErrors) && (chain != null))
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("\n");
                for (int i = 0; i < chain.ChainStatus.Length; i++)
                {
                    builder.AppendFormat("\n{0} - {1}", i, chain.ChainStatus[i].StatusInformation);
                }
                str = builder.ToString();
            }
            string sTitle = (sslPolicyErrors == SslPolicyErrors.None) ? "Accept Remote Certificate" : "Ignore remote certificate error?";
            string str3 = (sslPolicyErrors == SslPolicyErrors.None) ? "the following certificate: " : ("a certificate that did not validate, due to " + sslPolicyErrors.ToString() + "." + str);
            string str4 = (sslPolicyErrors == SslPolicyErrors.None) ? string.Empty : "(This warning can be disabled by clicking Tools | Fiddler Options.)";
            string sHint = (sslPolicyErrors == SslPolicyErrors.None) ? "Accept this certificate?" : "Ignore errors and proceed anyway?";
            frmAlert alert = new frmAlert(sTitle, string.Format("Session #{0}: The remote server ({1}) presented {2}\r\n\r\nSUBJECT: {3}\r\nISSUER: {4}\r\nEXPIRES: {5}\r\n\r\n{6}", new object[] { oS.id, sExpectedCN, str3, certificate.Subject, certificate.Issuer, certificate.GetExpirationDateString(), str4 }), sHint, MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2, frmAlert.AlertIcon.Insecure);
            alert.TopMost = true;
            alert.StartPosition = FormStartPosition.CenterScreen;
            DialogResult result = (DialogResult) FiddlerApplication._frmMain.Invoke(new getDecisionDelegate(FiddlerApplication._frmMain.GetDecision), new object[] { alert });
            if (DialogResult.Yes == result)
            {
                if (slAcceptableBadCertificates == null)
                {
                    slAcceptableBadCertificates = new StringCollection();
                }
                slAcceptableBadCertificates.Add(sExpectedCN + certificate.GetSerialNumberString());
            }
            return (DialogResult.Yes == result);
        }

        public string DescribeConnectionSecurity()
        {
            if (base._httpsStream == null)
            {
                return "No connection security";
            }
            string str = string.Empty;
            if (base._httpsStream.IsMutuallyAuthenticated)
            {
                str = "== Client Certificate ==========\nUnknown.\n";
            }
            if (base._httpsStream.LocalCertificate != null)
            {
                str = "\n== Client Certificate ==========\n" + base._httpsStream.LocalCertificate.ToString(true) + "\n";
            }
            StringBuilder builder = new StringBuilder(0x800);
            builder.AppendFormat("Secure Protocol: {0}\n", base._httpsStream.SslProtocol.ToString());
            builder.AppendFormat("Cipher: {0} {1}bits\n", base._httpsStream.CipherAlgorithm.ToString(), base._httpsStream.CipherStrength);
            string str2 = base._httpsStream.HashAlgorithm.ToString();
            if (str2 == "32780")
            {
                str2 = "Sha256";
            }
            else if (str2 == "32781")
            {
                str2 = "Sha384";
            }
            builder.AppendFormat("Hash Algorithm: {0} {1}bits\n", str2, base._httpsStream.HashStrength);
            string str3 = base._httpsStream.KeyExchangeAlgorithm.ToString();
            if (str3 == "44550")
            {
                str3 = "ECDHE_RSA (0xae06)";
            }
            builder.AppendFormat("Key Exchange: {0} {1}bits\n", str3, base._httpsStream.KeyExchangeStrength);
            builder.Append(str);
            builder.AppendLine("\n== Server Certificate ==========");
            builder.AppendLine(base._httpsStream.RemoteCertificate.ToString(true));
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.storeservercertchain", false))
            {
                builder.AppendFormat("[Chain]\n {0}\n", this.GetServerCertChain());
            }
            return builder.ToString();
        }

        private static X509CertificateCollection GetCertificateCollectionFromFile(string sClientCertificateFilename)
        {
            if (string.IsNullOrEmpty(sClientCertificateFilename))
            {
                return null;
            }
            X509CertificateCollection certificates = null;
            try
            {
                sClientCertificateFilename = Utilities.EnsurePathIsAbsolute(CONFIG.GetPath("Root"), sClientCertificateFilename);
                if (System.IO.File.Exists(sClientCertificateFilename))
                {
                    certificates = new X509CertificateCollection();
                    certificates.Add(X509Certificate.CreateFromCertFile(sClientCertificateFilename));
                    return certificates;
                }
                FiddlerApplication.Log.LogFormat("!! ERROR: Specified client certificate file '{0}' does not exist.", new object[] { sClientCertificateFilename });
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Failed to GetCertificateCollection from " + sClientCertificateFilename);
            }
            return certificates;
        }

        internal string GetConnectionCipherInfo()
        {
            if (base._httpsStream == null)
            {
                return "<none>";
            }
            return string.Format("{0} {1}bits", base._httpsStream.CipherAlgorithm.ToString(), base._httpsStream.CipherStrength);
        }

        internal string GetServerCertChain()
        {
            if (this._ServerCertChain != null)
            {
                return this._ServerCertChain;
            }
            if (base._httpsStream == null)
            {
                return string.Empty;
            }
            try
            {
                X509Certificate2 certificate = new X509Certificate2(base._httpsStream.RemoteCertificate);
                if (certificate == null)
                {
                    return string.Empty;
                }
                StringBuilder builder = new StringBuilder();
                X509Chain chain = new X509Chain();
                chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
                chain.Build(certificate);
                for (int i = chain.ChainElements.Count - 1; i >= 1; i--)
                {
                    builder.Append(SummarizeCert(chain.ChainElements[i].Certificate));
                    builder.Append(" > ");
                }
                if (chain.ChainElements.Count > 0)
                {
                    builder.AppendFormat("{0} [{1}]", SummarizeCert(chain.ChainElements[0].Certificate), chain.ChainElements[0].Certificate.SerialNumber);
                }
                this._ServerCertChain = builder.ToString();
                return builder.ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        internal string GetServerCertCN()
        {
            if (base._httpsStream == null)
            {
                return null;
            }
            if (base._httpsStream.RemoteCertificate == null)
            {
                return null;
            }
            string subject = base._httpsStream.RemoteCertificate.Subject;
            if (subject.Contains("CN="))
            {
                return Utilities.TrimAfter(Utilities.TrimBefore(subject, "CN="), ",");
            }
            return subject;
        }

        internal void MarkAsAuthenticated(int clientPID)
        {
            this._isAuthenticated = true;
            int num = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.auth.reusemode", 0);
            if ((num == 0) && (clientPID == 0))
            {
                num = 1;
            }
            switch (num)
            {
                case 0:
                    this.ReusePolicy = PipeReusePolicy.MarriedToClientProcess;
                    this._iMarriedToPID = clientPID;
                    this.sPoolKey = string.Format("pid{0}*{1}", clientPID, this.sPoolKey);
                    return;

                case 1:
                    this.ReusePolicy = PipeReusePolicy.MarriedToClientPipe;
                    return;
            }
        }

        internal bool SecureExistingConnection(Session oS, string sCertCN, string sClientCertificateFilename, SslProtocols sslprotClient, ref int iHandshakeTime)
        {
            RemoteCertificateValidationCallback userCertificateValidationCallback = null;
            LocalCertificateSelectionCallback userCertificateSelectionCallback = null;
            MethodInvoker oDel = null;
            this.sPoolKey = this.sPoolKey.Replace("->http/", "->https/");
            if (this.sPoolKey.EndsWith("->*"))
            {
                this.sPoolKey = this.sPoolKey.Replace("->*", string.Format("->https/{0}:{1}", oS.hostname, oS.port));
            }
            X509CertificateCollection certificateCollectionFromFile = GetCertificateCollectionFromFile(sClientCertificateFilename);
            Stopwatch stopwatch = Stopwatch.StartNew();
            try
            {
                Stream baseStream = new NetworkStream(base._baseSocket, false);
                if (_bEatTLSAlerts || oS.oFlags.ContainsKey("https-DropSNIAlerts"))
                {
                    baseStream = new TLSAlertEatingStream(baseStream, oS.host);
                }
                if (userCertificateValidationCallback == null)
                {
                    userCertificateValidationCallback = delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) {
                        try
                        {
                            this._certServer = new X509Certificate2(certificate);
                        }
                        catch (Exception)
                        {
                        }
                        return ConfirmServerCertificate(oS, sCertCN, certificate, chain, sslPolicyErrors);
                    };
                }
                if (userCertificateSelectionCallback == null)
                {
                    userCertificateSelectionCallback = delegate (object sender, string targetHost, X509CertificateCollection localCertificates, X509Certificate remoteCertificate, string[] acceptableIssuers) {
                        return this.AttachClientCertificate(oS, sender, targetHost, localCertificates, remoteCertificate, acceptableIssuers);
                    };
                }
                base._httpsStream = new SslStream(baseStream, false, userCertificateValidationCallback, userCertificateSelectionCallback);
                SslProtocols oAcceptedServerHTTPSProtocols = CONFIG.oAcceptedServerHTTPSProtocols;
                if (oS.oFlags.ContainsKey("x-OverrideSslProtocols"))
                {
                    oAcceptedServerHTTPSProtocols = Utilities.ParseSSLProtocolString(oS.oFlags["x-OverrideSslProtocols"]);
                }
                else if (CONFIG.bMimicClientHTTPSProtocols && (sslprotClient != SslProtocols.None))
                {
                    oAcceptedServerHTTPSProtocols |= sslprotClient;
                }
                base._httpsStream.AuthenticateAsClient(sCertCN, certificateCollectionFromFile, oAcceptedServerHTTPSProtocols, FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.checkcertificaterevocation", false));
                iHandshakeTime = (int) stopwatch.ElapsedMilliseconds;
            }
            catch (Exception exception)
            {
                iHandshakeTime = (int) stopwatch.ElapsedMilliseconds;
                FiddlerApplication.DebugSpew("SecureExistingConnection failed: {0}\n{1}", new object[] { Utilities.DescribeException(exception), exception.StackTrace });
                string s = string.Format("fiddler.network.https> HTTPS handshake to {0} (for #{1}) failed. {2}\n\n", sCertCN, oS.id, Utilities.DescribeException(exception));
                if ((exception is CryptographicException) && (FiddlerApplication.oDefaultClientCertificate != null))
                {
                    s = s + "NOTE: A ClientCertificate was supplied. Make certain that the certificate is valid and its public key is accessible in the current user account.\n";
                }
                if (((exception is AuthenticationException) && (exception.InnerException != null)) && (exception.InnerException is Win32Exception))
                {
                    Win32Exception innerException = (Win32Exception) exception.InnerException;
                    if (innerException.NativeErrorCode == -2146893007)
                    {
                        s = s + "HTTPS handshake returned error SEC_E_ALGORITHM_MISMATCH.\nFiddler's Enabled HTTPS Protocols: [" + CONFIG.oAcceptedServerHTTPSProtocols.ToString() + "] are controlled inside Tools > Fiddler Options > HTTPS.";
                        if (oS.oFlags.ContainsKey("x-OverrideSslProtocols"))
                        {
                            s = s + "\nThis connection specified X-OverrideSslProtocols: " + oS.oFlags["x-OverrideSslProtocols"];
                        }
                    }
                    else
                    {
                        s = s + "Win32 (SChannel) Native Error Code: 0x" + innerException.NativeErrorCode.ToString("x");
                    }
                }
                if (oDel == null)
                {
                    oDel = delegate {
                        if (oS.ViewItem != null)
                        {
                            oS.ViewItem.ImageIndex = 12;
                        }
                    };
                }
                FiddlerApplication.UIInvokeAsync(oDel, null);
                if (Utilities.IsNullOrEmpty(oS.responseBodyBytes))
                {
                    oS.responseBodyBytes = Encoding.UTF8.GetBytes(s);
                }
                FiddlerApplication.Log.LogString(s);
                return false;
            }
            return true;
        }

        internal void setTimeouts()
        {
            try
            {
                int num = (base.iUseCount < 2) ? _timeoutReceiveInitial : _timeoutReceiveReused;
                int num2 = (base.iUseCount < 2) ? _timeoutSendInitial : _timeoutSendReused;
                if (num > 0)
                {
                    base._baseSocket.ReceiveTimeout = num;
                }
                if (num2 > 0)
                {
                    base._baseSocket.SendTimeout = num2;
                }
            }
            catch
            {
            }
        }

        private static string SummarizeCert(X509Certificate2 oCert)
        {
            if (!string.IsNullOrEmpty(oCert.FriendlyName))
            {
                return oCert.FriendlyName;
            }
            string subject = oCert.Subject;
            if (string.IsNullOrEmpty(subject))
            {
                return string.Empty;
            }
            if (subject.Contains("CN="))
            {
                return Utilities.TrimAfter(Utilities.TrimBefore(subject, "CN="), ",");
            }
            if (subject.Contains("O="))
            {
                return Utilities.TrimAfter(Utilities.TrimBefore(subject, "O="), ",");
            }
            return subject;
        }

        public override string ToString()
        {
            return string.Format("{0}[Key: {1}; UseCnt: {2} [{3}]; {4}; {5} (:{6} to {7}:{8} {9}) {10}]", new object[] { base._sPipeName, this._sPoolKey, base.iUseCount, string.Empty, base.bIsSecured ? "Secure" : "PlainText", this._isAuthenticated ? "Authenticated" : "Anonymous", base.LocalPort, base.Address, base.Port, this.isConnectedToGateway ? "Gateway" : "Direct", this._reusePolicy });
        }

        internal bool isAuthenticated
        {
            get
            {
                return this._isAuthenticated;
            }
        }

        internal bool isClientCertAttached
        {
            get
            {
                return ((base._httpsStream != null) && base._httpsStream.IsMutuallyAuthenticated);
            }
        }

        public bool isConnectedToGateway
        {
            get
            {
                return this._bIsConnectedToGateway;
            }
        }

        public bool isConnectedViaSOCKS
        {
            get
            {
                return this._bIsConnectedViaSOCKS;
            }
            set
            {
                this._bIsConnectedViaSOCKS = value;
            }
        }

        public IPEndPoint RemoteEndPoint
        {
            get
            {
                if (base._baseSocket == null)
                {
                    return null;
                }
                try
                {
                    return (base._baseSocket.RemoteEndPoint as IPEndPoint);
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }

        public PipeReusePolicy ReusePolicy
        {
            get
            {
                return this._reusePolicy;
            }
            set
            {
                this._reusePolicy = value;
            }
        }

        public X509Certificate2 ServerCertificate
        {
            get
            {
                return this._certServer;
            }
        }

        public string sPoolKey
        {
            get
            {
                return this._sPoolKey;
            }
            private set
            {
                if ((CONFIG.bDebugSpew && !string.IsNullOrEmpty(this._sPoolKey)) && (this._sPoolKey != value))
                {
                    FiddlerApplication.Log.LogFormat("fiddler.pipes>{0} pooling key changing from '{1}' to '{2}'", new object[] { base._sPipeName, this._sPoolKey, value });
                }
                this._sPoolKey = value.ToLower();
            }
        }

        internal class TLSAlertEatingStream : Stream
        {
            private Stream _innerStream;
            private string _toHost;
            private bool bFirstRead = true;

            public TLSAlertEatingStream(Stream baseStream, string sHostname)
            {
                this._innerStream = baseStream;
                this._toHost = sHostname;
            }

            protected override void Dispose(bool disposing)
            {
                this._innerStream.Close();
            }

            public override void Flush()
            {
                this._innerStream.Flush();
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                int num = this._innerStream.Read(buffer, offset, count);
                if (this.bFirstRead && (num > 1))
                {
                    if (((buffer[offset] == 0x15) && (num == 5)) && ((buffer[offset + 3] == 0) && (2 == buffer[offset + 4])))
                    {
                        num = this._innerStream.Read(buffer, offset, 2);
                        if (((num == 2) && (1 == buffer[offset])) && (0x70 == buffer[offset + 1]))
                        {
                            FiddlerApplication.Log.LogString("! Eating a TLS unrecognized_name alert (level: Warning) when connecting to '" + this._toHost + "'");
                            num = this._innerStream.Read(buffer, offset, count);
                        }
                    }
                    this.bFirstRead = false;
                    this._toHost = null;
                }
                return num;
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                throw new NotSupportedException();
            }

            public override void SetLength(long value)
            {
                throw new NotSupportedException();
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                this._innerStream.Write(buffer, offset, count);
            }

            public override bool CanRead
            {
                get
                {
                    return this._innerStream.CanRead;
                }
            }

            public override bool CanSeek
            {
                get
                {
                    return false;
                }
            }

            public override bool CanWrite
            {
                get
                {
                    return this._innerStream.CanWrite;
                }
            }

            public override long Length
            {
                get
                {
                    throw new NotSupportedException();
                }
            }

            public override long Position
            {
                get
                {
                    throw new NotSupportedException();
                }
                set
                {
                    throw new NotSupportedException();
                }
            }

            public override int ReadTimeout
            {
                get
                {
                    return this._innerStream.ReadTimeout;
                }
                set
                {
                    this._innerStream.ReadTimeout = value;
                }
            }

            public override int WriteTimeout
            {
                get
                {
                    return this._innerStream.WriteTimeout;
                }
                set
                {
                    this._innerStream.WriteTimeout = value;
                }
            }
        }
    }
}

