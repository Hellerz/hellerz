﻿namespace Fiddler
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Text;

    public class ClientChatter
    {
        private HTTPRequestHeaders m_headers;
        private Session m_session;
        public ClientPipe pipeClient;
        internal static int s_cbClientReadBuffer = 0x2000;
        internal static int s_SO_RCVBUF_Option = -1;
        internal static int s_SO_SNDBUF_Option = -1;
        private RequestReaderState stateRead;

        internal ClientChatter(Session oSession)
        {
            this.m_session = oSession;
        }

        internal ClientChatter(Session oSession, string sData)
        {
            this.m_session = oSession;
            this.headers = Parser.ParseRequest(sData);
            if (this.headers != null)
            {
                if ("CONNECT" == this.m_headers.HTTPMethod)
                {
                    this.m_session.isTunnel = true;
                }
            }
            else
            {
                this.headers = new HTTPRequestHeaders("/MALFORMED", new string[] { "Fiddler: Malformed header string" });
            }
        }

        private long _calculateExpectedEntityTransferSize()
        {
            if (this.m_headers == null)
            {
                throw new InvalidDataException("HTTP Request did not contain headers");
            }
            long result = 0L;
            if (this.m_headers.ExistsAndEquals("Transfer-Encoding", "chunked"))
            {
                long num2;
                long num3;
                if (this.m_session.isAnyFlagSet(SessionFlags.IsRPCTunnel | SessionFlags.RequestStreamed))
                {
                    return (this.stateRead.m_requestData.Length - this.stateRead.iEntityBodyOffset);
                }
                RequestReaderState stateRead = this.stateRead;
                if (stateRead.iEntityBodyOffset >= stateRead.m_requestData.Length)
                {
                    throw new InvalidDataException("Bad request: Chunked Body was missing entirely.");
                }
                if (!Utilities.IsChunkedBodyComplete(this.m_session, stateRead.m_requestData, (long) stateRead.iEntityBodyOffset, out num3, out num2))
                {
                    throw new InvalidDataException("Bad request: Chunked Body was incomplete.");
                }
                if (num2 < stateRead.iEntityBodyOffset)
                {
                    throw new InvalidDataException("Bad request: Chunked Body was malformed. Entity ends before it starts!");
                }
                return (num2 - stateRead.iEntityBodyOffset);
            }
            if (long.TryParse(this.m_headers["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out result) && (result >= 0L))
            {
                return result;
            }
            return 0L;
        }

        private void _freeRequestData()
        {
            RequestReaderState stateRead = this.stateRead;
            this.stateRead = null;
            if (stateRead != null)
            {
                stateRead.Dispose();
            }
        }

        private bool _isRequestComplete()
        {
            long num2;
            if (this.m_headers == null)
            {
                if (!this.stateRead._areHeadersAvailable(this.m_session))
                {
                    if (this.stateRead.m_requestData.Length > ClientPipe._cbLimitRequestHeaders)
                    {
                        this.m_headers = new HTTPRequestHeaders();
                        this.m_headers.HTTPMethod = "BAD";
                        this.m_headers["Host"] = "BAD-REQUEST";
                        this.m_headers.RequestPath = "/REQUEST_TOO_LONG";
                        this.FailSession(0x19e, "Fiddler - Request Too Long", "[Fiddler] Request Header parsing failed. Headers not found in the first " + this.stateRead.m_requestData.Length.ToString() + " bytes.");
                        return true;
                    }
                    return false;
                }
                if (!this._ParseRequestForHeaders())
                {
                    string str;
                    if (this.stateRead.m_requestData != null)
                    {
                        str = Utilities.ByteArrayToHexView(this.stateRead.m_requestData.GetBuffer(), 0x18, (int) Math.Min(this.stateRead.m_requestData.Length, 0x800L));
                    }
                    else
                    {
                        str = "{Fiddler:no data}";
                    }
                    if (this.m_headers == null)
                    {
                        this.m_headers = new HTTPRequestHeaders();
                        this.m_headers.HTTPMethod = "BAD";
                        this.m_headers["Host"] = "BAD-REQUEST";
                        this.m_headers.RequestPath = "/BAD_REQUEST";
                    }
                    this.FailSession(400, "Fiddler - Bad Request", "[Fiddler] Request Header parsing failed. Request was:\n" + str);
                    return true;
                }
                this.m_session.Timers.FiddlerGotRequestHeaders = DateTime.Now;
                this.m_session._AssignID();
                if (!this.m_session.ShouldBeHidden())
                {
                    FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.addSession), new object[] { this.m_session });
                }
                FiddlerApplication.DoRequestHeadersAvailable(this.m_session);
                if (this.m_session.isFlagSet(SessionFlags.RequestStreamed))
                {
                    if ((!("CONNECT" == this.m_headers.HTTPMethod) && !this.m_headers.ExistsAndEquals("Content-Length", "0")) && (this.m_headers.Exists("Content-Length") || this.m_headers.Exists("Transfer-Encoding")))
                    {
                        return true;
                    }
                    this.m_session.SetBitFlag(SessionFlags.RequestStreamed, false);
                }
                if (Utilities.isRPCOverHTTPSMethod(this.m_headers.HTTPMethod) && !this.m_headers.ExistsAndEquals("Content-Length", "0"))
                {
                    this.m_session.SetBitFlag(SessionFlags.IsRPCTunnel, true);
                    return true;
                }
                if (this.m_headers.ExistsAndEquals("Transfer-Encoding", "chunked"))
                {
                    this.stateRead.bIsChunkedBody = true;
                }
                else if (this.m_headers.Exists("Content-Length"))
                {
                    long result = 0L;
                    if (!long.TryParse(this.m_headers["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out result) || (result < 0L))
                    {
                        FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, true, true, "Request content length was invalid.\nContent-Length: " + this.m_headers["Content-Length"]);
                        this.FailSession(400, "Fiddler - Bad Request", "[Fiddler] Request Content-Length header parsing failed.\nContent-Length: " + this.m_headers["Content-Length"]);
                        return true;
                    }
                    this.stateRead.iContentLength = result;
                    if (result > 0L)
                    {
                        this.stateRead.m_requestData.HintTotalSize((int) (result + this.stateRead.iEntityBodyOffset));
                    }
                }
            }
            if (!this.stateRead.bIsChunkedBody)
            {
                return (this.stateRead.m_requestData.Length >= (this.stateRead.iEntityBodyOffset + this.stateRead.iContentLength));
            }
            if (this.stateRead.m_lngLastChunkInfoOffset < this.stateRead.iEntityBodyOffset)
            {
                this.stateRead.m_lngLastChunkInfoOffset = this.stateRead.iEntityBodyOffset;
            }
            return Utilities.IsChunkedBodyComplete(this.m_session, this.stateRead.m_requestData, this.stateRead.m_lngLastChunkInfoOffset, out this.stateRead.m_lngLastChunkInfoOffset, out num2);
        }

        private bool _ParseRequestForHeaders()
        {
            byte[] buffer;
            int num;
            int num2;
            int num3;
            byte[] buffer2;
            if ((this.stateRead.m_requestData != null) && (this.stateRead.iEntityBodyOffset >= 4))
            {
                string str;
                this.m_headers = new HTTPRequestHeaders(CONFIG.oHeaderEncoding);
                buffer = this.stateRead.m_requestData.GetBuffer();
                Parser.CrackRequestLine(buffer, out num2, out num3, out num, out str);
                if ((num2 < 1) || (num3 < 1))
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, true, false, "Incorrectly formed Request-Line");
                    FiddlerApplication.Log.LogFormat("!CrackRequestLine couldn't find URI.\n{0}\n", new object[] { Utilities.ByteArrayToHexView(buffer, 0x10, 0x100, true) });
                    return false;
                }
                if (!string.IsNullOrEmpty(str))
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, true, false, str);
                    FiddlerApplication.Log.LogFormat("!CrackRequestLine returned '{0}'.\n{1}\n", new object[] { str, Utilities.ByteArrayToHexView(buffer, 0x10, 0x100, true) });
                }
                string str2 = Encoding.ASCII.GetString(buffer, 0, num2 - 1);
                this.m_headers.HTTPMethod = str2.ToUpperInvariant();
                if (str2 != this.m_headers.HTTPMethod)
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, false, false, string.Format("Per RFC2616, HTTP Methods are case-sensitive. Client sent '{0}', expected '{1}'.", str2, this.m_headers.HTTPMethod));
                }
                this.m_headers.HTTPVersion = Encoding.ASCII.GetString(buffer, (num2 + num3) + 1, ((num - num3) - num2) - 2).Trim().ToUpperInvariant();
                int num4 = 0;
                if (buffer[num2] != 0x2f)
                {
                    if (((num3 > 7) && (buffer[num2 + 4] == 0x3a)) && ((buffer[num2 + 5] == 0x2f) && (buffer[num2 + 6] == 0x2f)))
                    {
                        this.m_headers.UriScheme = Encoding.ASCII.GetString(buffer, num2, 4);
                        num4 = num2 + 6;
                        num2 += 7;
                        num3 -= 7;
                    }
                    else if (((num3 > 8) && (buffer[num2 + 5] == 0x3a)) && ((buffer[num2 + 6] == 0x2f) && (buffer[num2 + 7] == 0x2f)))
                    {
                        this.m_headers.UriScheme = Encoding.ASCII.GetString(buffer, num2, 5);
                        num4 = num2 + 7;
                        num2 += 8;
                        num3 -= 8;
                    }
                    else if (((num3 > 6) && (buffer[num2 + 3] == 0x3a)) && ((buffer[num2 + 4] == 0x2f) && (buffer[num2 + 5] == 0x2f)))
                    {
                        this.m_headers.UriScheme = Encoding.ASCII.GetString(buffer, num2, 3);
                        num4 = num2 + 5;
                        num2 += 6;
                        num3 -= 6;
                    }
                }
                if (num4 == 0)
                {
                    if ((this.pipeClient != null) && this.pipeClient.bIsSecured)
                    {
                        this.m_headers.UriScheme = "https";
                    }
                    else
                    {
                        this.m_headers.UriScheme = "http";
                    }
                }
                if (num4 <= 0)
                {
                    goto Label_038D;
                }
                if (num3 != 0)
                {
                    while (((num3 > 0) && (buffer[num2] != 0x2f)) && (buffer[num2] != 0x3f))
                    {
                        num2++;
                        num3--;
                    }
                    int index = num4 + 1;
                    int count = num2 - index;
                    if (count > 0)
                    {
                        this.stateRead.m_sHostFromURI = CONFIG.oHeaderEncoding.GetString(buffer, index, count);
                        if ((this.m_headers.UriScheme == "ftp") && this.stateRead.m_sHostFromURI.Contains("@"))
                        {
                            int length = this.stateRead.m_sHostFromURI.LastIndexOf("@") + 1;
                            this.m_headers.UriUserInfo = this.stateRead.m_sHostFromURI.Substring(0, length);
                            this.stateRead.m_sHostFromURI = this.stateRead.m_sHostFromURI.Substring(length);
                        }
                    }
                    goto Label_038D;
                }
                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, true, false, "Incorrectly formed Request-Line. Request-URI component was missing.\r\n\r\n" + Encoding.ASCII.GetString(buffer, 0, num));
            }
            return false;
        Label_038D:
            buffer2 = new byte[num3];
            Buffer.BlockCopy(buffer, num2, buffer2, 0, num3);
            this.m_headers.RawPath = buffer2;
            if (string.IsNullOrEmpty(this.m_headers.RequestPath))
            {
                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, false, false, "Incorrectly formed Request-Line. abs_path was empty (e.g. missing /). RFC2616 Section 5.1.2");
            }
            string str3 = CONFIG.oHeaderEncoding.GetString(buffer, num, this.stateRead.iEntityBodyOffset - num).Trim();
            buffer = null;
            if (str3.Length >= 1)
            {
                string[] sHeaderLines = str3.Replace("\r\n", "\n").Split(new char[] { '\n' });
                string sErrors = string.Empty;
                if (!Parser.ParseNVPHeaders(this.m_headers, sHeaderLines, 0, ref sErrors))
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, true, false, "Incorrectly formed request headers.\n" + sErrors);
                }
            }
            if (this.m_headers.Exists("Content-Length") && this.m_headers.ExistsAndContains("Transfer-Encoding", "chunked"))
            {
                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, false, false, "Content-Length request header MUST NOT be present when Transfer-Encoding is used (RFC2616 Section 4.4)");
            }
            return true;
        }

        private void _ValidateHostDuringReadRequest()
        {
            if (this.stateRead.m_sHostFromURI != null)
            {
                if (this.m_headers.Exists("Host"))
                {
                    if (!Utilities.areOriginsEquivalent(this.stateRead.m_sHostFromURI, this.m_headers["Host"], this.m_session.isHTTPS ? 0x1bb : (this.m_session.isFTP ? 0x15 : 80)) && (!this.m_session.isTunnel || !Utilities.areOriginsEquivalent(this.stateRead.m_sHostFromURI, this.m_headers["Host"], 0x1bb)))
                    {
                        this.m_session.oFlags["X-Original-Host"] = this.m_headers["Host"];
                        this.m_session.oFlags["X-URI-Host"] = this.stateRead.m_sHostFromURI;
                        if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.SetHostHeaderFromURL", true))
                        {
                            this.m_headers["Host"] = this.stateRead.m_sHostFromURI;
                        }
                    }
                }
                else
                {
                    if ("HTTP/1.1".OICEquals(this.m_headers.HTTPVersion))
                    {
                        this.m_session.oFlags["X-Original-Host"] = string.Empty;
                    }
                    this.m_headers["Host"] = this.stateRead.m_sHostFromURI;
                }
            }
        }

        internal void BuildAndReturnResponse(int iStatus, string sStatusText, string sBodyText, Action<Session> delLastChance)
        {
            this.m_session.SetBitFlag(SessionFlags.ResponseGeneratedByFiddler, true);
            if ((iStatus >= 400) && (sBodyText.Length < 0x200))
            {
                sBodyText = sBodyText.PadRight(0x200, ' ');
            }
            this.m_session.responseBodyBytes = Encoding.UTF8.GetBytes(sBodyText);
            this.m_session.oResponse.headers = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
            this.m_session.oResponse.headers.SetStatus(iStatus, sStatusText);
            this.m_session.oResponse.headers.Add("Date", DateTime.UtcNow.ToString("r"));
            this.m_session.oResponse.headers.Add("Content-Type", "text/html; charset=UTF-8");
            this.m_session.oResponse.headers.Add("Connection", "close");
            this.m_session.oResponse.headers.Add("Cache-Control", "no-cache, must-revalidate");
            this.m_session.oResponse.headers.Add("Timestamp", DateTime.Now.ToString("HH:mm:ss.fff"));
            this.m_session.state = SessionStates.Aborted;
            if (delLastChance != null)
            {
                delLastChance(this.m_session);
            }
            FiddlerApplication.DoBeforeReturningError(this.m_session);
            this.m_session.ReturnResponse(false);
        }

        public void FailSession(int iError, string sErrorStatusText, string sErrorBody)
        {
            this.m_session.EnsureID();
            this.m_session.oFlags["X-FailSession-When"] = this.m_session.state.ToString();
            this.BuildAndReturnResponse(iError, sErrorStatusText, sErrorBody, null);
        }

        internal bool ReadRequest()
        {
            if (this.stateRead != null)
            {
                FiddlerApplication.ReportException(new InvalidOperationException("ReadRequest called when requestData buffer already existed."));
                return false;
            }
            if (this.pipeClient == null)
            {
                FiddlerApplication.ReportException(new InvalidOperationException("ReadRequest called after pipeClient was null'd."));
                return false;
            }
            this.stateRead = new RequestReaderState();
            this.m_session.SetBitFlag(SessionFlags.ClientPipeReused, this.pipeClient.iUseCount > 0);
            this.pipeClient.IncrementUse(0);
            this.pipeClient.setReceiveTimeout(true);
            bool flag = false;
            bool flag2 = false;
            byte[] arrBuffer = new byte[s_cbClientReadBuffer];
            int bytesRead = 0;
            SessionTimers.NetTimestamps timestamps = new SessionTimers.NetTimestamps();
            Stopwatch stopwatch = Stopwatch.StartNew();
        Label_008E:
            try
            {
                bytesRead = this.pipeClient.Receive(arrBuffer);
                timestamps.AddRead(stopwatch.ElapsedMilliseconds, bytesRead);
            }
            catch (SocketException exception)
            {
                flag = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("ReadRequest {0} threw #{1} - {2}", new object[] { (this.pipeClient == null) ? "Null pipeClient" : this.pipeClient.ToString(), exception.ErrorCode, exception.Message });
                }
                if (exception.SocketErrorCode == SocketError.TimedOut)
                {
                    this.m_session.oFlags["X-ClientPipeError"] = string.Format("ReadRequest timed out; total of {0:N0} bytes read from client.", this.stateRead.m_requestData.Length);
                    this.FailSession(0x198, "Request Timed Out", string.Format("The client failed to send a complete request on this {0} connection before the timeout period elapsed; {1} bytes were read from client.", ((this.pipeClient.iUseCount < 2) || (this.pipeClient.bIsSecured && (this.pipeClient.iUseCount < 3))) ? "NEW" : "REUSED", this.stateRead.m_requestData.Length));
                }
                goto Label_0377;
            }
            catch (Exception exception2)
            {
                flag = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("ReadRequest {0} threw {1}", new object[] { (this.pipeClient == null) ? "Null pipeClient" : this.pipeClient.ToString(), exception2.Message });
                }
                goto Label_0377;
            }
            if (bytesRead < 1)
            {
                flag2 = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("ReadRequest {0} returned {1}", new object[] { (this.pipeClient == null) ? "Null pipeClient" : this.pipeClient.ToString(), bytesRead });
                }
            }
            else
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("READ {0} FROM {1}:\n{2}", new object[] { bytesRead, this.pipeClient, Utilities.ByteArrayToHexView(arrBuffer, 0x20, bytesRead) });
                }
                if (0L == this.stateRead.m_requestData.Length)
                {
                    this.m_session.Timers.ClientBeginRequest = DateTime.Now;
                    if (((1 == this.pipeClient.iUseCount) && (bytesRead > 2)) && ((arrBuffer[0] == 4) || (arrBuffer[0] == 5)))
                    {
                        FiddlerApplication.Log.LogFormat("It looks like '{0}' is trying to send SOCKS traffic to us.\r\n{1}", new object[] { this.m_session["X-ProcessInfo"], Utilities.ByteArrayToHexView(arrBuffer, 0x10, Math.Min(bytesRead, 0x100)) });
                        return false;
                    }
                    int index = 0;
                    while ((index < bytesRead) && ((13 == arrBuffer[index]) || (10 == arrBuffer[index])))
                    {
                        index++;
                    }
                    this.stateRead.m_requestData.Write(arrBuffer, index, bytesRead - index);
                    this.pipeClient.setReceiveTimeout(false);
                }
                else
                {
                    this.stateRead.m_requestData.Write(arrBuffer, 0, bytesRead);
                }
            }
        Label_0377:
            if ((!flag2 && !flag) && !this._isRequestComplete())
            {
                goto Label_008E;
            }
            arrBuffer = null;
            stopwatch = null;
            this.m_session.Timers.ClientReads = timestamps;
            if (flag || (this.stateRead.m_requestData.Length == 0L))
            {
                FiddlerApplication.DebugSpew("Reading from client set bAbort or m_requestData was empty");
                if ((this.pipeClient != null) && ((this.pipeClient.iUseCount < 2) || (this.pipeClient.bIsSecured && (this.pipeClient.iUseCount < 3))))
                {
                    FiddlerApplication.Log.LogFormat("[Fiddler] No {0} request was received from ({1}) new client socket, port {2}.", new object[] { this.pipeClient.bIsSecured ? "HTTPS" : "HTTP", this.m_session.oFlags["X-ProcessInfo"], this.m_session.oFlags["X-CLIENTPORT"] });
                }
                return false;
            }
            if (this.m_headers == null)
            {
                FiddlerApplication.DebugSpew("Reading from client set either bDone or bAbort without making any headers available");
                return false;
            }
            if (this.m_session.state >= SessionStates.Done)
            {
                FiddlerApplication.DebugSpew("SessionState >= Done while reading request");
                return false;
            }
            if ("CONNECT" == this.m_headers.HTTPMethod)
            {
                this.m_session.isTunnel = true;
                this.stateRead.m_sHostFromURI = this.m_session.PathAndQuery;
            }
            this._ValidateHostDuringReadRequest();
            return this.m_headers.Exists("Host");
        }

        internal bool ReadRequestBodyFromFile(string sFilename)
        {
            if (!File.Exists(sFilename))
            {
                this.m_session.utilSetRequestBody("File not found: " + sFilename);
                return false;
            }
            this.m_session.RequestBody = File.ReadAllBytes(sFilename);
            return true;
        }

        internal byte[] TakeEntity()
        {
            byte[] bytes;
            if (this.stateRead == null)
            {
                return Utilities.emptyByteArray;
            }
            if (this.stateRead.m_requestData.Length < 1L)
            {
                this._freeRequestData();
                return Utilities.emptyByteArray;
            }
            long num = this.stateRead.m_requestData.Length - this.stateRead.iEntityBodyOffset;
            long num2 = this._calculateExpectedEntityTransferSize();
            if (num != num2)
            {
                if (num > num2)
                {
                    try
                    {
                        byte[] dst = new byte[num - num2];
                        FiddlerApplication.Log.LogFormat("HTTP Pipelining Client detected; {0:N0} bytes of excess data on client socket for Session #{1}.", new object[] { dst.Length, this.m_session.id });
                        Buffer.BlockCopy(this.stateRead.m_requestData.GetBuffer(), this.stateRead.iEntityBodyOffset + ((int) num2), dst, 0, dst.Length);
                        this.pipeClient.putBackSomeBytes(dst);
                    }
                    catch (OutOfMemoryException exception)
                    {
                        this.m_session.PoisonClientPipe();
                        FiddlerApplication.Log.LogFormat("HTTP Request Pipelined data too large to store. Abandoning it" + Utilities.DescribeException(exception), new object[0]);
                    }
                    num = num2;
                }
                else if (!this.m_session.isAnyFlagSet(SessionFlags.IsRPCTunnel | SessionFlags.RequestStreamed))
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, true, true, string.Format("Content-Length mismatch: Request Header indicated {0:N0} bytes, but client sent {1:N0} bytes.", num2, num));
                    if (!this.m_session.isAnyFlagSet(SessionFlags.RequestGeneratedByFiddler))
                    {
                        if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.RejectIncompleteRequests", true))
                        {
                            this.FailSession(0x198, "Request body incomplete", string.Format("The request body did not contain the specified number of bytes. Got {0:N0}, expected {1:N0}", num, num2));
                            throw new InvalidDataException(string.Format("The request body did not contain the specified number of bytes. Got {0:N0}, expected {1:N0}", num, num2));
                        }
                        if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.FixRequestContentLength", true))
                        {
                            this.m_headers.RenameHeaderItems("Content-Length", "Original-Content-Length");
                            this.m_headers["Content-Length"] = num.ToString();
                        }
                    }
                }
            }
            try
            {
                bytes = new byte[num];
                Buffer.BlockCopy(this.stateRead.m_requestData.GetBuffer(), this.stateRead.iEntityBodyOffset, bytes, 0, bytes.Length);
            }
            catch (OutOfMemoryException exception2)
            {
                FiddlerApplication.ReportException(exception2, "HTTP Request Too Large");
                bytes = Encoding.ASCII.GetBytes("Fiddler: Out of memory");
                this.m_session.PoisonClientPipe();
            }
            this._freeRequestData();
            return bytes;
        }

        internal long _PeekUploadProgress
        {
            get
            {
                RequestReaderState stateRead = this.stateRead;
                if (stateRead == null)
                {
                    return -1L;
                }
                return stateRead.GetBodyBytesRead();
            }
        }

        public bool bClientSocketReused
        {
            get
            {
                return this.m_session.isFlagSet(SessionFlags.ClientPipeReused);
            }
        }

        [CodeDescription("Controls whether the request body is streamed to the server as it is read from the client.")]
        public bool BufferRequest
        {
            get
            {
                return this.m_session.isFlagSet(SessionFlags.RequestStreamed);
            }
            set
            {
                if (this.m_session.state > SessionStates.ReadingRequest)
                {
                    throw new InvalidOperationException("Too late. BufferRequest may only be set before or while ReadingRequest.");
                }
                this.m_session.SetBitFlag(SessionFlags.RequestStreamed, !value);
            }
        }

        public HTTPRequestHeaders headers
        {
            get
            {
                return this.m_headers;
            }
            set
            {
                this.m_headers = value;
            }
        }

        public string host
        {
            get
            {
                if (this.m_headers != null)
                {
                    return this.m_headers["Host"];
                }
                return string.Empty;
            }
            internal set
            {
                if (this.m_headers != null)
                {
                    if (value == null)
                    {
                        value = string.Empty;
                    }
                    if (value.EndsWith(":80") && "HTTP".OICEquals(this.m_headers.UriScheme))
                    {
                        value = value.Substring(0, value.Length - 3);
                    }
                    this.m_headers["Host"] = value;
                    if ("CONNECT".OICEquals(this.m_headers.HTTPMethod))
                    {
                        this.m_headers.RequestPath = value;
                    }
                }
            }
        }

        [CodeDescription("Returns the port on which Fiddler read the request (typically 8888). Only available while the request is alive.")]
        public int InboundPort
        {
            get
            {
                try
                {
                    if (this.pipeClient != null)
                    {
                        return this.pipeClient.LocalPort;
                    }
                }
                catch
                {
                }
                return 0;
            }
        }

        public string this[string sHeader]
        {
            get
            {
                if (this.m_headers == null)
                {
                    return string.Empty;
                }
                return this.m_headers[sHeader];
            }
            set
            {
                if (this.m_headers == null)
                {
                    throw new InvalidDataException("Request Headers object does not exist");
                }
                this.m_headers[sHeader] = value;
            }
        }

        private class RequestReaderState : IDisposable
        {
            internal bool bIsChunkedBody;
            internal int iBodySeekProgress;
            internal long iContentLength;
            internal int iEntityBodyOffset;
            internal long m_lngLastChunkInfoOffset;
            internal PipeReadBuffer m_requestData = new PipeReadBuffer(true);
            internal string m_sHostFromURI;

            internal RequestReaderState()
            {
            }

            internal bool _areHeadersAvailable(Session oS)
            {
                HTTPHeaderParseWarnings warnings;
                if (this.m_requestData.Length < 0x10L)
                {
                    return false;
                }
                long length = this.m_requestData.Length;
                if (!Parser.FindEndOfHeaders(this.m_requestData.GetBuffer(), ref this.iBodySeekProgress, length, out warnings))
                {
                    return false;
                }
                this.iEntityBodyOffset = this.iBodySeekProgress + 1;
                switch (warnings)
                {
                    case HTTPHeaderParseWarnings.EndedWithLFLF:
                        FiddlerApplication.HandleHTTPError(oS, SessionFlags.ProtocolViolationInRequest, false, false, "The Client did not send properly formatted HTTP Headers. HTTP headers\nshould be terminated with CRLFCRLF. These were terminated with LFLF.");
                        break;

                    case HTTPHeaderParseWarnings.EndedWithLFCRLF:
                        FiddlerApplication.HandleHTTPError(oS, SessionFlags.ProtocolViolationInRequest, false, false, "The Client did not send properly formatted HTTP Headers. HTTP headers\nshould be terminated with CRLFCRLF. These were terminated with LFCRLF.");
                        break;
                }
                return true;
            }

            public void Dispose()
            {
                if (this.m_requestData != null)
                {
                    this.m_requestData.Dispose();
                    this.m_requestData = null;
                }
            }

            internal long GetBodyBytesRead()
            {
                long length = this.m_requestData.Length;
                if (length > this.iEntityBodyOffset)
                {
                    return (length - this.iEntityBodyOffset);
                }
                return length;
            }
        }
    }
}

