﻿namespace Fiddler
{
    using System;
    using System.Windows.Forms;

    internal class HiddenMessagingWindow : NativeWindow
    {
        private IntPtr _hwndParent;

        public HiddenMessagingWindow(IntPtr Parent)
        {
            this._hwndParent = Parent;
            CreateParams cp = new CreateParams();
            cp.Caption = "Fiddler - HTTP Debugging Proxy";
            cp.ClassName = null;
            this.CreateHandle(cp);
        }

        protected override void WndProc(ref Message m)
        {
            int msg = m.Msg;
            if (msg != 0x18)
            {
                if (msg == 0x4a)
                {
                    FiddlerApplication.UI.HandleWMCopyData(m);
                    return;
                }
                if (msg != 0x312)
                {
                    base.WndProc(ref m);
                    return;
                }
            }
            Utilities.SendMessage(this._hwndParent, (int) m.Msg, m.WParam, m.LParam);
        }
    }
}

