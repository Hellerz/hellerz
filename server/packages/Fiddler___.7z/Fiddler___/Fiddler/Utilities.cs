﻿namespace Fiddler
{
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.IO.Compression;
    using System.Net;
    using System.Net.NetworkInformation;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Security.Authentication;
    using System.Security.Cryptography;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Web;
    using System.Windows.Forms;
    using Xceed.Compression;
    using Xceed.Compression.Formats;
    using Xceed.FileSystem;
    using Xceed.Zip;

    public static class Utilities
    {
        private const int CB_SETCUEBANNER = 0x1703;
        private const int EM_SETCUEBANNER = 0x1501;
        public static readonly byte[] emptyByteArray = new byte[0];
        public const string sCommonRequestHeaders = "Cache-Control,If-None-Match,If-Modified-Since,Pragma,If-Unmodified-Since,If-Range,If-Match,Content-Length,Content-Type,Referer,Origin,SOAPAction,Expect,Content-Encoding,TE,Transfer-Encoding,Proxy-Connection,Connection,Accept,Accept-Charset,Accept-Encoding,Accept-Language,User-Agent,UA-Color,UA-CPU,UA-OS,UA-Pixels,Cookie,Cookie2,DNT,Authorization,Proxy-Authorization,X-Requested-With,X-Download-Initiator";
        public const string sCommonResponseHeaders = "Age,Cache-Control,Date,Expires,Pragma,Vary,Content-Length,ETag,Last-Modified,Content-Type,Content-Disposition,Content-Encoding,Transfer-encoding,Via,Keep-Alive,Location,Proxy-Connection,Connection,Set-Cookie,WWW-Authenticate,Proxy-Authenticate,P3P,X-UA-Compatible,X-Frame-options,X-Content-Type-Options,X-XSS-Protection,Strict-Transport-Security,Content-Security-Policy,Access-Control-Allow-Origin";
        private static Encoding[] sniffableEncodings = new Encoding[] { Encoding.UTF32, Encoding.BigEndianUnicode, Encoding.Unicode, Encoding.UTF8 };
        internal const int SW_HIDE = 0;
        internal const int SW_RESTORE = 9;
        internal const int SW_SHOW = 5;
        internal const int SW_SHOWNA = 8;
        internal const int WM_COPYDATA = 0x4a;
        internal const int WM_HOTKEY = 0x312;
        internal const int WM_QUERYENDSESSION = 0x11;
        internal const int WM_SHOWWINDOW = 0x18;
        internal const int WM_SIZE = 5;

        private static MemoryStream _ConvertJXRToPNG(MemoryStream oStream)
        {
            string path = CONFIG.GetPath("Tools") + "jxr2png.exe";
            if (!System.IO.File.Exists(path))
            {
                throw new Exception(@"JXR images can only be decoded if jxr2png.exe is in Fiddler's \Tools\ subfolder.");
            }
            Guid guid = Guid.NewGuid();
            string str2 = CONFIG.GetPath("Root") + guid.ToString() + ".jxr";
            string str3 = CONFIG.GetPath("Root") + guid.ToString() + ".png";
            System.IO.File.WriteAllBytes(str2, oStream.ToArray());
            try
            {
                string sParams = string.Format("\"{0}\" \"{1}\"", str2, str3);
                int iExitCode = 0;
                GetExecutableOutput(path, sParams, out iExitCode);
                if (iExitCode != 0)
                {
                    throw new Exception("JXR conversion failed");
                }
                oStream = new MemoryStream(System.IO.File.ReadAllBytes(str3));
            }
            finally
            {
                try
                {
                    System.IO.File.Delete(str2);
                }
                catch
                {
                }
                try
                {
                    System.IO.File.Delete(str3);
                }
                catch
                {
                }
            }
            return oStream;
        }

        private static MemoryStream _ConvertWebPToPNG(MemoryStream oStream)
        {
            string path = CONFIG.GetPath("Tools") + "dwebp.exe";
            if (!System.IO.File.Exists(path))
            {
                throw new Exception(@"WebP images can only be decoded if DWebP.exe is in Fiddler's \Tools\ subfolder.");
            }
            Guid guid = Guid.NewGuid();
            string str2 = CONFIG.GetPath("Root") + guid.ToString() + ".webp";
            string str3 = CONFIG.GetPath("Root") + guid.ToString() + ".png";
            System.IO.File.WriteAllBytes(str2, oStream.ToArray());
            try
            {
                string sParams = string.Format("\"{0}\" -o \"{1}\"", str2, str3);
                int iExitCode = 0;
                GetExecutableOutput(path, sParams, out iExitCode);
                if (iExitCode != 0)
                {
                    throw new Exception("WebP conversion failed");
                }
                oStream = new MemoryStream(System.IO.File.ReadAllBytes(str3));
            }
            finally
            {
                try
                {
                    System.IO.File.Delete(str2);
                }
                catch
                {
                }
                try
                {
                    System.IO.File.Delete(str3);
                }
                catch
                {
                }
            }
            return oStream;
        }

        private static void _DecodeInOrder(string sEncodingsInOrder, bool bAllowChunks, ref byte[] arrBody, bool bNoUI)
        {
            if (!string.IsNullOrEmpty(sEncodingsInOrder))
            {
                string[] strArray = sEncodingsInOrder.ToLower().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = strArray.Length - 1; i >= 0; i--)
                {
                    string str = strArray[i].Trim();
                    switch (str)
                    {
                        case "gzip":
                            arrBody = GzipExpand(arrBody, bNoUI);
                            goto Label_0221;

                        case "deflate":
                            arrBody = DeflaterExpand(arrBody, bNoUI);
                            goto Label_0221;

                        case "bzip2":
                            arrBody = bzip2Expand(arrBody, bNoUI);
                            goto Label_0221;

                        case "br":
                            if (!FiddlerApplication.Supports("br"))
                            {
                                goto Label_0203;
                            }
                            try
                            {
                                arrBody = BrotliExpand(arrBody);
                                goto Label_0221;
                            }
                            catch (Exception exception)
                            {
                                FiddlerApplication.Log.LogFormat("!Cannot decode HTTP response using Encoding: {0}; error: {1}", new object[] { str, DescribeException(exception) });
                                goto Label_0203;
                            }
                            break;

                        case "xpress":
                            break;

                        case "chunked":
                            if (bAllowChunks)
                            {
                                if (i != (strArray.Length - 1))
                                {
                                    FiddlerApplication.Log.LogFormat("!Chunked Encoding must be the LAST Transfer-Encoding applied!", new object[] { sEncodingsInOrder });
                                }
                                arrBody = doUnchunk(arrBody, null, bNoUI);
                            }
                            else
                            {
                                FiddlerApplication.Log.LogFormat("!Chunked encoding is permitted only in the Transfer-Encoding header. Content-Encoding: {0}", new object[] { str });
                            }
                            goto Label_0221;

                        case "none":
                        case "identity":
                            goto Label_0221;

                        default:
                            goto Label_0203;
                    }
                    try
                    {
                        arrBody = XpressExpand(arrBody);
                    }
                    catch (Exception exception2)
                    {
                        FiddlerApplication.Log.LogFormat("!Cannot decode HTTP response using Encoding: {0}; error: {1}", new object[] { str, DescribeException(exception2) });
                    }
                    goto Label_0221;
                Label_0203:;
                    FiddlerApplication.Log.LogFormat("!Cannot decode HTTP response using Encoding: {0}", new object[] { str });
                Label_0221:;
                }
            }
        }

        public static bool _HasGZIPMarker(byte[] arrData)
        {
            byte[] arrMagics = new byte[] { 0x1f, 0x8b };
            return HasMagicBytes(arrData, arrMagics);
        }

        public static string _HasZLIBMarker(byte[] arrData)
        {
            if (((arrData[0] & 15) != 8) || ((arrData[0] & 0x80) != 0))
            {
                return "Not DEFLATE";
            }
            if ((((arrData[0] * 0x100) + arrData[1]) % 0x1f) != 0)
            {
                return "Invalid FCHECK";
            }
            int num = (arrData[0] & 240) >> 4;
            int num2 = (int) Math.Pow(2.0, (double) (num + 8));
            bool flag = (arrData[1] & 0x20) == 0x20;
            int num3 = (arrData[1] & 0xc0) >> 6;
            return string.Format("Deflate WindowSize is: 0x{0:X}\nDictionary: {1}\nCompLevel: {2}", num2, flag, num3);
        }

        private static bool _TryContentDecode(string sEncodingsInOrder, out string sRemainingEncodings, ref byte[] arrBody, bool bNoUI)
        {
            if (string.IsNullOrEmpty(sEncodingsInOrder))
            {
                sRemainingEncodings = null;
                return false;
            }
            string[] strArray = sEncodingsInOrder.ToLower().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = strArray.Length - 1; i >= 0; i--)
            {
                string str = strArray[i].Trim();
                switch (str)
                {
                    case "gzip":
                    {
                        arrBody = GzipExpand(arrBody, bNoUI);
                        continue;
                    }
                    case "deflate":
                    {
                        arrBody = DeflaterExpand(arrBody, bNoUI);
                        continue;
                    }
                    case "br":
                        if (!FiddlerApplication.Supports("br"))
                        {
                            goto Label_01D5;
                        }
                        try
                        {
                            arrBody = BrotliExpand(arrBody);
                            continue;
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.Log.LogFormat("!Cannot decode HTTP response using Encoding: {0}; error: {1}", new object[] { str, DescribeException(exception) });
                            goto Label_01D5;
                        }
                        break;

                    case "bzip2":
                        break;

                    case "xpress":
                        goto Label_0173;

                    case "none":
                    case "identity":
                    {
                        continue;
                    }
                    case "chunked":
                        goto Label_01B7;

                    default:
                        goto Label_01D5;
                }
                arrBody = bzip2Expand(arrBody, bNoUI);
                continue;
            Label_0173:
                if (!FiddlerApplication.Supports("xpress"))
                {
                    goto Label_01D5;
                }
                try
                {
                    arrBody = XpressExpand(arrBody);
                    continue;
                }
                catch (Exception exception2)
                {
                    FiddlerApplication.Log.LogFormat("!Cannot decode HTTP response using Encoding: {0}; error: {1}", new object[] { str, DescribeException(exception2) });
                    goto Label_01D5;
                }
            Label_01B7:;
                FiddlerApplication.Log.LogFormat("!Chunked encoding is permitted only in the Transfer-Encoding header. Content-Encoding: {0}", new object[] { str });
            Label_01D5:;
                FiddlerApplication.Log.LogFormat("!Cannot decode HTTP response using Content-Encoding: {0}", new object[] { str });
                sRemainingEncodings = string.Join(",", strArray, 0, i + 1);
                return false;
            }
            sRemainingEncodings = null;
            return true;
        }

        private static void _WriteChunkSizeToStream(MemoryStream oMS, int iLen)
        {
            byte[] bytes = Encoding.ASCII.GetBytes(iLen.ToString("x"));
            oMS.Write(bytes, 0, bytes.Length);
        }

        private static void _WriteCRLFToStream(MemoryStream oMS)
        {
            oMS.WriteByte(13);
            oMS.WriteByte(10);
        }

        internal static void activateTabByTitle(string sName, TabControl tabSet)
        {
            foreach (TabPage page in tabSet.TabPages)
            {
                if (page.Text.OICEquals(sName))
                {
                    tabSet.SelectedTab = page;
                    break;
                }
            }
        }

        internal static void AddPathToPlaces(FileDialog dlg, string sPath)
        {
            try
            {
                if (((((sPath.Length >= 3) && (sPath[1] == Path.VolumeSeparatorChar)) && (sPath[2] == Path.DirectorySeparatorChar)) && (((sPath[0] >= 'a') && (sPath[0] <= 'z')) || ((sPath[0] >= 'A') && (sPath[0] <= 'Z')))) || (((sPath.Length >= 2) && (sPath[0] == '\\')) && (sPath[1] == '\\')))
                {
                    dlg.CustomPlaces.Add(sPath);
                }
                else
                {
                    FiddlerApplication.Log.LogFormat("!Unable to add '{0}' to CustomPlaces, it looks like a relative path", new object[] { sPath });
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("!Unable to add '{0}' to CustomPlaces: {1}", new object[] { sPath, DescribeException(exception) });
            }
        }

        public static void AdjustFontSize(Control c, float flSize)
        {
            if (c.Font.Size != flSize)
            {
                c.Font = new Font(c.Font.FontFamily, flSize);
            }
        }

        public static bool areOriginsEquivalent(string sOrigin1, string sOrigin2, int iDefaultPort)
        {
            string str;
            if (sOrigin1.OICEquals(sOrigin2))
            {
                return true;
            }
            int iPort = iDefaultPort;
            CrackHostAndPort(sOrigin1, out str, ref iPort);
            string inStr = string.Format("{0}:{1}", str, iPort);
            iPort = iDefaultPort;
            CrackHostAndPort(sOrigin2, out str, ref iPort);
            string toMatch = string.Format("{0}:{1}", str, iPort);
            return inStr.OICEquals(toMatch);
        }

        internal static bool arrayContainsNonText(byte[] arrIn)
        {
            if (arrIn != null)
            {
                for (int i = 0; i < arrIn.Length; i++)
                {
                    if (arrIn[i] == 0)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static byte[] BrotliExpand(byte[] arrIn)
        {
            string path = string.Concat(new object[] { CONFIG.GetPath("Root"), "tmpToCompress", Guid.NewGuid(), ".br" });
            string str2 = path + ".dat";
            System.IO.File.WriteAllBytes(path, arrIn);
            string sParams = string.Format("-d --in \"{0}\" --out \"{1}\"", path, str2);
            int iExitCode = 0;
            GetExecutableOutput(CONFIG.GetPath("Tools") + "brotli.exe", sParams, out iExitCode);
            if (iExitCode != 0)
            {
                throw new Exception("Brotli conversion failed");
            }
            byte[] buffer = System.IO.File.ReadAllBytes(str2);
            try
            {
                System.IO.File.Delete(path);
            }
            catch
            {
                FiddlerApplication.LogLeakedFile(path);
            }
            try
            {
                System.IO.File.Delete(str2);
            }
            catch
            {
                FiddlerApplication.LogLeakedFile(str2);
            }
            return buffer;
        }

        [CodeDescription("Returns a string representing a Hex view of a byte array. Slow.")]
        public static string ByteArrayToHexView(byte[] inArr, int iBytesPerLine)
        {
            return ByteArrayToHexView(inArr, iBytesPerLine, inArr.Length, true);
        }

        [CodeDescription("Returns a string representing a Hex view of a byte array. PERF: Slow.")]
        public static string ByteArrayToHexView(byte[] inArr, int iBytesPerLine, int iMaxByteCount)
        {
            return ByteArrayToHexView(inArr, iBytesPerLine, iMaxByteCount, true);
        }

        [CodeDescription("Returns a string representing a Hex view of a byte array. PERF: Slow.")]
        public static string ByteArrayToHexView(byte[] inArr, int iBytesPerLine, int iMaxByteCount, bool bShowASCII)
        {
            return ByteArrayToHexView(inArr, 0, iBytesPerLine, iMaxByteCount, bShowASCII);
        }

        [CodeDescription("Returns a string representing a Hex view of a byte array. PERF: Slow.")]
        public static string ByteArrayToHexView(byte[] inArr, int iStartAt, int iBytesPerLine, int iMaxByteCount, bool bShowASCII)
        {
            if ((inArr == null) || (inArr.Length == 0))
            {
                return string.Empty;
            }
            if ((iBytesPerLine < 1) || (iMaxByteCount < 1))
            {
                return string.Empty;
            }
            int num = Math.Min(iMaxByteCount + iStartAt, inArr.Length);
            StringBuilder builder = new StringBuilder(iMaxByteCount * 5);
            int num2 = iStartAt;
            bool flag = false;
            while (num2 < num)
            {
                int num3 = Math.Min(iBytesPerLine, num - num2);
                flag = num3 < iBytesPerLine;
                for (int i = 0; i < num3; i++)
                {
                    builder.Append(inArr[num2 + i].ToString("X2"));
                    builder.Append(" ");
                }
                if (flag)
                {
                    builder.Append(new string(' ', 3 * (iBytesPerLine - num3)));
                }
                if (bShowASCII)
                {
                    builder.Append(" ");
                    for (int j = 0; j < num3; j++)
                    {
                        if (inArr[num2 + j] < 0x20)
                        {
                            builder.Append(".");
                        }
                        else
                        {
                            builder.Append((char) inArr[num2 + j]);
                        }
                    }
                    if (flag)
                    {
                        builder.Append(new string(' ', iBytesPerLine - num3));
                    }
                }
                builder.Append("\r\n");
                num2 += iBytesPerLine;
            }
            return builder.ToString();
        }

        [CodeDescription("Returns a string representing a Hex stream of a byte array. Slow.")]
        public static string ByteArrayToString(byte[] inArr)
        {
            if (inArr == null)
            {
                return "null";
            }
            if (inArr.Length == 0)
            {
                return "empty";
            }
            return BitConverter.ToString(inArr).Replace('-', ' ');
        }

        [CodeDescription("Returns a byte[] representing the bzip2'd representation of writeData[]")]
        public static byte[] bzip2Compress(byte[] writeData)
        {
            if ((writeData == null) || (writeData.Length == 0))
            {
                return emptyByteArray;
            }
            try
            {
                MemoryStream inner = new MemoryStream();
                using (ZLibCompressedStream stream2 = new ZLibCompressedStream(inner, Xceed.Compression.CompressionMethod.BZip2, Xceed.Compression.CompressionLevel.Highest))
                {
                    stream2.Write(writeData, 0, writeData.Length);
                }
                return inner.ToArray();
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("The content could not be compressed.\n\n" + exception.Message, "Fiddler: BZIP Compression failed");
                return writeData;
            }
        }

        public static byte[] bzip2Expand(byte[] compressedData)
        {
            return bzip2Expand(compressedData, false);
        }

        public static byte[] bzip2Expand(byte[] compressedData, bool bThrowErrors)
        {
            if ((compressedData == null) || (compressedData.Length == 0))
            {
                return emptyByteArray;
            }
            try
            {
                MemoryStream inner = new MemoryStream(compressedData);
                MemoryStream stream2 = new MemoryStream(compressedData.Length);
                using (ZLibCompressedStream stream3 = new ZLibCompressedStream(inner, Xceed.Compression.CompressionMethod.BZip2, Xceed.Compression.CompressionLevel.Highest))
                {
                    byte[] buffer = new byte[0x8000];
                    int count = 0;
                    while ((count = stream3.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        stream2.Write(buffer, 0, count);
                    }
                }
                return stream2.ToArray();
            }
            catch (Exception exception)
            {
                if (bThrowErrors)
                {
                    throw new InvalidDataException("The content could not be expanded from BZip", exception);
                }
                FiddlerApplication.DoNotifyUser("The content could not be decompressed.\n\n" + exception.Message, "Fiddler: BZIP expansion failed");
                return emptyByteArray;
            }
        }

        [DllImport("cabinet", SetLastError=true)]
        private static extern bool CloseCompressor(IntPtr hCompressor);
        [DllImport("cabinet", SetLastError=true)]
        private static extern bool CloseDecompressor(IntPtr hDecompressor);
        [CodeDescription("Convert a full path into one that uses environment variables, e.g. %SYSTEM%")]
        public static string CollapsePath(string sPath)
        {
            StringBuilder pszBuf = new StringBuilder(0x103);
            if (PathUnExpandEnvStrings(sPath, pszBuf, pszBuf.Capacity))
            {
                return pszBuf.ToString();
            }
            return sPath;
        }

        public static string ColorToString(System.Drawing.Color c)
        {
            if (c.IsNamedColor)
            {
                return c.Name;
            }
            return string.Format("#{0:x2}{1:x2}{2:x2}", c.R, c.G, c.B);
        }

        [CodeDescription("Combine multiple Sessions with partial responses into a single Session with all of the response parts.")]
        public static Session CombinePartialResponses(Session[] arrParts)
        {
            if (arrParts.Length < 2)
            {
                return null;
            }
            HTTPRequestHeaders headersRequest = null;
            byte[] arrRequestBody = null;
            byte[] dst = null;
            HTTPResponseHeaders headersResponse = null;
            string fullUrl = arrParts[0].fullUrl;
            try
            {
                for (int i = 0; i < arrParts.Length; i++)
                {
                    if ((HasHeaders(arrParts[i].oResponse) && (arrParts[i].responseCode == 200)) && (arrParts[i].fullUrl == fullUrl))
                    {
                        if (headersResponse == null)
                        {
                            long num2;
                            headersResponse = (HTTPResponseHeaders) arrParts[i].oResponse.headers.Clone();
                            arrRequestBody = arrParts[i].requestBodyBytes;
                            headersRequest = arrParts[i].oRequest.headers;
                            if (!long.TryParse(headersResponse["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num2))
                            {
                                FiddlerApplication.DoNotifyUser("Unable to determine Content-Length for final response.", "Failed");
                                return null;
                            }
                            dst = new byte[num2];
                        }
                        if (!IsNullOrEmpty(arrParts[i].responseBodyBytes))
                        {
                            Buffer.BlockCopy(arrParts[i].responseBodyBytes, 0, dst, 0, arrParts[i].responseBodyBytes.Length);
                        }
                    }
                }
                for (int j = 0; j < arrParts.Length; j++)
                {
                    if ((HasHeaders(arrParts[j].oResponse) && !IsNullOrEmpty(arrParts[j].responseBodyBytes)) && ((arrParts[j].responseCode == 0xce) && (arrParts[j].fullUrl == fullUrl)))
                    {
                        string inStr = arrParts[j].oResponse.headers["Content-Range"];
                        if (inStr.OICStartsWith("bytes "))
                        {
                            string s = TrimAfter(inStr.Substring(6), "-");
                            if (headersResponse == null)
                            {
                                long num4;
                                headersResponse = (HTTPResponseHeaders) arrParts[j].oResponse.headers.Clone();
                                arrRequestBody = arrParts[j].requestBodyBytes;
                                headersRequest = arrParts[j].oRequest.headers;
                                headersResponse.SetStatus(200, "OK - Reassembled by Fiddler");
                                headersResponse.Remove("Content-Range");
                                if (!long.TryParse(TrimBefore(inStr.Substring(6), "/"), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num4))
                                {
                                    FiddlerApplication.DoNotifyUser("Unable to determine Content-Length for final response.", "Failed");
                                    return null;
                                }
                                dst = new byte[num4];
                            }
                            long result = 0L;
                            if (long.TryParse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out result))
                            {
                                Buffer.BlockCopy(arrParts[j].responseBodyBytes, 0, dst, (int) result, arrParts[j].responseBodyBytes.Length);
                            }
                        }
                    }
                }
                return FiddlerApplication.UI.AddMockSession(headersRequest, arrRequestBody, headersResponse, dst, false);
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
                return null;
            }
        }

        internal static void CompactLOHIfPossible()
        {
            try
            {
                PropertyInfo property = typeof(GCSettings).GetProperty("LargeObjectHeapCompactionMode", BindingFlags.Public | BindingFlags.Static);
                if (null != property)
                {
                    property.GetSetMethod().Invoke(null, new object[] { 2 });
                    GC.Collect();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(DescribeException(exception));
            }
        }

        public static string CompactPath(string sPath, int iCharLen)
        {
            if (string.IsNullOrEmpty(sPath))
            {
                return string.Empty;
            }
            if (sPath.Length > iCharLen)
            {
                StringBuilder pszOut = new StringBuilder(iCharLen + 1);
                if (PathCompactPathEx(pszOut, sPath, (int) (iCharLen + 1), 0))
                {
                    return pszOut.ToString();
                }
            }
            return sPath;
        }

        public static int CompareVersions(string sRequiredVersion, Version verTest)
        {
            string[] strArray = sRequiredVersion.Split(new char[] { '.' });
            if (strArray.Length != 4)
            {
                return 5;
            }
            VersionStruct struct2 = new VersionStruct();
            if ((!int.TryParse(strArray[0], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out struct2.Major) || !int.TryParse(strArray[1], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out struct2.Minor)) || (!int.TryParse(strArray[2], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out struct2.Build) || !int.TryParse(strArray[3], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out struct2.Private)))
            {
                return 6;
            }
            if (struct2.Major > verTest.Major)
            {
                return 4;
            }
            if (verTest.Major > struct2.Major)
            {
                return -4;
            }
            if (struct2.Minor > verTest.Minor)
            {
                return 3;
            }
            if (verTest.Minor > struct2.Minor)
            {
                return -3;
            }
            if (struct2.Build > verTest.Build)
            {
                return 2;
            }
            if (verTest.Build > struct2.Build)
            {
                return -2;
            }
            if (struct2.Private > verTest.Revision)
            {
                return 1;
            }
            if (verTest.Revision > struct2.Private)
            {
                return -1;
            }
            return 0;
        }

        internal static string ContentTypeForFileExtension(string sExtension)
        {
            if (string.IsNullOrEmpty(sExtension) || (sExtension.Length > 0xff))
            {
                return null;
            }
            if (sExtension == ".js")
            {
                return "text/javascript";
            }
            if (sExtension == ".json")
            {
                return "application/json";
            }
            if (sExtension == ".css")
            {
                return "text/css";
            }
            if (sExtension == ".htm")
            {
                return "text/html";
            }
            if (sExtension == ".html")
            {
                return "text/html";
            }
            if (sExtension == ".appcache")
            {
                return "text/cache-manifest";
            }
            if (sExtension == ".flv")
            {
                return "video/x-flv";
            }
            if (sExtension == ".woff")
            {
                return "application/font-woff";
            }
            if (sExtension == ".woff2")
            {
                return "application/font-woff2";
            }
            string str = null;
            string str2 = null;
            try
            {
                RegistryKey key = Registry.ClassesRoot.OpenSubKey(sExtension, RegistryKeyPermissionCheck.ReadSubTree);
                if (key == null)
                {
                    return str;
                }
                str = (string) key.GetValue("Content Type");
                if (string.IsNullOrEmpty(str))
                {
                    str2 = (string) key.GetValue("");
                    if (!string.IsNullOrEmpty(str2))
                    {
                        RegistryKey key2 = Registry.ClassesRoot.OpenSubKey(str2, RegistryKeyPermissionCheck.ReadSubTree);
                        if (key2 != null)
                        {
                            str = (string) key2.GetValue("Content Type");
                            key2.Close();
                        }
                    }
                }
                key.Close();
            }
            catch (SecurityException)
            {
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Registry Failure");
            }
            return str;
        }

        public static string ContentTypeForFilename(string sFilename)
        {
            string sExtension = string.Empty;
            try
            {
                sExtension = Path.GetExtension(sFilename);
            }
            catch (Exception)
            {
                return "application/octet-stream";
            }
            string str2 = ContentTypeForFileExtension(sExtension);
            if (string.IsNullOrEmpty(str2))
            {
                return "application/octet-stream";
            }
            return str2;
        }

        internal static string ConvertCRAndLFToSpaces(string sIn)
        {
            sIn = sIn.Replace("\r\n", " ");
            sIn = sIn.Replace('\r', ' ');
            sIn = sIn.Replace('\n', ' ');
            return sIn;
        }

        [CodeDescription("Copy a string to the clipboard, with exception handling.")]
        public static bool CopyToClipboard(string sText)
        {
            DataObject oData = new DataObject();
            oData.SetData(DataFormats.Text, sText);
            return CopyToClipboard(oData);
        }

        public static bool CopyToClipboard(DataObject oData)
        {
            try
            {
                Clipboard.SetDataObject(oData, true);
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("Please disable any clipboard monitoring tools and try again.\n\n" + exception.Message, ".NET Framework Bug");
                return true;
            }
        }

        [CodeDescription("This function cracks the Host/Port combo, removing IPV6 brackets if needed.")]
        public static void CrackHostAndPort(string sHostPort, out string sHostname, ref int iPort)
        {
            int length = sHostPort.LastIndexOf(':');
            if ((length > -1) && (length > sHostPort.LastIndexOf(']')))
            {
                if (!int.TryParse(sHostPort.Substring(length + 1), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out iPort))
                {
                    iPort = -1;
                }
                sHostname = sHostPort.Substring(0, length);
            }
            else
            {
                sHostname = sHostPort;
            }
            if (sHostname.StartsWith("[", StringComparison.Ordinal) && sHostname.EndsWith("]", StringComparison.Ordinal))
            {
                sHostname = sHostname.Substring(1, sHostname.Length - 2);
            }
        }

        public static void CreateBundle(string sOutputFile, string[] sInputFiles, string sComment)
        {
            if (System.IO.File.Exists(sOutputFile))
            {
                System.IO.File.Delete(sOutputFile);
            }
            ZipArchive archive = new ZipArchive(new DiskFile(sOutputFile));
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.SAZ.UseMemoryCache", true))
            {
                archive.TempFolder = new MemoryFolder();
            }
            archive.BeginUpdate();
            if (!string.IsNullOrEmpty(sComment))
            {
                archive.Comment = sComment;
            }
            foreach (string str in sInputFiles)
            {
                if (System.IO.File.Exists(str))
                {
                    new DiskFile(str).CopyTo(archive.RootFolder, true);
                }
            }
            archive.EndUpdate();
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.ClearCaches", false))
            {
                ZipArchive.ClearCachedZipHandlers();
            }
        }

        [DllImport("cabinet", SetLastError=true)]
        private static extern bool CreateDecompressor(CompressAlgorithm Algorithm, IntPtr pAllocators, out IntPtr hDecompressor);
        [DllImport("cabinet", SetLastError=true)]
        private static extern bool Decompress(IntPtr hDecompressor, byte[] arrCompressedData, IntPtr cbCompressedDataSize, byte[] arrOutputBuffer, IntPtr cbUncompressedBufferSize, out IntPtr cbUncompressedDataSize);
        [CodeDescription("Returns a byte[] containing a DEFLATE'd copy of writeData[]")]
        public static byte[] DeflaterCompress(byte[] writeData)
        {
            if ((writeData == null) || (writeData.Length == 0))
            {
                return emptyByteArray;
            }
            try
            {
                return QuickCompression.Compress(writeData, Xceed.Compression.CompressionMethod.Deflated, Xceed.Compression.CompressionLevel.Normal);
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("The content could not be compressed.\n\n" + exception.Message, "Fiddler: Deflation failed");
                return writeData;
            }
        }

        [CodeDescription("Returns a byte[] representing the INFLATE'd representation of compressedData[]")]
        public static byte[] DeflaterExpand(byte[] compressedData)
        {
            return DeflaterExpand(compressedData, false);
        }

        public static byte[] DeflaterExpand(byte[] compressedData, bool bThrowErrors)
        {
            try
            {
                return DeflaterExpandInternal(CONFIG.bUseXceedDecompressForDeflate, compressedData);
            }
            catch (Exception exception)
            {
                if (bThrowErrors)
                {
                    throw new InvalidDataException("The content could not be inFlated", exception);
                }
                FiddlerApplication.DoNotifyUser("The content could not be decompressed.\n\n" + exception.Message, "Fiddler: Inflation failed");
                return emptyByteArray;
            }
        }

        public static byte[] DeflaterExpandInternal(bool bUseXceed, byte[] compressedData)
        {
            if ((compressedData == null) || (compressedData.Length == 0))
            {
                return emptyByteArray;
            }
            int offset = 0;
            if (((compressedData.Length > 2) && ((compressedData[0] & 15) == 8)) && (((compressedData[0] & 0x80) == 0) && ((((compressedData[0] << 8) + compressedData[1]) % 0x1f) == 0)))
            {
                offset = 2;
            }
            if (bUseXceed)
            {
                return QuickCompression.Decompress(compressedData, offset, compressedData.Length - offset, Xceed.Compression.CompressionMethod.Deflated, CONFIG.bCheckCompressionIntegrity);
            }
            MemoryStream stream = new MemoryStream(compressedData, offset, compressedData.Length - offset, false);
            MemoryStream stream2 = new MemoryStream(compressedData.Length);
            using (DeflateStream stream3 = new DeflateStream(stream, CompressionMode.Decompress))
            {
                byte[] buffer = new byte[0x8000];
                int count = 0;
                while ((count = stream3.Read(buffer, 0, buffer.Length)) > 0)
                {
                    stream2.Write(buffer, 0, count);
                }
            }
            return stream2.ToArray();
        }

        internal static string DescribeException(Exception eX)
        {
            StringBuilder builder = new StringBuilder(0x200);
            builder.AppendFormat("{0} {1}", eX.GetType(), eX.Message);
            if (eX.InnerException != null)
            {
                builder.AppendFormat(" < {0}", eX.InnerException.Message);
            }
            return builder.ToString();
        }

        internal static string DescribeExceptionWithStack(Exception eX)
        {
            StringBuilder builder = new StringBuilder(0x200);
            builder.AppendLine(eX.Message);
            builder.AppendLine(eX.StackTrace);
            if (eX.InnerException != null)
            {
                builder.AppendFormat(" < {0}", eX.InnerException.Message);
            }
            return builder.ToString();
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        private static extern bool DestroyIcon(IntPtr handle);
        public static byte[] doChunk(byte[] writeData, int iSuggestedChunkCount)
        {
            if ((writeData == null) || (writeData.Length < 1))
            {
                return Encoding.ASCII.GetBytes("0\r\n\r\n");
            }
            if (iSuggestedChunkCount < 1)
            {
                iSuggestedChunkCount = 1;
            }
            if (iSuggestedChunkCount > writeData.Length)
            {
                iSuggestedChunkCount = writeData.Length;
            }
            MemoryStream oMS = new MemoryStream(writeData.Length + (10 * iSuggestedChunkCount));
            int offset = 0;
            do
            {
                int num2 = writeData.Length - offset;
                int num3 = num2 / iSuggestedChunkCount;
                num3 = Math.Max(1, num3);
                num3 = Math.Min(num2, num3);
                _WriteChunkSizeToStream(oMS, num3);
                _WriteCRLFToStream(oMS);
                oMS.Write(writeData, offset, num3);
                _WriteCRLFToStream(oMS);
                offset += num3;
                iSuggestedChunkCount--;
                if (iSuggestedChunkCount < 1)
                {
                    iSuggestedChunkCount = 1;
                }
            }
            while (offset < writeData.Length);
            _WriteChunkSizeToStream(oMS, 0);
            _WriteCRLFToStream(oMS);
            _WriteCRLFToStream(oMS);
            return oMS.ToArray();
        }

        public static void DoFlash(IntPtr hWnd)
        {
            FLASHWINFO structure = new FLASHWINFO();
            structure.cbSize = Marshal.SizeOf(structure);
            structure.hwnd = hWnd;
            structure.dwFlags = 14;
            structure.uCount = 0;
            structure.dwTimeout = 0;
            FlashWindowEx(ref structure);
        }

        public static void DoOpenFileWith(string sFilename)
        {
            if (Environment.OSVersion.Version.Major > 5)
            {
                IntPtr zero = IntPtr.Zero;
                if (FiddlerApplication.UI != null)
                {
                    zero = FiddlerApplication.UI.Handle;
                }
                tagOPENASINFO oOAI = new tagOPENASINFO();
                oOAI.cszFile = sFilename;
                oOAI.cszClass = string.Empty;
                oOAI.oaifInFlags = tagOPEN_AS_INFO_FLAGS.OAIF_EXEC | tagOPEN_AS_INFO_FLAGS.OAIF_ALLOW_REGISTRATION;
                int num = SHOpenWithDialog(zero, ref oOAI);
                if (num != 0)
                {
                    FiddlerApplication.Log.LogFormat("SHOpenWithDialog returned 0x{0:X} for '{1}'", new object[] { num, sFilename });
                }
            }
            else
            {
                using (Process.Start("rundll32", "shell32.dll,OpenAs_RunDLL " + sFilename))
                {
                }
            }
        }

        public static byte[] doUnchunk(byte[] writeData)
        {
            return doUnchunk(writeData, null, !CONFIG.bReportHTTPErrors || CONFIG.QuietMode);
        }

        internal static byte[] doUnchunk(byte[] writeData, Session oS, bool bNoUI)
        {
            if ((writeData == null) || (writeData.Length == 0))
            {
                return emptyByteArray;
            }
            MemoryStream stream = new MemoryStream(writeData.Length);
            int index = 0;
            bool flag = false;
            while (!flag && (index <= (writeData.Length - 3)))
            {
                int num3;
                int num2 = index;
                while (((num2 < (writeData.Length - 1)) && (13 != writeData[num2])) && (10 != writeData[num2 + 1]))
                {
                    num2++;
                }
                if (num2 > (writeData.Length - 2))
                {
                    throw new InvalidDataException("HTTP Error: The chunked content is corrupt. Cannot find Chunk-Length in expected location. Offset: " + index.ToString());
                }
                string sString = Encoding.ASCII.GetString(writeData, index, num2 - index);
                index = num2 + 2;
                if (!TryHexParse(TrimAfter(sString, ';'), out num3))
                {
                    throw new InvalidDataException("HTTP Error: The chunked content is corrupt. Chunk Length was malformed. Offset: " + index.ToString());
                }
                if (num3 == 0)
                {
                    flag = true;
                }
                else
                {
                    if (writeData.Length < (num3 + index))
                    {
                        throw new InvalidDataException("HTTP Error: The chunked entity body is corrupt. The final chunk length is greater than the number of bytes remaining.");
                    }
                    stream.Write(writeData, index, num3);
                    index += num3 + 2;
                }
            }
            if (!flag)
            {
                FiddlerApplication.Log.LogFormat("{0}Chunked body did not terminate properly with 0-sized chunk.", new object[] { (oS != null) ? string.Format("Session #{0} -", oS.id) : string.Empty });
                if (!bNoUI)
                {
                    if (oS == null)
                    {
                    }
                    else
                    {
                        string.Format("\nSession #{0} -", oS.id);
                    }
                    FiddlerApplication.DoNotifyUser("Chunked body did not terminate properly with 0-sized chunk.", "HTTP Protocol Violation");
                }
            }
            byte[] dst = new byte[stream.Length];
            Buffer.BlockCopy(stream.GetBuffer(), 0, dst, 0, dst.Length);
            return dst;
        }

        public static byte[] Dupe(byte[] bIn)
        {
            if (bIn == null)
            {
                return emptyByteArray;
            }
            byte[] dst = new byte[bIn.Length];
            Buffer.BlockCopy(bIn, 0, dst, 0, bIn.Length);
            return dst;
        }

        public static string EllipsizeIfNeeded(string sString, int iMaxLength)
        {
            if (string.IsNullOrEmpty(sString))
            {
                return string.Empty;
            }
            if (iMaxLength >= sString.Length)
            {
                return sString;
            }
            return (sString.Substring(0, iMaxLength - 1) + '…');
        }

        public static T EnsureInRange<T>(T current, T min, T max)
        {
            if (Comparer<T>.Default.Compare(current, min) < 0)
            {
                return min;
            }
            if (Comparer<T>.Default.Compare(current, max) > 0)
            {
                return max;
            }
            return current;
        }

        public static void EnsureOverwritable(string sFilename)
        {
            if (!Directory.Exists(Path.GetDirectoryName(sFilename)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(sFilename));
            }
            if (System.IO.File.Exists(sFilename))
            {
                FileAttributes attributes = System.IO.File.GetAttributes(sFilename);
                System.IO.File.SetAttributes(sFilename, attributes & ~(FileAttributes.System | FileAttributes.Hidden | FileAttributes.ReadOnly));
            }
        }

        public static string EnsurePathIsAbsolute(string sRootPath, string sFilename)
        {
            try
            {
                if (!Path.IsPathRooted(sFilename))
                {
                    sFilename = sRootPath + sFilename;
                }
            }
            catch (Exception)
            {
            }
            return sFilename;
        }

        public static string EnsureUniqueFilename(string sFilename)
        {
            string sResult = sFilename;
            try
            {
                string directoryName = Path.GetDirectoryName(sFilename);
                string str3 = EnsureValidAsPath(directoryName);
                if (directoryName != str3)
                {
                    sResult = string.Format("{0}{1}{2}", str3, Path.DirectorySeparatorChar, Path.GetFileName(sFilename));
                }
                if (!FileOrFolderExists(sResult))
                {
                    return sResult;
                }
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(sResult);
                string extension = Path.GetExtension(sResult);
                int num = 1;
                do
                {
                    sResult = string.Format("{0}{1}{2}[{3}]{4}", new object[] { directoryName, Path.DirectorySeparatorChar, fileNameWithoutExtension, num.ToString(), extension });
                    num++;
                }
                while (FileOrFolderExists(sResult) || (num > 0x4000));
            }
            catch (Exception)
            {
            }
            return sResult;
        }

        public static string EnsureValidAsPath(string sTargetFolder)
        {
            try
            {
                if (Directory.Exists(sTargetFolder))
                {
                    return sTargetFolder;
                }
                string pathRoot = Path.GetPathRoot(sTargetFolder);
                if (!Directory.Exists(pathRoot))
                {
                    return sTargetFolder;
                }
                if (pathRoot[pathRoot.Length - 1] != Path.DirectorySeparatorChar)
                {
                    pathRoot = pathRoot + Path.DirectorySeparatorChar;
                }
                sTargetFolder = sTargetFolder.Substring(pathRoot.Length);
                string[] strArray = sTargetFolder.Split(new char[] { Path.DirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
                string str2 = pathRoot;
                for (int i = 0; i < strArray.Length; i++)
                {
                    if (System.IO.File.Exists(str2 + strArray[i]))
                    {
                        int num2 = 1;
                        string str3 = strArray[i];
                        do
                        {
                            strArray[i] = string.Format("{0}[{1}]", str3, num2);
                            num2++;
                        }
                        while (System.IO.File.Exists(str2 + strArray[i]));
                        break;
                    }
                    if (!Directory.Exists(str2 + strArray[i]))
                    {
                        break;
                    }
                    str2 = string.Format("{0}{1}{2}{1}", str2, Path.DirectorySeparatorChar, strArray[i]);
                }
                return string.Format("{0}{1}", pathRoot, string.Join(new string(Path.DirectorySeparatorChar, 1), strArray));
            }
            catch (Exception)
            {
                return sTargetFolder;
            }
        }

        internal static string ExtractAttributeValue(string sFullValue, string sAttribute)
        {
            string str = null;
            System.Text.RegularExpressions.Match match = new Regex(Regex.Escape(sAttribute) + "\\s?=\\s?[\"]?(?<TokenValue>[^\";]*)", RegexOptions.IgnoreCase).Match(sFullValue);
            if (match.Success && (match.Groups["TokenValue"] != null))
            {
                str = match.Groups["TokenValue"].Value;
            }
            return str;
        }

        internal static long ExtractAttributeValue(string sFullValue, string sAttribute, long lngDefault)
        {
            long result = lngDefault;
            System.Text.RegularExpressions.Match match = new Regex(Regex.Escape(sAttribute) + "\\s?=\\s?[\"]?(?<TokenValue>[^\";]*)", RegexOptions.IgnoreCase).Match(sFullValue);
            if ((match.Success && (match.Groups["TokenValue"] != null)) && !long.TryParse(match.Groups["TokenValue"].Value, out result))
            {
                result = lngDefault;
            }
            return result;
        }

        internal static bool FiddlerMeetsVersionRequirement(Assembly assemblyInput, string sWhatType)
        {
            if (!assemblyInput.IsDefined(typeof(RequiredVersionAttribute), false))
            {
                return false;
            }
            RequiredVersionAttribute customAttribute = (RequiredVersionAttribute) Attribute.GetCustomAttribute(assemblyInput, typeof(RequiredVersionAttribute));
            int num = CompareVersions(customAttribute.RequiredVersion, CONFIG.FiddlerVersionInfo);
            if (num > 0)
            {
                FiddlerApplication.DoNotifyUser(string.Format("The {0} in {1} require Fiddler v{2} or later. (You have v{3})\n\nPlease install the latest version of Fiddler from http://getfiddler.com.\n\nCode: {4}", new object[] { sWhatType, assemblyInput.CodeBase, customAttribute.RequiredVersion, CONFIG.FiddlerVersionInfo, num }), "Extension Not Loaded");
                return false;
            }
            return true;
        }

        internal static string FileExtensionForMIMEType(string sMIME)
        {
            if (!string.IsNullOrEmpty(sMIME) && (sMIME.Length <= 0xff))
            {
                sMIME = sMIME.ToLower();
                switch (sMIME)
                {
                    case "text/css":
                        return ".css";

                    case "text/html":
                        return ".htm";

                    case "text/javascript":
                    case "application/javascript":
                    case "application/x-javascript":
                        return ".js";

                    case "text/cache-manifest":
                        return ".appcache";

                    case "image/jpg":
                    case "image/jpeg":
                        return ".jpg";

                    case "image/gif":
                        return ".gif";

                    case "image/png":
                        return ".png";

                    case "image/x-icon":
                        return ".ico";

                    case "text/xml":
                        return ".xml";

                    case "video/x-flv":
                        return ".flv";

                    case "video/mp4":
                        return ".mp4";

                    case "text/plain":
                    case "application/octet-stream":
                        return ".txt";
                }
                try
                {
                    RegistryKey key = Registry.ClassesRoot.OpenSubKey(string.Format(@"\MIME\Database\Content Type\{0}", sMIME), RegistryKeyPermissionCheck.ReadSubTree);
                    if (key != null)
                    {
                        string str = (string) key.GetValue("Extension");
                        key.Close();
                        if (!string.IsNullOrEmpty(str))
                        {
                            return str;
                        }
                    }
                }
                catch
                {
                }
                if (sMIME.EndsWith("+xml"))
                {
                    return ".xml";
                }
            }
            return ".txt";
        }

        internal static bool FileOrFolderExists(string sResult)
        {
            try
            {
                return (System.IO.File.Exists(sResult) || Directory.Exists(sResult));
            }
            catch (Exception)
            {
                return true;
            }
        }

        [DllImport("user32.dll")]
        internal static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        private static extern bool FlashWindowEx(ref FLASHWINFO pwfi);
        internal static string GetClipboardAsString()
        {
            if (Clipboard.ContainsFileDropList())
            {
                string[] data = (string[]) Clipboard.GetData("FileDrop");
                if ((data == null) || (data.Length < 1))
                {
                    return string.Empty;
                }
                StringBuilder builder = new StringBuilder();
                foreach (string str in data)
                {
                    builder.AppendFormat("\"{0}\" ", str);
                }
                return builder.ToString(0, builder.Length - 1);
            }
            string text = Clipboard.GetText();
            if (!string.IsNullOrEmpty(text))
            {
                text = text.Replace('\r', ' ').Replace("\n", "").Replace('\t', ' ');
            }
            return text;
        }

        private static COMBOBOXINFO GetComboBoxInfo(Control control)
        {
            COMBOBOXINFO structure = new COMBOBOXINFO();
            structure.cbSize = Marshal.SizeOf(structure);
            GetComboBoxInfo(control.Handle, ref structure);
            return structure;
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError=true)]
        private static extern bool GetComboBoxInfo(IntPtr hwnd, ref COMBOBOXINFO pcbi);
        public static string GetCommaTokenValue(string sString, string sTokenName)
        {
            if (sString == null)
            {
                return null;
            }
            if (string.IsNullOrEmpty(sTokenName))
            {
                return null;
            }
            if (sString.Length < sTokenName.Length)
            {
                return null;
            }
            string str = null;
            if (!string.IsNullOrEmpty(sString))
            {
                System.Text.RegularExpressions.Match match = new Regex("(?:^" + sTokenName + "|[^\\w-=\"]" + sTokenName + ")(?:\\s?=\\s?[\"]?(?<TokenValue>[^\";,]*)|[\\s,;])", RegexOptions.IgnoreCase).Match(sString);
                if (match.Success && (match.Groups["TokenValue"] != null))
                {
                    str = match.Groups["TokenValue"].Value;
                }
            }
            return str;
        }

        public static System.Drawing.Color GetContrastingTextColor(System.Drawing.Color clrBackground)
        {
            if (Math.Sqrt((((clrBackground.R * clrBackground.R) * 0.299) + ((clrBackground.G * clrBackground.G) * 0.587)) + ((clrBackground.B * clrBackground.B) * 0.114)) <= 130.0)
            {
                return System.Drawing.Color.White;
            }
            return System.Drawing.Color.Black;
        }

        [CodeDescription("Gets (via Headers or Sniff) the provided body's text Encoding. Returns CONFIG.oHeaderEncoding (usually UTF-8) if unknown. Potentially slow.")]
        public static Encoding getEntityBodyEncoding(HTTPHeaders oHeaders, byte[] oBody)
        {
            if (oHeaders != null)
            {
                string tokenValue = oHeaders.GetTokenValue("Content-Type", "charset");
                if (tokenValue != null)
                {
                    try
                    {
                        return GetTextEncoding(tokenValue);
                    }
                    catch (Exception)
                    {
                    }
                }
            }
            Encoding oHeaderEncoding = CONFIG.oHeaderEncoding;
            if ((oBody != null) && (oBody.Length >= 2))
            {
                foreach (Encoding encoding2 in sniffableEncodings)
                {
                    byte[] preamble = encoding2.GetPreamble();
                    if (oBody.Length >= preamble.Length)
                    {
                        bool flag = preamble.Length > 0;
                        for (int i = 0; i < preamble.Length; i++)
                        {
                            if (preamble[i] != oBody[i])
                            {
                                flag = false;
                                break;
                            }
                        }
                        if (flag)
                        {
                            oHeaderEncoding = encoding2;
                            break;
                        }
                    }
                }
                if ((oHeaders != null) && oHeaders.Exists("Content-Type"))
                {
                    if (oHeaders.ExistsAndContains("Content-Type", "multipart/form-data"))
                    {
                        string str2 = oHeaderEncoding.GetString(oBody, 0, Math.Min(0x2000, oBody.Length));
                        MatchCollection matchs = new Regex(".*Content-Disposition: form-data; name=\"_charset_\"\\s+(?<thecharset>[^\\s'&>\\\"]*)", RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase).Matches(str2);
                        if ((matchs.Count > 0) && (matchs[0].Groups.Count > 0))
                        {
                            try
                            {
                                oHeaderEncoding = GetTextEncoding(matchs[0].Groups[1].Value);
                            }
                            catch (Exception)
                            {
                            }
                        }
                    }
                    if (oHeaders.ExistsAndContains("Content-Type", "application/x-www-form-urlencoded"))
                    {
                        string str4 = oHeaderEncoding.GetString(oBody, 0, Math.Min(0x1000, oBody.Length));
                        MatchCollection matchs2 = new Regex(".*_charset_=(?<thecharset>[^'&>\\\"]*)", RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase).Matches(str4);
                        if ((matchs2.Count > 0) && (matchs2[0].Groups.Count > 0))
                        {
                            try
                            {
                                oHeaderEncoding = GetTextEncoding(matchs2[0].Groups[1].Value);
                            }
                            catch (Exception)
                            {
                            }
                        }
                    }
                    if (!oHeaders.ExistsAndContains("Content-Type", "html"))
                    {
                        return oHeaderEncoding;
                    }
                    string input = oHeaderEncoding.GetString(oBody, 0, Math.Min(0x1000, oBody.Length));
                    MatchCollection matchs3 = new Regex("<meta\\s.*charset\\s*=\\s*['\\\"]?(?<thecharset>[^'>\\\"]*)", RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase).Matches(input);
                    if ((matchs3.Count <= 0) || (matchs3[0].Groups.Count <= 0))
                    {
                        return oHeaderEncoding;
                    }
                    string sEncoding = null;
                    try
                    {
                        sEncoding = matchs3[0].Groups[1].Value;
                        Encoding textEncoding = GetTextEncoding(sEncoding);
                        if (textEncoding == oHeaderEncoding)
                        {
                            return oHeaderEncoding;
                        }
                        if (((oHeaderEncoding == Encoding.UTF8) && (((textEncoding == Encoding.BigEndianUnicode) || (textEncoding == Encoding.Unicode)) || (textEncoding == Encoding.UTF32))) || ((textEncoding == Encoding.UTF8) && (((oHeaderEncoding == Encoding.BigEndianUnicode) || (oHeaderEncoding == Encoding.Unicode)) || (oHeaderEncoding == Encoding.UTF32))))
                        {
                            if (CONFIG.bReportHTTPLintErrors)
                            {
                                FiddlerApplication.Log.LogFormat("HTML content specified a CHARSET that appears to be inaccurate. It claimed '{0}' but was probably '{1}'", new object[] { textEncoding.HeaderName, oHeaderEncoding.HeaderName });
                            }
                            return oHeaderEncoding;
                        }
                        oHeaderEncoding = textEncoding;
                    }
                    catch (Exception)
                    {
                        if (CONFIG.bReportHTTPLintErrors)
                        {
                            FiddlerApplication.Log.LogFormat("HTML content specified a CHARSET that did not parse. Value was: {0}", new object[] { sEncoding });
                        }
                    }
                }
            }
            return oHeaderEncoding;
        }

        [CodeDescription("Run an executable, wait for it to exit, and return its output as a string.")]
        public static string GetExecutableOutput(string sExecute, string sParams, out int iExitCode)
        {
            iExitCode = -999;
            StringBuilder builder = new StringBuilder();
            builder.Append("Results from " + sExecute + " " + sParams + "\r\n\r\n");
            try
            {
                string str;
                Process process = new Process();
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = false;
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.FileName = sExecute;
                process.StartInfo.Arguments = sParams;
                process.Start();
                while ((str = process.StandardOutput.ReadLine()) != null)
                {
                    str = str.TrimEnd(new char[0]);
                    if (str.Length > 0)
                    {
                        builder.AppendLine(str);
                    }
                }
                iExitCode = process.ExitCode;
                process.Dispose();
            }
            catch (Exception exception)
            {
                builder.Append("Exception thrown: " + exception.ToString() + "\r\n" + exception.StackTrace.ToString());
            }
            builder.Append("-------------------------------------------\r\n");
            return builder.ToString();
        }

        internal static string GetFirstLocalResponse(string sFilename)
        {
            sFilename = TrimAfter(sFilename, '?');
            try
            {
                if (!Path.IsPathRooted(sFilename))
                {
                    string str = sFilename;
                    sFilename = CONFIG.GetPath("TemplateResponses") + str;
                    if (System.IO.File.Exists(sFilename))
                    {
                        return sFilename;
                    }
                    sFilename = CONFIG.GetPath("Responses") + str;
                }
            }
            catch (Exception)
            {
            }
            return sFilename;
        }

        public static string GetHashAsBase64(string sHashAlgorithm, byte[] bIn)
        {
            HashAlgorithm algorithm;
            string str;
            string str2 = sHashAlgorithm.ToLower();
            if (str2 != null)
            {
                if (!(str2 == "md5"))
                {
                    if (str2 == "sha1")
                    {
                        algorithm = SHA1.Create();
                        goto Label_0086;
                    }
                    if (str2 == "sha256")
                    {
                        algorithm = SHA256.Create();
                        goto Label_0086;
                    }
                    if (str2 == "sha384")
                    {
                        algorithm = SHA384.Create();
                        goto Label_0086;
                    }
                    if (str2 == "sha512")
                    {
                        algorithm = SHA512.Create();
                        goto Label_0086;
                    }
                }
                else
                {
                    algorithm = MD5.Create();
                    goto Label_0086;
                }
            }
            throw new NotImplementedException("Unrecognized algorithm: " + sHashAlgorithm);
        Label_0086:
            str = Convert.ToBase64String(algorithm.ComputeHash(bIn));
            algorithm.Clear();
            return str;
        }

        internal static Icon GetIconFromImage(Image oBMP)
        {
            IntPtr hicon = ((Bitmap) oBMP).GetHicon();
            Icon icon = (Icon) Icon.FromHandle(hicon).Clone();
            DestroyIcon(hicon);
            return icon;
        }

        internal static string GetLocalIPList(bool bLeadingTab)
        {
            IPAddress[] hostAddresses = Dns.GetHostAddresses(string.Empty);
            StringBuilder builder = new StringBuilder();
            foreach (IPAddress address in hostAddresses)
            {
                builder.AppendFormat("{0}{1}\n", bLeadingTab ? "\t" : string.Empty, address.ToString());
            }
            return builder.ToString();
        }

        public static string GetMD5Hash(byte[] bIn)
        {
            using (MD5 md = MD5.Create())
            {
                return BitConverter.ToString(md.ComputeHash(bIn));
            }
        }

        internal static string GetNetworkInfo()
        {
            try
            {
                StringBuilder builder = new StringBuilder();
                long num = 0L;
                NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
                Array.Sort<NetworkInterface>(allNetworkInterfaces, delegate (NetworkInterface x, NetworkInterface y) {
                    return string.Compare(y.OperationalStatus.ToString(), x.OperationalStatus.ToString());
                });
                foreach (NetworkInterface interface2 in allNetworkInterfaces)
                {
                    builder.AppendFormat("{0,32}\t '{1}' Type: {2} @ {3:N0}/sec. Status: {4}\n", new object[] { interface2.Name, interface2.Description, interface2.NetworkInterfaceType, interface2.Speed, interface2.OperationalStatus.ToString().ToUpperInvariant() });
                    if ((((interface2.OperationalStatus == OperationalStatus.Up) && (interface2.NetworkInterfaceType != NetworkInterfaceType.Loopback)) && ((interface2.NetworkInterfaceType != NetworkInterfaceType.Tunnel) && (interface2.NetworkInterfaceType != NetworkInterfaceType.Unknown))) && !interface2.IsReceiveOnly)
                    {
                        num += interface2.GetIPv4Statistics().BytesReceived;
                    }
                }
                builder.AppendFormat("\nTotal bytes received (IPv4): {0:N0}\n", num);
                builder.AppendFormat("\nLocal Addresses:\n{0}", GetLocalIPList(true));
                return builder.ToString();
            }
            catch (Exception exception)
            {
                return ("Failed to obtain NetworkInterfaces information. " + DescribeException(exception));
            }
        }

        internal static object GetOSVerString()
        {
            return Environment.OSVersion.VersionString.Replace("Microsoft Windows ", "Win").Replace("Service Pack ", "SP");
        }

        [CodeDescription("Returns an bool from the registry, or bDefault if the registry key is missing or cannot be used as an bool.")]
        public static bool GetRegistryBool(RegistryKey oReg, string sName, bool bDefault)
        {
            bool flag = bDefault;
            object obj2 = oReg.GetValue(sName);
            if (obj2 is int)
            {
                return (1 == ((int) obj2));
            }
            string toMatch = obj2 as string;
            if (toMatch != null)
            {
                flag = "true".OICEquals(toMatch);
            }
            return flag;
        }

        [CodeDescription("Returns an float from the registry, or flDefault if the registry key is missing or cannot be used as an float.")]
        public static float GetRegistryFloat(RegistryKey oReg, string sName, float flDefault)
        {
            float result = flDefault;
            object obj2 = oReg.GetValue(sName);
            if (obj2 is int)
            {
                return (float) obj2;
            }
            string s = obj2 as string;
            if ((s != null) && !float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out result))
            {
                result = flDefault;
            }
            return result;
        }

        [CodeDescription("Returns an integer from the registry, or iDefault if the registry key is missing or cannot be used as an integer.")]
        public static int GetRegistryInt(RegistryKey oReg, string sName, int iDefault)
        {
            int result = iDefault;
            object obj2 = oReg.GetValue(sName);
            if (obj2 is int)
            {
                return (int) obj2;
            }
            string s = obj2 as string;
            if ((s != null) && !int.TryParse(s, out result))
            {
                return iDefault;
            }
            return result;
        }

        public static MemoryStream GetRenderableImageStream(MemoryStream oStream)
        {
            byte[] buffer = oStream.GetBuffer();
            if (((((oStream.Length > 0x20L) && (0x52 == buffer[0])) && ((0x49 == buffer[1]) && (70 == buffer[2]))) && (((70 == buffer[3]) && (0x57 == buffer[8])) && ((0x45 == buffer[9]) && (0x42 == buffer[10])))) && (80 == buffer[11]))
            {
                oStream = _ConvertWebPToPNG(oStream);
                return oStream;
            }
            if (((oStream.Length > 3L) && (0x49 == buffer[0])) && ((0x49 == buffer[1]) && (0xbc == buffer[2])))
            {
                oStream = _ConvertJXRToPNG(oStream);
            }
            return oStream;
        }

        [CodeDescription("Gets (via Headers or Sniff) the Response Text Encoding. Returns CONFIG.oHeaderEncoding (usually UTF-8) if unknown. Potentially slow.")]
        public static Encoding getResponseBodyEncoding(Session oSession)
        {
            if (oSession == null)
            {
                return CONFIG.oHeaderEncoding;
            }
            if (!oSession.bHasResponse)
            {
                return CONFIG.oHeaderEncoding;
            }
            return getEntityBodyEncoding(oSession.oResponse.headers, oSession.responseBodyBytes);
        }

        public static string GetSHA1Hash(byte[] bIn)
        {
            using (SHA1 sha = SHA1.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(bIn));
            }
        }

        public static string GetSHA256Hash(byte[] bIn)
        {
            using (SHA256 sha = SHA256.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(bIn));
            }
        }

        public static string GetSHA384Hash(byte[] bIn)
        {
            using (SHA384 sha = SHA384.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(bIn));
            }
        }

        public static string GetSHA512Hash(byte[] bIn)
        {
            using (SHA512 sha = SHA512.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(bIn));
            }
        }

        [CodeDescription("Gets a string from a byte-array, stripping a BOM if present.")]
        public static string GetStringFromArrayRemovingBOM(byte[] arrInput, Encoding oDefaultEncoding)
        {
            if (arrInput == null)
            {
                return string.Empty;
            }
            if (arrInput.Length >= 2)
            {
                foreach (Encoding encoding in sniffableEncodings)
                {
                    byte[] preamble = encoding.GetPreamble();
                    if (arrInput.Length >= preamble.Length)
                    {
                        bool flag = preamble.Length > 0;
                        for (int i = 0; i < preamble.Length; i++)
                        {
                            if (preamble[i] != arrInput[i])
                            {
                                flag = false;
                                break;
                            }
                        }
                        if (flag)
                        {
                            int length = encoding.GetPreamble().Length;
                            return encoding.GetString(arrInput, length, arrInput.Length - length);
                        }
                    }
                }
            }
            return oDefaultEncoding.GetString(arrInput);
        }

        public static Encoding GetTextEncoding(string sEncoding)
        {
            if (sEncoding.OICEquals("utf8"))
            {
                sEncoding = "utf-8";
            }
            return Encoding.GetEncoding(sEncoding);
        }

        public static long GetTickCount()
        {
            if (Environment.OSVersion.Version.Major > 5)
            {
                return GetTickCount64();
            }
            int tickCount = Environment.TickCount;
            if (tickCount > 0)
            {
                return (long) tickCount;
            }
            return (0xfffffffeL - -tickCount);
        }

        [DllImport("Kernel32.dll", CharSet=CharSet.Unicode)]
        private static extern long GetTickCount64();
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool GetWindowRect(IntPtr hWnd, ref RECT lpRect);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern IntPtr GlobalFree(IntPtr hMem);
        internal static void GlobalFreeIfNonZero(IntPtr hMem)
        {
            if (IntPtr.Zero != hMem)
            {
                GlobalFree(hMem);
            }
        }

        [CodeDescription("Returns a byte[] containing a gzip-compressed copy of writeData[]")]
        public static byte[] GzipCompress(byte[] writeData)
        {
            try
            {
                MemoryStream inner = new MemoryStream();
                using (GZipCompressedStream stream2 = new GZipCompressedStream(inner))
                {
                    stream2.Write(writeData, 0, writeData.Length);
                }
                return inner.ToArray();
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("The content could not be compressed.\n\n" + exception.Message, "Fiddler: GZip failed");
                return writeData;
            }
        }

        [CodeDescription("Returns a byte[] containing an un-gzipped copy of compressedData[]")]
        public static byte[] GzipExpand(byte[] compressedData)
        {
            return GzipExpand(compressedData, false);
        }

        public static byte[] GzipExpand(byte[] compressedData, bool bThrowErrors)
        {
            try
            {
                return GzipExpandInternal(CONFIG.bUseXceedDecompressForGZIP, compressedData);
            }
            catch (Exception exception)
            {
                if (bThrowErrors)
                {
                    throw new InvalidDataException("The content could not be ungzipped", exception);
                }
                FiddlerApplication.DoNotifyUser("The content could not be decompressed.\n\n" + exception.Message, "Fiddler: UnGZip failed");
                return emptyByteArray;
            }
        }

        public static byte[] GzipExpandInternal(bool bUseXceed, byte[] compressedData)
        {
            if ((compressedData == null) || (compressedData.Length < 4))
            {
                return emptyByteArray;
            }
            MemoryStream inner = new MemoryStream(compressedData, false);
            int capacity = ((compressedData[compressedData.Length - 4] + (compressedData[compressedData.Length - 3] << 8)) + (compressedData[compressedData.Length - 2] << 0x10)) + (compressedData[compressedData.Length - 1] << 0x18);
            if ((capacity < 0) || (capacity > (40 * compressedData.Length)))
            {
                capacity = compressedData.Length;
            }
            MemoryStream stream2 = new MemoryStream(capacity);
            if (bUseXceed)
            {
                using (GZipCompressedStream stream3 = new GZipCompressedStream(inner, Xceed.Compression.CompressionLevel.Normal, false, CONFIG.bCheckCompressionIntegrity))
                {
                    byte[] buffer = new byte[0x8000];
                    int count = 0;
                    while ((count = stream3.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        stream2.Write(buffer, 0, count);
                    }
                    goto Label_00EA;
                }
            }
            using (GZipStream stream4 = new GZipStream(inner, CompressionMode.Decompress))
            {
                byte[] buffer2 = new byte[0x8000];
                int num3 = 0;
                while ((num3 = stream4.Read(buffer2, 0, buffer2.Length)) > 0)
                {
                    stream2.Write(buffer2, 0, num3);
                }
            }
        Label_00EA:
            if (((((stream2.Length == 0L) && (compressedData.Length > 2)) && ((compressedData[0] == 0x1f) && (compressedData[1] == 0x8b))) && (compressedData[3] == 0)) && (((compressedData[compressedData.Length - 4] != 0) || (compressedData[compressedData.Length - 3] != 0)) || ((compressedData[compressedData.Length - 2] != 0) || (compressedData[compressedData.Length - 1] != 0))))
            {
                FiddlerApplication.Log.LogString("!ERROR: \"Content-Encoding: gzip\" body was missing required footer bytes.");
                byte[] dst = new byte[compressedData.Length - 10];
                Buffer.BlockCopy(compressedData, 10, dst, 0, dst.Length);
                return DeflaterExpand(dst, false);
            }
            if (stream2.Length == stream2.Capacity)
            {
                return stream2.GetBuffer();
            }
            return stream2.ToArray();
        }

        internal static bool HasHeaders(ClientChatter oCC)
        {
            return ((oCC != null) && (null != oCC.headers));
        }

        internal static bool HasHeaders(ServerChatter oSC)
        {
            return ((oSC != null) && (null != oSC.headers));
        }

        internal static bool HasImageFileExtension(string sExt)
        {
            if (((!sExt.EndsWith(".gif") && !sExt.EndsWith(".jpg")) && (!sExt.EndsWith(".jpeg") && !sExt.EndsWith(".png"))) && !sExt.EndsWith(".webp"))
            {
                return sExt.EndsWith(".ico");
            }
            return true;
        }

        public static bool HasMagicBytes(byte[] arrData, byte[] arrMagics)
        {
            return HasMagicBytes(arrData, 0, arrMagics);
        }

        public static bool HasMagicBytes(byte[] arrData, string sMagics)
        {
            return HasMagicBytes(arrData, Encoding.ASCII.GetBytes(sMagics));
        }

        public static bool HasMagicBytes(byte[] arrData, int iXOffset, byte[] arrMagics)
        {
            if (arrData == null)
            {
                return false;
            }
            if (arrData.Length < (iXOffset + arrMagics.Length))
            {
                return false;
            }
            for (int i = 0; i < arrMagics.Length; i++)
            {
                if (arrData[i + iXOffset] != arrMagics[i])
                {
                    return false;
                }
            }
            return true;
        }

        public static string HtmlDecode(string sInput)
        {
            return WebUtility.HtmlDecode(sInput);
        }

        public static string HtmlEncode(string sInput)
        {
            if (sInput == null)
            {
                return null;
            }
            return WebUtility.HtmlEncode(sInput);
        }

        [CodeDescription("Returns TRUE if the HTTP Method MAY have a body.")]
        public static bool HTTPMethodAllowsBody(string sMethod)
        {
            if (((!("POST" == sMethod) && !("PUT" == sMethod)) && (!("PROPPATCH" == sMethod) && !("PATCH" == sMethod))) && (!("LOCK" == sMethod) && !("PROPFIND" == sMethod)))
            {
                return ("SEARCH" == sMethod);
            }
            return true;
        }

        public static bool HTTPMethodIsIdempotent(string sMethod)
        {
            if (((!("GET" == sMethod) && !("HEAD" == sMethod)) && (!("OPTIONS" == sMethod) && !("TRACE" == sMethod))) && !("PUT" == sMethod))
            {
                return ("DELETE" == sMethod);
            }
            return true;
        }

        [CodeDescription("Returns TRUE if the HTTP Method MUST have a body.")]
        public static bool HTTPMethodRequiresBody(string sMethod)
        {
            if (!("PROPPATCH" == sMethod))
            {
                return ("PATCH" == sMethod);
            }
            return true;
        }

        [CodeDescription("Returns TRUE if a response body is allowed for this responseCode.")]
        public static bool HTTPStatusAllowsBody(int iResponseCode)
        {
            if (((0xcc == iResponseCode) || (0xcd == iResponseCode)) || (0x130 == iResponseCode))
            {
                return false;
            }
            if (iResponseCode > 0x63)
            {
                return (iResponseCode >= 200);
            }
            return true;
        }

        public static int IndexOfNth(string sString, int n, char chSeek)
        {
            if (!string.IsNullOrEmpty(sString))
            {
                if (n < 1)
                {
                    throw new ArgumentException("index must be greater than 0");
                }
                for (int i = 0; i < sString.Length; i++)
                {
                    if (sString[i] == chSeek)
                    {
                        n--;
                        if (n == 0)
                        {
                            return i;
                        }
                    }
                }
            }
            return -1;
        }

        public static int IndexOfSequence(byte[] arrNeedle, byte[] arrHaystack, int iStartAt)
        {
            int length = arrHaystack.Length;
            int num2 = arrNeedle.Length;
            int num3 = 0;
            if ((arrHaystack.Length - iStartAt) >= num2)
            {
                while (iStartAt <= (length - num2))
                {
                    while (arrHaystack[iStartAt + num3] == arrNeedle[num3++])
                    {
                        if (num3 == num2)
                        {
                            return iStartAt;
                        }
                    }
                    num3 = 0;
                    iStartAt++;
                }
                return -1;
            }
            return -1;
        }

        public static IPEndPoint IPEndPointFromHostPortString(string sHostAndPort)
        {
            if (IsNullOrWhiteSpace(sHostAndPort))
            {
                return null;
            }
            sHostAndPort = TrimAfter(sHostAndPort, ';');
            try
            {
                string str;
                int iPort = 80;
                CrackHostAndPort(sHostAndPort, out str, ref iPort);
                return new IPEndPoint(DNSResolver.GetIPAddress(str, true), iPort);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static IPEndPoint[] IPEndPointListFromHostPortString(string sAllHostAndPorts)
        {
            if (IsNullOrWhiteSpace(sAllHostAndPorts))
            {
                return null;
            }
            string[] strArray = sAllHostAndPorts.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            List<IPEndPoint> list = new List<IPEndPoint>();
            foreach (string str in strArray)
            {
                try
                {
                    string str2;
                    int iPort = 80;
                    CrackHostAndPort(str, out str2, ref iPort);
                    foreach (IPAddress address in DNSResolver.GetIPAddressList(str2, true, null))
                    {
                        list.Add(new IPEndPoint(address, iPort));
                    }
                }
                catch (Exception)
                {
                }
            }
            if (list.Count < 1)
            {
                return null;
            }
            return list.ToArray();
        }

        [CodeDescription("This function attempts to be a ~fast~ way to return an IP from a hoststring that contains an IP-Literal. ")]
        public static IPAddress IPFromString(string sHost)
        {
            for (int i = 0; i < sHost.Length; i++)
            {
                if (((((sHost[i] != '.') && (sHost[i] != ':')) && ((sHost[i] < '0') || (sHost[i] > '9'))) && ((sHost[i] < 'A') || (sHost[i] > 'F'))) && ((sHost[i] < 'a') || (sHost[i] > 'f')))
                {
                    return null;
                }
            }
            if (sHost.EndsWith("."))
            {
                sHost = TrimBeforeLast(sHost, '.');
            }
            try
            {
                return IPAddress.Parse(sHost);
            }
            catch
            {
                return null;
            }
        }

        public static bool IsBinaryMIME(string sContentType)
        {
            if (string.IsNullOrEmpty(sContentType))
            {
                return false;
            }
            if (sContentType.OICStartsWith("image/"))
            {
                return !sContentType.OICStartsWith("image/svg+xml");
            }
            if (sContentType.OICStartsWith("audio/"))
            {
                return true;
            }
            if (sContentType.OICStartsWith("video/"))
            {
                return true;
            }
            if (sContentType.OICStartsWith("text/"))
            {
                return false;
            }
            return (sContentType.OICContains("msbin1") || (sContentType.OICStartsWith("application/octet") || sContentType.OICStartsWith("application/x-shockwave")));
        }

        public static bool IsBrowserProcessName(string sProcessName)
        {
            if (string.IsNullOrEmpty(sProcessName))
            {
                return false;
            }
            return sProcessName.OICStartsWithAny(new string[] { "ie", "chrom", "firefox", "microsoftedge", "browser_broker", "tbb-", "opera", "webkit", "safari" });
        }

        internal static bool IsChunkedBodyComplete(Session m_session, MemoryStream oData, long iStartAtOffset, out long outStartOfLatestChunk, out long outEndOfEntity)
        {
            return IsChunkedBodyComplete(m_session, oData.GetBuffer(), iStartAtOffset, oData.Length, out outStartOfLatestChunk, out outEndOfEntity);
        }

        internal static bool IsChunkedBodyComplete(Session m_session, byte[] oRawBuffer, long iStartAtOffset, long iEndAtOffset, out long outStartOfLatestChunk, out long outEndOfEntity)
        {
            int index = (int) iStartAtOffset;
            outStartOfLatestChunk = index;
            outEndOfEntity = -1L;
            while (index < iEndAtOffset)
            {
                byte num4;
                outStartOfLatestChunk = index;
                string sString = Encoding.ASCII.GetString(oRawBuffer, index, Math.Min(0x40, ((int) iEndAtOffset) - index));
                int length = sString.IndexOf("\r\n", StringComparison.Ordinal);
                if (length > -1)
                {
                    index += length + 2;
                    sString = sString.Substring(0, length);
                }
                else
                {
                    return false;
                }
                sString = TrimAfter(sString, ';');
                int iOutput = 0;
                if (!TryHexParse(sString, out iOutput))
                {
                    if (m_session != null)
                    {
                        SessionFlags flagViolation = (m_session.state <= SessionStates.ReadingRequest) ? SessionFlags.ProtocolViolationInRequest : SessionFlags.ProtocolViolationInResponse;
                        FiddlerApplication.HandleHTTPError(m_session, flagViolation, true, true, "Illegal chunked encoding. '" + sString + "' is not a hexadecimal number.");
                    }
                    return true;
                }
                if (iOutput != 0)
                {
                    goto Label_00F7;
                }
                bool flag = true;
                bool flag2 = false;
                if (iEndAtOffset >= (index + 2))
                {
                    goto Label_00F0;
                }
                return false;
            Label_00B1:
                num4 = oRawBuffer[index++];
                if (num4 != 10)
                {
                    if (num4 != 13)
                    {
                        goto Label_00EA;
                    }
                    flag2 = true;
                }
                else if (flag2)
                {
                    if (flag)
                    {
                        outEndOfEntity = index;
                        return true;
                    }
                    flag = true;
                    flag2 = false;
                }
                else
                {
                    flag2 = false;
                    flag = false;
                }
                goto Label_00F0;
            Label_00EA:
                flag2 = false;
                flag = false;
            Label_00F0:
                if (index < iEndAtOffset)
                {
                    goto Label_00B1;
                }
                return false;
            Label_00F7:
                index += iOutput + 2;
            }
            return false;
        }

        public static bool IsCommentUserSupplied(string strComment)
        {
            if (string.IsNullOrEmpty(strComment))
            {
                return false;
            }
            if (strComment.StartsWith("[#") && strComment.EndsWith("]"))
            {
                return false;
            }
            return true;
        }

        internal static bool isHTTP200Array(byte[] arrData)
        {
            return ((((((arrData.Length > 12) && (arrData[9] == 50)) && ((arrData[10] == 0x30) && (arrData[11] == 0x30))) && (((arrData[0] == 0x48) && (arrData[1] == 0x54)) && ((arrData[2] == 0x54) && (arrData[3] == 80)))) && ((arrData[4] == 0x2f) && (arrData[5] == 0x31))) && (arrData[6] == 0x2e));
        }

        internal static bool isHTTP407Array(byte[] arrData)
        {
            return ((((((arrData.Length > 12) && (arrData[9] == 0x34)) && ((arrData[10] == 0x30) && (arrData[11] == 0x37))) && (((arrData[0] == 0x48) && (arrData[1] == 0x54)) && ((arrData[2] == 0x54) && (arrData[3] == 80)))) && ((arrData[4] == 0x2f) && (arrData[5] == 0x31))) && (arrData[6] == 0x2e));
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool IsIconic(IntPtr hWnd);
        [CodeDescription("Returns true if True if the sHostAndPort's host is 127.0.0.1, 'localhost', or ::1. Note that list is not complete.")]
        public static bool isLocalhost(string sHostAndPort)
        {
            string str;
            int iPort = 0;
            CrackHostAndPort(sHostAndPort, out str, ref iPort);
            return isLocalhostname(str);
        }

        [CodeDescription("Returns true if True if the sHostname is 127.0.0.1, 'localhost', or ::1. Note that list is not complete.")]
        public static bool isLocalhostname(string sHostname)
        {
            if ((!"localhost".OICEquals(sHostname) && !"127.0.0.1".Equals(sHostname)) && !"localhost.".OICEquals(sHostname))
            {
                return "::1".Equals(sHostname);
            }
            return true;
        }

        internal static bool IsNotExtension(string sFilename)
        {
            return (sFilename.StartsWith("_") || sFilename.OICStartsWithAny(new string[] { "qwhale.", "Be.Windows.Forms.", "Telerik.WinControls." }));
        }

        public static bool IsNullOrEmpty(byte[] bIn)
        {
            return ((bIn == null) || (bIn.Length == 0));
        }

        internal static bool IsNullOrWhiteSpace(string sInput)
        {
            return string.IsNullOrWhiteSpace(sInput);
        }

        [CodeDescription("Returns false if Hostname contains any dots or colons.")]
        public static bool isPlainHostName(string sHostAndPort)
        {
            string str;
            int iPort = 0;
            CrackHostAndPort(sHostAndPort, out str, ref iPort);
            char[] anyOf = new char[] { '.', ':' };
            return (str.IndexOfAny(anyOf) < 0);
        }

        public static bool IsRedirectStatus(int iResponseCode)
        {
            if (((iResponseCode != 0x12d) && (iResponseCode != 0x12e)) && ((iResponseCode != 0x12f) && (iResponseCode != 0x133)))
            {
                return (iResponseCode == 0x134);
            }
            return true;
        }

        internal static bool isRPCOverHTTPSMethod(string sMethod)
        {
            if (!(sMethod == "RPC_IN_DATA"))
            {
                return (sMethod == "RPC_OUT_DATA");
            }
            return true;
        }

        public static bool isUnsupportedEncoding(string sTE, string sCE)
        {
            if (!string.IsNullOrEmpty(sTE))
            {
                if (sTE.OICContains("xpress"))
                {
                    return !FiddlerApplication.Supports("xpress");
                }
                if (sTE.OICContains("sdch"))
                {
                    return true;
                }
            }
            if (!string.IsNullOrEmpty(sCE))
            {
                if (sCE.OICContains("xpress"))
                {
                    return !FiddlerApplication.Supports("xpress");
                }
                if (sCE.OICContains("sdch"))
                {
                    return true;
                }
            }
            return false;
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("shell32.dll")]
        public static extern bool IsUserAnAdmin();
        internal static bool IsWin8OrLater()
        {
            return ((Environment.OSVersion.Version.Major > 6) || ((Environment.OSVersion.Version.Major == 6) && (Environment.OSVersion.Version.Minor > 1)));
        }

        public static byte[] JoinByteArrays(byte[] arr1, byte[] arr2)
        {
            byte[] dst = new byte[arr1.Length + arr2.Length];
            Buffer.BlockCopy(arr1, 0, dst, 0, arr1.Length);
            Buffer.BlockCopy(arr2, 0, dst, arr1.Length, arr2.Length);
            return dst;
        }

        internal static bool LaunchBrowser(string sExe, string sParams, string sURL)
        {
            if (!string.IsNullOrEmpty(sParams))
            {
                sParams = sParams.Replace("%U", sURL);
            }
            else
            {
                sParams = sURL;
            }
            return RunExecutable(sExe, sParams);
        }

        [CodeDescription("ShellExecutes the sURL.")]
        public static bool LaunchHyperlink(string sURL)
        {
            try
            {
                using (Process.Start(sURL))
                {
                }
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("Your web browser is not correctly configured to launch hyperlinks.\n\nTo see this content, visit:\n\t" + sURL + "\n...in your web browser.\n\nError: " + exception.Message, "Error");
            }
            return false;
        }

        internal static void MoveForm(Form oF, string sNewLocationAndSize)
        {
            try
            {
                if (!string.IsNullOrEmpty(sNewLocationAndSize))
                {
                    string[] strArray = sNewLocationAndSize.Split(new char[] { ' ', ';', ',' }, 4, StringSplitOptions.RemoveEmptyEntries);
                    int x = 0;
                    int y = 0;
                    if (strArray.Length > 0)
                    {
                        x = int.Parse(strArray[0]);
                    }
                    if (strArray.Length > 1)
                    {
                        y = int.Parse(strArray[1]);
                    }
                    oF.Location = new Point(x, y);
                    if (strArray.Length >= 4)
                    {
                        x = int.Parse(strArray[2]);
                        y = int.Parse(strArray[3]);
                        oF.Size = new Size(x, y);
                    }
                }
            }
            catch
            {
            }
        }

        public static string[] ObtainFilenames(string sDialogTitle, string sFilter, string sInitialDirectory, bool bAllowMultiple)
        {
            string[] fileNames = null;
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = sDialogTitle;
                dialog.Multiselect = bAllowMultiple;
                dialog.Filter = sFilter;
                if (!string.IsNullOrEmpty(sInitialDirectory))
                {
                    dialog.InitialDirectory = sInitialDirectory;
                    dialog.RestoreDirectory = true;
                }
                AddPathToPlaces(dialog, CONFIG.GetPath("Captures"));
                if (DialogResult.OK == dialog.ShowDialog(FiddlerApplication.UI))
                {
                    fileNames = dialog.FileNames;
                }
            }
            return fileNames;
        }

        public static string ObtainOpenFilename(string sDialogTitle, string sFilter)
        {
            return ObtainOpenFilename(sDialogTitle, sFilter, null);
        }

        public static string ObtainOpenFilename(string sDialogTitle, string sFilter, string sInitialDirectory)
        {
            string fileName = null;
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = sDialogTitle;
                dialog.Filter = sFilter;
                if (!string.IsNullOrEmpty(sInitialDirectory))
                {
                    dialog.InitialDirectory = sInitialDirectory;
                    dialog.RestoreDirectory = true;
                }
                AddPathToPlaces(dialog, CONFIG.GetPath("Captures"));
                if (DialogResult.OK == dialog.ShowDialog(FiddlerApplication.UI))
                {
                    fileName = dialog.FileName;
                }
            }
            return fileName;
        }

        public static string ObtainSaveFilename(string sDialogTitle, string sFilter)
        {
            return ObtainSaveFilename(sDialogTitle, sFilter, null);
        }

        public static string ObtainSaveFilename(string sDialogTitle, string sFilter, string sInitialDirectory)
        {
            string fileName = null;
            using (FileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = sDialogTitle;
                dialog.Filter = sFilter;
                if (!string.IsNullOrEmpty(sInitialDirectory))
                {
                    dialog.InitialDirectory = sInitialDirectory;
                    dialog.RestoreDirectory = true;
                }
                AddPathToPlaces(dialog, CONFIG.GetPath("Captures"));
                if (DialogResult.OK == dialog.ShowDialog(FiddlerApplication.UI))
                {
                    fileName = dialog.FileName;
                }
            }
            return fileName;
        }

        [CodeDescription("Tokenize a string into tokens. Delimits on whitespace; \" marks are dropped unless preceded by \\ characters.")]
        public static string[] Parameterize(string sInput)
        {
            return Parameterize(sInput, false);
        }

        [CodeDescription("Tokenize a string into tokens. Delimits on whitespace; \" marks are dropped unless preceded by \\ characters.")]
        public static string[] Parameterize(string sInput, bool bAllowSQuote)
        {
            List<string> list = new List<string>();
            bool flag = false;
            bool flag2 = false;
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < sInput.Length; i++)
            {
                char ch = sInput[i];
                switch (ch)
                {
                    case ' ':
                    case '\t':
                    {
                        if (flag || flag2)
                        {
                            goto Label_011E;
                        }
                        if ((builder.Length > 0) || ((i > 0) && (sInput[i - 1] == '"')))
                        {
                            list.Add(builder.ToString());
                            builder.Length = 0;
                        }
                        continue;
                    }
                    case '!':
                        goto Label_012F;

                    case '"':
                    {
                        if (!flag2)
                        {
                            break;
                        }
                        builder.Append(sInput[i]);
                        continue;
                    }
                    default:
                    {
                        if (ch != '\'')
                        {
                            goto Label_012F;
                        }
                        if (!bAllowSQuote || flag)
                        {
                            builder.Append(sInput[i]);
                        }
                        else if ((i > 0) && (sInput[i - 1] == '\\'))
                        {
                            builder.Length--;
                            builder.Append('\'');
                        }
                        else
                        {
                            flag2 = !flag2;
                        }
                        continue;
                    }
                }
                if ((i > 0) && (sInput[i - 1] == '\\'))
                {
                    builder.Length--;
                    builder.Append('"');
                }
                else
                {
                    flag = !flag;
                }
                continue;
            Label_011E:
                builder.Append(sInput[i]);
                continue;
            Label_012F:
                builder.Append(sInput[i]);
            }
            if (builder.Length > 0)
            {
                list.Add(builder.ToString());
            }
            return list.ToArray();
        }

        public static System.Drawing.Color ParseColor(string sColor)
        {
            if ((sColor.Length == 7) && (sColor[0] == '#'))
            {
                return System.Drawing.Color.FromArgb(Convert.ToInt32(sColor.Substring(1, 2), 0x10), Convert.ToInt32(sColor.Substring(3, 2), 0x10), Convert.ToInt32(sColor.Substring(5, 2), 0x10));
            }
            return System.Drawing.Color.FromName(sColor);
        }

        public static NameValueCollection ParseQueryString(string sQuery)
        {
            return HttpUtility.ParseQueryString(sQuery);
        }

        internal static SslProtocols ParseSSLProtocolString(string sList)
        {
            SslProtocols none = SslProtocols.None;
            if (sList.OICContains("ssl2"))
            {
                none |= SslProtocols.Ssl2;
            }
            if (sList.OICContains("ssl3"))
            {
                none |= SslProtocols.Ssl3;
            }
            if (sList.OICContains("tls1.0"))
            {
                none |= SslProtocols.Tls;
            }
            if (sList.OICContains("tls1.1"))
            {
                none |= (SslProtocols)768;
            }
            if (sList.OICContains("tls1.2"))
            {
                none |= (SslProtocols)3072;
            }
            return none;
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("shlwapi.dll", CharSet=CharSet.Unicode)]
        private static extern bool PathCompactPathEx(StringBuilder pszOut, string pszSrc, int cchMax, int dwFlags);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("shlwapi.dll", CharSet=CharSet.Auto)]
        private static extern bool PathUnExpandEnvStrings(string pszPath, [Out] StringBuilder pszBuf, int cchBuf);
        internal static void PingTarget(string sTarget)
        {
            FiddlerApplication.Log.LogFormat("Pinging: {0}...", new object[] { sTarget });
            Ping ping = new Ping();
            ping.PingCompleted += delegate (object oS, PingCompletedEventArgs pcea) {
                StringBuilder builder = new StringBuilder();
                if (pcea.Reply == null)
                {
                    builder.AppendFormat("Pinging '{0}' failed: {1}\n", pcea.UserState, pcea.Error.InnerException.ToString());
                }
                else
                {
                    builder.AppendFormat("Pinged '{0}'.\n\tFinal Result:\t{1}\n", pcea.UserState as string, pcea.Reply.Status.ToString());
                    if (pcea.Reply.Status == IPStatus.Success)
                    {
                        builder.AppendFormat("\tTarget Address:\t{0}\n", pcea.Reply.Address);
                        builder.AppendFormat("\tRoundTrip time:\t{0}", pcea.Reply.RoundtripTime);
                    }
                }
                FiddlerApplication.Log.LogString(builder.ToString());
            };
            ping.SendAsync(sTarget, 0xea60, new byte[0], new PingOptions(0x80, true), sTarget);
        }

        internal static void PlayNamedSound(string sSoundName)
        {
            PlaySound(sSoundName, IntPtr.Zero, SoundFlags.SND_ALIAS | SoundFlags.SND_ASYNC);
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("winmm.dll", SetLastError=true)]
        private static extern bool PlaySound(string pszSound, IntPtr hMod, SoundFlags sf);
        public static void PlaySoundFile(string sFilename)
        {
            PlaySound(sFilename, IntPtr.Zero, SoundFlags.SND_NOSTOP | SoundFlags.SND_FILENAME | SoundFlags.SND_ASYNC | SoundFlags.SND_NODEFAULT);
        }

        public static string PrefixEllipsizeIfNeeded(string sString, int iMaxLength)
        {
            if (string.IsNullOrEmpty(sString))
            {
                return string.Empty;
            }
            if (iMaxLength >= sString.Length)
            {
                return sString;
            }
            return ('…' + sString.Substring((sString.Length - iMaxLength) - 1));
        }

        internal static byte[] ReadEntireStream(Stream oS)
        {
            MemoryStream stream = new MemoryStream();
            byte[] buffer = new byte[0x8000];
            int count = 0;
            while ((count = oS.Read(buffer, 0, buffer.Length)) > 0)
            {
                stream.Write(buffer, 0, count);
            }
            return stream.ToArray();
        }

        [CodeDescription("Reads oStream until arrBytes is filled.")]
        public static int ReadEntireStream(Stream oStream, byte[] arrBytes)
        {
            int offset = 0;
            while (offset < arrBytes.LongLength)
            {
                offset += oStream.Read(arrBytes, offset, arrBytes.Length - offset);
            }
            return offset;
        }

        public static Session[] ReadSessionArchive(string sFilename, bool bVerboseDialogs)
        {
            return ReadSessionArchive(sFilename, bVerboseDialogs, string.Empty);
        }

        public static Session[] ReadSessionArchive(string sFilename, bool bVerboseDialogs, string sContext)
        {
            return ReadSessionArchive(sFilename, bVerboseDialogs, sContext, null);
        }

        [CodeDescription("Load the specified .SAZ or .ZIP session archive")]
        public static Session[] ReadSessionArchive(string sFilename, bool bVerboseDialogs, string sContext, GetPasswordDelegate fnPasswordCallback)
        {
            if (!System.IO.File.Exists(sFilename))
            {
                if (bVerboseDialogs)
                {
                    FiddlerApplication.DoNotifyUser("File " + sFilename + " does not exist.", "ReadSessionArchive Failed", MessageBoxIcon.Hand);
                }
                return null;
            }
            if (FiddlerApplication.oSAZProvider == null)
            {
                throw new NotSupportedException("This application was compiled without .SAZ support.");
            }
            Application.DoEvents();
            List<Session> list = new List<Session>();
            try
            {
                using (FileStream stream = System.IO.File.Open(sFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    if (((stream.Length < 0x40L) || (stream.ReadByte() != 80)) || (stream.ReadByte() != 0x4b))
                    {
                        string str = null;
                        if (!Path.GetExtension(sFilename).OICEndsWith(".saz"))
                        {
                            str = "\n\nIf you are attempting to import from another format, please choose File > Import Sessions...";
                        }
                        if (bVerboseDialogs)
                        {
                            FiddlerApplication.DoNotifyUser(string.Format("{0} is not a Fiddler-generated .SAZ archive of Web Sessions.{1}", sFilename, str), "ReadSessionArchive Failed", MessageBoxIcon.Hand);
                        }
                        return null;
                    }
                }
                ISAZReader reader = FiddlerApplication.oSAZProvider.LoadSAZ(sFilename);
                if (fnPasswordCallback != null)
                {
                    ISAZReader2 reader2 = reader as ISAZReader2;
                    if (reader2 != null)
                    {
                        reader2.PasswordCallback = fnPasswordCallback;
                    }
                }
                string[] requestFileList = reader.GetRequestFileList();
                if (requestFileList.Length < 1)
                {
                    if (bVerboseDialogs)
                    {
                        FiddlerApplication.DoNotifyUser("The selected file is not a Fiddler-generated .SAZ archive of Web Sessions.", "Invalid Archive", MessageBoxIcon.Hand);
                    }
                    reader.Close();
                    return null;
                }
                foreach (string str2 in requestFileList)
                {
                    try
                    {
                        byte[] buffer;
                        try
                        {
                            buffer = reader.GetFileBytes(str2);
                        }
                        catch (OperationCanceledException)
                        {
                            reader.Close();
                            return null;
                        }
                        string str3 = str2.Replace("_c.txt", "_s.txt");
                        byte[] fileBytes = reader.GetFileBytes(str3);
                        string str4 = str2.Replace("_c.txt", "_m.xml");
                        Stream fileStream = reader.GetFileStream(str4);
                        Session oS = new Session(buffer, fileBytes);
                        if (fileStream != null)
                        {
                            oS.LoadMetadata(fileStream);
                        }
                        oS.oFlags["x-LoadedFrom"] = str2.Replace("_c.txt", "_s.txt");
                        oS.SetBitFlag(SessionFlags.LoadedFromSAZ, true);
                        if (oS.isAnyFlagSet(SessionFlags.IsWebSocketTunnel) && !oS.HTTPMethodIs("CONNECT"))
                        {
                            string str5 = str2.Replace("_c.txt", "_w.txt");
                            Stream strmWSMessages = reader.GetFileStream(str5);
                            if (strmWSMessages != null)
                            {
                                WebSocket.LoadWebSocketMessagesFromStream(oS, strmWSMessages);
                            }
                            else
                            {
                                oS.oFlags["X-WS-SAZ"] = "SAZ File did not contain any WebSocket messages.";
                            }
                        }
                        list.Add(oS);
                    }
                    catch (Exception exception)
                    {
                        if (bVerboseDialogs)
                        {
                            FiddlerApplication.DoNotifyUser(string.Format("Invalid data was present for session [{0}].\n\n{1}\n{2}", TrimAfter(str2, "_"), DescribeException(exception), exception.StackTrace), "Archive Incomplete", MessageBoxIcon.Hand);
                        }
                    }
                }
                reader.Close();
            }
            catch (Exception exception2)
            {
                string sCallerMessage = "Fiddler was unable to load the specified archive";
                if (!string.IsNullOrEmpty(sContext))
                {
                    sCallerMessage = sCallerMessage + " for " + sContext + ".";
                }
                else
                {
                    sCallerMessage = sCallerMessage + ".";
                }
                if (sFilename.StartsWith(@"\\"))
                {
                    sCallerMessage = sCallerMessage + "\n\nThis may be an indication of a connectivity problem or storage corruption on your network file share.";
                }
                FiddlerApplication.ReportException(exception2, "Unable to load Archive", sCallerMessage);
                return null;
            }
            Session[] arrSessions = list.ToArray();
            FiddlerApplication.DoAfterLoadSAZ(sFilename, arrSessions, sContext);
            return arrSessions;
        }

        public static void RecoverMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            CompactLOHIfPossible();
        }

        internal static string RegExEscape(string sString, bool bAddPrefixCaret, bool bAddSuffixDollarSign)
        {
            StringBuilder builder = new StringBuilder();
            if (bAddPrefixCaret)
            {
                builder.Append("^");
            }
            foreach (char ch in sString)
            {
                switch (ch)
                {
                    case '#':
                    case '$':
                    case '(':
                    case ')':
                    case '+':
                    case '.':
                    case '?':
                    case '[':
                    case '\\':
                    case '^':
                    case '{':
                    case '|':
                        builder.Append('\\');
                        break;

                    case '*':
                        builder.Append('.');
                        break;
                }
                builder.Append(ch);
            }
            if (bAddSuffixDollarSign)
            {
                builder.Append('$');
            }
            return builder.ToString();
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vlc);
        public static bool RunExecutable(string sExecute, string sParams)
        {
            try
            {
                using (Process.Start(sExecute, sParams))
                {
                }
                return true;
            }
            catch (Exception exception)
            {
                if (!(exception is Win32Exception) || (0x4c7 != (exception as Win32Exception).NativeErrorCode))
                {
                    FiddlerApplication.DoNotifyUser(string.Format("Failed to execute: {0}\r\n{1}\r\n\r\n{2}\r\n{3}", new object[] { sExecute, string.IsNullOrEmpty(sParams) ? string.Empty : ("with parameters: " + sParams), exception.Message, exception.StackTrace.ToString() }), "ShellExecute Failed");
                }
            }
            return false;
        }

        [CodeDescription("Run an executable and wait for it to exit.")]
        public static bool RunExecutableAndWait(string sExecute, string sParams)
        {
            try
            {
                Process process = new Process();
                process.StartInfo.FileName = sExecute;
                process.StartInfo.Arguments = sParams;
                process.Start();
                process.WaitForExit();
                process.Dispose();
                return true;
            }
            catch (Exception exception)
            {
                if (!(exception is Win32Exception) || (0x4c7 != (exception as Win32Exception).NativeErrorCode))
                {
                    FiddlerApplication.DoNotifyUser("Fiddler Exception thrown: " + exception.ToString() + "\r\n" + exception.StackTrace.ToString(), "ShellExecute Failed");
                }
                return false;
            }
        }

        [DllImport("user32.dll", EntryPoint="SendMessage")]
        private static extern IntPtr SendCueTextMessage(IntPtr hWnd, int msg, IntPtr wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);
        [DllImport("user32.dll")]
        internal static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll", EntryPoint="SendMessage")]
        internal static extern IntPtr SendWMCopyMessage(IntPtr hWnd, int Msg, IntPtr wParam, ref SendDataStruct lParam);
        public static void SetCueText(Control oCtl, string sText)
        {
            IntPtr hwndItem;
            if (oCtl is ComboBox)
            {
                if (Environment.OSVersion.Version.Major >= 6)
                {
                    SendCueTextMessage(oCtl.Handle, 0x1703, IntPtr.Zero, sText);
                    return;
                }
                hwndItem = GetComboBoxInfo(oCtl).hwndItem;
            }
            else
            {
                hwndItem = oCtl.Handle;
            }
            SendCueTextMessage(hwndItem, 0x1501, IntPtr.Zero, sText);
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool SetForegroundWindow(IntPtr hWnd);
        [CodeDescription("Save a string to the registry. Correctly handles null Value, saving as String.Empty.")]
        public static void SetRegistryString(RegistryKey oReg, string sName, string sValue)
        {
            if (sName != null)
            {
                if (sValue == null)
                {
                    sValue = string.Empty;
                }
                oReg.SetValue(sName, sValue);
            }
        }

        [DllImport("shell32.dll", CharSet=CharSet.Unicode)]
        private static extern int SHOpenWithDialog(IntPtr hWndParent, ref tagOPENASINFO oOAI);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
        internal static string SslProtocolsToString(SslProtocols sslProts)
        {
            List<string> list = new List<string>();
            if ((sslProts & SslProtocols.Ssl2) != SslProtocols.None)
            {
                list.Add("ssl2");
            }
            if ((sslProts & SslProtocols.Ssl3) != SslProtocols.None)
            {
                list.Add("ssl3");
            }
            if ((sslProts & SslProtocols.Tls) != SslProtocols.None)
            {
                list.Add("tls1.0");
            }
            if ((sslProts & (SslProtocols)768) != SslProtocols.None)
            {
                list.Add("tls1.1");
            }
            if ((sslProts & (SslProtocols)3072) != SslProtocols.None)
            {
                list.Add("tls1.2");
            }
            return string.Join(";", list.ToArray());
        }

        internal static string StringToCF_HTML(string inStr)
        {
            string str = "<HTML><HEAD><STYLE>.REQUEST { font: 8pt Courier New; color: blue;} .RESPONSE { font: 8pt Courier New; color: green;}</STYLE></HEAD><BODY>" + inStr + "</BODY></HTML>";
            string format = "Version:1.0\r\nStartHTML:{0:00000000}\r\nEndHTML:{1:00000000}\r\nStartFragment:{0:00000000}\r\nEndFragment:{1:00000000}\r\n";
            return (string.Format(format, format.Length - 0x10, (str.Length + format.Length) - 0x10) + str);
        }

        internal static string StripIPv6LiteralBrackets(string sHost)
        {
            if (((sHost.Length > 2) && sHost.StartsWith("[")) && sHost.EndsWith("]"))
            {
                sHost = sHost.Substring(1, sHost.Length - 2);
            }
            return sHost;
        }

        [CodeDescription("Returns the part of a string up to (but NOT including) the first instance of specified delimiter. If delim not found, returns entire string.")]
        public static string TrimAfter(string sString, char chDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            int index = sString.IndexOf(chDelim);
            if (index < 0)
            {
                return sString;
            }
            return sString.Substring(0, index);
        }

        public static string TrimAfter(string sString, int iMaxLength)
        {
            return TrimTo(sString, iMaxLength);
        }

        [CodeDescription("Returns the part of a string up to (but NOT including) the first instance of specified substring. If delim not found, returns entire string.")]
        public static string TrimAfter(string sString, string sDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            if (sDelim == null)
            {
                return sString;
            }
            int index = sString.IndexOf(sDelim);
            if (index < 0)
            {
                return sString;
            }
            return sString.Substring(0, index);
        }

        [CodeDescription("Returns the part of a string after (but NOT including) the first instance of specified delimiter. If delim not found, returns entire string.")]
        public static string TrimBefore(string sString, char chDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            int index = sString.IndexOf(chDelim);
            if (index < 0)
            {
                return sString;
            }
            return sString.Substring(index + 1);
        }

        [CodeDescription("Returns the part of a string after (but NOT including) the first instance of specified substring. If delim not found, returns entire string.")]
        public static string TrimBefore(string sString, string sDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            if (sDelim == null)
            {
                return sString;
            }
            int index = sString.IndexOf(sDelim);
            if (index < 0)
            {
                return sString;
            }
            return sString.Substring(index + sDelim.Length);
        }

        [CodeDescription("Returns the part of a string after (but not including) the last instance of specified delimiter. If delim not found, returns entire string.")]
        public static string TrimBeforeLast(string sString, char chDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            int num = sString.LastIndexOf(chDelim);
            if (num < 0)
            {
                return sString;
            }
            return sString.Substring(num + 1);
        }

        [CodeDescription("Returns the part of a string after (but not including) the last instance of specified substring. If delim not found, returns entire string.")]
        public static string TrimBeforeLast(string sString, string sDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            if (sDelim == null)
            {
                return sString;
            }
            int num = sString.LastIndexOf(sDelim);
            if (num < 0)
            {
                return sString;
            }
            return sString.Substring(num + sDelim.Length);
        }

        [CodeDescription("Returns the first iMaxLength or fewer characters from the target string.")]
        public static string TrimTo(string sString, int iMaxLength)
        {
            if (string.IsNullOrEmpty(sString))
            {
                return string.Empty;
            }
            if (iMaxLength >= sString.Length)
            {
                return sString;
            }
            return sString.Substring(0, iMaxLength);
        }

        [CodeDescription("Returns the part of a string after (and including) the first instance of specified substring. If delim not found, returns entire string.")]
        public static string TrimUpTo(string sString, string sDelim)
        {
            if (sString == null)
            {
                return string.Empty;
            }
            if (sDelim == null)
            {
                return sString;
            }
            int index = sString.IndexOf(sDelim);
            if (index < 0)
            {
                return sString;
            }
            return sString.Substring(index);
        }

        [CodeDescription("Try parsing the string for a Hex-formatted int. If it fails, return false and 0 in iOutput.")]
        public static bool TryHexParse(string sInput, out int iOutput)
        {
            return int.TryParse(sInput, NumberStyles.HexNumber, NumberFormatInfo.InvariantInfo, out iOutput);
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll")]
        internal static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        public static string UNSTABLE_DescribeClientHello(MemoryStream msHello)
        {
            HTTPSClientHello hello = new HTTPSClientHello();
            if (hello.LoadFromStream(msHello))
            {
                return hello.ToString();
            }
            return string.Empty;
        }

        public static string UNSTABLE_DescribeServerHello(MemoryStream msHello)
        {
            HTTPSServerHello hello = new HTTPSServerHello();
            if (hello.LoadFromStream(msHello))
            {
                return hello.ToString();
            }
            return string.Empty;
        }

        public static string UrlDecode(string sInput)
        {
            return UrlDecode(sInput, Encoding.UTF8);
        }

        public static string UrlDecode(string sInput, Encoding oEnc)
        {
            return HttpUtility.UrlDecode(sInput, oEnc);
        }

        public static byte[] UrlDecodeToBytes(string sInput, Encoding oEnc)
        {
            return HttpUtility.UrlDecodeToBytes(sInput, oEnc);
        }

        public static string UrlEncode(string sInput)
        {
            return UrlEncodeChars(sInput, Encoding.UTF8);
        }

        public static string UrlEncode(string sInput, Encoding oEnc)
        {
            return UrlEncodeChars(sInput, oEnc);
        }

        private static string UrlEncodeChars(string str, Encoding oEnc)
        {
            if (string.IsNullOrEmpty(str))
            {
                return str;
            }
            StringBuilder builder = new StringBuilder();
            foreach (char ch in str)
            {
                if ((((ch >= 'a') && (ch <= 'z')) || ((ch >= 'A') && (ch <= 'Z'))) || (((ch >= '0') && (ch <= '9')) || ((((ch == '-') || (ch == '.')) || ((ch == '(') || (ch == ')'))) || (((ch == '*') || (ch == '\'')) || ((ch == '_') || (ch == '!'))))))
                {
                    builder.Append(ch);
                }
                else if (ch == ' ')
                {
                    builder.Append("+");
                }
                else
                {
                    foreach (byte num in oEnc.GetBytes(new char[] { ch }))
                    {
                        builder.Append("%");
                        builder.Append(num.ToString("X2"));
                    }
                }
            }
            return builder.ToString();
        }

        public static string UrlPathEncode(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return str;
            }
            int index = str.IndexOf('?');
            if (index >= 0)
            {
                return (UrlPathEncode(str.Substring(0, index)) + str.Substring(index));
            }
            return UrlPathEncodeChars(str);
        }

        private static string UrlPathEncodeChars(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return str;
            }
            StringBuilder builder = new StringBuilder();
            foreach (char ch in str)
            {
                if ((ch > ' ') && (ch < '\x007f'))
                {
                    builder.Append(ch);
                }
                else if (ch < '!')
                {
                    builder.Append("%");
                    builder.Append(((byte) ch).ToString("X2"));
                }
                else
                {
                    foreach (byte num in Encoding.UTF8.GetBytes(new char[] { ch }))
                    {
                        builder.Append("%");
                        builder.Append(num.ToString("X2"));
                    }
                }
            }
            return builder.ToString();
        }

        public static void utilDecodeHTTPBody(HTTPHeaders oHeaders, ref byte[] arrBody)
        {
            utilDecodeHTTPBody(oHeaders, ref arrBody, false);
        }

        public static void utilDecodeHTTPBody(HTTPHeaders oHeaders, ref byte[] arrBody, bool bSilent)
        {
            if (!IsNullOrEmpty(arrBody))
            {
                _DecodeInOrder(oHeaders["Transfer-Encoding"], true, ref arrBody, bSilent);
                _DecodeInOrder(oHeaders["Content-Encoding"], false, ref arrBody, bSilent);
            }
        }

        internal static bool utilTryDecode(HTTPHeaders oHeaders, ref byte[] arrBody, bool bSilent)
        {
            string sRemainingEncodings = null;
            if (!IsNullOrEmpty(arrBody))
            {
                _DecodeInOrder(oHeaders.AllValues("Transfer-Encoding"), true, ref arrBody, bSilent);
                _TryContentDecode(oHeaders.AllValues("Content-Encoding"), out sRemainingEncodings, ref arrBody, bSilent);
            }
            oHeaders.RemoveRange(new string[] { "Transfer-Encoding", "Content-Encoding" });
            if (!string.IsNullOrEmpty(sRemainingEncodings))
            {
                oHeaders["Content-Encoding"] = sRemainingEncodings;
            }
            oHeaders["Content-Length"] = (arrBody == null) ? "0" : arrBody.LongLength.ToString();
            return string.IsNullOrEmpty(sRemainingEncodings);
        }

        [CodeDescription("Writes arrBytes to a file, creating the target directory and overwriting if the file exists.")]
        public static void WriteArrayToFile(string sFilename, byte[] arrBytes)
        {
            if (arrBytes == null)
            {
                arrBytes = emptyByteArray;
            }
            EnsureOverwritable(sFilename);
            System.IO.File.WriteAllBytes(sFilename, arrBytes);
        }

        [CodeDescription("Save the specified .SAZ session archive")]
        public static bool WriteSessionArchive(string sFilename, Session[] arrSessions, string sPassword, bool bVerboseDialogs)
        {
            if ((arrSessions == null) || (arrSessions.Length < 1))
            {
                if (bVerboseDialogs)
                {
                    FiddlerApplication.DoNotifyUser("No sessions were provided to save to the archive.", "WriteSessionArchive - No Input");
                }
                return false;
            }
            if (FiddlerApplication.oSAZProvider == null)
            {
                throw new NotSupportedException("This application was compiled without .SAZ support.");
            }
            FiddlerApplication.DoBeforeSaveSAZ(sFilename, arrSessions);
            try
            {
                if (System.IO.File.Exists(sFilename))
                {
                    System.IO.File.Delete(sFilename);
                }
                ISAZWriter oISW = FiddlerApplication.oSAZProvider.CreateSAZ(sFilename);
                if (!string.IsNullOrEmpty(sPassword))
                {
                    oISW.SetPassword(sPassword);
                }
                oISW.Comment = "Fiddler (v" + Application.ProductVersion + ") Session Archive. See http://fiddler2.com";
                int iFileNumber = 1;
                int length = arrSessions.Length;
                string sFileNumberFormat = "D" + length.ToString().Length;
                foreach (Session session in arrSessions)
                {
                    WriteSessionToSAZ(session, oISW, iFileNumber, sFileNumberFormat, null, bVerboseDialogs);
                    iFileNumber++;
                }
                oISW.CompleteArchive();
                return true;
            }
            catch (Exception exception)
            {
                if (bVerboseDialogs)
                {
                    FiddlerApplication.DoNotifyUser("Failed to save Session Archive.\n\n" + exception.Message, "Save Failed");
                }
                return false;
            }
        }

        internal static void WriteSessionToSAZ(Session oSession, ISAZWriter oISW, int iFileNumber, string sFileNumberFormat, StringBuilder sbHTML, bool bVerboseDialogs)
        {
            SAZWriterDelegate oSWD = null;
            SAZWriterDelegate delegate3 = null;
            SAZWriterDelegate delegate4 = null;
            SAZWriterDelegate delegate5 = null;
            string str = @"raw\" + iFileNumber.ToString(sFileNumberFormat);
            string sFilename = str + "_c.txt";
            string str3 = str + "_s.txt";
            string str4 = str + "_m.xml";
            try
            {
                if (oSWD == null)
                {
                    oSWD = delegate (Stream oS) {
                        oSession.WriteRequestToStream(false, true, oS);
                    };
                }
                oISW.AddFile(sFilename, oSWD);
            }
            catch (Exception exception)
            {
                if (bVerboseDialogs)
                {
                    FiddlerApplication.DoNotifyUser("Unable to add " + sFilename + "\n\n" + DescribeExceptionWithStack(exception), "Archive Failure");
                }
            }
            try
            {
                if (delegate3 == null)
                {
                    delegate3 = delegate (Stream oS) {
                        oSession.WriteResponseToStream(oS, false);
                    };
                }
                oISW.AddFile(str3, delegate3);
            }
            catch (Exception exception2)
            {
                if (bVerboseDialogs)
                {
                    FiddlerApplication.DoNotifyUser("Unable to add " + str3 + "\n\n" + DescribeExceptionWithStack(exception2), "Archive Failure");
                }
            }
            try
            {
                if (delegate4 == null)
                {
                    delegate4 = delegate (Stream oS) {
                        oSession.WriteMetadataToStream(oS);
                    };
                }
                oISW.AddFile(str4, delegate4);
            }
            catch (Exception exception3)
            {
                if (bVerboseDialogs)
                {
                    FiddlerApplication.DoNotifyUser("Unable to add " + str4 + "\n\n" + DescribeExceptionWithStack(exception3), "Archive Failure");
                }
            }
            if (oSession.bHasWebSocketMessages)
            {
                string str5 = str + "_w.txt";
                try
                {
                    if (delegate5 == null)
                    {
                        delegate5 = delegate (Stream oS) {
                            oSession.WriteWebSocketMessagesToStream(oS);
                        };
                    }
                    oISW.AddFile(str5, delegate5);
                }
                catch (Exception exception4)
                {
                    if (bVerboseDialogs)
                    {
                        FiddlerApplication.DoNotifyUser("Unable to add " + str5 + "\n\n" + DescribeExceptionWithStack(exception4), "Archive Failure");
                    }
                }
            }
            if (sbHTML != null)
            {
                sbHTML.Append("<tr>");
                sbHTML.AppendFormat("<td><a href='{0}'>C</a>&nbsp;", sFilename);
                sbHTML.AppendFormat("<a href='{0}'>S</a>&nbsp;", str3);
                sbHTML.AppendFormat("<a href='{0}'>M</a>", str4);
                if (oSession.bHasWebSocketMessages)
                {
                    sbHTML.AppendFormat("&nbsp;<a href='{0}_w.txt'>W</a>", str);
                }
                sbHTML.AppendFormat("</td>", new object[0]);
                ListViewItem viewItem = oSession.ViewItem;
                if (viewItem != null)
                {
                    ListViewItem.ListViewSubItemCollection subItems = viewItem.SubItems;
                    if (subItems != null)
                    {
                        foreach (ListViewItem.ListViewSubItem item2 in subItems)
                        {
                            sbHTML.AppendFormat("<td>{0}</td>", HtmlEncode(item2.Text));
                        }
                    }
                }
                sbHTML.Append("</tr>");
            }
        }

        public static byte[] XpressExpand(byte[] arrBlock)
        {
            return XpressExpandInternal(arrBlock);
        }

        private static byte[] XpressExpandInternal(byte[] arrBlock)
        {
            IntPtr ptr;
            if (arrBlock.Length < 9)
            {
                return emptyByteArray;
            }
            MemoryStream stream = new MemoryStream();
            CreateDecompressor(CompressAlgorithm.XPRESS | CompressAlgorithm.RAW, IntPtr.Zero, out ptr);
            int startIndex = 0;
            do
            {
                IntPtr ptr2;
                int num2 = BitConverter.ToInt32(arrBlock, startIndex);
                startIndex += 4;
                if ((num2 < 0) || (num2 > 0x3b9aca00))
                {
                    throw new InvalidDataException(string.Format("Uncompressed data was too large {0:N0} bytes", num2));
                }
                int num3 = BitConverter.ToInt32(arrBlock, startIndex);
                startIndex += 4;
                if ((num3 + startIndex) > arrBlock.Length)
                {
                    throw new InvalidDataException(string.Format("Expecting {0:N0} bytes of compressed data, but only {1:N0} bytes remain in this stream", num3, arrBlock.Length - startIndex));
                }
                byte[] dst = new byte[num3];
                Buffer.BlockCopy(arrBlock, startIndex, dst, 0, dst.Length);
                byte[] arrOutputBuffer = new byte[num2];
                Decompress(ptr, dst, (IntPtr) dst.Length, arrOutputBuffer, (IntPtr) arrOutputBuffer.Length, out ptr2);
                long num1 = num2;
                long num4 = ptr2.Toint32();
                stream.Write(arrOutputBuffer, 0, (int) ptr2.Toint32());
                startIndex += num3;
            }
            while (startIndex < arrBlock.Length);
            CloseDecompressor(ptr);
            return stream.ToArray();
        }

        public static byte[] ZLibExpand(byte[] compressedData)
        {
            if ((compressedData == null) || (compressedData.Length == 0))
            {
                return emptyByteArray;
            }
            try
            {
                MemoryStream inner = new MemoryStream(compressedData);
                MemoryStream stream2 = new MemoryStream(compressedData.Length);
                using (ZLibCompressedStream stream3 = new ZLibCompressedStream(inner, Xceed.Compression.CompressionMethod.Deflated, Xceed.Compression.CompressionLevel.Highest))
                {
                    byte[] buffer = new byte[0x8000];
                    int count = 0;
                    while ((count = stream3.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        stream2.Write(buffer, 0, count);
                    }
                }
                return stream2.ToArray();
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("The content could not be decompressed.\n\n" + exception.Message, "Fiddler: ZLib Inflation failed");
                return emptyByteArray;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct COMBOBOXINFO
        {
            public int cbSize;
            public Utilities.RECT rcItem;
            public Utilities.RECT rcButton;
            public int stateButton;
            public IntPtr hwndCombo;
            public IntPtr hwndItem;
            public IntPtr hwndList;
        }

        [Flags]
        private enum CompressAlgorithm : int
        {
            Invalid = 0,
            LZMS = 5,
            MSZIP = 2,
            Null = 1,
            RAW = 0x20000000,
            XPRESS = 3,
            XPRESS_HUFF = 4
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct COPYDATASTRUCT
        {
            public IntPtr dwData;
            public int cbData;
            public IntPtr lpData;
        }

        [Flags]
        private enum FlashWInfo : int
        {
            FLASHW_ALL = 3,
            FLASHW_CAPTION = 1,
            FLASHW_STOP = 0,
            FLASHW_TIMER = 4,
            FLASHW_TIMERNOFG = 12,
            FLASHW_TRAY = 2
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct FLASHWINFO
        {
            public int cbSize;
            public IntPtr hwnd;
            public Utilities.FlashWInfo dwFlags;
            public int uCount;
            public int dwTimeout;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct RECT
        {
            internal int Left;
            internal int Top;
            internal int Right;
            internal int Bottom;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
        internal struct SendDataStruct
        {
            public IntPtr dwData;
            public int cbData;
            public string strData;
        }

        [Flags]
        internal enum SoundFlags : int
        {
            SND_ALIAS = 0x10000,
            SND_ALIAS_ID = 0x110000,
            SND_ASYNC = 1,
            SND_FILENAME = 0x20000,
            SND_LOOP = 8,
            SND_MEMORY = 4,
            SND_NODEFAULT = 2,
            SND_NOSTOP = 0x10,
            SND_NOWAIT = 0x2000,
            SND_RESOURCE = 0x40004,
            SND_SYNC = 0
        }

        [Flags]
        private enum tagOPEN_AS_INFO_FLAGS
        {
            OAIF_ALLOW_REGISTRATION = 1,
            OAIF_EXEC = 4,
            OAIF_FILE_IS_URI = 0x80,
            OAIF_FORCE_REGISTRATION = 8,
            OAIF_HIDE_REGISTRATION = 0x20,
            OAIF_REGISTER_EXT = 2,
            OAIF_URL_PROTOCOL = 0x40
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct tagOPENASINFO
        {
            [MarshalAs(UnmanagedType.LPWStr)]
            public string cszFile;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string cszClass;
            [MarshalAs(UnmanagedType.I4)]
            public Utilities.tagOPEN_AS_INFO_FLAGS oaifInFlags;
        }
    }
}

