﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public class QuickExecEventArgs : EventArgs
    {
        public QuickExecEventArgs(string sCmd)
        {
            this.sCommand = sCmd;
            this.bAddToHistory = true;
        }

        public bool bAddToHistory
        {
            
            get
            {
                return this.bAddToHistory;
            }
            
            set
            {
                this.bAddToHistory = value;
            }
        }

        public bool bHandled
        {
            
            get
            {
                return this.bHandled;
            }
            
            set
            {
                this.bHandled = value;
            }
        }

        public string sCommand
        {
            
            get
            {
                return this.sCommand;
            }
            private 
            set
            {
                this.sCommand = value;
            }
        }
    }
}

