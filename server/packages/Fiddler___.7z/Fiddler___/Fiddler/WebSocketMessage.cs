﻿namespace Fiddler
{
    using System;
    using System.IO;
    using System.Text;

    public class WebSocketMessage
    {
        private byte[] _arrMask;
        private byte[] _arrRawPayload;
        private bool _bIsFinalFragment;
        private bool _bOutbound;
        private byte _byteReservedFlags;
        private int _iID;
        private WebSocketFrameTypes _wsftType;
        private WebSocket _wsOwner;
        private WSMFlags BitFlags;
        public WebSocketTimers Timers = new WebSocketTimers();

        internal WebSocketMessage(WebSocket oWSOwner, int iID, bool bIsOutbound)
        {
            this._wsOwner = oWSOwner;
            this._iID = iID;
            this._bOutbound = bIsOutbound;
        }

        private void _SetPayloadWithoutCopy(byte[] arrNewPayload)
        {
            MaskDataInPlace(arrNewPayload, this._arrMask);
            this._arrRawPayload = arrNewPayload;
        }

        [CodeDescription("Cancel transmission of this WebSocketMessage.")]
        public void Abort()
        {
            this.BitFlags |= WSMFlags.Aborted;
        }

        internal void Assemble(WebSocketMessage oWSM)
        {
            this.BitFlags |= WSMFlags.Assembled;
            MemoryStream stream = new MemoryStream();
            byte[] buffer = this.PayloadAsBytes();
            stream.Write(buffer, 0, buffer.Length);
            byte[] buffer2 = oWSM.PayloadAsBytes();
            stream.Write(buffer2, 0, buffer2.Length);
            this.SetPayload(stream.ToArray());
            if (oWSM.IsFinalFrame)
            {
                this._bIsFinalFragment = true;
            }
            this.Timers.dtDoneSend = oWSM.Timers.dtDoneSend;
        }

        internal void AssignHeader(byte byteHeader)
        {
            this._bIsFinalFragment = 0x80 == (byteHeader & 0x80);
            this._byteReservedFlags = (byte) ((byteHeader & 0x70) >> 4);
            this.FrameType = (WebSocketFrameTypes) ((byte) (byteHeader & 15));
        }

        private static void MaskDataInPlace(byte[] arrInOut, byte[] arrKey)
        {
            if (arrKey != null)
            {
                for (int i = 0; i < arrInOut.Length; i++)
                {
                    arrInOut[i] = (byte) (arrInOut[i] ^ arrKey[i % 4]);
                }
            }
        }

        [CodeDescription("Returns the WebSocketMessage's payload as byte[], unmasking if needed.")]
        public byte[] PayloadAsBytes()
        {
            if (this._arrRawPayload == null)
            {
                return Utilities.emptyByteArray;
            }
            byte[] arrOut = new byte[this._arrRawPayload.Length];
            if (this._arrMask != null)
            {
                UnmaskData(this._arrRawPayload, this._arrMask, arrOut);
                return arrOut;
            }
            Buffer.BlockCopy(this._arrRawPayload, 0, arrOut, 0, arrOut.Length);
            return arrOut;
        }

        [CodeDescription("Returns the WebSocketMessage's payload as a string, unmasking if needed.")]
        public string PayloadAsString()
        {
            byte[] buffer;
            if (this._arrRawPayload == null)
            {
                return "<NoPayload>";
            }
            if (this._arrMask != null)
            {
                buffer = new byte[this._arrRawPayload.Length];
                UnmaskData(this._arrRawPayload, this._arrMask, buffer);
            }
            else
            {
                buffer = this._arrRawPayload;
            }
            if (this._wsftType == WebSocketFrameTypes.Text)
            {
                return Encoding.UTF8.GetString(buffer);
            }
            return BitConverter.ToString(buffer);
        }

        internal void SerializeToStream(Stream oFS)
        {
            byte[] buffer = this.ToByteArray();
            string str = this.Timers.ToHeaderString();
            string s = string.Format("{0}: {1}\r\nID: {2}\r\nBitFlags: {3}\r\n{4}\r\n", new object[] { this.IsOutbound ? "Request-Length" : "Response-Length", buffer.Length, this.ID, (int) this.BitFlags, str });
            byte[] bytes = Encoding.ASCII.GetBytes(s);
            oFS.Write(bytes, 0, bytes.Length);
            oFS.Write(buffer, 0, buffer.Length);
            oFS.WriteByte(13);
            oFS.WriteByte(10);
        }

        internal void SetBitFlags(WSMFlags oF)
        {
            this.BitFlags = oF;
        }

        [CodeDescription("Replaces the WebSocketMessage's payload with the specified byte array, masking if needed.")]
        public void SetPayload(byte[] arrNewPayload)
        {
            byte[] dst = new byte[arrNewPayload.Length];
            Buffer.BlockCopy(arrNewPayload, 0, dst, 0, arrNewPayload.Length);
            this._SetPayloadWithoutCopy(dst);
        }

        [CodeDescription("Replaces the WebSocketMessage's payload with the specified string, masking if needed.")]
        public void SetPayload(string sPayload)
        {
            this._SetPayloadWithoutCopy(Encoding.UTF8.GetBytes(sPayload));
        }

        [CodeDescription("Returns the entire WebSocketMessage, including headers.")]
        public byte[] ToByteArray()
        {
            byte[] buffer;
            if (this._arrRawPayload == null)
            {
                return Utilities.emptyByteArray;
            }
            MemoryStream stream = new MemoryStream();
            stream.WriteByte((byte) (((this._bIsFinalFragment ? ((byte) 0x80) : ((byte) 0)) | ((byte) (this._byteReservedFlags << 4))) | ((int) this.FrameType)));
            long length = (long) this._arrRawPayload.Length;
            if (this._arrRawPayload.Length < 0x7e)
            {
                buffer = new byte[] { (byte) this._arrRawPayload.Length };
            }
            else if (this._arrRawPayload.Length < 0xffff)
            {
                buffer = new byte[] { 0x7e, (byte) (length >> 8), (byte) (length & ((long) 0xffL)) };
            }
            else
            {
                buffer = new byte[] { 0x7f, (byte) (length >> 0x38), (byte) ((length & 0xff000000000000L) >> 0x30), (byte) ((length & 0xff0000000000L) >> 40), (byte) ((length & 0xff00000000L) >> 0x20), (byte) ((length & 0xff000000L) >> 0x18), (byte) ((length & 0xff0000L) >> 0x10), (byte) ((length & 0xff00L) >> 8), (byte) (length & ((long) 0xffL)) };
            }
            if (this._arrMask != null)
            {
                buffer[0] = (byte) (buffer[0] | 0x80);
            }
            stream.Write(buffer, 0, buffer.Length);
            if (this._arrMask != null)
            {
                stream.Write(this._arrMask, 0, 4);
            }
            stream.Write(this._arrRawPayload, 0, this._arrRawPayload.Length);
            return stream.ToArray();
        }

        [CodeDescription("Returns all info about this message.")]
        public override string ToString()
        {
            return string.Format("WS{0}\nMessageID:\t{1}.{2}\nMessageType:\t{3}\nPayloadString:\t{4}\nMasking:\t{5}\n", new object[] { this._wsOwner.ToString(), this._bOutbound ? "Client" : "Server", this._iID, this._wsftType, this.PayloadAsString(), (this._arrMask == null) ? "<none>" : BitConverter.ToString(this._arrMask) });
        }

        private static void UnmaskData(byte[] arrIn, byte[] arrKey, byte[] arrOut)
        {
            if (Utilities.IsNullOrEmpty(arrKey))
            {
                Buffer.BlockCopy(arrIn, 0, arrOut, 0, arrIn.Length);
            }
            else
            {
                for (int i = 0; i < arrIn.Length; i++)
                {
                    arrOut[i] = (byte) (arrIn[i] ^ arrKey[i % 4]);
                }
            }
        }

        public WebSocketFrameTypes FrameType
        {
            get
            {
                return this._wsftType;
            }
            internal set
            {
                this._wsftType = value;
            }
        }

        [CodeDescription("If this is a Close frame, returns the close code. Otherwise, returns -1.")]
        public int iCloseReason
        {
            get
            {
                if (((this.FrameType != WebSocketFrameTypes.Close) || (this._arrRawPayload == null)) || (this._arrRawPayload.Length < 2))
                {
                    return -1;
                }
                byte[] arrIn = new byte[] { this._arrRawPayload[0], this._arrRawPayload[1] };
                UnmaskData(arrIn, this._arrMask, arrIn);
                return ((arrIn[0] << 8) + arrIn[1]);
            }
        }

        public int ID
        {
            get
            {
                return this._iID;
            }
        }

        public bool IsFinalFrame
        {
            get
            {
                return this._bIsFinalFragment;
            }
        }

        [CodeDescription("Returns TRUE if this is a Client->Server message, FALSE if this is a message from Server->Client.")]
        public bool IsOutbound
        {
            get
            {
                return this._bOutbound;
            }
        }

        [CodeDescription("Returns the WebSocketMessage's masking key, if any.")]
        public byte[] MaskingKey
        {
            get
            {
                return this._arrMask;
            }
            internal set
            {
                this._arrMask = value;
            }
        }

        [CodeDescription("Returns the raw payload data, which may be masked.")]
        public byte[] PayloadData
        {
            get
            {
                return this._arrRawPayload;
            }
            internal set
            {
                this._arrRawPayload = value;
            }
        }

        public int PayloadLength
        {
            get
            {
                if (this._arrRawPayload == null)
                {
                    return 0;
                }
                return this._arrRawPayload.Length;
            }
        }

        [CodeDescription("Indicates whether this WebSocketMessage was aborted.")]
        public bool WasAborted
        {
            get
            {
                return ((this.BitFlags & WSMFlags.Aborted) == WSMFlags.Aborted);
            }
        }
    }
}

