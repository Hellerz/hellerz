﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    public class CacheClearEventArgs : CancelEventArgs
    {
        

        public CacheClearEventArgs(bool bClearFiles, bool bClearCookies)
        {
            this.ClearCacheFiles = bClearFiles;
            this.ClearCookies = bClearCookies;
        }

        public bool ClearCacheFiles
        {
            
            get
            {
                return this.ClearCacheFiles;
            }
            
            set
            {
                this.ClearCacheFiles = value;
            }
        }

        public bool ClearCookies
        {
            
            get
            {
                return this.ClearCookies;
            }
            
            set
            {
                this.ClearCookies = value;
            }
        }
    }
}

