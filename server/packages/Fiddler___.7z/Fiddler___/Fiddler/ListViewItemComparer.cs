﻿namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Globalization;
    using System.Windows.Forms;

    internal class ListViewItemComparer : IComparer
    {
        internal bool bAscending;
        public CompareType CompareAs = CompareType.asInt;
        private int iCol = 0;
        private ListView lvOwner;

        public ListViewItemComparer(ListView oOwner)
        {
            this.lvOwner = oOwner;
            this.bAscending = true;
        }

        public int Compare(object x, object y)
        {
            int num = -1;
            ListViewItem item = (ListViewItem) x;
            ListViewItem item2 = (ListViewItem) y;
            if (item.SubItems.Count <= this.iCol)
            {
                num = -1;
            }
            else if (item2.SubItems.Count <= this.iCol)
            {
                num = 1;
            }
            else
            {
                try
                {
                    double num2;
                    double num3;
                    switch (this.CompareAs)
                    {
                        case CompareType.asString:
                            num = string.Compare(item.SubItems[this.iCol].Text, item2.SubItems[this.iCol].Text, StringComparison.Ordinal);
                            goto Label_01F3;

                        case CompareType.asInt:
                            num = int.Parse(item.SubItems[this.iCol].Text, NumberStyles.AllowThousands | NumberStyles.AllowLeadingSign).CompareTo(int.Parse(item2.SubItems[this.iCol].Text, NumberStyles.AllowThousands | NumberStyles.AllowLeadingSign));
                            goto Label_01F3;

                        case CompareType.asDouble:
                            break;

                        case CompareType.asDateTime:
                            num = DateTime.Parse(item.SubItems[this.iCol].Text).CompareTo(DateTime.Parse(item2.SubItems[this.iCol].Text));
                            goto Label_01F3;

                        default:
                            goto Label_01F3;
                    }
                    if (!double.TryParse(item.SubItems[this.iCol].Text, out num2))
                    {
                        num2 = -0.0099999997764825821;
                    }
                    if (!double.TryParse(item2.SubItems[this.iCol].Text, out num3))
                    {
                        num3 = -0.0099999997764825821;
                    }
                    num = num2.CompareTo(num3);
                }
                catch (Exception exception)
                {
                    FiddlerApplication.DebugSpew(exception.Message + "\n" + item.SubItems[this.iCol].Text + "\n" + item2.SubItems[this.iCol].Text);
                }
            }
        Label_01F3:
            if (!this.bAscending)
            {
                num = -num;
            }
            return num;
        }

        public int Column
        {
            get
            {
                return this.iCol;
            }
            set
            {
                int iCol = this.iCol;
                LVNative.LV_COLUMN lParam = new LVNative.LV_COLUMN();
                if (value == iCol)
                {
                    this.bAscending = !this.bAscending;
                }
                else
                {
                    this.iCol = value;
                    this.bAscending = true;
                    lParam.mask = 1;
                    LVNative.SendLVColMessage(this.lvOwner.Handle, 0x105f, (int) iCol, ref lParam);
                    lParam.fmt &= 0xfffff9ff;
                    LVNative.SendLVColMessage(this.lvOwner.Handle, 0x1060, (int) iCol, ref lParam);
                }
                lParam.mask = 1;
                LVNative.SendLVColMessage(this.lvOwner.Handle, 0x105f, (int) this.iCol, ref lParam);
                if (this.bAscending)
                {
                    lParam.fmt &= 0xfffffdff;
                    lParam.fmt |= 0x400;
                }
                else
                {
                    lParam.fmt &= 0xfffffbff;
                    lParam.fmt |= 0x200;
                }
                LVNative.SendLVColMessage(this.lvOwner.Handle, 0x1060, (int) this.iCol, ref lParam);
            }
        }

        public enum CompareType : byte
        {
            asDateTime = 3,
            asDouble = 2,
            asInt = 1,
            asString = 0
        }
    }
}

