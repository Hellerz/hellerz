﻿namespace Fiddler
{
    using System;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Threading;

    internal static class AppRecovery
    {
        private static bool _bIsRecovering;
        private static APPLICATION_RECOVERY_CALLBACK ard = new APPLICATION_RECOVERY_CALLBACK(AppRecovery.Recover);
        private static IntPtr methodPtrRecover;

        [DllImport("kernel32.dll")]
        private static extern int ApplicationRecoveryFinished(bool bSuccess);
        [DllImport("kernel32.dll")]
        private static extern int ApplicationRecoveryInProgress(out bool pbCancelled);
        private static bool CheckUIThreadBlocked()
        {
            Semaphore smCallback = new Semaphore(0, 1);
            FiddlerApplication.UI.BeginInvoke(delegate {
                smCallback.Release(1);
            });
            return !smCallback.WaitOne(250, false);
        }

        private static int Recover(IntPtr p)
        {
            _bIsRecovering = true;
            bool pbCancelled = false;
            ApplicationRecoveryInProgress(out pbCancelled);
            try
            {
                Trace.WriteLine("FiddlerRecovery: Unhooking all connectoids");
                FiddlerApplication.oProxy.oAllConnectoids.UnhookAllConnections();
            }
            catch
            {
            }
            Trace.WriteLine("FiddlerRecovery: Checking UI responsiveness...");
            bool flag2 = CheckUIThreadBlocked();
            Trace.WriteLine(string.Format("FiddlerRecovery: UI Thread {0} hung.", flag2 ? "IS" : "is NOT"));
            ApplicationRecoveryInProgress(out pbCancelled);
            if (!pbCancelled && !flag2)
            {
                try
                {
                    Trace.WriteLine("FiddlerRecovery: Storing Composer History");
                    UIComposer.SavePrefs();
                }
                catch (Exception exception)
                {
                    Trace.WriteLine(Utilities.DescribeException(exception));
                }
            }
            ApplicationRecoveryInProgress(out pbCancelled);
            try
            {
                Trace.WriteLine("FiddlerRecovery: Storing Preferences");
                CONFIG.RawPrefs.Close();
            }
            catch (Exception exception2)
            {
                Trace.WriteLine(Utilities.DescribeException(exception2));
            }
            if (!pbCancelled)
            {
                try
                {
                    Trace.WriteLine("FiddlerRecovery: Storing QuickExec History");
                    FiddlerApplication.UI._SaveQuickExecHistory();
                }
                catch (Exception exception3)
                {
                    Trace.WriteLine(Utilities.DescribeException(exception3));
                }
                if (!flag2)
                {
                    ApplicationRecoveryInProgress(out pbCancelled);
                    if (!pbCancelled)
                    {
                        try
                        {
                            Trace.WriteLine("FiddlerRecovery: Storing AutoResponder");
                            FiddlerApplication._AutoResponder.SaveDefaultRules();
                        }
                        catch (Exception exception4)
                        {
                            Trace.WriteLine(Utilities.DescribeException(exception4));
                        }
                    }
                }
            }
            ApplicationRecoveryInProgress(out pbCancelled);
            try
            {
                if (!flag2)
                {
                    Trace.WriteLine("FiddlerRecovery: Storing CONFIG and UI Layout");
                    CONFIG.SaveSettings(FiddlerApplication.UI);
                }
                else
                {
                    Trace.WriteLine("FiddlerRecovery: Storing CONFIG only");
                    CONFIG.SaveNonUISettings();
                }
            }
            catch (Exception exception5)
            {
                Trace.WriteLine(Utilities.DescribeException(exception5));
            }
            Trace.WriteLine("FiddlerRecovery: Done");
            ApplicationRecoveryFinished(true);
            return 0;
        }

        [DllImport("kernel32.dll")]
        private static extern int RegisterApplicationRecoveryCallback(IntPtr pRecoveryCallback, IntPtr pvParameter, int dwPingInterval, int dwFlags);
        [DllImport("kernel32.dll")]
        private static extern int RegisterApplicationRestart(string pszCommandline, RestartFlags dwFlags);
        internal static bool RegisterForRecovery()
        {
            if (Environment.OSVersion.Version.Major < 6)
            {
                return false;
            }
            int num = RegisterApplicationRestart("-recover", RestartFlags.RESTART_NO_PATCH | RestartFlags.RESTART_NO_REBOOT);
            if (num != 0)
            {
                Trace.WriteLine("FIDDLER: Failed to RegisterApplicationRestart: " + num.ToString());
            }
            methodPtrRecover = Marshal.GetFunctionPointerForDelegate(ard);
            num = RegisterApplicationRecoveryCallback(methodPtrRecover, IntPtr.Zero, 0x1388, 0);
            if (num != 0)
            {
                Trace.WriteLine("FIDDLER: Failed to RegisterApplicationRecoveryCallback: " + num.ToString());
            }
            return (0 == num);
        }

        public static bool IsRecovering
        {
            get
            {
                return _bIsRecovering;
            }
        }

        private delegate int APPLICATION_RECOVERY_CALLBACK(IntPtr pvParameter);

        [Flags]
        private enum RestartFlags : int
        {
            None = 0,
            RESTART_NO_CRASH = 1,
            RESTART_NO_HANG = 2,
            RESTART_NO_PATCH = 4,
            RESTART_NO_REBOOT = 8
        }
    }
}

