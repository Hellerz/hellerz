﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    internal static class ModernWinAPI
    {
        internal static int LaunchEdgeBrowser(string sURL)
        {
            try
            {
                int num;
                new ApplicationActivationManager().ActivateApplication("Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge", !string.IsNullOrEmpty(sURL) ? sURL : null, ActivateOptions.None, out num);
                return num;
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Failed to launch Microsoft Edge", "Unable to launch Microsoft Edge. Is it installed on this machine?");
                return 0;
            }
        }

        private enum ActivateOptions
        {
            DesignMode = 1,
            NoErrorUI = 2,
            None = 0,
            NoSplashScreen = 4
        }

        [ComImport, Guid("45BA127D-10A8-46EA-8AB7-56EA9078943C")]
        private class ApplicationActivationManager : ModernWinAPI.IApplicationActivationManager
        {
            [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType=MethodCodeType.Runtime)]
            public extern IntPtr ActivateApplication([In] string appUserModelId, [In] string arguments, [In] ModernWinAPI.ActivateOptions options, out int processId);
            [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType=MethodCodeType.Runtime)]
            public extern IntPtr ActivateForFile([In] string appUserModelId, [In] IntPtr itemArray, [In] string verb, out int processId);
            [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType=MethodCodeType.Runtime)]
            public extern IntPtr ActivateForProtocol([In] string appUserModelId, [In] IntPtr itemArray, out int processId);
        }

        [ComImport, Guid("2e941141-7f97-4756-ba1d-9decde894a3d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IApplicationActivationManager
        {
            IntPtr ActivateApplication([In] string appUserModelId, [In] string arguments, [In] ModernWinAPI.ActivateOptions options, out int processId);
            IntPtr ActivateForFile([In] string appUserModelId, [In] IntPtr itemArray, [In] string verb, out int processId);
            IntPtr ActivateForProtocol([In] string appUserModelId, [In] IntPtr itemArray, out int processId);
        }
    }
}

