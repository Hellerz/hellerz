﻿namespace Fiddler
{
    using System;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Net.NetworkInformation;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Security;
    using System.Security.Authentication;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class ServerChatter
    {
        internal MakeConnectionExecutionState _esState;
        private bool m_bLeakedHeaders;
        internal bool m_bWasForwarded;
        private int m_iBodySeekProgress;
        private int m_iEntityBodyOffset;
        private HTTPResponseHeaders m_inHeaders;
        private long m_lngLastChunkInfoOffset;
        private long m_lngLeakedOffset;
        private PipeReadBuffer m_responseData;
        internal long m_responseTotalDataCount;
        private Session m_session;
        public ServerPipe pipeServer;
        internal static int s_cbServerReadBuffer = 0x8000;
        internal static int s_SO_RCVBUF_Option = -1;
        internal static int s_SO_SNDBUF_Option = -1;
        internal static int s_WATCHDOG_INTERVAL;

        static ServerChatter()
        {
            TimeSpan span = new TimeSpan(0, 5, 0);
            s_WATCHDOG_INTERVAL = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.watchdoginterval", (int) span.TotalMilliseconds);
        }

        internal ServerChatter(Session oSession)
        {
            this.m_lngLastChunkInfoOffset = -1L;
            this.m_session = oSession;
            this.m_responseData = new PipeReadBuffer(false);
        }

        internal ServerChatter(Session oSession, string sHeaders)
        {
            this.m_lngLastChunkInfoOffset = -1L;
            this.m_session = oSession;
            this.m_inHeaders = Parser.ParseResponse(sHeaders);
        }

        private static byte[] _BuildSOCKS4ConnectHandshakeForTarget(string sTargetHost, int iPort)
        {
            byte[] bytes = Encoding.ASCII.GetBytes(sTargetHost);
            byte[] dst = new byte[10 + bytes.Length];
            dst[0] = 4;
            dst[1] = 1;
            dst[2] = (byte) (iPort >> 8);
            dst[3] = (byte) (iPort & 0xff);
            dst[7] = 0x7f;
            Buffer.BlockCopy(bytes, 0, dst, 9, bytes.Length);
            return dst;
        }

        private void _deleteInformationalMessage()
        {
            this.m_inHeaders = null;
            int iDefaultCapacity = ((int) this.m_responseData.Length) - this.m_iEntityBodyOffset;
            PipeReadBuffer buffer = new PipeReadBuffer(iDefaultCapacity);
            buffer.Write(this.m_responseData.GetBuffer(), this.m_iEntityBodyOffset, iDefaultCapacity);
            this.m_responseData = buffer;
            this.m_responseTotalDataCount = this.m_responseData.Length;
            this.m_iEntityBodyOffset = this.m_iBodySeekProgress = 0;
        }

        internal void _detachServerPipe()
        {
            if (this.pipeServer != null)
            {
                if (((this.pipeServer.ReusePolicy != PipeReusePolicy.NoReuse) && (this.pipeServer.ReusePolicy != PipeReusePolicy.MarriedToClientPipe)) && (this.pipeServer.isClientCertAttached && !this.pipeServer.isAuthenticated))
                {
                    this.pipeServer.MarkAsAuthenticated(this.m_session.LocalProcessID);
                }
                Proxy.htServerPipePool.PoolOrClosePipe(this.pipeServer);
                this.pipeServer = null;
            }
        }

        private void _EnableStreamingIfAppropriate()
        {
            string inStr = this.m_inHeaders["Content-Type"];
            if (inStr.OICStartsWithAny(new string[] { "text/event-stream", "multipart/x-mixed-replace" }) && FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.AutoStreamByMIME", true))
            {
                this.m_session.bBufferResponse = false;
            }
            else if (CONFIG.bStreamAudioVideo && inStr.OICStartsWithAny(new string[] { "video/", "audio/", "application/x-mms-framed" }))
            {
                this.m_session.bBufferResponse = false;
            }
            if (!this.m_session.bBufferResponse)
            {
                if (this.m_session.HTTPMethodIs("CONNECT"))
                {
                    this.m_session.bBufferResponse = true;
                }
                else if (0x65 == this.m_inHeaders.HTTPResponseCode)
                {
                    this.m_session.bBufferResponse = true;
                }
                else if (this.m_session.oRequest.pipeClient == null)
                {
                    this.m_session.bBufferResponse = true;
                }
                else if (((0x191 == this.m_inHeaders.HTTPResponseCode) || (0x197 == this.m_inHeaders.HTTPResponseCode)) && this.m_session.oFlags.ContainsKey("x-AutoAuth"))
                {
                    this.m_session.bBufferResponse = true;
                }
            }
        }

        internal bool _MayRetryWhenSendFailed()
        {
            return (this.bServerSocketReused && (this.m_session.state != SessionStates.Aborted));
        }

        internal byte[] _PeekAtBody()
        {
            if (((this.m_iEntityBodyOffset < 1) || (this.m_responseData == null)) || (this.m_responseData.Length < 1L))
            {
                return Utilities.emptyByteArray;
            }
            int count = ((int) this.m_responseData.Length) - this.m_iEntityBodyOffset;
            if (count < 1)
            {
                return Utilities.emptyByteArray;
            }
            byte[] dst = new byte[count];
            Buffer.BlockCopy(this.m_responseData.GetBuffer(), this.m_iEntityBodyOffset, dst, 0, count);
            return dst;
        }

        internal void _PoisonPipe()
        {
            if (this.pipeServer != null)
            {
                this.pipeServer.ReusePolicy = PipeReusePolicy.NoReuse;
            }
        }

        private void _ReturnFileReadError(string sRemoteError, string sTrustedError)
        {
            string str;
            this.Initialize(false);
            if ((this.m_session.LocalProcessID > 0) || this.m_session.isFlagSet(SessionFlags.RequestGeneratedByFiddler))
            {
                str = sTrustedError;
            }
            else
            {
                str = sRemoteError;
            }
            str = str.PadRight(0x200, ' ');
            this.m_session.responseBodyBytes = Encoding.UTF8.GetBytes(str);
            this.m_inHeaders = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
            this.m_inHeaders.SetStatus(0x194, "Not Found");
            this.m_inHeaders.Add("Content-Length", this.m_session.responseBodyBytes.Length.ToString());
            this.m_inHeaders.Add("Cache-Control", "max-age=0, must-revalidate");
        }

        internal bool _ShouldAbortAsOrphan()
        {
            if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.abortorphanstreams", true))
            {
                return false;
            }
            if (this.m_session.ViewItem != null)
            {
                return (this.m_session.ViewItem.Index < 0);
            }
            return true;
        }

        private void _smHandleConnectionException(Exception eX)
        {
            string str2;
            string str3;
            string str = string.Empty;
            bool flag = true;
            if (eX is SecurityException)
            {
                flag = false;
            }
            SocketException exception = eX as SocketException;
            if (exception != null)
            {
                if (((exception.SocketErrorCode == SocketError.AccessDenied) || (exception.SocketErrorCode == SocketError.NetworkDown)) || (exception.SocketErrorCode == SocketError.InvalidArgument))
                {
                    str = string.Format("A Firewall may be blocking Fiddler's traffic.<br />Error: {0} (0x{1:x}).", exception.SocketErrorCode, (int) exception.SocketErrorCode);
                    flag = false;
                }
                else
                {
                    str = string.Format("<br />Error: {0} (0x{1:x}).", exception.SocketErrorCode, (int) exception.SocketErrorCode);
                }
            }
            if (this.m_bWasForwarded)
            {
                str2 = "Fiddler - Gateway Connection Failed";
                str3 = "[Fiddler] The connection to the upstream proxy/gateway failed.";
                if (flag)
                {
                    str = string.Format("Closing Fiddler, changing your system proxy settings, and restarting Fiddler may help. {0}", str);
                }
            }
            else
            {
                str2 = "Fiddler - Connection Failed";
                str3 = string.Format("[Fiddler] The connection to '{0}' failed.", Utilities.HtmlEncode(this._esState.sServerHostname));
            }
            this.m_session.oRequest.FailSession(0x1f6, str2, string.Format("{0} {1} <br />{2}", str3, str, Utilities.HtmlEncode(Utilities.DescribeException(eX))));
        }

        private void _smNotifyCSMDone()
        {
            AsyncCallback onDone = this._esState.OnDone;
            this._esState = null;
            onDone(null);
        }

        private Socket _SOCKSifyConnection(string sServerHostname, int iServerPort, Socket newSocket)
        {
            this.m_bWasForwarded = false;
            FiddlerApplication.DebugSpew("Creating SOCKS connection for {0}:{1}.", new object[] { sServerHostname, iServerPort });
            byte[] buffer = _BuildSOCKS4ConnectHandshakeForTarget(sServerHostname, iServerPort);
            newSocket.Send(buffer);
            byte[] buffer2 = new byte[0x40];
            int iMaxByteCount = newSocket.Receive(buffer2);
            if (((iMaxByteCount > 1) && (buffer2[0] == 0)) && (buffer2[1] == 90))
            {
                if (iMaxByteCount > 7)
                {
                    string str = string.Format("{0}.{1}.{2}.{3}", new object[] { buffer2[4], buffer2[5], buffer2[6], buffer2[7] });
                    this.m_session.m_hostIP = str;
                    this.m_session.oFlags["x-hostIP"] = str;
                }
                return newSocket;
            }
            try
            {
                newSocket.Close();
            }
            catch
            {
            }
            string str2 = string.Empty;
            if ((iMaxByteCount > 1) && (buffer2[0] == 0))
            {
                int num2 = buffer2[1];
                str2 = string.Format("Gateway returned error 0x{0:x}", num2);
                switch (num2)
                {
                    case 0x5b:
                        str2 = str2 + "-'request rejected or failed'";
                        goto Label_0177;

                    case 0x5c:
                        str2 = str2 + "-'request failed because client is not running identd (or not reachable from the server)'";
                        goto Label_0177;

                    case 0x5d:
                        str2 = str2 + "-'request failed because client's identd could not confirm the user ID string in the request'";
                        goto Label_0177;
                }
                str2 = str2 + "-'unknown'";
            }
            else if (iMaxByteCount > 0)
            {
                str2 = "Gateway returned a malformed response:\n" + Utilities.ByteArrayToHexView(buffer2, 8, iMaxByteCount);
            }
            else
            {
                str2 = "Gateway returned no data.";
            }
        Label_0177:
            throw new InvalidDataException("SOCKS gateway failed: " + str2);
        }

        internal void BeginAsyncConnectToHost(AsyncCallback OnDone)
        {
            if (this.m_session.isFTP && !this.m_session.isFlagSet(SessionFlags.SentToGateway))
            {
                OnDone(null);
            }
            else
            {
                this._esState = new MakeConnectionExecutionState();
                this._esState.OnDone = OnDone;
                this._esState.CurrentState = StateConnecting.BeginFindGateway;
                this.RunConnectionStateMachine();
            }
        }

        private static Socket CreateConnectedSocket(IPEndPoint[] arrDest, Session _oSession)
        {
            Socket sockServer = null;
            bool flag = false;
            Stopwatch stopwatch = Stopwatch.StartNew();
            Exception exception = null;
            foreach (IPEndPoint point in arrDest)
            {
                try
                {
                    sockServer = new Socket(point.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                    sockServer.NoDelay = true;
                    if (FiddlerApplication.oProxy._DefaultEgressEndPoint != null)
                    {
                        sockServer.Bind(FiddlerApplication.oProxy._DefaultEgressEndPoint);
                    }
                    sockServer.Connect(point);
                    _oSession.m_hostIP = point.Address.ToString();
                    _oSession.oFlags["x-hostIP"] = _oSession.m_hostIP;
                    if (s_SO_RCVBUF_Option >= 0)
                    {
                        sockServer.ReceiveBufferSize = s_SO_RCVBUF_Option;
                    }
                    if (s_SO_SNDBUF_Option >= 0)
                    {
                        sockServer.SendBufferSize = s_SO_SNDBUF_Option;
                    }
                    FiddlerApplication.DoAfterSocketConnect(_oSession, sockServer);
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("[ServerPipe]\n SendBufferSize:\t{0}\n ReceiveBufferSize:\t{1}\n SendTimeout:\t{2}\n ReceiveTimeOut:\t{3}\n NoDelay:\t{4}\n EgressEP:\t{5}\n", new object[] { sockServer.SendBufferSize, sockServer.ReceiveBufferSize, sockServer.SendTimeout, sockServer.ReceiveTimeout, sockServer.NoDelay, (FiddlerApplication.oProxy._DefaultEgressEndPoint != null) ? FiddlerApplication.oProxy._DefaultEgressEndPoint.ToString() : "none" });
                    }
                    flag = true;
                    break;
                }
                catch (Exception exception2)
                {
                    exception = exception2;
                    if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.network.dns.fallback", true))
                    {
                        break;
                    }
                    _oSession.oFlags["x-DNS-Failover"] = _oSession.oFlags["x-DNS-Failover"] + "+1";
                }
            }
            _oSession.Timers.ServerConnected = DateTime.Now;
            _oSession.Timers.TCPConnectTime = (int) stopwatch.ElapsedMilliseconds;
            if (!flag)
            {
                throw exception;
            }
            return sockServer;
        }

        internal void FreeResponseDataBuffer()
        {
            if (this.m_responseData != null)
            {
                this.m_responseData.Dispose();
                this.m_responseData = null;
            }
        }

        internal void GenerateHeadersForLocalFile(string sFilename)
        {
            FileInfo info = new FileInfo(sFilename);
            this.Initialize(false);
            this.m_inHeaders = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
            this.m_inHeaders.SetStatus(200, "OK with automatic headers");
            this.m_inHeaders["Date"] = DateTime.UtcNow.ToString("r");
            this.m_inHeaders["Content-Length"] = info.Length.ToString();
            this.m_inHeaders["Cache-Control"] = "max-age=0, must-revalidate";
            string str = Utilities.ContentTypeForFilename(sFilename);
            if (str != null)
            {
                this.m_inHeaders["Content-Type"] = str;
            }
        }

        private bool GetHeaders()
        {
            if (!this.HeadersAvailable())
            {
                return false;
            }
            if (!this.ParseResponseForHeaders())
            {
                string str;
                this.m_session.SetBitFlag(SessionFlags.ProtocolViolationInResponse, true);
                this._PoisonPipe();
                if (this.m_responseData != null)
                {
                    str = "<plaintext>\n" + Utilities.ByteArrayToHexView(this.m_responseData.GetBuffer(), 0x18, (int) Math.Min(this.m_responseData.Length, 0x800L));
                }
                else
                {
                    str = "{Fiddler:no data}";
                }
                this.m_session.oRequest.FailSession(500, "Fiddler - Bad Response", string.Format("[Fiddler] Response Header parsing failed.\n{0}Response Data:\n{1}", this.m_session.isFlagSet(SessionFlags.ServerPipeReused) ? "This can be caused by an illegal HTTP response earlier on this reused server socket-- for instance, a HTTP/304 response which illegally contains a body.\n" : string.Empty, str));
                return true;
            }
            if ((this.m_inHeaders.HTTPResponseCode > 0x63) && (this.m_inHeaders.HTTPResponseCode < 200))
            {
                if (this.m_inHeaders.Exists("Content-Length") && ("0" != this.m_inHeaders["Content-Length"].Trim()))
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "HTTP/1xx responses MUST NOT contain a body, but a non-zero content-length was returned.");
                }
                if ((this.m_inHeaders.HTTPResponseCode != 0x65) || !this.m_inHeaders.ExistsAndContains("Upgrade", "WebSocket"))
                {
                    if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.leakhttp1xx", true) && (this.m_session.oRequest.pipeClient != null))
                    {
                        try
                        {
                            StringDictionary dictionary;
                            this.m_session.oRequest.pipeClient.Send(this.m_inHeaders.ToByteArray(true, true));
                            (dictionary = this.m_session.oFlags)["x-fiddler-Stream1xx"] = dictionary["x-fiddler-Stream1xx"] + "Returned a HTTP/" + this.m_inHeaders.HTTPResponseCode.ToString() + " message from the server.";
                        }
                        catch (Exception exception)
                        {
                            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.abortifclientaborts", false))
                            {
                                throw new Exception("Leaking HTTP/1xx response to client failed", exception);
                            }
                            FiddlerApplication.Log.LogFormat("fiddler.network.streaming> Streaming of HTTP/1xx headers from #{0} to client failed: {1}", new object[] { this.m_session.id, exception.Message });
                        }
                    }
                    else
                    {
                        StringDictionary dictionary2;
                        (dictionary2 = this.m_session.oFlags)["x-fiddler-streaming"] = dictionary2["x-fiddler-streaming"] + "Eating a HTTP/" + this.m_inHeaders.HTTPResponseCode.ToString() + " message from the stream.";
                    }
                    this._deleteInformationalMessage();
                    return this.GetHeaders();
                }
            }
            return true;
        }

        private bool HeadersAvailable()
        {
            if (this.m_iEntityBodyOffset <= 0)
            {
                HTTPHeaderParseWarnings warnings;
                if (this.m_responseData == null)
                {
                    return false;
                }
                if (!Parser.FindEndOfHeaders(this.m_responseData.GetBuffer(), ref this.m_iBodySeekProgress, this.m_responseData.Length, out warnings))
                {
                    return false;
                }
                this.m_iEntityBodyOffset = this.m_iBodySeekProgress + 1;
                switch (warnings)
                {
                    case HTTPHeaderParseWarnings.EndedWithLFLF:
                        FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "The Server did not return properly formatted HTTP Headers. HTTP headers\nshould be terminated with CRLFCRLF. These were terminated with LFLF.");
                        break;

                    case HTTPHeaderParseWarnings.EndedWithLFCRLF:
                        FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "The Server did not return properly formatted HTTP Headers. HTTP headers\nshould be terminated with CRLFCRLF. These were terminated with LFCRLF.");
                        break;
                }
            }
            return true;
        }

        internal void Initialize(bool bAllocatePipeReadBuffer)
        {
            this.m_responseData = bAllocatePipeReadBuffer ? new PipeReadBuffer(false) : null;
            this.m_responseTotalDataCount = this.m_lngLeakedOffset = this.m_iBodySeekProgress = this.m_iEntityBodyOffset = 0;
            this.m_lngLastChunkInfoOffset = -1L;
            this.m_inHeaders = null;
            this.m_bLeakedHeaders = false;
            if (this.pipeServer != null)
            {
                FiddlerApplication.DebugSpew("Reinitializing ServerChatter; detaching ServerPipe.");
                this.pipeServer.End();
                this.pipeServer = null;
            }
            this.m_bWasForwarded = false;
            this.m_session.SetBitFlag(SessionFlags.ServerPipeReused, false);
        }

        private bool isResponseBodyComplete()
        {
            if (this.m_session.HTTPMethodIs("HEAD"))
            {
                return true;
            }
            if (this.m_session.HTTPMethodIs("CONNECT") && (this.m_inHeaders.HTTPResponseCode == 200))
            {
                return true;
            }
            if ((this.m_inHeaders.HTTPResponseCode == 200) && this.m_session.isFlagSet(SessionFlags.IsRPCTunnel))
            {
                this.m_session.bBufferResponse = true;
                return true;
            }
            if (((this.m_inHeaders.HTTPResponseCode == 0xcc) || (this.m_inHeaders.HTTPResponseCode == 0xcd)) || ((this.m_inHeaders.HTTPResponseCode == 0x130) || ((this.m_inHeaders.HTTPResponseCode > 0x63) && (this.m_inHeaders.HTTPResponseCode < 200))))
            {
                if (this.m_inHeaders.Exists("Content-Length") && ("0" != this.m_inHeaders["Content-Length"].Trim()))
                {
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "This type of HTTP response MUST NOT contain a body, but a non-zero content-length was returned.");
                    return true;
                }
                return true;
            }
            if (this.m_inHeaders.ExistsAndEquals("Transfer-Encoding", "chunked"))
            {
                long num;
                if (this.m_lngLastChunkInfoOffset < this.m_iEntityBodyOffset)
                {
                    this.m_lngLastChunkInfoOffset = this.m_iEntityBodyOffset;
                }
                return Utilities.IsChunkedBodyComplete(this.m_session, this.m_responseData, this.m_lngLastChunkInfoOffset, out this.m_lngLastChunkInfoOffset, out num);
            }
            if (this.m_inHeaders.Exists("Content-Length"))
            {
                long num2;
                if (long.TryParse(this.m_inHeaders["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num2) && (num2 >= 0L))
                {
                    return (this.m_responseTotalDataCount >= (this.m_iEntityBodyOffset + num2));
                }
                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, true, true, "Content-Length response header is not a valid unsigned integer.\nContent-Length: " + this.m_inHeaders["Content-Length"]);
                return true;
            }
            if ((!this.m_inHeaders.ExistsAndEquals("Connection", "close") && !this.m_inHeaders.ExistsAndEquals("Proxy-Connection", "close")) && ((this.m_inHeaders.HTTPVersion == "HTTP/1.1") || this.m_inHeaders.ExistsAndContains("Connection", "Keep-Alive")))
            {
                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, true, true, "No Connection: close, no Content-Length. No way to tell if the response is complete.");
            }
            return false;
        }

        private bool IsWorkableFTPRequest()
        {
            if (this.m_session.isFTP && !this.m_session.isFlagSet(SessionFlags.SentToGateway))
            {
                try
                {
                    FTPGateway.MakeFTPRequest(this.m_session, this.m_responseData, out this.m_inHeaders);
                    return true;
                }
                catch (Exception exception)
                {
                    this.m_session.oFlags["X-ServerPipeError"] = Utilities.DescribeException(exception);
                    FiddlerApplication.Log.LogFormat("fiddler.network.readresponse.failure> FTPSession #{0} raised exception: {1}", new object[] { this.m_session.id, Utilities.DescribeException(exception) });
                    return false;
                }
            }
            return false;
        }

        private bool LeakResponseBytes()
        {
            try
            {
                if (this.m_session.oRequest.pipeClient == null)
                {
                    return false;
                }
                if (!this.m_bLeakedHeaders)
                {
                    if (((0x191 == this.m_inHeaders.HTTPResponseCode) && this.m_inHeaders["WWW-Authenticate"].OICStartsWith("N")) || ((0x197 == this.m_inHeaders.HTTPResponseCode) && this.m_inHeaders["Proxy-Authenticate"].OICStartsWith("N")))
                    {
                        this.m_inHeaders["Proxy-Support"] = "Session-Based-Authentication";
                    }
                    this.m_session.Timers.ClientBeginResponse = DateTime.Now;
                    this.m_bLeakedHeaders = true;
                    this.m_session.oRequest.pipeClient.Send(this.m_inHeaders.ToByteArray(true, true));
                    this.m_lngLeakedOffset = this.m_iEntityBodyOffset;
                }
                this.m_session.oRequest.pipeClient.Send(this.m_responseData.GetBuffer(), (int) this.m_lngLeakedOffset, (int) (this.m_responseData.Length - this.m_lngLeakedOffset));
                this.m_lngLeakedOffset = this.m_responseData.Length;
                return true;
            }
            catch (Exception exception)
            {
                this.m_session.PoisonClientPipe();
                FiddlerApplication.Log.LogFormat("fiddler.network.streaming> Streaming of response #{0} to client failed: {1}. Leaking aborted.", new object[] { this.m_session.id, exception.Message });
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.abortifclientaborts", false))
                {
                    throw new OperationCanceledException("Leaking response to client failed", exception);
                }
                if (this._ShouldAbortAsOrphan())
                {
                    throw new OperationCanceledException("Aborting orphan stream", exception);
                }
                return false;
            }
        }

        private bool ParseResponseForHeaders()
        {
            if ((this.m_responseData != null) && (this.m_iEntityBodyOffset >= 4))
            {
                this.m_inHeaders = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
                byte[] bytes = this.m_responseData.GetBuffer();
                string str = CONFIG.oHeaderEncoding.GetString(bytes, 0, this.m_iEntityBodyOffset).Trim();
                if ((str == null) || (str.Length < 1))
                {
                    this.m_inHeaders = null;
                    return false;
                }
                string[] sHeaderLines = str.Replace("\r\n", "\n").Split(new char[] { '\n' });
                if (sHeaderLines.Length >= 1)
                {
                    int index = sHeaderLines[0].IndexOf(' ');
                    if (index > 0)
                    {
                        this.m_inHeaders.HTTPVersion = sHeaderLines[0].Substring(0, index).ToUpperInvariant();
                        sHeaderLines[0] = sHeaderLines[0].Substring(index + 1).Trim();
                        if (!this.m_inHeaders.HTTPVersion.OICStartsWith("HTTP/"))
                        {
                            if (!this.m_inHeaders.HTTPVersion.OICStartsWith("ICY"))
                            {
                                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "Response does not start with HTTP. Data:\n\n\t" + sHeaderLines[0]);
                                return false;
                            }
                            this.m_session.bBufferResponse = false;
                            this.m_session.oFlags["log-drop-response-body"] = "ICY";
                        }
                        this.m_inHeaders.HTTPResponseStatus = sHeaderLines[0];
                        bool flag = false;
                        index = sHeaderLines[0].IndexOf(' ');
                        if (index > 0)
                        {
                            flag = int.TryParse(sHeaderLines[0].Substring(0, index).Trim(), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out this.m_inHeaders.HTTPResponseCode);
                        }
                        else
                        {
                            string s = sHeaderLines[0].Trim();
                            flag = int.TryParse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out this.m_inHeaders.HTTPResponseCode);
                            if (!flag)
                            {
                                for (int i = 0; i < s.Length; i++)
                                {
                                    if (!char.IsDigit(s[i]))
                                    {
                                        flag = int.TryParse(s.Substring(0, i), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out this.m_inHeaders.HTTPResponseCode);
                                        if (flag)
                                        {
                                            FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, false, "The response's status line was missing a space between ResponseCode and ResponseStatus. Data:\n\n\t" + s);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        if (!flag)
                        {
                            FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "The response's status line did not contain a ResponseCode. Data:\n\n\t" + sHeaderLines[0]);
                            return false;
                        }
                        string sErrors = string.Empty;
                        if (!Parser.ParseNVPHeaders(this.m_inHeaders, sHeaderLines, 1, ref sErrors))
                        {
                            FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "Incorrectly formed response headers.\n" + sErrors);
                        }
                        if (this.m_inHeaders.Exists("Content-Length") && this.m_inHeaders.ExistsAndContains("Transfer-Encoding", "chunked"))
                        {
                            FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInRequest, false, false, "Content-Length response header MUST NOT be present when Transfer-Encoding is used (RFC2616 Section 4.4)");
                        }
                        return true;
                    }
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, false, true, "Cannot parse HTTP response; Status line contains no spaces. Data:\n\n\t" + sHeaderLines[0]);
                }
            }
            return false;
        }

        internal bool ReadResponse()
        {
            long maxValue = long.MaxValue;
            if (this.pipeServer == null)
            {
                return this.IsWorkableFTPRequest();
            }
            int bytesRead = 0;
            bool flag = false;
            bool flag2 = false;
            bool flag3 = false;
            bool flag4 = false;
            byte[] arrBuffer = new byte[s_cbServerReadBuffer];
            SessionTimers.NetTimestamps timestamps = new SessionTimers.NetTimestamps();
            Stopwatch stopwatch = Stopwatch.StartNew();
        Label_0038:
            try
            {
                bytesRead = this.pipeServer.Receive(arrBuffer);
                timestamps.AddRead(stopwatch.ElapsedMilliseconds, bytesRead);
                if (0L == this.m_session.Timers.ServerBeginResponse.Ticks)
                {
                    this.m_session.Timers.ServerBeginResponse = DateTime.Now;
                }
                if (bytesRead < 1)
                {
                    flag = true;
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("END-OF-STREAM: Read from {0}: returned {1}", new object[] { this.pipeServer, bytesRead });
                    }
                }
                else
                {
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("READ {0:N0} FROM {1}:\n{2}", new object[] { bytesRead, this.pipeServer, Utilities.ByteArrayToHexView(arrBuffer, 0x20, bytesRead) });
                    }
                    if (maxValue < Utilities.GetTickCount())
                    {
                        ListViewItem viewItem = this.m_session.ViewItem;
                        if (((viewItem == null) || (viewItem.Index < 0)) && (this.m_session.bBufferResponse || !FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.abortifclientaborts", false)))
                        {
                            FiddlerApplication.DebugSpew("Closing {0} for {1} due to Watchdog expiration", new object[] { this.pipeServer, this.m_session.id });
                            throw new OperationCanceledException(string.Format("Session {0} did not encounter end of response on '{1}' before fiddler.network.timeouts.serverpipe.watchdoginterval timeout expired.", this.m_session.id, this.pipeServer));
                        }
                        maxValue = Utilities.GetTickCount() + s_WATCHDOG_INTERVAL;
                    }
                    this.m_responseData.Write(arrBuffer, 0, bytesRead);
                    this.m_responseTotalDataCount += bytesRead;
                    if (this.m_inHeaders == null)
                    {
                        if (!this.GetHeaders())
                        {
                            goto Label_074C;
                        }
                        this.m_session.Timers.FiddlerGotResponseHeaders = DateTime.Now;
                        if ((this.m_session.state == SessionStates.Aborted) && this.m_session.isAnyFlagSet(SessionFlags.ProtocolViolationInResponse))
                        {
                            return false;
                        }
                        int iSize = 0;
                        if ((!this.m_session.HTTPMethodIs("HEAD") && this.m_inHeaders.TryGetEntitySize(out iSize)) && (iSize > 0))
                        {
                            iSize = (int) (this.m_iEntityBodyOffset + Math.Min((long) CONFIG.cbAutoStreamAndForget, (long) iSize));
                            this.m_responseData.HintTotalSize(iSize);
                        }
                        FiddlerApplication.DoResponseHeadersAvailable(this.m_session);
                        if (((0x197 == this.m_inHeaders.HTTPResponseCode) && (!this.m_session.isAnyFlagSet(SessionFlags.SentToGateway) || this.m_session.isHTTPS)) && FiddlerApplication.Prefs.GetBoolPref("fiddler.security.ForbidServer407", true))
                        {
                            this.m_session.SetBitFlag(SessionFlags.ProtocolViolationInResponse, true);
                            this._PoisonPipe();
                            string sErrorBody = "<plaintext>\n[Fiddler] Security Warning\nA HTTP/407 response was received on a request not sent to an upstream proxy.\nThis may reflect an attempt to compromise your credentials.\nPreference 'fiddler.security.ForbidServer407' is set to true.";
                            this.m_session.oRequest.FailSession(500, "Fiddler - Illegal Response", sErrorBody);
                            return false;
                        }
                        this._EnableStreamingIfAppropriate();
                        if (iSize > CONFIG.cbAutoStreamAndForget)
                        {
                            this.m_session.oFlags["log-drop-response-body"] = "OverToolsOptionsLimit";
                            this.m_session.bBufferResponse = false;
                        }
                        this.m_session.ExecuteBasicResponseManipulationsUsingHeadersOnly();
                        if (this.m_session.oFlags.ContainsKey("x-breakresponse"))
                        {
                            this.m_session.bBufferResponse = true;
                        }
                        if (this.m_session.isAnyFlagSet(SessionFlags.IsRPCTunnel) && (200 == this.m_inHeaders.HTTPResponseCode))
                        {
                            this.m_session.bBufferResponse = true;
                        }
                        this.m_session.SetBitFlag(SessionFlags.ResponseStreamed, !this.m_session.bBufferResponse);
                        if (!this.m_session.bBufferResponse)
                        {
                            if (this.m_session.oFlags.ContainsKey("response-trickle-delay"))
                            {
                                int num4 = int.Parse(this.m_session.oFlags["response-trickle-delay"]);
                                this.m_session.oRequest.pipeClient.TransmitDelay = num4;
                            }
                            if (this.m_session.oFlags.ContainsKey("log-drop-response-body") || FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.ForgetStreamedData", false))
                            {
                                flag3 = true;
                            }
                        }
                        if (!this.m_inHeaders.Exists("Content-Length"))
                        {
                            maxValue = Utilities.GetTickCount() + s_WATCHDOG_INTERVAL;
                        }
                    }
                    if (!flag3 && ((this.m_responseData.Length - this.m_iEntityBodyOffset) > CONFIG.cbAutoStreamAndForget))
                    {
                        if (CONFIG.bDebugSpew)
                        {
                            FiddlerApplication.DebugSpew("While reading response, exceeded CONFIG.cbAutoStreamAndForget when stream reached {0:N0} bytes. Enabling streaming now", new object[] { this.m_responseData.Length });
                        }
                        this.m_session.SetBitFlag(SessionFlags.ResponseStreamed, true);
                        this.m_session.oFlags["log-drop-response-body"] = "OverToolsOptionsLimit";
                        this.m_session.bBufferResponse = false;
                        flag3 = true;
                        if (this.m_session.oFlags.ContainsKey("response-trickle-delay"))
                        {
                            int num5 = int.Parse(this.m_session.oFlags["response-trickle-delay"]);
                            this.m_session.oRequest.pipeClient.TransmitDelay = num5;
                        }
                    }
                    if (this.m_session.isFlagSet(SessionFlags.ResponseStreamed))
                    {
                        if (!flag4)
                        {
                            if (!this.LeakResponseBytes())
                            {
                                flag4 = true;
                            }
                        }
                        else if (this._ShouldAbortAsOrphan())
                        {
                            throw new OperationCanceledException("Aborting orphan stream");
                        }
                        if (flag3)
                        {
                            this.m_session.SetBitFlag(SessionFlags.ResponseBodyDropped, true);
                            if (this.m_lngLastChunkInfoOffset > -1L)
                            {
                                this.ReleaseStreamedChunkedData();
                            }
                            else if (this.m_inHeaders.ExistsAndContains("Transfer-Encoding", "chunked"))
                            {
                                this.ReleaseStreamedChunkedData();
                            }
                            else
                            {
                                this.ReleaseStreamedData();
                            }
                        }
                    }
                }
            }
            catch (SocketException exception)
            {
                flag2 = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("ReadResponse() failure {0}", new object[] { Utilities.DescribeException(exception) });
                }
                if (exception.SocketErrorCode == SocketError.TimedOut)
                {
                    this.m_session.oFlags["X-ServerPipeError"] = "Timed out while reading response.";
                }
                else
                {
                    FiddlerApplication.Log.LogFormat("fiddler.network.readresponse.failure> Session #{0} raised exception {1}", new object[] { this.m_session.id, Utilities.DescribeException(exception) });
                }
            }
            catch (Exception exception2)
            {
                flag2 = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("ReadResponse() failure {0}\n{1}", new object[] { Utilities.DescribeException(exception2), Utilities.ByteArrayToHexView(this.m_responseData.ToArray(), 0x20) });
                }
                if (exception2 is OperationCanceledException)
                {
                    this.m_session.state = SessionStates.Aborted;
                    FiddlerApplication.Log.LogFormat("fiddler.network.readresponse.failure> Session #{0} was aborted {1}", new object[] { this.m_session.id, Utilities.DescribeException(exception2) });
                }
                else if (exception2 is OutOfMemoryException)
                {
                    FiddlerApplication.ReportException(exception2);
                    this.m_session.state = SessionStates.Aborted;
                    FiddlerApplication.Log.LogFormat("fiddler.network.readresponse.failure> Session #{0} Out of Memory", new object[] { this.m_session.id });
                }
                else
                {
                    FiddlerApplication.Log.LogFormat("fiddler.network.readresponse.failure> Session #{0} raised exception {1}", new object[] { this.m_session.id, Utilities.DescribeException(exception2) });
                }
            }
        Label_074C:
            if ((!flag && !flag2) && ((this.m_inHeaders == null) || !this.isResponseBodyComplete()))
            {
                goto Label_0038;
            }
            this.m_session.Timers.ServerDoneResponse = DateTime.Now;
            if (this.m_session.isFlagSet(SessionFlags.ResponseStreamed))
            {
                this.m_session.Timers.ClientDoneResponse = this.m_session.Timers.ServerDoneResponse;
            }
            arrBuffer = null;
            stopwatch = null;
            this.m_session.Timers.ServerReads = timestamps;
            FiddlerApplication.DebugSpew("Finished reading server response: {0:N0} bytes.", new object[] { this.m_responseTotalDataCount });
            if ((0L == this.m_responseTotalDataCount) && (this.m_inHeaders == null))
            {
                flag2 = true;
            }
            if (flag2)
            {
                if (this.m_bLeakedHeaders)
                {
                    FiddlerApplication.DebugSpew("*** Aborted on a Response  #{0} which had partially streamed ****", new object[] { this.m_session.id });
                }
                FiddlerApplication.DebugSpew("*** Abort on Read from Server for Session #{0} ****", new object[] { this.m_session.id });
                return false;
            }
            if (this.m_inHeaders == null)
            {
                FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, true, true, "The Server did not return properly-formatted HTTP Headers. Maybe missing altogether (e.g. HTTP/0.9), maybe only \\r\\r instead of \\r\\n\\r\\n?\n");
                this.m_session.SetBitFlag(SessionFlags.ResponseStreamed, false);
                this.m_inHeaders = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
                this.m_inHeaders.HTTPVersion = "HTTP/1.0";
                this.m_inHeaders.SetStatus(200, "This buggy server did not return headers");
                this.m_iEntityBodyOffset = 0;
                return true;
            }
            if (flag)
            {
                FiddlerApplication.DebugSpew("Got FIN reading Response to #{0}.", new object[] { this.m_session.id });
                this._PoisonPipe();
                if (this.m_inHeaders.ExistsAndEquals("Transfer-Encoding", "chunked"))
                {
                    FiddlerApplication.DebugSpew("^ Previous FIN unexpected; chunked body ended abnormally for #{0}.", new object[] { this.m_session.id });
                    FiddlerApplication.HandleHTTPError(this.m_session, SessionFlags.ProtocolViolationInResponse, true, true, "Transfer-Encoding: Chunked response did not terminate with a proper zero-size chunk.");
                }
            }
            if (flag3)
            {
                this.m_session["x-ResponseBodyTransferLength"] = this.m_responseTotalDataCount.ToString("N0");
            }
            return true;
        }

        private bool ReadResponseFromArray(byte[] arrResponse, bool bAllowBOM, string sContentTypeHint)
        {
            this.Initialize(true);
            int length = arrResponse.Length;
            int index = 0;
            bool flag = false;
            if (bAllowBOM)
            {
                flag = (((arrResponse.Length > 3) && (arrResponse[0] == 0xef)) && (arrResponse[1] == 0xbb)) && (arrResponse[2] == 0xbf);
                if (flag)
                {
                    index = 3;
                    length -= 3;
                }
            }
            bool flag2 = ((((arrResponse.Length > (5 + index)) && (arrResponse[index] == 0x48)) && ((arrResponse[index + 1] == 0x54) && (arrResponse[index + 2] == 0x54))) && (arrResponse[index + 3] == 80)) && (arrResponse[index + 4] == 0x2f);
            if (flag && !flag2)
            {
                length += 3;
                index = 0;
            }
            this.m_responseData.Capacity = length;
            this.m_responseData.Write(arrResponse, index, length);
            if ((flag2 && this.HeadersAvailable()) && this.ParseResponseForHeaders())
            {
                this.m_session.responseBodyBytes = this.TakeEntity();
            }
            else
            {
                this.Initialize(false);
                this.m_inHeaders = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
                this.m_inHeaders.SetStatus(200, "OK with automatic headers");
                this.m_inHeaders["Date"] = DateTime.UtcNow.ToString("r");
                this.m_inHeaders["Content-Length"] = arrResponse.LongLength.ToString();
                this.m_inHeaders["Cache-Control"] = "max-age=0, must-revalidate";
                if (sContentTypeHint != null)
                {
                    this.m_inHeaders["Content-Type"] = sContentTypeHint;
                }
                this.m_session.responseBodyBytes = arrResponse;
            }
            return true;
        }

        internal bool ReadResponseFromFile(string sFilename, string sOptionalContentTypeHint)
        {
            byte[] buffer;
            if (!System.IO.File.Exists(sFilename))
            {
                this._ReturnFileReadError("Fiddler - The requested file was not found.", "Fiddler - The file '" + sFilename + "' was not found.");
                return false;
            }
            try
            {
                buffer = System.IO.File.ReadAllBytes(sFilename);
            }
            catch (Exception exception)
            {
                this._ReturnFileReadError("Fiddler - The requested file could not be read.", "Fiddler - The requested file could not be read. " + Utilities.DescribeException(exception));
                return false;
            }
            return this.ReadResponseFromArray(buffer, true, sOptionalContentTypeHint);
        }

        internal bool ReadResponseFromStream(Stream oResponse, string sContentTypeHint)
        {
            MemoryStream stream = new MemoryStream();
            byte[] buffer = new byte[0x8000];
            int count = 0;
            while ((count = oResponse.Read(buffer, 0, buffer.Length)) > 0)
            {
                stream.Write(buffer, 0, count);
            }
            byte[] arrResponse = stream.ToArray();
            return this.ReadResponseFromArray(arrResponse, false, sContentTypeHint);
        }

        internal void releaseServerPipe()
        {
            if (this.pipeServer != null)
            {
                if (((this.headers.ExistsAndEquals("Connection", "close") || this.headers.ExistsAndEquals("Proxy-Connection", "close")) || ((this.headers.HTTPVersion != "HTTP/1.1") && !this.headers.ExistsAndContains("Connection", "Keep-Alive"))) || !this.pipeServer.Connected)
                {
                    this.pipeServer.ReusePolicy = PipeReusePolicy.NoReuse;
                }
                this._detachServerPipe();
            }
        }

        private void ReleaseStreamedChunkedData()
        {
            long num;
            if (this.m_iEntityBodyOffset > this.m_lngLastChunkInfoOffset)
            {
                this.m_lngLastChunkInfoOffset = this.m_iEntityBodyOffset;
            }
            Utilities.IsChunkedBodyComplete(this.m_session, this.m_responseData, this.m_lngLastChunkInfoOffset, out this.m_lngLastChunkInfoOffset, out num);
            int iDefaultCapacity = (int) (this.m_responseData.Length - this.m_lngLastChunkInfoOffset);
            PipeReadBuffer buffer = new PipeReadBuffer(iDefaultCapacity);
            buffer.Write(this.m_responseData.GetBuffer(), (int) this.m_lngLastChunkInfoOffset, iDefaultCapacity);
            this.m_responseData = buffer;
            this.m_lngLeakedOffset = iDefaultCapacity;
            this.m_lngLastChunkInfoOffset = 0L;
            this.m_iEntityBodyOffset = 0;
        }

        private void ReleaseStreamedData()
        {
            this.m_responseData = new PipeReadBuffer(false);
            this.m_lngLeakedOffset = 0L;
            if (this.m_iEntityBodyOffset > 0)
            {
                this.m_responseTotalDataCount -= this.m_iEntityBodyOffset;
                this.m_iEntityBodyOffset = 0;
            }
        }

        internal void RunConnectionStateMachine()
        {
            AsyncCallback callbackAsync = null;
            bool flag = false;
        Label_0005:
            if (this._esState == null)
            {
                Exception eX = new NullReferenceException("Fatal Error in Session #" + this.m_session.id.ToString() + ". Looping RunConnectionStateMachine, _esState null for " + this.m_session.fullUrl + "\r\nState: " + this.m_session.state.ToString());
                FiddlerApplication.ReportException(eX);
                throw eX;
            }
            switch (this._esState.CurrentState)
            {
                case StateConnecting.BeginFindGateway:
                    this._esState.sTarget = this.m_session.oFlags["x-overrideHostName"];
                    if (this._esState.sTarget != null)
                    {
                        this.m_session.oFlags["x-overrideHost"] = string.Format("{0}:{1}", this._esState.sTarget, this.m_session.port);
                    }
                    this._esState.sTarget = this.m_session.oFlags["x-overrideHost"];
                    if (this._esState.sTarget != null)
                    {
                        this._esState.sPoolKeyContext = string.Format("-for-{0}", this.m_session.host);
                        break;
                    }
                    if (this.m_session.HTTPMethodIs("CONNECT"))
                    {
                        this._esState.sTarget = this.m_session.PathAndQuery;
                    }
                    else
                    {
                        this._esState.sTarget = this.m_session.host;
                    }
                    break;

                case StateConnecting.EndFindGateway:
                    if (this._esState.ipepGateways == null)
                    {
                        if (this.m_session.isFTP)
                        {
                            this._esState.CurrentState = StateConnecting.Established;
                            goto Label_0ED0;
                        }
                    }
                    else
                    {
                        this.m_bWasForwarded = true;
                    }
                    this._esState.iServerPort = this.m_session.isHTTPS ? 0x1bb : (this.m_session.isFTP ? 0x15 : 80);
                    Utilities.CrackHostAndPort(this._esState.sTarget, out this._esState.sServerHostname, ref this._esState.iServerPort);
                    if (this._esState.ipepGateways != null)
                    {
                        if (this.m_session.isHTTPS || this._esState.bUseSOCKSGateway)
                        {
                            this._esState.sSuitableConnectionID = string.Format("{0}:{1}->{2}/{3}:{4}", new object[] { this._esState.bUseSOCKSGateway ? "socks" : "gw", this._esState.ipepGateways[0], this.m_session.isHTTPS ? "https" : "http", this._esState.sServerHostname, this._esState.iServerPort });
                        }
                        else
                        {
                            this._esState.sSuitableConnectionID = string.Format("gw:{0}->*", this._esState.ipepGateways[0]);
                        }
                    }
                    else
                    {
                        this._esState.sSuitableConnectionID = string.Format("direct->http{0}/{1}:{2}{3}", new object[] { this.m_session.isHTTPS ? "s" : string.Empty, this._esState.sServerHostname, this._esState.iServerPort, this._esState.sPoolKeyContext });
                    }
                    if (((this.pipeServer != null) && !this.m_session.oFlags.ContainsKey("X-ServerPipe-Marriage-Trumps-All")) && !SIDsMatch(this.m_session.LocalProcessID, this._esState.sSuitableConnectionID, this.pipeServer.sPoolKey))
                    {
                        FiddlerApplication.Log.LogFormat("Session #{0} detaching ServerPipe. Had: '{1}' but needs: '{2}'", new object[] { this.m_session.id, this.pipeServer.sPoolKey, this._esState.sSuitableConnectionID });
                        this.m_session.oFlags["X-Divorced-ServerPipe"] = string.Format("Had: '{0}' but needs: '{1}'", this.pipeServer.sPoolKey, this._esState.sSuitableConnectionID);
                        this._detachServerPipe();
                    }
                    if ((this.pipeServer == null) && !this.m_session.oFlags.ContainsKey("X-Bypass-ServerPipe-Reuse-Pool"))
                    {
                        this.pipeServer = Proxy.htServerPipePool.TakePipe(this._esState.sSuitableConnectionID, this.m_session.LocalProcessID, this.m_session.id);
                    }
                    if (this.pipeServer != null)
                    {
                        StringDictionary dictionary;
                        this.m_session.Timers.ServerConnected = this.pipeServer.dtConnected;
                        (dictionary = this.m_session.oFlags)["x-serversocket"] = dictionary["x-serversocket"] + "REUSE " + this.pipeServer._sPipeName;
                        if ((this.pipeServer.Address != null) && !this.pipeServer.isConnectedToGateway)
                        {
                            this.m_session.m_hostIP = this.pipeServer.Address.ToString();
                            this.m_session.oFlags["x-hostIP"] = this.m_session.m_hostIP;
                        }
                        if (CONFIG.bDebugSpew)
                        {
                            FiddlerApplication.DebugSpew("Session #{0} ({1} {2}): Reusing {3}\r\n", new object[] { this.m_session.id, this.m_session.RequestMethod, this.m_session.fullUrl, this.pipeServer.ToString() });
                        }
                        this._esState.CurrentState = StateConnecting.Established;
                    }
                    else
                    {
                        if (this.m_session.oFlags.ContainsKey("x-serversocket"))
                        {
                            StringDictionary dictionary2;
                            (dictionary2 = this.m_session.oFlags)["x-serversocket"] = dictionary2["x-serversocket"] + "*NEW*";
                        }
                        this._esState.CurrentState = (StateConnecting) ((byte) (((int) this._esState.CurrentState) + 1));
                    }
                    goto Label_0ED0;

                case StateConnecting.BeginGenerateIPEndPoint:
                    if (this._esState.ipepGateways == null)
                    {
                        if ((this._esState.iServerPort < 0) || (this._esState.iServerPort > 0xffff))
                        {
                            this.m_session.oRequest.FailSession(400, "Fiddler - Bad Request", "[Fiddler] HTTP Request specified an invalid port number.");
                            this._esState.CurrentState = StateConnecting.Failed;
                        }
                        else
                        {
                            try
                            {
                                if (callbackAsync == null)
                                {
                                    callbackAsync = delegate (IAsyncResult iar) {
                                        if (this._esState == null)
                                        {
                                            this._esState = new MakeConnectionExecutionState();
                                            this._esState.CurrentState = StateConnecting.Failed;
                                        }
                                        else
                                        {
                                            this._esState.CurrentState = StateConnecting.EndGenerateIPEndPoint;
                                        }
                                        this.RunConnectionStateMachine();
                                    };
                                }
                                if (!DNSResolver.ResolveWentAsync(this._esState, this.m_session.Timers, callbackAsync))
                                {
                                    this._esState.CurrentState = StateConnecting.EndGenerateIPEndPoint;
                                }
                                else
                                {
                                    flag = true;
                                }
                            }
                            catch (Exception exception2)
                            {
                                FiddlerApplication.oTelemetry.TrackException(exception2);
                                this._esState.lastException = exception2;
                                this._esState.CurrentState = StateConnecting.EndGenerateIPEndPoint;
                            }
                        }
                    }
                    else
                    {
                        this._esState.arrIPEPDest = this._esState.ipepGateways;
                        this._esState.CurrentState = StateConnecting.BeginConnectSocket;
                    }
                    goto Label_0ED0;

                case StateConnecting.EndGenerateIPEndPoint:
                    if (this._esState.lastException == null)
                    {
                        this._esState.CurrentState = (StateConnecting) ((byte) (((int) this._esState.CurrentState) + 1));
                    }
                    else
                    {
                        this.m_session.oRequest.FailSession(0x1f6, "Fiddler - DNS Lookup Failed", string.Format("[Fiddler] DNS Lookup for \"{0}\" failed. {1}{2}", Utilities.HtmlEncode(this._esState.sServerHostname), NetworkInterface.GetIsNetworkAvailable() ? string.Empty : "The system reports that no network connection is available. \n", Utilities.DescribeException(this._esState.lastException)));
                        this._esState.CurrentState = StateConnecting.Failed;
                    }
                    goto Label_0ED0;

                case StateConnecting.BeginConnectSocket:
                    try
                    {
                        if (this.m_session.isHTTPS && this.m_bWasForwarded)
                        {
                            ManualResetEvent oWaitForTunnel = new ManualResetEvent(false);
                            string str3 = this.m_session.oRequest["User-Agent"];
                            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.composer.HTTPSProxyBasicCreds", null);
                            if (!string.IsNullOrEmpty(stringPref))
                            {
                                stringPref = Convert.ToBase64String(Encoding.UTF8.GetBytes(stringPref));
                            }
                            HTTPRequestHeaders oRequestHeaders = new HTTPRequestHeaders();
                            oRequestHeaders.HTTPMethod = "CONNECT";
                            oRequestHeaders.RequestPath = this._esState.sServerHostname + ":" + this._esState.iServerPort.ToString();
                            oRequestHeaders["Host"] = this._esState.sServerHostname + ":" + this._esState.iServerPort.ToString();
                            if (!string.IsNullOrEmpty(str3))
                            {
                                oRequestHeaders["User-Agent"] = str3;
                            }
                            if (!string.IsNullOrEmpty(stringPref))
                            {
                                oRequestHeaders["Proxy-Authorization"] = "Basic " + stringPref;
                            }
                            Session session = new Session(oRequestHeaders, null);
                            session.SetBitFlag(SessionFlags.RequestGeneratedByFiddler, true);
                            session.oFlags["X-AutoAuth"] = this.m_session["X-AutoAuth"];
                            session.oFlags["x-CreatedTunnel"] = "Fiddler-Created-This-CONNECT-Tunnel";
                            int iFinalResultCode = 0;
                            session.OnCompleteTransaction += delegate (object s, EventArgs oEA) {
                                Session session = s as Session;
                                if (session == null)
                                {
                                    throw new InvalidDataException("Session must not be null when OnCompleteTransaction is called");
                                }
                                iFinalResultCode = session.responseCode;
                                if (200 == iFinalResultCode)
                                {
                                    ServerChatter oResponse = session.oResponse;
                                    if (oResponse != null)
                                    {
                                        ServerPipe pipeServer = oResponse.pipeServer;
                                        if (pipeServer != null)
                                        {
                                            this._esState.newSocket = pipeServer.GetRawSocket();
                                            oResponse.pipeServer = null;
                                        }
                                    }
                                }
                                oWaitForTunnel.Set();
                            };
                            ThreadPool.UnsafeQueueUserWorkItem(new WaitCallback(session.Execute), null);
                            if (!oWaitForTunnel.WaitOne(0x7530, false))
                            {
                                throw new Exception("Upstream Gateway timed out CONNECT.");
                            }
                            if (iFinalResultCode != 200)
                            {
                                throw new Exception("Upstream Gateway refused requested CONNECT. " + iFinalResultCode.ToString());
                            }
                            if (this._esState.newSocket == null)
                            {
                                throw new Exception("Upstream Gateway CONNECT failed.");
                            }
                            this.m_session.oFlags["x-CreatedTunnel"] = "Fiddler-Created-A-CONNECT-Tunnel";
                        }
                        else
                        {
                            this._esState.newSocket = CreateConnectedSocket(this._esState.arrIPEPDest, this.m_session);
                            if (this._esState.bUseSOCKSGateway)
                            {
                                this._esState.newSocket = this._SOCKSifyConnection(this._esState.sServerHostname, this._esState.iServerPort, this._esState.newSocket);
                            }
                        }
                        this.pipeServer = new ServerPipe(this._esState.newSocket, "ServerPipe#" + this.m_session.id.ToString(), this.m_bWasForwarded, this._esState.sSuitableConnectionID);
                        if (this._esState.bUseSOCKSGateway)
                        {
                            this.pipeServer.isConnectedViaSOCKS = true;
                        }
                        if (this.m_session.isHTTPS)
                        {
                            SslProtocols none = SslProtocols.None;
                            if ((this.m_session.oRequest != null) && (this.m_session.oRequest.pipeClient != null))
                            {
                                none = this.m_session.oRequest.pipeClient.SecureProtocol;
                            }
                            if (!this.pipeServer.SecureExistingConnection(this.m_session, this._esState.sServerHostname, this.m_session.oFlags["https-Client-Certificate"], none, ref this.m_session.Timers.HTTPSHandshakeTime))
                            {
                                string message = "Failed to negotiate HTTPS connection with server.";
                                if (!Utilities.IsNullOrEmpty(this.m_session.responseBodyBytes))
                                {
                                    message = message + Encoding.UTF8.GetString(this.m_session.responseBodyBytes);
                                }
                                throw new SecurityException(message);
                            }
                        }
                        this._esState.CurrentState = StateConnecting.Established;
                    }
                    catch (Exception exception3)
                    {
                        this._smHandleConnectionException(exception3);
                        this._esState.CurrentState = StateConnecting.Failed;
                    }
                    goto Label_0ED0;

                case StateConnecting.EndConnectSocket:
                    this._esState.CurrentState = (StateConnecting) ((byte) (((int) this._esState.CurrentState) + 1));
                    goto Label_0ED0;

                case StateConnecting.Established:
                    this._smNotifyCSMDone();
                    flag = true;
                    goto Label_0ED0;

                case StateConnecting.Failed:
                    this._smNotifyCSMDone();
                    flag = true;
                    goto Label_0ED0;

                default:
                {
                    Exception exception4 = new InvalidOperationException(string.Concat(new object[] { "Fatal Error in Session #", this.m_session.id.ToString(), ". In RunConnectionStateMachine, _esState is ", this._esState.CurrentState, "\n", this.m_session.fullUrl, "\r\nState: ", this.m_session.state.ToString() }));
                    FiddlerApplication.ReportException(exception4);
                    flag = true;
                    goto Label_0ED0;
                }
            }
            if (this.m_session.oFlags["x-overrideGateway"] != null)
            {
                if ("DIRECT".OICEquals(this.m_session.oFlags["x-overrideGateway"]))
                {
                    this.m_session.bypassGateway = true;
                    goto Label_040C;
                }
                string inStr = this.m_session.oFlags["x-overrideGateway"];
                if (inStr.OICStartsWith("socks="))
                {
                    this._esState.bUseSOCKSGateway = true;
                    inStr = inStr.Substring(6);
                }
                this._esState.ipepGateways = Utilities.IPEndPointListFromHostPortString(inStr);
                if (this._esState.ipepGateways != null)
                {
                    goto Label_040C;
                }
                FiddlerApplication.DebugSpew("DNS lookup failed for X-OverrideGateway: '{0}'", new object[] { inStr });
                if (this._esState.bUseSOCKSGateway)
                {
                    this.m_session.oRequest.FailSession(0x1f6, "Fiddler - SOCKS Proxy DNS Lookup Failed", string.Format("[Fiddler] DNS Lookup for SOCKS Proxy \"{0}\" failed. {1}", Utilities.HtmlEncode(inStr), NetworkInterface.GetIsNetworkAvailable() ? string.Empty : "The system reports that no network connection is available. \n"));
                    this._esState.CurrentState = StateConnecting.Failed;
                }
                else
                {
                    if (FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.IgnoreGatewayOverrideIfUnreachable", false))
                    {
                        goto Label_040C;
                    }
                    this.m_session.oRequest.FailSession(0x1f6, "Fiddler - Proxy DNS Lookup Failed", string.Format("[Fiddler] DNS Lookup for Proxy \"{0}\" failed. {1}", Utilities.HtmlEncode(inStr), NetworkInterface.GetIsNetworkAvailable() ? string.Empty : "The system reports that no network connection is available. \n"));
                    this._esState.CurrentState = StateConnecting.Failed;
                }
                goto Label_0ED0;
            }
            if (!this.m_session.bypassGateway)
            {
                int tickCount = Environment.TickCount;
                string uriScheme = this.m_session.oRequest.headers.UriScheme;
                if ((uriScheme == "http") && this.m_session.HTTPMethodIs("CONNECT"))
                {
                    uriScheme = "https";
                }
                IPEndPoint point = FiddlerApplication.oProxy.FindGatewayForOrigin(uriScheme, this._esState.sTarget);
                if (point != null)
                {
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("Using Gateway: '{0}' for request to '{1}'", new object[] { point.ToString(), this.m_session.fullUrl });
                    }
                    this._esState.ipepGateways = new IPEndPoint[] { point };
                }
                this.m_session.Timers.GatewayDeterminationTime = Environment.TickCount - tickCount;
            }
        Label_040C:
            this._esState.CurrentState = (StateConnecting) ((byte) (((int) this._esState.CurrentState) + 1));
        Label_0ED0:
            if (!flag)
            {
                goto Label_0005;
            }
        }

        internal void SendRequest()
        {
            if (!this.m_session.isFTP || this.m_session.isFlagSet(SessionFlags.SentToGateway))
            {
                if (this.pipeServer == null)
                {
                    throw new InvalidOperationException("Cannot SendRequest unless pipeServer is set!");
                }
                this.pipeServer.IncrementUse(this.m_session.id);
                this.pipeServer.setTimeouts();
                this.m_session.Timers.ServerConnected = this.pipeServer.dtConnected;
                this.m_bWasForwarded = this.pipeServer.isConnectedToGateway;
                this.m_session.SetBitFlag(SessionFlags.ServerPipeReused, this.pipeServer.iUseCount > 1);
                this.m_session.SetBitFlag(SessionFlags.SentToGateway, this.m_bWasForwarded);
                if (this.pipeServer.isConnectedViaSOCKS)
                {
                    this.m_session.SetBitFlag(SessionFlags.SentToSOCKSGateway, true);
                }
                if (!this.m_bWasForwarded && !this.m_session.isHTTPS)
                {
                    this.m_session.oRequest.headers.RenameHeaderItems("Proxy-Connection", "Connection");
                }
                if (!this.pipeServer.isAuthenticated)
                {
                    string inStr = this.m_session.oRequest.headers["Authorization"];
                    if ((inStr != null) && inStr.OICStartsWith("N"))
                    {
                        this.pipeServer.MarkAsAuthenticated(this.m_session.LocalProcessID);
                    }
                }
                if (this.m_session.oFlags.ContainsKey("request-trickle-delay"))
                {
                    int num = int.Parse(this.m_session.oFlags["request-trickle-delay"]);
                    this.pipeServer.TransmitDelay = num;
                }
                this.m_session.Timers.FiddlerBeginRequest = DateTime.Now;
                if (this.m_bWasForwarded || !this.m_session.HTTPMethodIs("CONNECT"))
                {
                    bool includeProtocolInPath = this.m_bWasForwarded && !this.m_session.isHTTPS;
                    byte[] oBytes = this.m_session.oRequest.headers.ToByteArray(true, true, includeProtocolInPath, this.m_session.oFlags["X-OverrideHost"]);
                    this.pipeServer.Send(oBytes);
                    if (!Utilities.IsNullOrEmpty(this.m_session.requestBodyBytes))
                    {
                        if (this.m_session.oFlags.ContainsKey("request-body-delay"))
                        {
                            Thread.Sleep(int.Parse(this.m_session.oFlags["request-body-delay"]));
                        }
                        this.pipeServer.Send(this.m_session.requestBodyBytes);
                    }
                }
                this.m_session.oFlags["x-EgressPort"] = this.pipeServer.LocalPort.ToString();
            }
        }

        private static bool SIDsMatch(int iPID, string sIDSession, string sIDPipe)
        {
            return (sIDSession.OICEquals(sIDPipe) || ((iPID != 0) && sIDPipe.OICEquals(string.Format("pid{0}*{1}", iPID, sIDSession))));
        }

        internal bool StreamRequestBody()
        {
            long result = 0L;
            long length = 0L;
            ChunkReader reader = null;
            if (long.TryParse(this.m_session.oRequest["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out result))
            {
                result -= this.m_session.requestBodyBytes.Length;
            }
            else if (this.m_session.oRequest.headers.ExistsAndContains("Transfer-Encoding", "chunked"))
            {
                reader = new ChunkReader();
                reader.pushBytes(this.m_session.requestBodyBytes, 0, this.m_session.requestBodyBytes.Length);
            }
            else
            {
                result = 0L;
            }
            if ((result < 1L) && (reader == null))
            {
                return true;
            }
            bool flag = !this.m_session.oFlags.ContainsKey("log-drop-request-body");
            PipeReadBuffer buffer = null;
            if (flag)
            {
                buffer = new PipeReadBuffer(true);
                buffer.Write(this.m_session.requestBodyBytes, 0, this.m_session.requestBodyBytes.Length);
            }
            else
            {
                if (!Utilities.IsNullOrEmpty(this.m_session.requestBodyBytes))
                {
                    length = this.m_session.requestBodyBytes.Length;
                }
                this.m_session.requestBodyBytes = Utilities.emptyByteArray;
                this.m_session.SetBitFlag(SessionFlags.RequestBodyDropped, true);
            }
            ClientPipe pipeClient = this.m_session.oRequest.pipeClient;
            if (pipeClient == null)
            {
                return false;
            }
            bool flag2 = false;
            bool flag3 = false;
            byte[] arrBuffer = new byte[ClientChatter.s_cbClientReadBuffer];
            int bytesRead = 0;
            SessionTimers.NetTimestamps timestamps = SessionTimers.NetTimestamps.FromCopy(this.m_session.Timers.ClientReads);
            Stopwatch stopwatch = Stopwatch.StartNew();
        Label_016B:
            try
            {
                bytesRead = pipeClient.Receive(arrBuffer);
                timestamps.AddRead(stopwatch.ElapsedMilliseconds, bytesRead);
            }
            catch (SocketException exception)
            {
                flag2 = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("STREAMReadRequest {0} threw #{1} - {2}", new object[] { pipeClient.ToString(), exception.ErrorCode, exception.Message });
                }
                if (exception.SocketErrorCode != SocketError.TimedOut)
                {
                    goto Label_055D;
                }
                this.m_session.oFlags["X-ClientPipeError"] = string.Format("STREAMReadRequest timed out; total of ?{0}? bytes read from client.", buffer.Length);
                this.m_session.oRequest.FailSession(0x198, "Request Timed Out", "The client failed to send a complete request before the timeout period elapsed.");
                return false;
            }
            catch (Exception exception2)
            {
                flag2 = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("STREAMReadRequest {0} threw {1}", new object[] { pipeClient.ToString(), exception2.Message });
                }
                goto Label_055D;
            }
            if (bytesRead < 1)
            {
                flag3 = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("STREAMReadRequest {0} returned {1}", new object[] { pipeClient.ToString(), bytesRead });
                }
            }
            else
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("STREAMREAD FROM {0}:\n{1}", new object[] { pipeClient, Utilities.ByteArrayToHexView(arrBuffer, 0x20, bytesRead) });
                }
                if (reader != null)
                {
                    reader.pushBytes(arrBuffer, 0, bytesRead);
                }
                if (reader != null)
                {
                    if (reader.state == ChunkedTransferState.Overread)
                    {
                        byte[] dst = new byte[reader.getOverage()];
                        FiddlerApplication.Log.LogFormat("HTTP Pipelining Client detected; {0:N0} bytes of excess data on client socket for Session #{1}.", new object[] { dst.Length, this.m_session.id });
                        Buffer.BlockCopy(arrBuffer, bytesRead - dst.Length, dst, 0, dst.Length);
                        bytesRead -= dst.Length;
                    }
                }
                else if (bytesRead > result)
                {
                    byte[] buffer4 = new byte[bytesRead - result];
                    FiddlerApplication.Log.LogFormat("HTTP Pipelining Client detected; {0:N0} bytes of excess data on client socket for Session #{1}.", new object[] { buffer4.Length, this.m_session.id });
                    Buffer.BlockCopy(arrBuffer, (int) result, buffer4, 0, buffer4.Length);
                    bytesRead = (int) result;
                }
                if (flag)
                {
                    buffer.Write(arrBuffer, 0, bytesRead);
                }
                if (this.pipeServer != null)
                {
                    try
                    {
                        this.pipeServer.Send(arrBuffer, 0, bytesRead);
                    }
                    catch (SocketException exception3)
                    {
                        flag2 = true;
                        FiddlerApplication.Log.LogFormat("STREAMSendRequest {0} threw #{1} - {2}", new object[] { this.pipeServer.ToString(), exception3.ErrorCode, exception3.Message });
                        if (CONFIG.bDebugSpew)
                        {
                            FiddlerApplication.DebugSpew("STREAMSendRequest {0} threw #{1} - {2}", new object[] { this.pipeServer.ToString(), exception3.ErrorCode, exception3.Message });
                        }
                        goto Label_055D;
                    }
                    catch (Exception exception4)
                    {
                        flag2 = true;
                        FiddlerApplication.Log.LogFormat("STREAMSendRequest {0} threw {1}", new object[] { this.pipeServer.ToString(), exception4.Message });
                        if (CONFIG.bDebugSpew)
                        {
                            FiddlerApplication.DebugSpew("STREAMSendRequest {0} threw {1}", new object[] { this.pipeServer.ToString(), exception4.Message });
                        }
                        goto Label_055D;
                    }
                }
                length += bytesRead;
                if (reader == null)
                {
                    result -= bytesRead;
                    FiddlerApplication.DebugSpew("Streaming Session #{0} to server. Wrote {1} bytes, {2} remain...", new object[] { this.m_session.id, bytesRead, result });
                    flag3 = result < 1L;
                }
                else
                {
                    flag3 = reader.state >= ChunkedTransferState.Completed;
                }
            }
        Label_055D:
            if (!flag3 && !flag2)
            {
                goto Label_016B;
            }
            arrBuffer = null;
            stopwatch = null;
            this.m_session.Timers.ClientReads = timestamps;
            this.m_session.Timers.ClientDoneRequest = DateTime.Now;
            if (reader != null)
            {
                this.m_session["X-UnchunkedBodySize"] = reader.getEntityLength().ToString();
                if (reader.state == ChunkedTransferState.Malformed)
                {
                    flag2 = true;
                }
            }
            if (flag2)
            {
                FiddlerApplication.DebugSpew("Reading from client or writing to server set bAbort");
                return false;
            }
            if (flag)
            {
                this.m_session.requestBodyBytes = buffer.ToArray();
            }
            else
            {
                this.m_session.oFlags["x-RequestBodyLength"] = length.ToString("N0");
            }
            return true;
        }

        internal byte[] TakeEntity()
        {
            byte[] bytes;
            long num = this.m_responseData.Length - this.m_iEntityBodyOffset;
            if (num < 1L)
            {
                this.FreeResponseDataBuffer();
                return Utilities.emptyByteArray;
            }
            try
            {
                bytes = new byte[num];
                Buffer.BlockCopy(this.m_responseData.GetBuffer(), this.m_iEntityBodyOffset, bytes, 0, bytes.Length);
            }
            catch (OutOfMemoryException exception)
            {
                FiddlerApplication.ReportException(exception, "HTTP Response Too Large");
                bytes = Encoding.ASCII.GetBytes("Fiddler: Out-of-memory/contiguous-address-space");
                this.m_session.PoisonServerPipe();
            }
            this.FreeResponseDataBuffer();
            return bytes;
        }

        internal long _PeekDownloadProgress
        {
            get
            {
                if (this.m_responseData != null)
                {
                    return this.m_responseTotalDataCount;
                }
                return -1L;
            }
        }

        internal bool bLeakedHeaders
        {
            get
            {
                return this.m_bLeakedHeaders;
            }
        }

        public bool bServerSocketReused
        {
            get
            {
                return this.m_session.isFlagSet(SessionFlags.ServerPipeReused);
            }
        }

        public bool bWasForwarded
        {
            get
            {
                return this.m_bWasForwarded;
            }
        }

        public HTTPResponseHeaders headers
        {
            get
            {
                return this.m_inHeaders;
            }
            set
            {
                if (value != null)
                {
                    this.m_inHeaders = value;
                }
            }
        }

        public string this[string sHeader]
        {
            get
            {
                if (this.m_inHeaders != null)
                {
                    return this.m_inHeaders[sHeader];
                }
                return string.Empty;
            }
            set
            {
                if (this.m_inHeaders == null)
                {
                    throw new InvalidDataException("Response Headers object does not exist");
                }
                this.m_inHeaders[sHeader] = value;
            }
        }

        public int iTTFB
        {
            get
            {
                TimeSpan span = (TimeSpan) (this.m_session.Timers.ServerBeginResponse - this.m_session.Timers.FiddlerBeginRequest);
                int totalMilliseconds = (int) span.TotalMilliseconds;
                if (totalMilliseconds <= 0)
                {
                    return 0;
                }
                return totalMilliseconds;
            }
        }

        public int iTTLB
        {
            get
            {
                TimeSpan span = (TimeSpan) (this.m_session.Timers.ServerDoneResponse - this.m_session.Timers.FiddlerBeginRequest);
                int totalMilliseconds = (int) span.TotalMilliseconds;
                if (totalMilliseconds <= 0)
                {
                    return 0;
                }
                return totalMilliseconds;
            }
        }

        public string MIMEType
        {
            get
            {
                if (this.headers == null)
                {
                    return string.Empty;
                }
                string sString = this.headers["Content-Type"];
                if (sString.Length > 0)
                {
                    sString = Utilities.TrimAfter(sString, ';').Trim();
                }
                return sString;
            }
        }

        internal class MakeConnectionExecutionState
        {
            internal IPEndPoint[] arrIPEPDest;
            internal bool bUseSOCKSGateway;
            internal ServerChatter.StateConnecting CurrentState;
            internal IPEndPoint[] ipepGateways;
            internal int iServerPort = -1;
            internal Exception lastException;
            internal Socket newSocket;
            internal AsyncCallback OnDone;
            internal string sPoolKeyContext;
            internal string sServerHostname;
            internal string sSuitableConnectionID;
            internal string sTarget;
        }

        internal enum StateConnecting : byte
        {
            BeginConnectSocket = 4,
            BeginFindGateway = 0,
            BeginGenerateIPEndPoint = 2,
            EndConnectSocket = 5,
            EndFindGateway = 1,
            EndGenerateIPEndPoint = 3,
            Established = 6,
            Failed = 7
        }
    }
}

