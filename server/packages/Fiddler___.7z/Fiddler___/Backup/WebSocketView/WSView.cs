﻿namespace WebSocketView
{
    using Fiddler;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class WSView : UserControl
    {
        internal Button btnGenFauxResponse;
        internal Button btnUnfragment;
        private ColumnHeader colMsgId;
        private ColumnHeader colPayloadSize;
        private ColumnHeader colPreview;
        private ColumnHeader colType;
        private IContainer components;
        private ImageList imglWSM;
        internal Label lblSessionID;
        internal DoubleBufferedListView lvMessages;
        private Panel pnlWSActions;
        private SplitContainer splitOuter;
        internal string strInspecting = string.Empty;
        internal TabControl tabsWSMInspectors;
        private TabPage tabWSMInfo;
        internal RichTextBox txtMetadata;
        internal WebSocketMessage wsmInspecting;

        public WSView()
        {
            this.InitializeComponent();
            if (CONFIG.flFontSize != this.txtMetadata.Font.Size)
            {
                this.txtMetadata.Font = new Font(this.txtMetadata.Font.FontFamily, CONFIG.flFontSize);
                this.lvMessages.Font = new Font(this.lvMessages.Font.FontFamily, CONFIG.flFontSize);
            }
            this.txtMetadata.BackColor = CONFIG.colorDisabledEdit;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(WSView));
            this.lblSessionID = new Label();
            this.splitOuter = new SplitContainer();
            this.lvMessages = new DoubleBufferedListView();
            this.colMsgId = new ColumnHeader();
            this.colType = new ColumnHeader();
            this.colPayloadSize = new ColumnHeader();
            this.colPreview = new ColumnHeader();
            this.imglWSM = new ImageList(this.components);
            this.tabsWSMInspectors = new TabControl();
            this.tabWSMInfo = new TabPage();
            this.txtMetadata = new RichTextBox();
            this.pnlWSActions = new Panel();
            this.btnUnfragment = new Button();
            this.btnGenFauxResponse = new Button();
            this.splitOuter.Panel1.SuspendLayout();
            this.splitOuter.Panel2.SuspendLayout();
            this.splitOuter.SuspendLayout();
            this.tabsWSMInspectors.SuspendLayout();
            this.tabWSMInfo.SuspendLayout();
            this.pnlWSActions.SuspendLayout();
            base.SuspendLayout();
            this.lblSessionID.AutoSize = true;
            this.lblSessionID.Dock = DockStyle.Top;
            this.lblSessionID.Location = new Point(0, 0);
            this.lblSessionID.Margin = new Padding(1, 0, 1, 0);
            this.lblSessionID.Name = "lblSessionID";
            this.lblSessionID.Padding = new Padding(3);
            this.lblSessionID.Size = new Size(0x6d, 0x13);
            this.lblSessionID.TabIndex = 0;
            this.lblSessionID.Text = "No Session Selected";
            this.lblSessionID.TextAlign = ContentAlignment.MiddleLeft;
            this.splitOuter.Dock = DockStyle.Fill;
            this.splitOuter.Location = new Point(0, 0);
            this.splitOuter.Name = "splitOuter";
            this.splitOuter.Orientation = Orientation.Horizontal;
            this.splitOuter.Panel1.Controls.Add(this.lvMessages);
            this.splitOuter.Panel1.Controls.Add(this.lblSessionID);
            this.splitOuter.Panel2.Controls.Add(this.tabsWSMInspectors);
            this.splitOuter.Panel2.Controls.Add(this.pnlWSActions);
            this.splitOuter.Size = new Size(0x27e, 0x1af);
            this.splitOuter.SplitterDistance = 0xd7;
            this.splitOuter.TabIndex = 2;
            this.lvMessages.BorderStyle = BorderStyle.None;
            this.lvMessages.Columns.AddRange(new ColumnHeader[] { this.colMsgId, this.colType, this.colPayloadSize, this.colPreview });
            this.lvMessages.Dock = DockStyle.Fill;
            this.lvMessages.EmptyText = null;
            this.lvMessages.FullRowSelect = true;
            this.lvMessages.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            this.lvMessages.HideSelection = false;
            this.lvMessages.Location = new Point(0, 0x13);
            this.lvMessages.Name = "lvMessages";
            this.lvMessages.Size = new Size(0x27e, 0xc4);
            this.lvMessages.SmallImageList = this.imglWSM;
            this.lvMessages.TabIndex = 1;
            this.lvMessages.UseCompatibleStateImageBehavior = false;
            this.lvMessages.View = View.Details;
            this.colMsgId.Text = "ID";
            this.colMsgId.Width = 40;
            this.colType.Text = "Type";
            this.colPayloadSize.Text = "Body";
            this.colPreview.Text = "Preview";
            this.colPreview.Width = 150;
            this.imglWSM.ImageStream = (ImageListStreamer) manager.GetObject("imglWSM.ImageStream");
            this.imglWSM.TransparentColor = Color.Magenta;
            this.imglWSM.Images.SetKeyName(0, "16x16_ws_Up.bmp");
            this.imglWSM.Images.SetKeyName(1, "16x16_ws_UpP.bmp");
            this.imglWSM.Images.SetKeyName(2, "16x16_ws_Down.bmp");
            this.imglWSM.Images.SetKeyName(3, "16x16_ws_DownP.bmp");
            this.imglWSM.Images.SetKeyName(4, "16x16_ws_UpC.bmp");
            this.imglWSM.Images.SetKeyName(5, "16x16_ws_DownC.bmp");
            this.tabsWSMInspectors.Controls.Add(this.tabWSMInfo);
            this.tabsWSMInspectors.Dock = DockStyle.Fill;
            this.tabsWSMInspectors.Location = new Point(0, 0x1a);
            this.tabsWSMInspectors.Name = "tabsWSMInspectors";
            this.tabsWSMInspectors.SelectedIndex = 0;
            this.tabsWSMInspectors.Size = new Size(0x27e, 0xba);
            this.tabsWSMInspectors.TabIndex = 0;
            this.tabWSMInfo.Controls.Add(this.txtMetadata);
            this.tabWSMInfo.Location = new Point(4, 0x16);
            this.tabWSMInfo.Name = "tabWSMInfo";
            this.tabWSMInfo.Padding = new Padding(3);
            this.tabWSMInfo.Size = new Size(630, 160);
            this.tabWSMInfo.TabIndex = 2;
            this.tabWSMInfo.Text = "Metadata";
            this.tabWSMInfo.UseVisualStyleBackColor = true;
            this.txtMetadata.BorderStyle = BorderStyle.None;
            this.txtMetadata.Dock = DockStyle.Fill;
            this.txtMetadata.Location = new Point(3, 3);
            this.txtMetadata.Name = "txtMetadata";
            this.txtMetadata.ReadOnly = true;
            this.txtMetadata.Size = new Size(0x270, 0x9a);
            this.txtMetadata.TabIndex = 0;
            this.txtMetadata.Text = "";
            this.pnlWSActions.Controls.Add(this.btnUnfragment);
            this.pnlWSActions.Controls.Add(this.btnGenFauxResponse);
            this.pnlWSActions.Dock = DockStyle.Top;
            this.pnlWSActions.Location = new Point(0, 0);
            this.pnlWSActions.Name = "pnlWSActions";
            this.pnlWSActions.Size = new Size(0x27e, 0x1a);
            this.pnlWSActions.TabIndex = 1;
            this.btnUnfragment.Location = new Point(0x9b, 0);
            this.btnUnfragment.Name = "btnUnfragment";
            this.btnUnfragment.Size = new Size(100, 0x17);
            this.btnUnfragment.TabIndex = 1;
            this.btnUnfragment.Text = "Unfragment All";
            this.btnUnfragment.UseVisualStyleBackColor = true;
            this.btnGenFauxResponse.Image = (Image) manager.GetObject("btnGenFauxResponse.Image");
            this.btnGenFauxResponse.Location = new Point(3, 0);
            this.btnGenFauxResponse.Name = "btnGenFauxResponse";
            this.btnGenFauxResponse.Size = new Size(0x92, 0x17);
            this.btnGenFauxResponse.TabIndex = 0;
            this.btnGenFauxResponse.Text = "Inspect as Response";
            this.btnGenFauxResponse.TextImageRelation = TextImageRelation.ImageBeforeText;
            this.btnGenFauxResponse.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.Controls.Add(this.splitOuter);
            this.Font = new Font("Tahoma", 8.25f);
            base.Name = "WSView";
            base.Size = new Size(0x27e, 0x1af);
            this.splitOuter.Panel1.ResumeLayout(false);
            this.splitOuter.Panel1.PerformLayout();
            this.splitOuter.Panel2.ResumeLayout(false);
            this.splitOuter.ResumeLayout(false);
            this.tabsWSMInspectors.ResumeLayout(false);
            this.tabWSMInfo.ResumeLayout(false);
            this.pnlWSActions.ResumeLayout(false);
            base.ResumeLayout(false);
        }
    }
}

