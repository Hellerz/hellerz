﻿namespace Fiddler
{
    using System;

    [Flags]
    public enum WSMFlags
    {
        Aborted = 1,
        Assembled = 4,
        Breakpointed = 8,
        GeneratedByFiddler = 2,
        None = 0
    }
}

