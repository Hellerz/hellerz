﻿namespace Fiddler
{
    using System;
    using System.Text;

    internal class HistoryItem
    {
        private string _Hash;
        private Fiddler.Session _sess;

        public HistoryItem(Fiddler.Session oS)
        {
            this.Session = oS;
        }

        public string Hash
        {
            get
            {
                if (this._Hash == null)
                {
                    if (this._sess == null)
                    {
                        return "MissingSession";
                    }
                    if (Utilities.HasHeaders(this._sess.oRequest))
                    {
                        this._Hash = Utilities.GetSHA1Hash(this._sess.oRequest.headers.ToByteArray(true, false, true));
                    }
                    else
                    {
                        this._Hash = "MissingHeaders";
                    }
                    if (!Utilities.IsNullOrEmpty(this._sess.requestBodyBytes))
                    {
                        this._Hash = this._Hash + Utilities.GetSHA1Hash(this._sess.requestBodyBytes);
                    }
                    string strComment = this._sess["ui-comments"];
                    if (Utilities.IsCommentUserSupplied(strComment))
                    {
                        this._Hash = this._Hash + Utilities.GetSHA1Hash(Encoding.UTF8.GetBytes(this._sess["ui-comments"]));
                    }
                }
                return this._Hash;
            }
        }

        public Fiddler.Session Session
        {
            get
            {
                return this._sess;
            }
            private set
            {
                this._sess = value;
                this._Hash = null;
            }
        }
    }
}

