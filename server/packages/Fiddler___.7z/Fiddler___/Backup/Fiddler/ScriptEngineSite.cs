﻿namespace Fiddler
{
    using Microsoft.JScript.Vsa;
    using System;
    using System.Runtime.InteropServices;

    internal class ScriptEngineSite : IJSVsaSite
    {
        private FiddlerScript _myOwner;

        public ScriptEngineSite(FiddlerScript myOwner)
        {
            this._myOwner = myOwner;
        }

        void IJSVsaSite.GetCompiledState(out byte[] pe, out byte[] debugInfo)
        {
            pe = (byte[]) (debugInfo = null);
        }

        object IJSVsaSite.GetEventSourceInstance(string itemName, string eventSourceName)
        {
            throw new JSVsaException(JSVsaError.EventSourceInvalid);
        }

        object IJSVsaSite.GetGlobalInstance(string name)
        {
            switch (name)
            {
                case "FiddlerObject":
                case "FiddlerScript":
                    return this._myOwner;

                case "UI":
                    return FiddlerApplication.UI;
            }
            return null;
        }

        void IJSVsaSite.Notify(string sNotify, object oInfo)
        {
        }

        bool IJSVsaSite.OnCompilerError(IJSVsaError e)
        {
            this._myOwner.NotifyOfCompilerError(e);
            return false;
        }
    }
}

