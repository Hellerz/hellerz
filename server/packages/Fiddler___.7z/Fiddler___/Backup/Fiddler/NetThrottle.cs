﻿namespace Fiddler
{
    using System;

    internal class NetThrottle
    {
    }
}

