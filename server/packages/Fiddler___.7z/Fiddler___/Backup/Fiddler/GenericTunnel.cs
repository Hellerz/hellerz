﻿namespace Fiddler
{
    using System;
    using System.Net.Sockets;
    using System.Threading;

    internal class GenericTunnel : ITunnel
    {
        private long _lngEgressByteCount;
        private long _lngIngressByteCount;
        private Session _mySession;
        private byte[] arrRequestBytes;
        private byte[] arrResponseBytes;
        private bool bIsOpen = true;
        private bool bResponseStreamStarted;
        private AutoResetEvent oKeepTunnelAlive;
        private ClientPipe pipeToClient;
        private ServerPipe pipeToRemote;

        private GenericTunnel(Session oSess, ClientPipe oFrom, ServerPipe oTo, bool bStreamResponse)
        {
            this._mySession = oSess;
            this.pipeToClient = oFrom;
            this.pipeToRemote = oTo;
            this.bResponseStreamStarted = bStreamResponse;
            this._mySession.SetBitFlag(SessionFlags.IsBlindTunnel, true);
            FiddlerApplication.DebugSpew("[GenericTunnel] For session #" + this._mySession.id.ToString() + " created...");
        }

        internal void BeginResponseStreaming()
        {
            FiddlerApplication.DebugSpew(">>> Begin response streaming in GenericTunnel for Session #" + this._mySession.id);
            this.bResponseStreamStarted = true;
            this._mySession.oResponse.pipeServer = null;
            this._mySession.oRequest.pipeClient = null;
            this.pipeToRemote.BeginReceive(this.arrResponseBytes, 0, this.arrResponseBytes.Length, SocketFlags.None, new AsyncCallback(this.OnRemoteReceive), null);
        }

        public void CloseTunnel()
        {
            FiddlerApplication.DebugSpew("Close Generic Tunnel for Session #" + ((this._mySession != null) ? this._mySession.id.ToString() : "<unassigned>"));
            try
            {
                if (this.pipeToClient != null)
                {
                    this.pipeToClient.End();
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.DebugSpew("Error closing gatewayFrom tunnel. " + exception.Message + "\n" + exception.StackTrace);
            }
            try
            {
                if (this.pipeToRemote != null)
                {
                    this.pipeToRemote.End();
                }
            }
            catch (Exception exception2)
            {
                FiddlerApplication.DebugSpew("Error closing gatewayTo tunnel. " + exception2.Message + "\n" + exception2.StackTrace);
            }
            try
            {
                if (this.oKeepTunnelAlive != null)
                {
                    this.oKeepTunnelAlive.Set();
                }
            }
            catch (Exception exception3)
            {
                FiddlerApplication.DebugSpew("Error closing oKeepTunnelAlive. " + exception3.Message + "\n" + exception3.StackTrace);
            }
        }

        internal static void CreateTunnel(Session oSession, bool bStreamResponse)
        {
            if (((oSession != null) && (oSession.oRequest != null)) && (((oSession.oRequest.headers != null) && (oSession.oRequest.pipeClient != null)) && (oSession.oResponse != null)))
            {
                ClientPipe pipeClient = oSession.oRequest.pipeClient;
                if (pipeClient != null)
                {
                    if (bStreamResponse)
                    {
                        oSession.oRequest.pipeClient = null;
                    }
                    ServerPipe pipeServer = oSession.oResponse.pipeServer;
                    if (pipeServer != null)
                    {
                        if (bStreamResponse)
                        {
                            oSession.oResponse.pipeServer = null;
                        }
                        GenericTunnel tunnel = new GenericTunnel(oSession, pipeClient, pipeServer, bStreamResponse);
                        oSession.__oTunnel = tunnel;
                        Thread thread = new Thread(new ThreadStart(tunnel.RunTunnel));
                        thread.IsBackground = true;
                        thread.Start();
                    }
                }
            }
        }

        private void DoTunnel()
        {
            if (FiddlerApplication.oProxy != null)
            {
                this.arrRequestBytes = new byte[0x4000];
                this.arrResponseBytes = new byte[0x4000];
                this.bIsOpen = true;
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew(string.Format("Generic Tunnel for Session #{0}, Response State: {1}, created between\n\t{2}\nand\n\t{3}", new object[] { this._mySession.id, this.bResponseStreamStarted ? "Streaming" : "Blocked", this.pipeToClient, this.pipeToRemote }));
                }
                try
                {
                    this.pipeToClient.BeginReceive(this.arrRequestBytes, 0, this.arrRequestBytes.Length, SocketFlags.None, new AsyncCallback(this.OnClientReceive), null);
                    if (this.bResponseStreamStarted)
                    {
                        this.pipeToRemote.BeginReceive(this.arrResponseBytes, 0, this.arrResponseBytes.Length, SocketFlags.None, new AsyncCallback(this.OnRemoteReceive), null);
                    }
                    this.WaitForCompletion();
                }
                catch (Exception)
                {
                }
                this.CloseTunnel();
            }
        }

        protected void OnClientReceive(IAsyncResult ar)
        {
            try
            {
                int iMaxByteCount = this.pipeToClient.EndReceive(ar);
                if (iMaxByteCount > 0)
                {
                    this._lngEgressByteCount += iMaxByteCount;
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("[GenericTunnel] Received from client: " + iMaxByteCount.ToString() + " bytes. Sending to server...");
                        FiddlerApplication.DebugSpew(Utilities.ByteArrayToHexView(this.arrRequestBytes, 0x10, iMaxByteCount));
                    }
                    this.pipeToRemote.Send(this.arrRequestBytes, 0, iMaxByteCount);
                    this.pipeToClient.BeginReceive(this.arrRequestBytes, 0, this.arrRequestBytes.Length, SocketFlags.None, new AsyncCallback(this.OnClientReceive), null);
                }
                else
                {
                    this.CloseTunnel();
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.DebugSpew("[GenericTunnel] OnClientReceive threw... " + exception.Message);
                this.CloseTunnel();
            }
        }

        protected void OnClientSent(IAsyncResult ar)
        {
            try
            {
                FiddlerApplication.DebugSpew("OnClientSent...");
                this.pipeToClient.EndSend(ar);
            }
            catch (Exception exception)
            {
                FiddlerApplication.DebugSpew("[GenericTunnel] OnClientSent failed... " + exception.Message);
                this.CloseTunnel();
            }
        }

        protected void OnRemoteReceive(IAsyncResult ar)
        {
            try
            {
                int iMaxByteCount = this.pipeToRemote.EndReceive(ar);
                if (iMaxByteCount > 0)
                {
                    this._lngIngressByteCount += iMaxByteCount;
                    if (CONFIG.bDebugSpew)
                    {
                        FiddlerApplication.DebugSpew("[GenericTunnel] Received from server: " + iMaxByteCount.ToString() + " bytes. Sending to client...");
                        FiddlerApplication.DebugSpew(Utilities.ByteArrayToHexView(this.arrResponseBytes, 0x10, iMaxByteCount));
                    }
                    this.pipeToClient.Send(this.arrResponseBytes, 0, iMaxByteCount);
                    this.pipeToRemote.BeginReceive(this.arrResponseBytes, 0, this.arrResponseBytes.Length, SocketFlags.None, new AsyncCallback(this.OnRemoteReceive), null);
                }
                else
                {
                    FiddlerApplication.DebugSpew("[GenericTunnel] ReadFromRemote failed, ret=" + iMaxByteCount.ToString());
                    this.CloseTunnel();
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.DebugSpew("[GenericTunnel] OnRemoteReceive failed... " + exception.Message);
                this.CloseTunnel();
            }
        }

        protected void OnRemoteSent(IAsyncResult ar)
        {
            try
            {
                FiddlerApplication.DebugSpew("OnRemoteSent...");
                this.pipeToRemote.EndSend(ar);
            }
            catch (Exception exception)
            {
                FiddlerApplication.DebugSpew("[GenericTunnel] OnRemoteSent failed... " + exception.Message);
                this.CloseTunnel();
            }
        }

        private void RunTunnel()
        {
            if (FiddlerApplication.oProxy != null)
            {
                try
                {
                    this.DoTunnel();
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception, "Uncaught Exception in Tunnel; Session #" + this._mySession.id.ToString());
                }
            }
        }

        private void WaitForCompletion()
        {
            AutoResetEvent oKeepTunnelAlive = this.oKeepTunnelAlive;
            this.oKeepTunnelAlive = new AutoResetEvent(false);
            FiddlerApplication.DebugSpew("[GenericTunnel] Blocking thread...");
            this.oKeepTunnelAlive.WaitOne();
            FiddlerApplication.DebugSpew("[GenericTunnel] Unblocking thread...");
            this.oKeepTunnelAlive.Close();
            this.oKeepTunnelAlive = null;
            this.bIsOpen = false;
            this.arrRequestBytes = (byte[]) (this.arrResponseBytes = null);
            this.pipeToClient = null;
            this.pipeToRemote = null;
            FiddlerApplication.DebugSpew("[GenericTunnel] Thread for session #" + this._mySession.id.ToString() + " has died...");
            if ((this._mySession.oResponse != null) && (this._mySession.oResponse.headers != null))
            {
                this._mySession.oResponse.headers["EndTime"] = DateTime.Now.ToString("HH:mm:ss.fff");
                this._mySession.oResponse.headers["ClientToServerBytes"] = this._lngEgressByteCount.ToString();
                this._mySession.oResponse.headers["ServerToClientBytes"] = this._lngIngressByteCount.ToString();
            }
            this._mySession.Timers.ServerDoneResponse = this._mySession.Timers.ClientBeginResponse = this._mySession.Timers.ClientDoneResponse = DateTime.Now;
            this._mySession.state = SessionStates.Done;
            this._mySession = null;
        }

        public long EgressByteCount
        {
            get
            {
                return this._lngEgressByteCount;
            }
        }

        public long IngressByteCount
        {
            get
            {
                return this._lngIngressByteCount;
            }
        }

        public bool IsOpen
        {
            get
            {
                return this.bIsOpen;
            }
        }
    }
}

