﻿namespace Fiddler.WebFormats
{
    using Fiddler;
    using System;
    using System.Collections;
    using System.Diagnostics;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Text;

    public class BSON
    {
        private static DateTime _dtEpoch = new DateTime(0x7b2, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);

        public static object BsonDecode(byte[] arrBSON, out BSONParseErrors oErrors)
        {
            BSONParseErrors errors = new BSONParseErrors();
            errors.iErrorIndex = -1;
            errors.sWarningText = string.Empty;
            oErrors = errors;
            if (!LooksLikeBSON(arrBSON))
            {
                oErrors.sWarningText = "BSON Document was not well formed.";
                return null;
            }
            int num = ((arrBSON[0] + (arrBSON[1] << 8)) + (arrBSON[2] << 0x10)) + (arrBSON[3] << 0x18);
            BinaryReader oBR = new BinaryReader(new MemoryStream(arrBSON, 0, arrBSON.Length, false, true));
            if (arrBSON.Length == num)
            {
                return ReadDocument(oBR);
            }
            object obj2 = new ArrayList();
            while (oBR.BaseStream.Position < arrBSON.Length)
            {
                (obj2 as ArrayList).Add(ReadDocument(oBR));
            }
            return obj2;
        }

        private static string GetBSONCString(BinaryReader oBR)
        {
            int count = 0;
            byte[] buffer = (oBR.BaseStream as MemoryStream).GetBuffer();
            for (long i = oBR.BaseStream.Position; i < oBR.BaseStream.Length; i += 1L)
            {
                if (buffer[(int) ((IntPtr) i)] == 0)
                {
                    break;
                }
                count++;
            }
            byte[] bytes = oBR.ReadBytes(count);
            oBR.ReadByte();
            return Encoding.UTF8.GetString(bytes);
        }

        private static string GetBSONString(BinaryReader oBR)
        {
            int num = oBR.ReadInt32();
            byte[] bytes = oBR.ReadBytes(num - 1);
            oBR.ReadByte();
            return Encoding.UTF8.GetString(bytes);
        }

        public static bool LooksLikeBSON(byte[] arrData)
        {
            if (arrData.Length < 5)
            {
                return false;
            }
            if (arrData[arrData.Length - 1] != 0)
            {
                return false;
            }
            int num = ((arrData[0] + (arrData[1] << 8)) + (arrData[2] << 0x10)) + (arrData[3] << 0x18);
            if (arrData.Length == num)
            {
                return true;
            }
            if (num < 5)
            {
                return false;
            }
            if (num > arrData.Length)
            {
                return false;
            }
            return (arrData[num - 1] == 0);
        }

        private static object ReadDocument(BinaryReader oBR)
        {
            oBR.ReadInt32();
            Hashtable hashtable = new Hashtable();
            for (BSONTokens tokens = (BSONTokens) oBR.ReadByte(); tokens != BSONTokens.tokEOF; tokens = (BSONTokens) oBR.ReadByte())
            {
                string bSONCString = GetBSONCString(oBR);
                switch (tokens)
                {
                    case BSONTokens.tokDouble:
                        hashtable.Add(bSONCString, oBR.ReadDouble());
                        break;

                    case BSONTokens.tokString:
                        hashtable.Add(bSONCString, GetBSONString(oBR));
                        break;

                    case BSONTokens.tokDoc:
                        hashtable.Add(bSONCString, ReadDocument(oBR));
                        break;

                    case BSONTokens.tokArray:
                        hashtable.Add(bSONCString, ReadDocument(oBR));
                        break;

                    case BSONTokens.tokBinary:
                    {
                        int count = oBR.ReadInt32();
                        oBR.ReadByte();
                        hashtable.Add(bSONCString, oBR.ReadBytes(count));
                        break;
                    }
                    case BSONTokens.tokUndefined:
                        hashtable.Add(bSONCString, "UNDEFINEDTOKEN");
                        break;

                    case BSONTokens.tokObjectID:
                    {
                        byte[] inArr = oBR.ReadBytes(12);
                        hashtable.Add(bSONCString, Utilities.ByteArrayToString(inArr));
                        break;
                    }
                    case BSONTokens.tokBool:
                    {
                        byte num2 = oBR.ReadByte();
                        hashtable.Add(bSONCString, num2 == 1);
                        break;
                    }
                    case BSONTokens.tokUTCDateTime:
                    {
                        long num3 = oBR.ReadInt64();
                        hashtable.Add(bSONCString, _dtEpoch.AddMilliseconds((double) num3).ToLocalTime());
                        break;
                    }
                    case BSONTokens.tokNull:
                        hashtable = null;
                        break;

                    case BSONTokens.tokRegex:
                        hashtable.Add(bSONCString, "REGEX " + GetBSONString(oBR) + "/" + GetBSONString(oBR));
                        break;

                    case BSONTokens.tokDBPointer:
                    {
                        GetBSONString(oBR);
                        byte[] buffer2 = oBR.ReadBytes(12);
                        hashtable.Add(bSONCString, Utilities.ByteArrayToString(buffer2));
                        break;
                    }
                    case BSONTokens.tokJS:
                    {
                        string bSONString = GetBSONString(oBR);
                        hashtable.Add(bSONCString, bSONString);
                        break;
                    }
                    case BSONTokens.tokDeprecated:
                        hashtable.Add(bSONCString, GetBSONString(oBR));
                        break;

                    case BSONTokens.tokJSWScope:
                        oBR.ReadInt32();
                        GetBSONString(oBR);
                        hashtable.Add(bSONCString, ReadDocument(oBR));
                        break;

                    case BSONTokens.tokInt32:
                        hashtable.Add(bSONCString, oBR.ReadUInt32());
                        break;

                    case BSONTokens.tokTimeStamp:
                        hashtable.Add(bSONCString, "TIMESTAMP=" + oBR.ReadInt64().ToString());
                        break;

                    case BSONTokens.tokInt64:
                        hashtable.Add(bSONCString, oBR.ReadInt64());
                        break;

                    default:
                        hashtable.Add(bSONCString, "UNDEFINED TOKEN TYPE 0x" + tokens.ToString("X"));
                        break;
                }
            }
            Trace.WriteLine("END BSON Document. Pointer at: 0x" + oBR.BaseStream.Position.ToString("X"));
            return hashtable;
        }

        public class BSONParseErrors
        {
            [CompilerGenerated]
            private int <iErrorIndex>k__BackingField;
            [CompilerGenerated]
            private string <sWarningText>k__BackingField;

            public int iErrorIndex
            {
                [CompilerGenerated]
                get
                {
                    return this.<iErrorIndex>k__BackingField;
                }
                [CompilerGenerated]
                set
                {
                    this.<iErrorIndex>k__BackingField = value;
                }
            }

            public string sWarningText
            {
                [CompilerGenerated]
                get
                {
                    return this.<sWarningText>k__BackingField;
                }
                [CompilerGenerated]
                set
                {
                    this.<sWarningText>k__BackingField = value;
                }
            }
        }

        private enum BSONSubTypes : byte
        {
            stokBinaryOld = 2,
            stokFunction = 1,
            stokGenericBinary = 0,
            stokMD5 = 5,
            stokUserDefined = 0x80,
            stokUUID = 4,
            stokUUIDOld = 3
        }

        private enum BSONTokens : byte
        {
            tokArray = 4,
            tokBinary = 5,
            tokBool = 8,
            tokDBPointer = 12,
            tokDeprecated = 14,
            tokDoc = 3,
            tokDouble = 1,
            tokEOF = 0,
            tokInt32 = 0x10,
            tokInt64 = 0x12,
            tokJS = 13,
            tokJSWScope = 15,
            tokMaxKey = 0x7f,
            tokMinKey = 0xff,
            tokNull = 10,
            tokObjectID = 7,
            tokRegex = 11,
            tokString = 2,
            tokTimeStamp = 0x11,
            tokUndefined = 6,
            tokUTCDateTime = 9
        }
    }
}

