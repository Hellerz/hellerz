﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class UICustomizeColumns : Form
    {
        private bool bTitleTextManuallySet;
        private Button btnAdd;
        private ComboBox cbxCollection;
        private ComboBox cbxFixedFields;
        private IContainer components;
        private static Dictionary<string, string> dictWizardColumns = new Dictionary<string, string>();
        private Label lblFieldName;
        private LinkLabel lnkLearnMore;
        private AutoCompleteStringCollection stringsRequestHeaders = new AutoCompleteStringCollection();
        private AutoCompleteStringCollection stringsResponseHeaders = new AutoCompleteStringCollection();
        private AutoCompleteStringCollection stringsSessionFlags = new AutoCompleteStringCollection();
        private TextBox txtFieldName;
        private TextBox txtTitle;
        private NumericUpDown updownWidth;

        public UICustomizeColumns()
        {
            this.InitializeComponent();
            this.cbxCollection.SelectedIndex = 0;
            this.stringsRequestHeaders.AddRange("Cache-Control,If-None-Match,If-Modified-Since,Pragma,If-Unmodified-Since,If-Range,If-Match,Content-Length,Content-Type,Referer,Origin,SOAPAction,Expect,Content-Encoding,TE,Transfer-Encoding,Proxy-Connection,Connection,Accept,Accept-Charset,Accept-Encoding,Accept-Language,User-Agent,UA-Color,UA-CPU,UA-OS,UA-Pixels,Cookie,Cookie2,DNT,Authorization,Proxy-Authorization,X-Requested-With,X-Download-Initiator".Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            this.stringsResponseHeaders.AddRange("Age,Cache-Control,Date,Expires,Pragma,Vary,Content-Length,ETag,Last-Modified,Content-Type,Content-Disposition,Content-Encoding,Transfer-encoding,Via,Keep-Alive,Location,Proxy-Connection,Connection,Set-Cookie,WWW-Authenticate,Proxy-Authenticate,P3P,X-UA-Compatible,X-Frame-options,X-Content-Type-Options,X-XSS-Protection,Strict-Transport-Security,Content-Security-Policy,Access-Control-Allow-Origin".Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            this.stringsSessionFlags.AddRange("https-Server-Cipher,X-ClientIP,X-ClientPort,X-EgressPort,X-HostIP,X-ResponseBodyTransferLength,X-HTTPProtocol-Violation".Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
        }

        private static void BindColumn(string sTitle, int iAtIndex, int iWidth, string sTarget)
        {
            if (!sTarget.OICStartsWith("@Calc."))
            {
                dictWizardColumns[sTitle] = sTarget;
                SerializeWizardColumns();
                FiddlerApplication.UI.lvSessions.AddBoundColumn(sTitle, 1, iWidth, sTarget, ColumnDataSource.BoundByWizard);
            }
            else
            {
                string str = sTarget.Substring(6);
                bool bSortColumnNumerically = false;
                getColumnStringDelegate delFn = null;
                switch (str)
                {
                    case "AspectRatio":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetAspect);
                        bSortColumnNumerically = true;
                        break;

                    case "PixelCount":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetPixelCount);
                        bSortColumnNumerically = true;
                        break;

                    case "Bytes/Pixel":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetBytesPerPixel);
                        bSortColumnNumerically = true;
                        break;

                    case "GeoLocation":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetGeoLocation);
                        break;

                    case "md5(ResponseBody)":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetResponseMD5);
                        break;

                    case "ImageRGB":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetImageRGB);
                        break;

                    case "ImageFingerprint":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetImageFingerprint);
                        break;

                    case "ImageDimensions":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetImageDimensions);
                        break;

                    case "SessionBitFlags":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetBitFlags);
                        break;

                    case "ClientPipeReuse":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetClientPipeReuse);
                        break;

                    case "ServerPipeReuse":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetServerPipeReuse);
                        break;

                    case "SentToGateway":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetSentToGateway);
                        break;

                    case "ResponseStreamed":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetResponseStreamed);
                        break;

                    case "RequestSize":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetRequestSize);
                        bSortColumnNumerically = true;
                        break;

                    case "ResponseSize":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetResponseSize);
                        bSortColumnNumerically = true;
                        break;

                    case "CompressionSavings":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetCompressionSavings);
                        bSortColumnNumerically = true;
                        break;

                    case "CompressionSavings%":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetCompressionSavingsPct);
                        break;

                    case "RequestBodySize":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetRequestBodySize);
                        bSortColumnNumerically = true;
                        break;

                    case "RequestMethod":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetRequestMethod);
                        break;

                    case "ResponseStatusText":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetResponseStatusText);
                        break;

                    case "ClientConnected":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetClientConnected);
                        break;

                    case "ClientBeginRequest":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetClientBeginRequest);
                        break;

                    case "GotRequestHeaders":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetFiddlerGotRequestHeaders);
                        break;

                    case "ClientDoneRequest":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetClientDoneRequest);
                        break;

                    case "Determine_Gateway":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetGatewayDeterminationTime);
                        bSortColumnNumerically = true;
                        break;

                    case "SecurityHeaders":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetSecurityHeaderSummary);
                        break;

                    case "DNS_Lookup":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetDNSTime);
                        bSortColumnNumerically = true;
                        break;

                    case "TCP/IP_Connect":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetTCPConnectTime);
                        bSortColumnNumerically = true;
                        break;

                    case "HTTPS_Handshake":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetHTTPSHandshakeTime);
                        bSortColumnNumerically = true;
                        break;

                    case "ServerConnected":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetServerConnected);
                        break;

                    case "FiddlerBeginRequest":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetFiddlerBeginRequest);
                        break;

                    case "ServerGotRequest":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetServerGotRequest);
                        break;

                    case "ServerBeginResponse":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetServerBeginResponse);
                        break;

                    case "GotResponseHeaders":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetFiddlerGotResponseHeaders);
                        break;

                    case "ServerDoneResponse":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetServerDoneResponse);
                        break;

                    case "ClientBeginResponse":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetClientBeginResponse);
                        break;

                    case "ClientDoneResponse":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetClientDoneResponse);
                        break;

                    case "TTFB":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetTTFB);
                        bSortColumnNumerically = true;
                        break;

                    case "TTLB":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetTTLB);
                        bSortColumnNumerically = true;
                        break;

                    case "Server_ThinkTime":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetServerThinkTime);
                        bSortColumnNumerically = true;
                        break;

                    case "Overall_Elapsed":
                        delFn = new getColumnStringDelegate(CustomColumnProviders.GetOverallElapsed);
                        break;
                }
                if (delFn == null)
                {
                    MessageBox.Show("The item '" + str + "' is not available in this build of Fiddler.", "Missing Custom Column Provider");
                }
                else
                {
                    dictWizardColumns[sTitle] = sTarget;
                    SerializeWizardColumns();
                    FiddlerApplication.UI.lvSessions.AddBoundColumn(sTitle, iAtIndex, iWidth, bSortColumnNumerically, ColumnDataSource.BoundByWizard, delFn);
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string key = this.txtTitle.Text.Trim().Replace("~", "-");
            string sTarget = this.txtFieldName.Text.Trim();
            if (this.cbxFixedFields.Visible)
            {
                if (this.cbxFixedFields.SelectedItem == null)
                {
                    MessageBox.Show("You must select a field from the dropdown.", "Choose a field");
                    this.cbxFixedFields.Focus();
                    return;
                }
            }
            else
            {
                if (sTarget.Length < 1)
                {
                    MessageBox.Show("The item name must not be empty.", "Invalid Item Name");
                    this.txtFieldName.Focus();
                    return;
                }
                if (sTarget.Contains(" "))
                {
                    MessageBox.Show("Header and Flag names must not contain spaces.", "Invalid Item Name");
                    this.txtFieldName.Focus();
                    return;
                }
            }
            if (key.Length < 1)
            {
                MessageBox.Show("Column title must not be empty.", "Invalid Column Title");
                this.txtTitle.Focus();
            }
            else if (dictWizardColumns.ContainsKey(key))
            {
                FiddlerApplication.UI.lvSessions.EnsureColumnIsVisible(key);
                MessageBox.Show("A column with this title already exists. Please choose a new name.", "Invalid Column Title");
                this.txtTitle.Focus();
            }
            else
            {
                switch (this.cbxCollection.SelectedIndex)
                {
                    case 0:
                        sTarget = "@Request." + sTarget;
                        break;

                    case 1:
                        sTarget = "@Response." + sTarget;
                        break;

                    case 3:
                    case 4:
                        sTarget = string.Format("@Calc.{0}", this.cbxFixedFields.SelectedItem);
                        break;
                }
                this.txtFieldName.Text = string.Empty;
                this.txtTitle.Text = string.Empty;
                this.cbxFixedFields.SelectedIndex = -1;
                this.Refresh();
                BindColumn(key, 1, (int) this.updownWidth.Value, sTarget);
                FiddlerApplication.UI.WithinLimitRefreshBoundColumns();
                this.txtFieldName.Focus();
            }
        }

        private void cbxCollection_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (this.cbxCollection.SelectedIndex)
            {
                case 0:
                    this.txtFieldName.AutoCompleteCustomSource = this.stringsRequestHeaders;
                    this.lblFieldName.Text = "Header &Name:";
                    this.cbxFixedFields.Visible = false;
                    this.txtFieldName.Visible = true;
                    return;

                case 1:
                    this.txtFieldName.AutoCompleteCustomSource = this.stringsResponseHeaders;
                    this.lblFieldName.Text = "Header &Name:";
                    this.cbxFixedFields.Visible = false;
                    this.txtFieldName.Visible = true;
                    return;

                case 2:
                    this.txtFieldName.AutoCompleteCustomSource = this.stringsSessionFlags;
                    this.lblFieldName.Text = "Flag &Name:";
                    this.cbxFixedFields.Visible = false;
                    this.txtFieldName.Visible = true;
                    return;

                case 3:
                    this.lblFieldName.Text = "Timer &Name:";
                    this.cbxFixedFields.Items.Clear();
                    this.cbxFixedFields.Items.AddRange(new string[] { 
                        "ClientConnected", "ClientBeginRequest", "GotRequestHeaders", "ClientDoneRequest", "Determine_Gateway", "DNS_Lookup", "TCP/IP_Connect", "HTTPS_Handshake", "ServerConnected", "FiddlerBeginRequest", "ServerGotRequest", "ServerBeginResponse", "GotResponseHeaders", "ServerDoneResponse", "ClientBeginResponse", "ClientDoneResponse", 
                        "TTFB", "TTLB", "Server_ThinkTime", "Overall_Elapsed"
                     });
                    this.cbxFixedFields.Visible = true;
                    this.txtFieldName.Visible = false;
                    if (this.bTitleTextManuallySet)
                    {
                        break;
                    }
                    this.txtTitle.Clear();
                    return;

                case 4:
                    this.lblFieldName.Text = "Field &Name:";
                    this.cbxFixedFields.Items.Clear();
                    this.cbxFixedFields.Items.AddRange(new string[] { 
                        "RequestMethod", "RequestSize", "RequestBodySize", "ResponseSize", "CompressionSavings", "CompressionSavings%", "SecurityHeaders", "md5(ResponseBody)", "ResponseStatusText", "ResponseStreamed", "SessionBitFlags", "SentToGateway", "ClientPipeReuse", "ServerPipeReuse", "ImageDimensions", "PixelCount", 
                        "Bytes/Pixel", "AspectRatio", "ImageRGB", "ImageFingerprint", "GeoLocation"
                     });
                    this.cbxFixedFields.Visible = true;
                    this.txtFieldName.Visible = false;
                    if (!this.bTitleTextManuallySet)
                    {
                        this.txtTitle.Clear();
                    }
                    break;

                default:
                    return;
            }
        }

        private void cbxFixedFields_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (((this.txtTitle.TextLength <= 0) || !this.bTitleTextManuallySet) && (this.cbxFixedFields.SelectedIndex >= 0))
            {
                this.txtTitle.Text = this.cbxFixedFields.SelectedItem.ToString();
                this.bTitleTextManuallySet = false;
            }
        }

        internal static void DeleteColumn(string sColTitle)
        {
            dictWizardColumns.Remove(sColTitle);
            SerializeWizardColumns();
        }

        internal static void DeserializeAndCreateWizardColumns()
        {
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.WizardColumnSet", string.Empty);
            if (!string.IsNullOrEmpty(stringPref))
            {
                string[] strArray = stringPref.Split(new char[] { '\x00a7' }, StringSplitOptions.RemoveEmptyEntries);
                int num = 1;
                foreach (string str2 in strArray)
                {
                    string sTitle = Utilities.TrimAfter(str2, "~");
                    string sTarget = Utilities.TrimBefore(str2, "~");
                    BindColumn(sTitle, num++, 50, sTarget);
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblFieldName = new Label();
            this.lnkLearnMore = new LinkLabel();
            this.updownWidth = new NumericUpDown();
            this.cbxCollection = new ComboBox();
            this.txtFieldName = new TextBox();
            this.btnAdd = new Button();
            this.txtTitle = new TextBox();
            this.cbxFixedFields = new ComboBox();
            Label label = new Label();
            Label label2 = new Label();
            Label label3 = new Label();
            this.updownWidth.BeginInit();
            base.SuspendLayout();
            label.AutoSize = true;
            label.Location = new Point(6, 13);
            label.Name = "lblCollection";
            label.Size = new Size(0x3f, 14);
            label.TabIndex = 0;
            label.Text = "&Collection:";
            label2.AutoSize = true;
            label2.Location = new Point(0x36, 0x3f);
            label2.Name = "lblWidth";
            label2.Size = new Size(0x2c, 14);
            label2.TabIndex = 5;
            label2.Text = "&Width:";
            label2.TextAlign = ContentAlignment.TopCenter;
            label3.AutoSize = true;
            label3.Location = new Point(0x90, 0x3f);
            label3.Name = "lblTitle";
            label3.Size = new Size(0x4f, 14);
            label3.TabIndex = 7;
            label3.Text = "Column &Title:";
            this.lblFieldName.AutoSize = true;
            this.lblFieldName.Location = new Point(0x90, 13);
            this.lblFieldName.Name = "lblFieldName";
            this.lblFieldName.Size = new Size(0x55, 14);
            this.lblFieldName.TabIndex = 2;
            this.lblFieldName.Text = "Header &Name:";
            this.lnkLearnMore.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.lnkLearnMore.AutoSize = true;
            this.lnkLearnMore.LinkArea = new LinkArea(0x12, 40);
            this.lnkLearnMore.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkLearnMore.Location = new Point(9, 0x7b);
            this.lnkLearnMore.Name = "lnkLearnMore";
            this.lnkLearnMore.Size = new Size(230, 0x13);
            this.lnkLearnMore.TabIndex = 10;
            this.lnkLearnMore.TabStop = true;
            this.lnkLearnMore.Text = "&Learn more about customizing columns...";
            this.lnkLearnMore.UseCompatibleTextRendering = true;
            this.lnkLearnMore.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkLearnMore_LinkClicked);
            int[] bits = new int[4];
            bits[0] = 10;
            this.updownWidth.Increment = new decimal(bits);
            this.updownWidth.Location = new Point(0x2f, 0x4f);
            int[] numArray2 = new int[4];
            numArray2[0] = 400;
            this.updownWidth.Maximum = new decimal(numArray2);
            int[] numArray3 = new int[4];
            numArray3[0] = 5;
            this.updownWidth.Minimum = new decimal(numArray3);
            this.updownWidth.Name = "updownWidth";
            this.updownWidth.Size = new Size(0x38, 0x16);
            this.updownWidth.TabIndex = 6;
            this.updownWidth.TextAlign = HorizontalAlignment.Center;
            int[] numArray4 = new int[4];
            numArray4[0] = 60;
            this.updownWidth.Value = new decimal(numArray4);
            this.cbxCollection.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxCollection.FormattingEnabled = true;
            this.cbxCollection.Items.AddRange(new object[] { "Request Headers", "Response Headers", "Session Flags", "Session Timers", "Miscellaneous" });
            this.cbxCollection.Location = new Point(9, 0x1d);
            this.cbxCollection.Name = "cbxCollection";
            this.cbxCollection.Size = new Size(0x84, 0x16);
            this.cbxCollection.TabIndex = 1;
            this.cbxCollection.SelectedIndexChanged += new EventHandler(this.cbxCollection_SelectedIndexChanged);
            this.txtFieldName.AutoCompleteMode = AutoCompleteMode.Suggest;
            this.txtFieldName.AutoCompleteSource = AutoCompleteSource.CustomSource;
            this.txtFieldName.Location = new Point(0x93, 0x1d);
            this.txtFieldName.Name = "txtFieldName";
            this.txtFieldName.Size = new Size(0xd6, 0x16);
            this.txtFieldName.TabIndex = 4;
            this.txtFieldName.TextChanged += new EventHandler(this.txtFieldName_TextChanged);
            this.txtFieldName.KeyDown += new KeyEventHandler(this.txtFieldName_KeyDown);
            this.btnAdd.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnAdd.Location = new Point(0x11e, 0x76);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(0x4b, 0x17);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
            this.txtTitle.Location = new Point(0x93, 0x4f);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new Size(0xd6, 0x16);
            this.txtTitle.TabIndex = 8;
            this.txtTitle.KeyPress += new KeyPressEventHandler(this.txtTitle_KeyPress);
            this.cbxFixedFields.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxFixedFields.FormattingEnabled = true;
            this.cbxFixedFields.Location = new Point(0x93, 0x1d);
            this.cbxFixedFields.Name = "cbxFixedFields";
            this.cbxFixedFields.Size = new Size(0xd6, 0x16);
            this.cbxFixedFields.TabIndex = 3;
            this.cbxFixedFields.Visible = false;
            this.cbxFixedFields.SelectionChangeCommitted += new EventHandler(this.cbxFixedFields_SelectionChangeCommitted);
            base.AutoScaleMode = AutoScaleMode.Inherit;
            base.ClientSize = new Size(0x179, 0x99);
            base.Controls.Add(this.txtTitle);
            base.Controls.Add(this.updownWidth);
            base.Controls.Add(this.txtFieldName);
            base.Controls.Add(this.cbxCollection);
            base.Controls.Add(label3);
            base.Controls.Add(this.btnAdd);
            base.Controls.Add(label2);
            base.Controls.Add(label);
            base.Controls.Add(this.lnkLearnMore);
            base.Controls.Add(this.cbxFixedFields);
            base.Controls.Add(this.lblFieldName);
            this.Font = new Font("Tahoma", 9f);
            base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            base.KeyPreview = true;
            base.Name = "UICustomizeColumns";
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.Manual;
            this.Text = "Customize Columns";
            base.KeyDown += new KeyEventHandler(this.UICustomizeColumns_KeyDown);
            this.updownWidth.EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lnkLearnMore_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.lnkLearnMore.LinkVisited = true;
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("FiddlerColumns"));
        }

        private static void SerializeWizardColumns()
        {
            string[] strArray = new string[dictWizardColumns.Count];
            int num = 0;
            foreach (KeyValuePair<string, string> pair in dictWizardColumns)
            {
                strArray[num++] = string.Format("{0}~{1}", pair.Key, pair.Value);
            }
            string sValue = string.Join("\x00a7", strArray);
            if (sValue.Length > 3)
            {
                FiddlerApplication.Prefs.SetStringPref("fiddler.ui.WizardColumnSet", sValue);
            }
            else
            {
                FiddlerApplication.Prefs.RemovePref("fiddler.ui.WizardColumnSet");
            }
        }

        private void txtFieldName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Space)
            {
                e.SuppressKeyPress = e.Handled = true;
            }
        }

        private void txtFieldName_TextChanged(object sender, EventArgs e)
        {
            if ((this.txtTitle.TextLength <= 0) || !this.bTitleTextManuallySet)
            {
                string text = this.txtFieldName.Text;
                if (text.Length > 0)
                {
                    text = char.ToUpper(text[0]) + text.Substring(1);
                }
                this.txtTitle.Text = text;
            }
        }

        private void txtTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.bTitleTextManuallySet = this.txtTitle.TextLength > 0;
        }

        private void UICustomizeColumns_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Alt | Keys.L))
            {
                this.lnkLearnMore.Focus();
            }
            if (e.KeyData == Keys.Escape)
            {
                TextBox activeControl = base.ActiveControl as TextBox;
                if ((activeControl != null) && (activeControl.TextLength > 0))
                {
                    activeControl.Clear();
                }
                else
                {
                    e.Handled = e.SuppressKeyPress = true;
                    base.Close();
                }
            }
            else if (e.KeyData == Keys.Return)
            {
                Control control = base.ActiveControl;
                if (((control is TextBox) || ((control is ComboBox) && !(control as ComboBox).DroppedDown)) || (control is NumericUpDown))
                {
                    do
                    {
                        base.ActiveControl = base.GetNextControl(base.ActiveControl, true);
                    }
                    while ((base.ActiveControl is Label) || !base.ActiveControl.Visible);
                    e.Handled = e.SuppressKeyPress = true;
                }
            }
        }
    }
}

