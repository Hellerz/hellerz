﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Text;
    using System.Windows.Forms;

    public class frmAbout : Form
    {
        private IContainer components;
        private readonly Keys[] kc = new Keys[] { Keys.Up, Keys.Down, Keys.Down, Keys.Left, Keys.Right, Keys.Left, Keys.Right, Keys.B, Keys.A };
        private int kci;
        internal PictureBox pbImage;
        private RichTextBox rtbAbout;
        private const string s_KMsg = "RUFTVEVSIEVHRw0KDQpDb25ncmF0dWxhdGlvbnMtLSBZb3UgZm91bmQgaXQhDQoNCkFsYXMsIHRoaXMgYWxsIHRoZXJlIGlzIHRvIGl0LiBUaGVyZSBhcmUgbWFueSBuaWNlDQpwYWdlcyBvbiB0aGUgSW50ZXJuZXQgd2l0aCBldmVyeXRoaW5nIGZyb20gZmxpZ2h0IA0Kc2ltdWxhdG9ycyB0byBkYXp6bGluZyBzbGlkZXNob3dzLiANCg0KRXhwbG9yZSB0aGVtIHdpdGggRmlkZGxlciB0byBmaW5kIHRoZWlyIEVhc3RlciBFZ2dzIQ==";

        public frmAbout()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        internal static void DoAboutBox()
        {
            Utilities.RecoverMemory();
            using (frmAbout about = new frmAbout())
            {
                about.rtbAbout.Text = FiddlerApplication.GetDetailedInfo() + "Send feedback to: fiddler@telerik.com\n\x00a92015 Telerik";
                about.rtbAbout.ForeColor = Utilities.GetContrastingTextColor(about.BackColor);
                about.ShowDialog(FiddlerApplication.UI);
            }
        }

        private void frmAbout_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyData == (Keys.Control | Keys.C)) && (this.rtbAbout.SelectedText.Length < 3))
            {
                e.SuppressKeyPress = e.Handled = true;
                Utilities.CopyToClipboard(this.rtbAbout.Text.Replace("\n", "\r\n"));
            }
            else if (((e.KeyCode == Keys.Escape) || (e.KeyCode == Keys.Return)) || (e.KeyCode == Keys.Space))
            {
                base.Close();
            }
            else if (e.KeyCode == this.kc[this.kci])
            {
                this.kci++;
                if (this.kci >= this.kc.Length)
                {
                    this.kci = 0;
                    FiddlerApplication.oTelemetry.TrackEvent("KCode");
                    this.rtbAbout.Text = Encoding.UTF8.GetString(Convert.FromBase64String("RUFTVEVSIEVHRw0KDQpDb25ncmF0dWxhdGlvbnMtLSBZb3UgZm91bmQgaXQhDQoNCkFsYXMsIHRoaXMgYWxsIHRoZXJlIGlzIHRvIGl0LiBUaGVyZSBhcmUgbWFueSBuaWNlDQpwYWdlcyBvbiB0aGUgSW50ZXJuZXQgd2l0aCBldmVyeXRoaW5nIGZyb20gZmxpZ2h0IA0Kc2ltdWxhdG9ycyB0byBkYXp6bGluZyBzbGlkZXNob3dzLiANCg0KRXhwbG9yZSB0aGVtIHdpdGggRmlkZGxlciB0byBmaW5kIHRoZWlyIEVhc3RlciBFZ2dzIQ=="));
                    this.pbImage.BackColor = Color.AliceBlue;
                    this.pbImage.Focus();
                }
            }
            else
            {
                this.kci = 0;
            }
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmAbout));
            this.rtbAbout = new RichTextBox();
            this.pbImage = new PictureBox();
            ((ISupportInitialize) this.pbImage).BeginInit();
            base.SuspendLayout();
            this.rtbAbout.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.rtbAbout.BackColor = Color.White;
            this.rtbAbout.BorderStyle = BorderStyle.None;
            this.rtbAbout.Cursor = Cursors.Default;
            this.rtbAbout.DetectUrls = false;
            this.rtbAbout.Font = new Font("Tahoma", 8.25f);
            this.rtbAbout.Location = new Point(0x42, 8);
            this.rtbAbout.Name = "rtbAbout";
            this.rtbAbout.ReadOnly = true;
            this.rtbAbout.ScrollBars = RichTextBoxScrollBars.None;
            this.rtbAbout.Size = new Size(0x102, 0xd4);
            this.rtbAbout.TabIndex = 0;
            this.rtbAbout.TabStop = false;
            this.rtbAbout.Text = "";
            this.rtbAbout.WordWrap = false;
            this.pbImage.Image = (Image) manager.GetObject("pbImage.Image");
            this.pbImage.Location = new Point(9, 9);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new Size(0x30, 0x30);
            this.pbImage.SizeMode = PictureBoxSizeMode.CenterImage;
            this.pbImage.TabIndex = 1;
            this.pbImage.TabStop = false;
            base.AutoScaleDimensions = new SizeF(96f, 96f);
            base.AutoScaleMode = AutoScaleMode.Dpi;
            this.BackColor = Color.White;
            base.ClientSize = new Size(0x148, 0xe0);
            base.Controls.Add(this.pbImage);
            base.Controls.Add(this.rtbAbout);
            this.Font = new Font("Tahoma", 8.25f);
            base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            base.KeyPreview = true;
            base.Name = "frmAbout";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "About Fiddler™";
            base.KeyDown += new KeyEventHandler(this.frmAbout_KeyDown);
            ((ISupportInitialize) this.pbImage).EndInit();
            base.ResumeLayout(false);
        }
    }
}

