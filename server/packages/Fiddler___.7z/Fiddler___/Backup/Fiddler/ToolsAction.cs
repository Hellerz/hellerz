﻿namespace Fiddler
{
    using System;

    [AttributeUsage(AttributeTargets.Method, Inherited=false)]
    public sealed class ToolsAction : Attribute
    {
        private string myName;
        private string mySubmenu;

        public ToolsAction(string name) : this(name, null)
        {
        }

        public ToolsAction(string name, string subMenu)
        {
            this.myName = name;
            this.mySubmenu = subMenu;
        }

        public string Name
        {
            get
            {
                return this.myName;
            }
        }

        public string SubMenu
        {
            get
            {
                return this.mySubmenu;
            }
        }
    }
}

