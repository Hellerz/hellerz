﻿namespace Fiddler
{
    using System;

    [AttributeUsage(AttributeTargets.Method, Inherited=false)]
    public sealed class ContextAction : Attribute
    {
        private string myName;
        private string mySubMenu;

        public ContextAction(string name) : this(name, null)
        {
        }

        public ContextAction(string name, string subMenu)
        {
            this.myName = name;
            this.mySubMenu = subMenu;
        }

        public string Name
        {
            get
            {
                return this.myName;
            }
        }

        public string SubMenu
        {
            get
            {
                return this.mySubMenu;
            }
        }
    }
}

