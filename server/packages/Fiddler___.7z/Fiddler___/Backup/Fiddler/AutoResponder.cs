﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;
    using System.Xml;

    public class AutoResponder
    {
        private List<ResponderRule> _alRules = new List<ResponderRule>();
        private bool _bEnabled;
        private bool _bPermitFallthrough;
        private bool _bRuleListIsDirty;
        private bool _bUseLatency;
        private ReaderWriterLockSlim _RWLockRules = new ReaderWriterLockSlim();
        private static Random myRand = new Random();
        private UIAutoResponder oAutoResponderUI = new UIAutoResponder();
        private static string sColorAutoResponded = "Lavender";
        internal static readonly string STR_CREATE_NEW = "Create New Response...";
        internal static readonly string STR_FIND_FILE = "Find a file...";

        internal AutoResponder()
        {
            try
            {
                sColorAutoResponded = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.Colors.AutoResponded", "Lavender");
            }
            catch
            {
            }
        }

        private static int _GetRandValue()
        {
            int num;
            Random random;
            bool lockTaken = false;
            try
            {
                Monitor.Enter(random = myRand, ref lockTaken);
                num = myRand.Next(1, 0x65);
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(random);
                }
            }
            return num;
        }

        private static void _MarkMatch(Session oS, ResponderRule oMatch)
        {
            oS["x-AutoResponder"] = "Matched: " + oMatch.sMatch + ", sent: " + oMatch.sAction;
            oS["ui-backcolor"] = sColorAutoResponded;
        }

        internal void AddActionsToUI(params string[] arrActions)
        {
            this.oAutoResponderUI.cbxRuleAction.Items.AddRange(arrActions);
        }

        public ResponderRule AddRule(string sRule, string sAction, bool bIsEnabled)
        {
            return this.AddRule(sRule, null, null, sAction, 0, bIsEnabled);
        }

        public ResponderRule AddRule(string sRule, Session oImportedSession, string sDescription, bool bEnabled)
        {
            if (oImportedSession != null)
            {
                return this.AddRule(sRule, oImportedSession.oResponse.headers, oImportedSession.responseBodyBytes, sDescription, 0, bEnabled);
            }
            return this.AddRule(sRule, null, null, sDescription, 0, bEnabled);
        }

        public ResponderRule AddRule(string sRule, Session oImportedSession, string sDescription, int iLatencyMS, bool bEnabled)
        {
            return this.AddRule(sRule, oImportedSession.oResponse.headers, oImportedSession.responseBodyBytes, sDescription, iLatencyMS, bEnabled);
        }

        public ResponderRule AddRule(string sRule, HTTPResponseHeaders oRH, byte[] arrResponseBody, string sDescription, int iLatencyMS, bool bEnabled)
        {
            return this.AddRule(sRule, oRH, arrResponseBody, sDescription, null, iLatencyMS, bEnabled);
        }

        public ResponderRule AddRule(string sRule, HTTPResponseHeaders oRH, byte[] arrResponseBody, string sDescription, string sComment, int iLatencyMS, bool bEnabled)
        {
            try
            {
                ResponderRule item = new ResponderRule(sRule, oRH, arrResponseBody, sDescription, sComment, iLatencyMS, bEnabled);
                try
                {
                    this.GetWriterLock();
                    this._alRules.Add(item);
                }
                finally
                {
                    this.FreeWriterLock();
                }
                this._bRuleListIsDirty = true;
                this.CreateViewItem(item);
                return item;
            }
            catch (Exception)
            {
                return null;
            }
        }

        internal void AddToUI()
        {
            FiddlerApplication.UI.pageResponder.Controls.Add(this.oAutoResponderUI);
            this.oAutoResponderUI.Parent = FiddlerApplication.UI.pageResponder;
            this.oAutoResponderUI.Dock = DockStyle.Fill;
        }

        private static bool CheckMatch(Session oS, ResponderRule oCandidate)
        {
            if (!oCandidate.IsEnabled)
            {
                return false;
            }
            return CheckMatch(oS.fullUrl, oS, oCandidate.sMatch);
        }

        internal static bool CheckMatch(string sURI, Session oSession, string sLookFor)
        {
            string sBodyToMatch = null;
            int index = sLookFor.IndexOf('%');
            if ((index > 0) && (index < 4))
            {
                int result = 0;
                if (int.TryParse(sLookFor.Substring(0, index), out result) && (_GetRandValue() > result))
                {
                    return false;
                }
                sLookFor = sLookFor.Substring(index + 1);
            }
            if (sLookFor.OICStartsWith("METHOD:"))
            {
                if ((oSession == null) || !Utilities.HasHeaders(oSession.oRequest))
                {
                    return false;
                }
                sLookFor = sLookFor.Substring(7);
                bool flag = false;
                bool flag2 = false;
                if (sLookFor.OICStartsWith("NOT:"))
                {
                    flag2 = true;
                    sLookFor = sLookFor.Substring(4);
                }
                string sTestFor = Utilities.TrimAfter(sLookFor, ' ');
                flag = oSession.HTTPMethodIs(sTestFor);
                if (flag2)
                {
                    flag = !flag;
                }
                if (!flag)
                {
                    return false;
                }
                sLookFor = sLookFor.Contains(" ") ? Utilities.TrimBefore(sLookFor, ' ') : "*";
            }
            if (sLookFor.OICStartsWith("URLWithBody:"))
            {
                sLookFor = sLookFor.Substring(12);
                sBodyToMatch = Utilities.TrimBefore(sLookFor, ' ');
                sLookFor = Utilities.TrimAfter(sLookFor, ' ');
            }
            if (sLookFor.OICStartsWith("HEADER:"))
            {
                if ((oSession == null) || !Utilities.HasHeaders(oSession.oRequest))
                {
                    return false;
                }
                sLookFor = sLookFor.Substring(7);
                bool flag3 = false;
                bool flag4 = false;
                if (sLookFor.OICStartsWith("NOT:"))
                {
                    flag4 = true;
                    sLookFor = sLookFor.Substring(4);
                }
                if (sLookFor.Contains("="))
                {
                    string sHeaderName = Utilities.TrimAfter(sLookFor, "=");
                    string sHeaderValue = Utilities.TrimBefore(sLookFor, "=");
                    flag3 = oSession.oRequest.headers.ExistsAndContains(sHeaderName, sHeaderValue);
                }
                else
                {
                    flag3 = oSession.oRequest.headers.Exists(sLookFor);
                }
                if (flag4)
                {
                    flag3 = !flag3;
                }
                return flag3;
            }
            if (sLookFor.OICStartsWith("FLAG:"))
            {
                if (oSession == null)
                {
                    return false;
                }
                bool flag5 = false;
                bool flag6 = false;
                sLookFor = sLookFor.Substring(5);
                if (sLookFor.OICStartsWith("NOT:"))
                {
                    flag6 = true;
                    sLookFor = sLookFor.Substring(4);
                }
                if (sLookFor.Contains("="))
                {
                    string str5 = Utilities.TrimAfter(sLookFor, "=");
                    string toMatch = Utilities.TrimBefore(sLookFor, "=");
                    string inStr = oSession.oFlags[str5];
                    if (inStr == null)
                    {
                        return false;
                    }
                    flag5 = inStr.OICContains(toMatch);
                }
                else
                {
                    flag5 = oSession.oFlags.ContainsKey(sLookFor);
                }
                if (flag6)
                {
                    flag5 = !flag5;
                }
                return flag5;
            }
            if ((sLookFor.Length > 6) && sLookFor.OICStartsWith("REGEX:"))
            {
                bool flag7;
                string pattern = sLookFor.Substring(6);
                try
                {
                    Regex regex = new Regex(pattern);
                    if (!regex.Match(sURI).Success)
                    {
                        return false;
                    }
                    if (!IsBodyMatch(oSession, sBodyToMatch))
                    {
                        return false;
                    }
                    flag7 = true;
                }
                catch
                {
                }
                return flag7;
            }
            if ((sLookFor.Length > 6) && sLookFor.OICStartsWith("EXACT:"))
            {
                if (!sLookFor.Substring(6).Equals(sURI, StringComparison.Ordinal))
                {
                    return false;
                }
                if (!IsBodyMatch(oSession, sBodyToMatch))
                {
                    return false;
                }
                return true;
            }
            if ((sLookFor.Length > 4) && sLookFor.OICStartsWith("NOT:"))
            {
                string str10 = sLookFor.Substring(4);
                if (sURI.OICContains(str10))
                {
                    return false;
                }
                if (!IsBodyMatch(oSession, sBodyToMatch))
                {
                    return false;
                }
                return true;
            }
            if (!("*" == sLookFor) && !sURI.OICContains(sLookFor))
            {
                return false;
            }
            return IsBodyMatch(oSession, sBodyToMatch);
        }

        internal void ClearActionsFromUI()
        {
            this.oAutoResponderUI.cbxRuleAction.Items.Clear();
        }

        public void ClearRules()
        {
            try
            {
                this.GetWriterLock();
                this._alRules.Clear();
            }
            finally
            {
                this.FreeWriterLock();
            }
            FiddlerApplication.UIInvoke(delegate {
                this.oAutoResponderUI.lvRespondRules.Items.Clear();
            });
            this._bRuleListIsDirty = true;
        }

        internal bool CreateRuleForFile(string sFilename, string sRelativeTo)
        {
            if ((sFilename == null) || !File.Exists(sFilename))
            {
                return false;
            }
            try
            {
                string fileName = null;
                if (string.IsNullOrEmpty(sRelativeTo))
                {
                    fileName = Path.GetFileName(sFilename);
                }
                else
                {
                    fileName = sFilename.Substring(sRelativeTo.Length).Replace('\\', '/');
                }
                fileName = Utilities.UrlPathEncode(fileName);
                bool flag = fileName.OICEndsWithAny(new string[] { ".htm", ".html", ".php", ".cgi", ".asp", ".cfm", ".aspx" });
                string sRule = "REGEX:(?inx).*" + Utilities.RegExEscape(fileName, false, !flag);
                if (flag)
                {
                    sRule = sRule + @"(\?.*)?$";
                }
                string sAction = sFilename;
                this.AddRule(sRule, sAction, true);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        internal void CreateRulesForFolder(string sFolderName)
        {
            DirectoryInfo info = new DirectoryInfo(sFolderName);
            foreach (FileInfo info2 in info.GetFiles("*", SearchOption.AllDirectories))
            {
                this.CreateRuleForFile(info2.FullName, info.Parent.FullName);
            }
        }

        private void CreateViewItem(ResponderRule oRule)
        {
            if (oRule != null)
            {
                ListViewItem item = this.oAutoResponderUI.lvRespondRules.Items.Add(oRule.sMatch);
                oRule.ViewItem = item;
                item.SubItems.Add(oRule.sAction);
                item.SubItems.Add(oRule.iLatency.ToString());
                item.SubItems.Add(oRule.sComment);
                item.Tag = oRule;
                item.Checked = oRule.IsEnabled;
                if (!item.Checked)
                {
                    item.ForeColor = Color.FromKnownColor(KnownColor.ControlDark);
                }
            }
        }

        internal bool DemoteRule(ResponderRule oRule)
        {
            bool flag;
            try
            {
                this.GetWriterLock();
                int index = this._alRules.IndexOf(oRule);
                if ((index > -1) && (index < (this._alRules.Count - 1)))
                {
                    this._alRules.Reverse(index, 2);
                    this._bRuleListIsDirty = true;
                    return true;
                }
                flag = false;
            }
            finally
            {
                this.FreeWriterLock();
            }
            return flag;
        }

        private static void DoDelay(ResponderRule oMatch)
        {
            if (FiddlerApplication.oAutoResponder.UseLatency && (oMatch.iLatency > 0))
            {
                Thread.Sleep(oMatch.iLatency);
            }
        }

        internal void DoMatchAfterRequestTampering(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                List<ResponderRule> list;
                try
                {
                    this.GetReaderLock();
                    list = new List<ResponderRule>(this._alRules);
                }
                finally
                {
                    this.FreeReaderLock();
                }
                using (List<ResponderRule>.Enumerator enumerator = list.GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        MethodInvoker oDel = null;
                        ResponderRule oCandidate = enumerator.Current;
                        if ((!string.IsNullOrEmpty(oCandidate.sAction) && !oCandidate.sAction.OICEquals("*bpu")) && CheckMatch(oSession, oCandidate))
                        {
                            if (oCandidate.bDisableOnMatch)
                            {
                                oCandidate.IsEnabled = false;
                                if (oDel == null)
                                {
                                    oDel = delegate {
                                        oCandidate.ViewItem.Checked = false;
                                    };
                                }
                                FiddlerApplication.UIInvokeAsync(oDel, null);
                            }
                            if (HandleMatch(oSession, oCandidate))
                            {
                                return;
                            }
                        }
                    }
                }
                if (!this._bPermitFallthrough)
                {
                    oSession["ui-backcolor"] = sColorAutoResponded;
                    oSession.SetBitFlag(SessionFlags.ResponseGeneratedByFiddler, true);
                    if (!oSession.HTTPMethodIs("CONNECT"))
                    {
                        if (oSession.state < SessionStates.SendingRequest)
                        {
                            oSession.utilCreateResponseAndBypassServer();
                        }
                        else
                        {
                            oSession.oResponse.headers = new HTTPResponseHeaders();
                            oSession.responseBodyBytes = Utilities.emptyByteArray;
                            oSession.bBufferResponse = true;
                        }
                        oSession.state = SessionStates.ReadingResponse;
                        oSession.oResponse["Date"] = DateTime.UtcNow.ToString("r");
                        if (oSession.oRequest.headers.Exists("If-Modified-Since") || oSession.oRequest.headers.Exists("If-None-Match"))
                        {
                            oSession.responseCode = 0x130;
                        }
                        else
                        {
                            oSession.responseCode = 0x194;
                            oSession.oResponse["Cache-Control"] = "max-age=0, must-revalidate";
                            if (!oSession.HTTPMethodIs("HEAD"))
                            {
                                oSession.utilSetResponseBody("[Fiddler] The Fiddler AutoResponder is enabled, but this request did not match any of the listed rules. Because the \"Unmatched requests passthrough\" option on the AutoResponder tab is not enabled, this HTTP/404 response has been generated.".PadRight(0x200, ' '));
                            }
                        }
                    }
                    else
                    {
                        oSession.oFlags["x-replywithtunnel"] = "AutoResponderWithNoFallthrough";
                    }
                }
            }
        }

        internal void DoMatchBeforeRequestTampering(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                try
                {
                    this.GetReaderLock();
                    using (List<ResponderRule>.Enumerator enumerator = this._alRules.GetEnumerator())
                    {
                        while (enumerator.MoveNext())
                        {
                            MethodInvoker oDel = null;
                            ResponderRule oCandidate = enumerator.Current;
                            if (oCandidate.sAction.OICEquals("*bpu") && CheckMatch(oSession, oCandidate))
                            {
                                if (oCandidate.bDisableOnMatch)
                                {
                                    oCandidate.IsEnabled = false;
                                    if (oDel == null)
                                    {
                                        oDel = delegate {
                                            oCandidate.ViewItem.Checked = false;
                                        };
                                    }
                                    FiddlerApplication.UIInvokeAsync(oDel, null);
                                }
                                oSession["x-breakrequest"] = "AutoResponder";
                                return;
                            }
                        }
                    }
                }
                finally
                {
                    this.FreeReaderLock();
                }
            }
        }

        internal bool ExportFARX(string sFilename)
        {
            return this.SaveRules(sFilename);
        }

        private void FreeReaderLock()
        {
            this._RWLockRules.ExitReadLock();
        }

        private void FreeWriterLock()
        {
            this._RWLockRules.ExitWriteLock();
        }

        private void GetReaderLock()
        {
            this._RWLockRules.EnterReadLock();
        }

        private void GetWriterLock()
        {
            this._RWLockRules.EnterWriteLock();
        }

        private static bool HandleMatch(Session oSession, ResponderRule oMatch)
        {
            setStringDelegate oDel = null;
            setStringDelegate delegate3 = null;
            bool flag = oSession.HTTPMethodIs("CONNECT");
            if (oMatch.sAction.StartsWith("*"))
            {
                if (oMatch.sAction.OICEquals("*drop"))
                {
                    DoDelay(oMatch);
                    if ((oSession.oRequest != null) && (oSession.oRequest.pipeClient != null))
                    {
                        oSession.oRequest.pipeClient.End();
                    }
                    oSession.utilCreateResponseAndBypassServer();
                    oSession.oResponse.headers.SetStatus(0, "Client Connection Dropped");
                    _MarkMatch(oSession, oMatch);
                    oSession.state = SessionStates.Aborted;
                    return true;
                }
                if (oMatch.sAction.OICEquals("*reset"))
                {
                    DoDelay(oMatch);
                    if ((oSession.oRequest != null) && (oSession.oRequest.pipeClient != null))
                    {
                        oSession.oRequest.pipeClient.EndWithRST();
                    }
                    oSession.utilCreateResponseAndBypassServer();
                    oSession.oResponse.headers.SetStatus(0, "Client Connection Reset");
                    _MarkMatch(oSession, oMatch);
                    oSession.state = SessionStates.Aborted;
                    return true;
                }
                if (oMatch.sAction.OICStartsWith("*ReplyWithTunnel"))
                {
                    if (!flag)
                    {
                        return false;
                    }
                    DoDelay(oMatch);
                    oSession.oFlags["X-ReplyWithTunnel"] = "*Reply rule";
                    _MarkMatch(oSession, oMatch);
                    return true;
                }
                if (oMatch.sAction.OICStartsWith("*CORSPreflightAllow"))
                {
                    DoDelay(oMatch);
                    oSession.utilCreateResponseAndBypassServer();
                    oSession.oResponse.headers.SetStatus(200, "Fiddler CORSPreflightAllow");
                    string str = oSession.oRequest["Origin"];
                    if (string.IsNullOrEmpty(str))
                    {
                        str = "*";
                    }
                    oSession.oResponse["Access-Control-Allow-Origin"] = str;
                    string str2 = oSession.oRequest["Access-Control-Request-Method"];
                    if (!string.IsNullOrEmpty(str2))
                    {
                        oSession.oResponse["Access-Control-Allow-Methods"] = str2;
                    }
                    string str3 = oSession.oRequest["Access-Control-Request-Headers"];
                    if (!string.IsNullOrEmpty(str3))
                    {
                        oSession.oResponse["Access-Control-Allow-Headers"] = str3;
                    }
                    oSession.oResponse["Access-Control-Max-Age"] = "1";
                    oSession.oResponse["Access-Control-Allow-Credentials"] = "true";
                    _MarkMatch(oSession, oMatch);
                    oSession.state = SessionStates.Aborted;
                    return true;
                }
                if (oMatch.sAction.OICStartsWith("*delay:"))
                {
                    int result = 0;
                    if (int.TryParse(Utilities.TrimBefore(oMatch.sAction, ':'), out result))
                    {
                        oSession.oFlags["x-AutoResponder-Delay"] = result.ToString();
                        Thread.Sleep(result);
                    }
                    return false;
                }
                if (oMatch.sAction.OICStartsWith("*flag:"))
                {
                    string key = Utilities.TrimAfter(oMatch.sAction.Substring(6), "=");
                    string str5 = Utilities.TrimBefore(oMatch.sAction, "=");
                    if (str5.Length > 0)
                    {
                        oSession.oFlags[key] = str5;
                    }
                    else
                    {
                        oSession.oFlags.Remove(key);
                    }
                    return false;
                }
                if (oMatch.sAction.OICStartsWith("*header:"))
                {
                    string sHeaderName = Utilities.TrimAfter(oMatch.sAction.Substring(8), "=");
                    string str7 = Utilities.TrimBefore(oMatch.sAction, "=");
                    if (str7.Length > 0)
                    {
                        oSession.oRequest[sHeaderName] = str7;
                    }
                    else
                    {
                        oSession.oRequest.headers.Remove(sHeaderName);
                    }
                    return false;
                }
                if (oMatch.sAction.OICEquals("*bpafter"))
                {
                    oSession["x-breakresponse"] = "AutoResponder";
                    oSession.bBufferResponse = true;
                    return false;
                }
                if (oMatch.sAction.OICStartsWith("*redir:") && !flag)
                {
                    DoDelay(oMatch);
                    oSession.utilCreateResponseAndBypassServer();
                    oSession.oResponse.headers.SetStatus(0x133, "AutoRedir");
                    if (oDel == null)
                    {
                        oDel = delegate (string sReplaceWith) {
                            oSession.oResponse.headers["Location"] = sReplaceWith.Substring(7);
                        };
                    }
                    if (!IfRuleIsRegExCallReplacementFunction(oMatch, oSession.fullUrl, oDel))
                    {
                        oSession.oResponse.headers["Location"] = oMatch.sAction.Substring(7);
                    }
                    oSession.oResponse.headers["Cache-Control"] = "max-age=0, must-revalidate";
                    _MarkMatch(oSession, oMatch);
                    return true;
                }
                if (oMatch.sAction.OICEquals("*exit"))
                {
                    DoDelay(oMatch);
                    return true;
                }
                if (oMatch.sAction.OICStartsWith("*script:"))
                {
                    string sMethodName = oMatch.sAction.Substring("*script:".Length);
                    bool flag2 = false;
                    string str9 = string.Empty;
                    try
                    {
                        oSession["x-AutoResponder"] = "Matched: " + oMatch.sMatch + ", ran: " + oMatch.sAction;
                        flag2 = FiddlerApplication.scriptRules.DoMethod(sMethodName, new Session[] { oSession });
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.ReportException(exception, "AutoResponder Error", "The AutoResponder rule failed to fire.");
                        str9 = Utilities.DescribeException(exception);
                    }
                    if (!flag2)
                    {
                        oSession.utilCreateResponseAndBypassServer();
                        oSession.oResponse.headers.SetStatus(500, "Invalid AutoResponse");
                        oSession.utilSetResponseBody(string.Format("The FiddlerScript function '{0}' could not be executed as an AutoResponder action.\r\n{1}\r\n", sMethodName, str9));
                    }
                    if (sMethodName.OICContains("filter"))
                    {
                        return false;
                    }
                    if (!oSession.oFlags.ContainsKey("ui-backcolor"))
                    {
                        oSession["ui-backcolor"] = sColorAutoResponded;
                    }
                    return true;
                }
            }
            if (oMatch.HasImportedResponse)
            {
                if (flag && (oMatch._oResponseHeaders.HTTPResponseCode == 200))
                {
                    return false;
                }
                if (oSession.state < SessionStates.SendingRequest)
                {
                    oSession.utilCreateResponseAndBypassServer();
                    _MarkMatch(oSession, oMatch);
                }
                else
                {
                    FiddlerApplication.Log.LogFormat("fiddler.autoresponder.error> AutoResponder will not respond to a request which is already in-flight; Session #{0} is at state: {1}", new object[] { oSession.id, oSession.state });
                    return true;
                }
                if ((oMatch._arrResponseBodyBytes == null) || (oMatch._oResponseHeaders == null))
                {
                    FiddlerApplication.Log.LogString("fiddler.autoresponder.error> Response data from imported session is missing.");
                    return true;
                }
                DoDelay(oMatch);
                if (oSession.HTTPMethodIs("HEAD"))
                {
                    oSession.responseBodyBytes = Utilities.emptyByteArray;
                }
                else
                {
                    oSession.responseBodyBytes = oMatch._arrResponseBodyBytes;
                }
                oSession.oResponse.headers = (HTTPResponseHeaders) oMatch._oResponseHeaders.Clone();
                oSession.state = SessionStates.AutoTamperResponseBefore;
                return true;
            }
            if (!flag && oMatch.sAction.OICStartsWithAny(new string[] { "http://", "https://", "ftp://" }))
            {
                DoDelay(oMatch);
                _MarkMatch(oSession, oMatch);
                oSession.oFlags["X-OriginalURL"] = oSession.fullUrl;
                if (delegate3 == null)
                {
                    delegate3 = delegate (string sReplaceWith) {
                        oSession.fullUrl = sReplaceWith;
                    };
                }
                if (!IfRuleIsRegExCallReplacementFunction(oMatch, oSession.fullUrl, delegate3))
                {
                    oSession.fullUrl = oMatch.sAction;
                }
                return true;
            }
            DoDelay(oMatch);
            if (!IfRuleIsRegExCallReplacementFunction(oMatch, oSession.fullUrl, delegate (string sReplaceWith) {
                if (sReplaceWith.OICStartsWithAny(new string[] { "http://", "https://", "ftp://" }))
                {
                    oSession.oFlags["X-OriginalURL"] = oSession.fullUrl;
                    oSession.fullUrl = sReplaceWith;
                }
                else if ('\\' == Path.DirectorySeparatorChar)
                {
                    oSession["x-replywithfile"] = sReplaceWith.Replace('/', '\\');
                }
            }))
            {
                oSession["x-replywithfile"] = oMatch.sAction;
            }
            _MarkMatch(oSession, oMatch);
            return true;
        }

        private static bool IfRuleIsRegExCallReplacementFunction(ResponderRule oMatch, string sInURI, setStringDelegate oDel)
        {
            string str2;
            string sMatch = oMatch.sMatch;
            if (sMatch.OICStartsWith("METHOD:"))
            {
                sMatch = Utilities.TrimBefore(sMatch.Substring(7), ' ');
            }
            if (sMatch.Length >= 7)
            {
                if (sMatch.OICStartsWith("REGEX:"))
                {
                    str2 = sMatch.Substring(6);
                    goto Label_0066;
                }
                if (sMatch.OICStartsWith("URLWithBody:REGEX:"))
                {
                    str2 = Utilities.TrimAfter(sMatch.Substring(0x12), ' ');
                    goto Label_0066;
                }
            }
            return false;
        Label_0066:
            if (str2 == ".*")
            {
                str2 = "^.+$";
            }
            try
            {
                string sNew = new Regex(str2).Replace(sInURI, oMatch.sAction);
                oDel(sNew);
            }
            catch
            {
                return false;
            }
            return true;
        }

        internal bool ImportFARX(string sFilename)
        {
            return this.LoadRules(sFilename, false);
        }

        public bool ImportSAZ(string sFilename)
        {
            return this.ImportSAZ(sFilename, false);
        }

        public bool ImportSAZ(string sFilename, bool bUsePlaybackHeuristics)
        {
            Session[] oSessions = Utilities.ReadSessionArchive(sFilename, true);
            if (oSessions == null)
            {
                return false;
            }
            if (sFilename.OICStartsWith(CONFIG.GetPath("Captures")))
            {
                sFilename = sFilename.Substring(CONFIG.GetPath("Captures").Length);
            }
            else
            {
                sFilename = Utilities.CollapsePath(sFilename);
            }
            return this.ImportSessions(oSessions, sFilename, bUsePlaybackHeuristics);
        }

        public bool ImportSessions(Session[] oSessions)
        {
            return this.ImportSessions(oSessions, null, false);
        }

        private bool ImportSessions(Session[] oSessions, string sAnnotation, bool bUsePlaybackHeuristics)
        {
            if ((oSessions == null) || (oSessions.Length < 1))
            {
                return false;
            }
            Dictionary<string, List<HTTPHeaderItem>> dictionary = null;
            foreach (Session session in oSessions)
            {
                if (session.HTTPMethodIs("CONNECT") && (200 == session.responseCode))
                {
                    if (bUsePlaybackHeuristics)
                    {
                        string sRule = "METHOD:CONNECT " + session.fullUrl;
                        if (this._alRules.Find(delegate (ResponderRule oCandidateRule) {
                            return oCandidateRule.sMatch == sRule;
                        }) == null)
                        {
                            this.AddRule(sRule, "*ReplyWithTunnel", true);
                        }
                    }
                }
                else if (session.bHasResponse && (session.oResponse != null))
                {
                    if ((bUsePlaybackHeuristics && (0x191 == session.responseCode)) && session.oResponse.headers.Exists("WWW-Authenticate"))
                    {
                        if (session.oResponse.headers.Exists("Set-Cookie"))
                        {
                            if (dictionary == null)
                            {
                                dictionary = new Dictionary<string, List<HTTPHeaderItem>>();
                            }
                            dictionary[session.fullUrl] = session.oResponse.headers.FindAll("Set-Cookie");
                        }
                    }
                    else
                    {
                        string str;
                        List<HTTPHeaderItem> list;
                        if ((bUsePlaybackHeuristics && session.HTTPMethodIs("POST")) && (Utilities.HasHeaders(session.oRequest) && session.oRequest.headers.Exists("SOAPAction")))
                        {
                            str = "Header:SOAPAction=" + session.oRequest.headers["SOAPAction"];
                        }
                        else if (!session.HTTPMethodIs("GET"))
                        {
                            str = string.Format("METHOD:{0} EXACT:{1}", session.RequestMethod, session.fullUrl);
                        }
                        else
                        {
                            str = "EXACT:" + session.fullUrl;
                        }
                        string sDescription = string.Format("*{0}-{1}", session.responseCode, (sAnnotation == null) ? ("SESSION_" + session.id.ToString()) : (sAnnotation + "#" + session.oFlags["x-LoadedFrom"]));
                        int iLatencyMS = 0;
                        if (session.Timers != null)
                        {
                            TimeSpan span = (TimeSpan) (session.Timers.ServerBeginResponse - session.Timers.ClientDoneRequest);
                            iLatencyMS = (int) span.TotalMilliseconds;
                        }
                        byte[] arrResponseBody = Utilities.Dupe(session.responseBodyBytes);
                        HTTPResponseHeaders oRH = (HTTPResponseHeaders) session.oResponse.headers.Clone();
                        if ((dictionary != null) && dictionary.TryGetValue(session.fullUrl, out list))
                        {
                            dictionary.Remove(session.fullUrl);
                            foreach (HTTPHeaderItem item in list)
                            {
                                oRH.Add(item.Name, item.Value);
                            }
                        }
                        if (bUsePlaybackHeuristics)
                        {
                            bool flag = !session.HTTPMethodIs("GET");
                            using (List<ResponderRule>.Enumerator enumerator2 = this._alRules.GetEnumerator())
                            {
                                while (enumerator2.MoveNext())
                                {
                                    MethodInvoker oDel = null;
                                    ResponderRule priorRule = enumerator2.Current;
                                    if (priorRule.sMatch == str)
                                    {
                                        priorRule.bDisableOnMatch = true;
                                    }
                                    else if (flag && (priorRule.sMatch == ("EXACT:" + session.fullUrl)))
                                    {
                                        priorRule.sMatch = "METHOD:GET " + priorRule.sMatch;
                                        if (oDel == null)
                                        {
                                            oDel = delegate {
                                                if (priorRule.ViewItem != null)
                                                {
                                                    priorRule.ViewItem.SubItems[0].Text = priorRule.sMatch;
                                                }
                                            };
                                        }
                                        FiddlerApplication.UIInvokeAsync(oDel, null);
                                    }
                                }
                            }
                        }
                        this.AddRule(str, oRH, arrResponseBody, sDescription, iLatencyMS, true);
                    }
                }
            }
            this._bRuleListIsDirty = true;
            return true;
        }

        private static bool IsBodyMatch(Session oSession, string sBodyToMatch)
        {
            if ((oSession == null) || string.IsNullOrEmpty(sBodyToMatch))
            {
                return true;
            }
            try
            {
                string requestBodyAsString = oSession.GetRequestBodyAsString();
                if (string.IsNullOrEmpty(requestBodyAsString))
                {
                    return false;
                }
                if ((sBodyToMatch.Length > 6) && sBodyToMatch.OICStartsWith("REGEX:"))
                {
                    bool flag;
                    string pattern = sBodyToMatch.Substring(6);
                    try
                    {
                        Regex regex = new Regex(pattern);
                        if (!regex.Match(requestBodyAsString).Success)
                        {
                            return false;
                        }
                        flag = true;
                    }
                    catch
                    {
                    }
                    return flag;
                }
                if ((sBodyToMatch.Length > 6) && sBodyToMatch.OICStartsWith("EXACT:"))
                {
                    return sBodyToMatch.Substring(6).Equals(requestBodyAsString, StringComparison.Ordinal);
                }
                if ((sBodyToMatch.Length > 4) && sBodyToMatch.OICStartsWith("NOT:"))
                {
                    string toMatch = sBodyToMatch.Substring(4);
                    return !requestBodyAsString.OICContains(toMatch);
                }
                if (!requestBodyAsString.OICContains(sBodyToMatch))
                {
                    return false;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        internal void LoadRules()
        {
            this.LoadRules(CONFIG.GetPath("AutoResponderDefaultRules"), true);
        }

        public bool LoadRules(string sFilename)
        {
            return this.LoadRules(sFilename, true);
        }

        public bool LoadRules(string sFilename, bool bIsDefaultRuleFile)
        {
            if (bIsDefaultRuleFile)
            {
                this.ClearRules();
            }
            try
            {
                FileStream stream;
                bool flag = false;
                if (!File.Exists(sFilename) || (new FileInfo(sFilename).Length < 0x8fL))
                {
                    return false;
                }
                try
                {
                    stream = new FileStream(sFilename, FileMode.Open, FileAccess.Read, FileShare.Read);
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception, "AutoResponder Rules Unreadable", string.Format("Your AutoResponder settings file exists, but it is unreadable. Filename: {0}\nError Code: 0x{1:x}", sFilename, Marshal.GetHRForException(exception)));
                    if (bIsDefaultRuleFile)
                    {
                        this.IsEnabled = false;
                    }
                    return false;
                }
                using (stream)
                {
                    XmlTextReader reader = new XmlTextReader(stream);
                    reader.WhitespaceHandling = WhitespaceHandling.None;
                    while (reader.Read())
                    {
                        string str7;
                        if ((reader.NodeType == XmlNodeType.Element) && ((str7 = reader.Name) != null))
                        {
                            if (!(str7 == "State"))
                            {
                                if (str7 == "ResponseRule")
                                {
                                    goto Label_0122;
                                }
                            }
                            else if (bIsDefaultRuleFile)
                            {
                                this.IsEnabled = "true" == reader.GetAttribute("Enabled");
                                this.PermitFallthrough = !("false" == reader.GetAttribute("Fallthrough"));
                                this.UseLatency = "true" == reader.GetAttribute("UseLatency");
                            }
                        }
                        continue;
                    Label_0122:
                        try
                        {
                            string attribute = reader.GetAttribute("Match");
                            string sDescription = reader.GetAttribute("Action");
                            int iLatencyMS = 0;
                            string s = reader.GetAttribute("Latency");
                            if (s != null)
                            {
                                iLatencyMS = XmlConvert.ToInt32(s);
                            }
                            string str4 = reader.GetAttribute("Comment");
                            if (!string.IsNullOrEmpty(str4))
                            {
                                flag = true;
                            }
                            bool flag2 = false;
                            s = reader.GetAttribute("DisableAfterMatch");
                            if ("true" == s)
                            {
                                flag2 = true;
                            }
                            bool bEnabled = "false" != reader.GetAttribute("Enabled");
                            string str5 = reader.GetAttribute("Headers");
                            if (string.IsNullOrEmpty(str5))
                            {
                                this.AddRule(attribute, null, null, sDescription, str4, iLatencyMS, bEnabled).bDisableOnMatch = flag2;
                            }
                            else
                            {
                                byte[] emptyByteArray;
                                HTTPResponseHeaders oRH = new HTTPResponseHeaders();
                                str5 = Encoding.UTF8.GetString(Convert.FromBase64String(str5));
                                oRH.AssignFromString(str5);
                                string str6 = reader.GetAttribute("DeflatedBody");
                                if (!string.IsNullOrEmpty(str6))
                                {
                                    emptyByteArray = Utilities.DeflaterExpand(Convert.FromBase64String(str6));
                                }
                                else
                                {
                                    str6 = reader.GetAttribute("Body");
                                    if (!string.IsNullOrEmpty(str6))
                                    {
                                        emptyByteArray = Convert.FromBase64String(str6);
                                    }
                                    else
                                    {
                                        emptyByteArray = Utilities.emptyByteArray;
                                    }
                                }
                                this.AddRule(attribute, oRH, emptyByteArray, sDescription, str4, iLatencyMS, bEnabled).bDisableOnMatch = flag2;
                            }
                            continue;
                        }
                        catch
                        {
                            continue;
                        }
                    }
                }
                if (bIsDefaultRuleFile && (this._alRules.Count < 1))
                {
                    this.IsEnabled = false;
                }
                if (bIsDefaultRuleFile)
                {
                    this._bRuleListIsDirty = false;
                }
                if (flag)
                {
                    this.oAutoResponderUI.lvRespondRules.Columns[3].Width = Math.Max(this.oAutoResponderUI.lvRespondRules.Columns[3].Width, 70);
                }
                return true;
            }
            catch (Exception exception2)
            {
                FiddlerApplication.ReportException(exception2, "AutoResponder Rules Unreadable", "Failed to load AutoResponder settings from " + sFilename);
                if (bIsDefaultRuleFile)
                {
                    this.IsEnabled = false;
                }
                return false;
            }
        }

        internal bool PromoteRule(ResponderRule oRule)
        {
            bool flag;
            try
            {
                this.GetWriterLock();
                int index = this._alRules.IndexOf(oRule);
                if (index > 0)
                {
                    this._alRules.Reverse(index - 1, 2);
                    this._bRuleListIsDirty = true;
                    return true;
                }
                flag = false;
            }
            finally
            {
                this.FreeWriterLock();
            }
            return flag;
        }

        public bool RemoveRule(ResponderRule oRule)
        {
            try
            {
                try
                {
                    this.GetWriterLock();
                    this._alRules.Remove(oRule);
                }
                finally
                {
                    this.FreeWriterLock();
                }
                this._bRuleListIsDirty = true;
                if (oRule.ViewItem != null)
                {
                    oRule.ViewItem.Remove();
                    oRule.ViewItem = null;
                }
                if (oRule._oEditor != null)
                {
                    oRule._oEditor.Dispose();
                    oRule._oEditor = null;
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        internal void SaveDefaultRules()
        {
            if (this._bRuleListIsDirty)
            {
                this.SaveRules(CONFIG.GetPath("AutoResponderDefaultRules"));
                this._bRuleListIsDirty = false;
            }
        }

        public bool SaveRules(string sFilename)
        {
            try
            {
                Utilities.EnsureOverwritable(sFilename);
                using (XmlTextWriter writer = new XmlTextWriter(sFilename, Encoding.UTF8))
                {
                    writer.Formatting = Formatting.Indented;
                    writer.WriteStartDocument();
                    writer.WriteStartElement("AutoResponder");
                    writer.WriteAttributeString("LastSave", XmlConvert.ToString(DateTime.Now, XmlDateTimeSerializationMode.RoundtripKind));
                    writer.WriteAttributeString("FiddlerVersion", Application.ProductVersion);
                    writer.WriteStartElement("State");
                    writer.WriteAttributeString("Enabled", XmlConvert.ToString(this._bEnabled));
                    writer.WriteAttributeString("Fallthrough", XmlConvert.ToString(this._bPermitFallthrough));
                    writer.WriteAttributeString("UseLatency", XmlConvert.ToString(this._bUseLatency));
                    try
                    {
                        this.GetReaderLock();
                        foreach (ResponderRule rule in this._alRules)
                        {
                            writer.WriteStartElement("ResponseRule");
                            writer.WriteAttributeString("Match", rule.sMatch);
                            writer.WriteAttributeString("Action", rule.sAction);
                            if (rule.bDisableOnMatch)
                            {
                                writer.WriteAttributeString("DisableAfterMatch", XmlConvert.ToString(rule.bDisableOnMatch));
                            }
                            if (rule.iLatency > 0)
                            {
                                writer.WriteAttributeString("Latency", rule.iLatency.ToString());
                            }
                            if (!string.IsNullOrEmpty(rule.sComment))
                            {
                                writer.WriteAttributeString("Comment", rule.sComment);
                            }
                            writer.WriteAttributeString("Enabled", XmlConvert.ToString(rule.IsEnabled));
                            if (rule.HasImportedResponse)
                            {
                                byte[] buffer = rule._oResponseHeaders.ToByteArray(true, true);
                                writer.WriteStartAttribute("Headers");
                                writer.WriteBase64(buffer, 0, buffer.Length);
                                writer.WriteEndAttribute();
                                byte[] writeData = rule._arrResponseBodyBytes;
                                if ((writeData != null) && (writeData.Length > 0))
                                {
                                    if (writeData.Length > 0x800)
                                    {
                                        byte[] buffer3 = Utilities.DeflaterCompress(writeData);
                                        if (buffer3.Length < (0.9 * writeData.Length))
                                        {
                                            writer.WriteStartAttribute("DeflatedBody");
                                            writer.WriteBase64(buffer3, 0, buffer3.Length);
                                            writer.WriteEndAttribute();
                                            writeData = null;
                                        }
                                    }
                                    if (writeData != null)
                                    {
                                        writer.WriteStartAttribute("Body");
                                        writer.WriteBase64(writeData, 0, writeData.Length);
                                        writer.WriteEndAttribute();
                                    }
                                }
                            }
                            writer.WriteEndElement();
                        }
                    }
                    finally
                    {
                        this.FreeReaderLock();
                    }
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Failed to save AutoResponder Rules", "Fiddler failed to save AutoResponder rules. This is often caused by redirected and misconfigured User Profile folders on corporate networks; you may need to contact your network administrator.");
                return false;
            }
        }

        internal void SetFontSize(float flFontSize)
        {
            if (this.oAutoResponderUI != null)
            {
                this.oAutoResponderUI.SetFontSize(flFontSize);
            }
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                this.GetReaderLock();
                builder.AppendFormat("The AutoResponder list contains {0} rules.\r\n", this._alRules.Count);
                foreach (ResponderRule rule in this._alRules)
                {
                    builder.AppendFormat("\t{0}\t->\t{1}\r\n", rule.sMatch, rule.sAction);
                }
            }
            finally
            {
                this.FreeReaderLock();
            }
            return builder.ToString();
        }

        public bool IsEnabled
        {
            get
            {
                return this._bEnabled;
            }
            set
            {
                if (value != this._bEnabled)
                {
                    FiddlerApplication.UIInvoke(delegate {
                        this.oAutoResponderUI.cbAutoRespond.Checked = this._bEnabled = value;
                    });
                    this._bRuleListIsDirty = true;
                }
            }
        }

        public bool IsRuleListDirty
        {
            get
            {
                return this._bRuleListIsDirty;
            }
            set
            {
                this._bRuleListIsDirty = value;
            }
        }

        public bool PermitFallthrough
        {
            get
            {
                return this._bPermitFallthrough;
            }
            set
            {
                if (value != this._bPermitFallthrough)
                {
                    FiddlerApplication.UIInvoke(delegate {
                        this.oAutoResponderUI.cbRespondPassthrough.Checked = this._bPermitFallthrough = value;
                    });
                    this._bRuleListIsDirty = true;
                }
            }
        }

        public bool UseLatency
        {
            get
            {
                return this._bUseLatency;
            }
            set
            {
                if (value != this._bUseLatency)
                {
                    FiddlerApplication.UIInvoke(delegate {
                        this.oAutoResponderUI.cbRespondUseLatency.Checked = this._bUseLatency = value;
                        this.oAutoResponderUI.lvRespondRules.Columns[2].Width = value ? 60 : 0;
                    });
                    this._bRuleListIsDirty = true;
                }
            }
        }
    }
}

