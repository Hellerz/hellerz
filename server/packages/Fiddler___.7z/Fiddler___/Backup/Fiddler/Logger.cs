﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    public class Logger
    {
        private EventHandler<LogEventArgs> OnLogString;
        private List<string> queueStartupMessages;

        public event EventHandler<LogEventArgs> OnLogString
        {
            add
            {
                EventHandler<LogEventArgs> handler2;
                EventHandler<LogEventArgs> onLogString = this.OnLogString;
                do
                {
                    handler2 = onLogString;
                    EventHandler<LogEventArgs> handler3 = (EventHandler<LogEventArgs>) Delegate.Combine(handler2, value);
                    onLogString = Interlocked.CompareExchange<EventHandler<LogEventArgs>>(ref this.OnLogString, handler3, handler2);
                }
                while (onLogString != handler2);
            }
            remove
            {
                EventHandler<LogEventArgs> handler2;
                EventHandler<LogEventArgs> onLogString = this.OnLogString;
                do
                {
                    handler2 = onLogString;
                    EventHandler<LogEventArgs> handler3 = (EventHandler<LogEventArgs>) Delegate.Remove(handler2, value);
                    onLogString = Interlocked.CompareExchange<EventHandler<LogEventArgs>>(ref this.OnLogString, handler3, handler2);
                }
                while (onLogString != handler2);
            }
        }

        public Logger(bool bQueueStartup)
        {
            this.queueStartupMessages = bQueueStartup ? new List<string>() : null;
        }

        internal void FlushStartupMessages()
        {
            if (this.queueStartupMessages != null)
            {
                EventHandler<LogEventArgs> onLogString = this.OnLogString;
                if (onLogString != null)
                {
                    List<string> queueStartupMessages = this.queueStartupMessages;
                    this.queueStartupMessages = null;
                    foreach (string str in queueStartupMessages)
                    {
                        LogEventArgs e = new LogEventArgs(str);
                        onLogString(this, e);
                    }
                }
                else
                {
                    this.queueStartupMessages = null;
                }
            }
        }

        public void LogFormat(string format, params object[] args)
        {
            this.LogString(string.Format(format, args));
        }

        public void LogString(string sMsg)
        {
            if (!string.IsNullOrEmpty(sMsg))
            {
                FiddlerApplication.DebugSpew(sMsg);
                if (this.queueStartupMessages != null)
                {
                    List<string> list;
                    bool lockTaken = false;
                    try
                    {
                        Monitor.Enter(list = this.queueStartupMessages, ref lockTaken);
                        this.queueStartupMessages.Add(sMsg);
                    }
                    finally
                    {
                        if (lockTaken)
                        {
                            Monitor.Exit(list);
                        }
                    }
                }
                else
                {
                    EventHandler<LogEventArgs> onLogString = this.OnLogString;
                    if (onLogString != null)
                    {
                        LogEventArgs e = new LogEventArgs(sMsg);
                        onLogString(this, e);
                    }
                }
            }
        }
    }
}

