﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    internal delegate void setStringDelegate(string sNew);
}

