﻿namespace Fiddler
{
    using Microsoft.Win32;
    using System;
    using System.ComponentModel;
    using System.Runtime.InteropServices;
    using System.Threading;

    internal class RegistryWatcher
    {
        private bool _disposed;
        private ManualResetEvent _eventTerminate = new ManualResetEvent(false);
        private UIntPtr _hiveToWatch;
        private object _lockForThread = new object();
        private RegistryEventFilter _regFilter = RegistryEventFilter.Values;
        private string _sSubKey;
        private Thread _threadWaitForChanges;
        private static readonly UIntPtr HKEY_CLASSES_ROOT = ((UIntPtr) (-2147483648));
        private static readonly UIntPtr HKEY_CURRENT_CONFIG = ((UIntPtr) (-2147483643));
        private static readonly UIntPtr HKEY_CURRENT_USER = ((UIntPtr) (-2147483647));
        private static readonly UIntPtr HKEY_DYN_DATA = ((UIntPtr) (-2147483642));
        private static readonly UIntPtr HKEY_LOCAL_MACHINE = ((UIntPtr) (-2147483646));
        private static readonly UIntPtr HKEY_PERFORMANCE_DATA = ((UIntPtr) (-2147483644));
        private static readonly UIntPtr HKEY_USERS = ((UIntPtr) (-2147483645));
        private const int KEY_NOTIFY = 0x10;
        private const int KEY_QUERY_VALUE = 1;
        private EventHandler KeyChanged;
        private const int STANDARD_RIGHTS_READ = 0x20000;

        public event EventHandler KeyChanged
        {
            add
            {
                EventHandler handler2;
                EventHandler keyChanged = this.KeyChanged;
                do
                {
                    handler2 = keyChanged;
                    EventHandler handler3 = (EventHandler) Delegate.Combine(handler2, value);
                    keyChanged = Interlocked.CompareExchange<EventHandler>(ref this.KeyChanged, handler3, handler2);
                }
                while (keyChanged != handler2);
            }
            remove
            {
                EventHandler handler2;
                EventHandler keyChanged = this.KeyChanged;
                do
                {
                    handler2 = keyChanged;
                    EventHandler handler3 = (EventHandler) Delegate.Remove(handler2, value);
                    keyChanged = Interlocked.CompareExchange<EventHandler>(ref this.KeyChanged, handler3, handler2);
                }
                while (keyChanged != handler2);
            }
        }

        private RegistryWatcher(RegistryHive registryHive, string subKey)
        {
            this.InitRegistryKey(registryHive, subKey);
        }

        public void Dispose()
        {
            this.Stop();
            this._disposed = true;
            GC.SuppressFinalize(this);
        }

        private void InitRegistryKey(RegistryHive hive, string name)
        {
            switch (hive)
            {
                case RegistryHive.ClassesRoot:
                    this._hiveToWatch = HKEY_CLASSES_ROOT;
                    break;

                case RegistryHive.CurrentUser:
                    this._hiveToWatch = HKEY_CURRENT_USER;
                    break;

                case RegistryHive.LocalMachine:
                    this._hiveToWatch = HKEY_LOCAL_MACHINE;
                    break;

                case RegistryHive.Users:
                    this._hiveToWatch = HKEY_USERS;
                    break;

                case RegistryHive.PerformanceData:
                    this._hiveToWatch = HKEY_PERFORMANCE_DATA;
                    break;

                case RegistryHive.CurrentConfig:
                    this._hiveToWatch = HKEY_CURRENT_CONFIG;
                    break;

                case RegistryHive.DynData:
                    this._hiveToWatch = HKEY_DYN_DATA;
                    break;

                default:
                    throw new InvalidEnumArgumentException("hive", (int) hive, typeof(RegistryHive));
            }
            this._sSubKey = name;
        }

        private void MonitorThread()
        {
            try
            {
                this.WatchAndNotify();
            }
            catch (Exception)
            {
            }
            this._threadWaitForChanges = null;
        }

        protected virtual void OnKeyChanged()
        {
            EventHandler keyChanged = this.KeyChanged;
            if (keyChanged != null)
            {
                keyChanged(this, null);
            }
        }

        [DllImport("advapi32.dll", SetLastError=true)]
        private static extern int RegCloseKey(IntPtr hKey);
        [DllImport("advapi32.dll", SetLastError=true)]
        private static extern int RegNotifyChangeKeyValue(IntPtr hKey, [MarshalAs(UnmanagedType.Bool)] bool bWatchSubtree, RegistryEventFilter dwNotifyFilter, IntPtr hEvent, [MarshalAs(UnmanagedType.Bool)] bool fAsynchronous);
        [DllImport("advapi32.dll", SetLastError=true)]
        private static extern int RegOpenKeyEx(UIntPtr hKey, string subKey, uint options, int samDesired, out IntPtr phkResult);
        private void Start()
        {
            object obj2;
            if (this._disposed)
            {
                throw new ObjectDisposedException(null, "This instance is already disposed");
            }
            bool lockTaken = false;
            try
            {
                Monitor.Enter(obj2 = this._lockForThread, ref lockTaken);
                if (!this.IsWatching)
                {
                    this._eventTerminate.Reset();
                    this._threadWaitForChanges = new Thread(new ThreadStart(this.MonitorThread));
                    this._threadWaitForChanges.IsBackground = true;
                    this._threadWaitForChanges.Start();
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(obj2);
                }
            }
        }

        public void Stop()
        {
            object obj2;
            if (this._disposed)
            {
                throw new ObjectDisposedException(null, "This instance is already disposed");
            }
            bool lockTaken = false;
            try
            {
                Monitor.Enter(obj2 = this._lockForThread, ref lockTaken);
                Thread thread = this._threadWaitForChanges;
                if (thread != null)
                {
                    this._eventTerminate.Set();
                    thread.Join();
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(obj2);
                }
            }
        }

        private void WatchAndNotify()
        {
            IntPtr ptr;
            int error = RegOpenKeyEx(this._hiveToWatch, this._sSubKey, 0, 0x20011, out ptr);
            if (error != 0)
            {
                throw new Win32Exception(error);
            }
            try
            {
                AutoResetEvent event2 = new AutoResetEvent(false);
                WaitHandle[] waitHandles = new WaitHandle[] { event2, this._eventTerminate };
                while (!this._eventTerminate.WaitOne(0, true))
                {
                    error = RegNotifyChangeKeyValue(ptr, false, this._regFilter, event2.SafeWaitHandle.DangerousGetHandle(), true);
                    if (error != 0)
                    {
                        throw new Win32Exception(error);
                    }
                    if (WaitHandle.WaitAny(waitHandles) == 0)
                    {
                        this.OnKeyChanged();
                    }
                }
            }
            finally
            {
                if (IntPtr.Zero != ptr)
                {
                    RegCloseKey(ptr);
                }
            }
        }

        internal static RegistryWatcher WatchKey(RegistryHive registryHive, string subKey, EventHandler oToNotify)
        {
            RegistryWatcher watcher = new RegistryWatcher(registryHive, subKey);
            watcher.KeyChanged += oToNotify;
            watcher.Start();
            return watcher;
        }

        public bool IsWatching
        {
            get
            {
                return (null != this._threadWaitForChanges);
            }
        }

        [Flags]
        private enum RegistryEventFilter : uint
        {
            ACLs = 8,
            Attributes = 2,
            Key = 1,
            Values = 4
        }
    }
}

