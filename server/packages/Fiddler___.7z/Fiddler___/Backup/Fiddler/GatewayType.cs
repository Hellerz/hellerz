﻿namespace Fiddler
{
    using System;

    public enum GatewayType : byte
    {
        Manual = 1,
        None = 0,
        System = 2,
        WPAD = 3
    }
}

