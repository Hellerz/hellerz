﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class UIViewSession : Form
    {
        private Session _SessionOwner;
        private string _sLastActiveRequestTab;
        private string _sLastActiveResponseTab;
        private IContainer components;
        private TabControl tabsRequestEditors;
        private TabControl tabsResponseEditors;
        private TabControl tabsViews;
        private TabPage tbpProperties;
        private TabPage tbpRequest;
        private TabPage tbpResponse;
        private RichTextBox txtProperties;

        public UIViewSession(Session oS) : this(oS, null)
        {
        }

        public UIViewSession(Session oS, string sTab)
        {
            this.InitializeComponent();
            this._SessionOwner = oS;
            this.txtProperties.BackColor = CONFIG.colorDisabledEdit;
            if (oS.ViewItem != null)
            {
                base.Icon = Utilities.GetIconFromImage(FiddlerApplication.UI.imglSessionIcons.Images[oS.ViewItem.ImageIndex]);
            }
            else
            {
                base.Icon = FiddlerApplication.UI.Icon;
            }
            FiddlerApplication.oInspectors.AddRequestInspectorsToTabControl(this.tabsRequestEditors, InspectorFlags.HideInNewWindow);
            FiddlerApplication.oInspectors.AddResponseInspectorsToTabControl(this.tabsResponseEditors, InspectorFlags.HideInNewWindow);
            this.tabsViews.ImageList = FiddlerApplication.UI.imglSessionIcons;
            this.tabsViews.TabPages[0].ImageIndex = 0;
            this.tabsViews.TabPages[1].ImageIndex = 2;
            this.tabsViews.TabPages[2].ImageIndex = 4;
            this.Text = string.Format("Fiddler Session #{0} - {1}", oS.id, oS.fullUrl);
            Utilities.activateTabByTitle("Headers", this.tabsRequestEditors);
            Utilities.activateTabByTitle("Headers", this.tabsResponseEditors);
            if (oS.bHasWebSocketMessages)
            {
                new WebSocketTab(this.tabsViews).DoInspectSession(oS);
                Utilities.activateTabByTitle("WebSocket", this.tabsViews);
            }
            if (!string.IsNullOrEmpty(sTab))
            {
                string str = null;
                if (sTab.Contains(">"))
                {
                    str = Utilities.TrimBefore(sTab, '>');
                    sTab = Utilities.TrimAfter(sTab, '>');
                }
                Utilities.activateTabByTitle(sTab, this.tabsViews);
                if (!string.IsNullOrEmpty(str))
                {
                    if (sTab.OICContains("Request"))
                    {
                        Utilities.activateTabByTitle(str, this.tabsRequestEditors);
                    }
                    else if (sTab.OICContains("Response"))
                    {
                        Utilities.activateTabByTitle(str, this.tabsResponseEditors);
                    }
                }
            }
            this.actUpdateAll();
            this._EnableBackButtonNavigationOfTabs();
        }

        private void _EnableBackButtonNavigationOfTabs()
        {
            this.tabsRequestEditors.Deselecting += delegate (object o, TabControlCancelEventArgs ea) {
                try
                {
                    this._sLastActiveRequestTab = ea.TabPage.Text;
                }
                catch
                {
                }
            };
            this.tabsResponseEditors.Deselecting += delegate (object o, TabControlCancelEventArgs ea) {
                try
                {
                    this._sLastActiveResponseTab = ea.TabPage.Text;
                }
                catch
                {
                }
            };
            this.tabsRequestEditors.MouseDown += delegate (object o, MouseEventArgs mea) {
                if (((mea.Button == MouseButtons.XButton1) || (mea.Button == MouseButtons.XButton2)) && !string.IsNullOrEmpty(this._sLastActiveRequestTab))
                {
                    Utilities.activateTabByTitle(this._sLastActiveRequestTab, this.tabsRequestEditors);
                }
            };
            this.tabsResponseEditors.MouseDown += delegate (object o, MouseEventArgs mea) {
                if (((mea.Button == MouseButtons.XButton1) || (mea.Button == MouseButtons.XButton2)) && !string.IsNullOrEmpty(this._sLastActiveResponseTab))
                {
                    Utilities.activateTabByTitle(this._sLastActiveResponseTab, this.tabsResponseEditors);
                }
            };
        }

        private void actUpdateAll()
        {
            if (!FiddlerApplication.isClosing)
            {
                this.actUpdateRequest();
                this.actUpdateResponse();
                this.actUpdateProperties();
            }
        }

        private void actUpdateProperties()
        {
            if (!FiddlerApplication.isClosing)
            {
                try
                {
                    this.txtProperties.Text = SessionProperties.GetSessionProperties(this._SessionOwner);
                    this.txtProperties.Select(0, 0);
                }
                catch (Exception exception)
                {
                    this.txtProperties.Clear();
                    this.txtProperties.AppendText(exception.Message + "\r\n" + exception.StackTrace);
                }
            }
        }

        private void actUpdateRequest()
        {
            if ((this.tabsRequestEditors != null) && (this.tabsRequestEditors.SelectedTab != null))
            {
                Inspector2 tag = this.tabsRequestEditors.SelectedTab.Tag as Inspector2;
                if (tag != null)
                {
                    tag.AssignSession(this._SessionOwner);
                    (tag as IBaseInspector2).bReadOnly = true;
                }
            }
        }

        private void actUpdateResponse()
        {
            if ((this.tabsResponseEditors != null) && (this.tabsResponseEditors.SelectedTab != null))
            {
                Inspector2 tag = this.tabsResponseEditors.SelectedTab.Tag as Inspector2;
                if (tag != null)
                {
                    tag.AssignSession(this._SessionOwner);
                    (tag as IBaseInspector2).bReadOnly = true;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabsResponseEditors = new TabControl();
            this.tabsRequestEditors = new TabControl();
            this.tabsViews = new TabControl();
            this.tbpRequest = new TabPage();
            this.tbpResponse = new TabPage();
            this.tbpProperties = new TabPage();
            this.txtProperties = new RichTextBox();
            this.tabsViews.SuspendLayout();
            this.tbpRequest.SuspendLayout();
            this.tbpResponse.SuspendLayout();
            this.tbpProperties.SuspendLayout();
            base.SuspendLayout();
            this.tabsResponseEditors.Dock = DockStyle.Fill;
            this.tabsResponseEditors.Location = new Point(3, 3);
            this.tabsResponseEditors.Multiline = true;
            this.tabsResponseEditors.Name = "tabsResponseEditors";
            this.tabsResponseEditors.SelectedIndex = 0;
            this.tabsResponseEditors.Size = new Size(0x2ec, 0x1b3);
            this.tabsResponseEditors.SizeMode = TabSizeMode.FillToRight;
            this.tabsResponseEditors.TabIndex = 10;
            this.tabsResponseEditors.SelectedIndexChanged += new EventHandler(this.tabsResponseEditors_SelectedIndexChanged);
            this.tabsRequestEditors.Dock = DockStyle.Fill;
            this.tabsRequestEditors.Location = new Point(3, 3);
            this.tabsRequestEditors.Multiline = true;
            this.tabsRequestEditors.Name = "tabsRequestEditors";
            this.tabsRequestEditors.SelectedIndex = 0;
            this.tabsRequestEditors.Size = new Size(0x2ec, 0x1b3);
            this.tabsRequestEditors.SizeMode = TabSizeMode.FillToRight;
            this.tabsRequestEditors.TabIndex = 11;
            this.tabsRequestEditors.SelectedIndexChanged += new EventHandler(this.tabsRequestEditors_SelectedIndexChanged);
            this.tabsViews.Appearance = TabAppearance.FlatButtons;
            this.tabsViews.Controls.Add(this.tbpRequest);
            this.tabsViews.Controls.Add(this.tbpResponse);
            this.tabsViews.Controls.Add(this.tbpProperties);
            this.tabsViews.Dock = DockStyle.Fill;
            this.tabsViews.Location = new Point(0, 0);
            this.tabsViews.Name = "tabsViews";
            this.tabsViews.SelectedIndex = 0;
            this.tabsViews.Size = new Size(0x2fa, 470);
            this.tabsViews.TabIndex = 11;
            this.tbpRequest.Controls.Add(this.tabsRequestEditors);
            this.tbpRequest.Location = new Point(4, 0x19);
            this.tbpRequest.Name = "tbpRequest";
            this.tbpRequest.Padding = new Padding(3);
            this.tbpRequest.Size = new Size(0x2f2, 0x1b9);
            this.tbpRequest.TabIndex = 0;
            this.tbpRequest.Text = "Request";
            this.tbpRequest.UseVisualStyleBackColor = true;
            this.tbpResponse.Controls.Add(this.tabsResponseEditors);
            this.tbpResponse.Location = new Point(4, 0x19);
            this.tbpResponse.Name = "tbpResponse";
            this.tbpResponse.Padding = new Padding(3);
            this.tbpResponse.Size = new Size(0x2f2, 0x1b9);
            this.tbpResponse.TabIndex = 1;
            this.tbpResponse.Text = "Response";
            this.tbpResponse.UseVisualStyleBackColor = true;
            this.tbpProperties.Controls.Add(this.txtProperties);
            this.tbpProperties.Location = new Point(4, 0x19);
            this.tbpProperties.Name = "tbpProperties";
            this.tbpProperties.Size = new Size(0x2f2, 0x1b9);
            this.tbpProperties.TabIndex = 2;
            this.tbpProperties.Text = "Properties";
            this.tbpProperties.UseVisualStyleBackColor = true;
            this.txtProperties.BorderStyle = BorderStyle.None;
            this.txtProperties.DetectUrls = false;
            this.txtProperties.Dock = DockStyle.Fill;
            this.txtProperties.Font = new Font("Lucida Console", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtProperties.Location = new Point(0, 0);
            this.txtProperties.Name = "txtProperties";
            this.txtProperties.ReadOnly = true;
            this.txtProperties.Size = new Size(0x2f2, 0x1b9);
            this.txtProperties.TabIndex = 3;
            this.txtProperties.Text = "";
            this.txtProperties.WordWrap = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2fa, 470);
            base.Controls.Add(this.tabsViews);
            this.DoubleBuffered = true;
            this.Font = new Font("Tahoma", 8.25f);
            base.KeyPreview = true;
            base.Name = "UIViewSession";
            this.Text = "ViewSession";
            base.FormClosing += new FormClosingEventHandler(this.UIViewSession_FormClosing);
            base.KeyDown += new KeyEventHandler(this.UIViewSession_KeyDown);
            this.tabsViews.ResumeLayout(false);
            this.tbpRequest.ResumeLayout(false);
            this.tbpResponse.ResumeLayout(false);
            this.tbpProperties.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void tabsRequestEditors_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing)
            {
                this.actUpdateRequest();
            }
        }

        private void tabsResponseEditors_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing)
            {
                this.actUpdateResponse();
            }
        }

        private void UIViewSession_FormClosing(object sender, FormClosingEventArgs e)
        {
            this._SessionOwner.__ViewForm = null;
            base.Dispose();
        }

        private void UIViewSession_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                e.Handled = e.SuppressKeyPress = true;
                this.actUpdateAll();
            }
        }
    }
}

