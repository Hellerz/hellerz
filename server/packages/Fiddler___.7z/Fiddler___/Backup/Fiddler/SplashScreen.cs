﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    internal class SplashScreen : Form
    {
        private Container components;
        private const int HTCAPTION = 2;
        private Label lblProgress;
        private Label lblVersion;
        private const int WM_LBUTTONDBLCLK = 0x203;
        private const int WM_NCHITTEST = 0x84;
        private const int WM_NCLBUTTONDBLCLK = 0xa3;

        internal SplashScreen()
        {
            try
            {
                this.InitializeComponent();
                this.lblVersion.Text = string.Format("v{0}{1}", Application.ProductVersion, CONFIG.bIsBeta ? " beta" : string.Empty);
            }
            catch (ArgumentException exception)
            {
                FiddlerApplication.DoNotifyUser(string.Format("It appears that one of your computer's fonts is missing or not registered properly. Please see {0}\n\n{1}\n{2}", CONFIG.GetRedirUrl("FONTMISSING"), exception.Message, exception.StackTrace), "Fiddler is unable to start");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        internal void IndicateProgress(string sWhatIsHappening)
        {
            this.lblProgress.Text = sWhatIsHappening;
            Application.DoEvents();
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(SplashScreen));
            this.lblProgress = new Label();
            this.lblVersion = new Label();
            base.SuspendLayout();
            this.lblProgress.BackColor = Color.White;
            this.lblProgress.Font = new Font("Tahoma", 9f);
            this.lblProgress.ForeColor = Color.FromArgb(0x2d, 0xb2, 0x45);
            this.lblProgress.ImeMode = ImeMode.NoControl;
            this.lblProgress.Location = new Point(0x5e, 0x108);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new Size(0xc6, 0x33);
            this.lblProgress.TabIndex = 0;
            this.lblProgress.Text = "Loading...";
            this.lblProgress.TextAlign = ContentAlignment.BottomLeft;
            this.lblVersion.BackColor = Color.White;
            this.lblVersion.Font = new Font("Tahoma", 8.25f);
            this.lblVersion.ForeColor = Color.DimGray;
            this.lblVersion.ImeMode = ImeMode.NoControl;
            this.lblVersion.Location = new Point(0xf5, 0x59);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new Size(0x6b, 0x1c);
            this.lblVersion.TabIndex = 2;
            this.lblVersion.Text = "v0.0.0.0";
            this.lblVersion.TextAlign = ContentAlignment.TopRight;
            base.AutoScaleMode = AutoScaleMode.None;
            this.BackColor = Color.White;
            this.BackgroundImage = (Image) manager.GetObject("$this.BackgroundImage");
            base.CausesValidation = false;
            base.ClientSize = new Size(480, 320);
            base.ControlBox = false;
            base.Controls.Add(this.lblVersion);
            base.Controls.Add(this.lblProgress);
            this.Cursor = Cursors.AppStarting;
            this.Font = new Font("Tahoma", 8.25f);
            this.ForeColor = Color.White;
            base.FormBorderStyle = FormBorderStyle.None;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.Name = "SplashScreen";
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Starting Fiddler...";
            base.ResumeLayout(false);
        }

        protected override void WndProc(ref Message m)
        {
            if ((m.Msg != 0x203) && (m.Msg != 0xa3))
            {
                if (m.Msg == 0x84)
                {
                    m.Result = (IntPtr) 2;
                }
                else
                {
                    base.WndProc(ref m);
                }
            }
        }

        protected override System.Windows.Forms.CreateParams CreateParams
        {
            get
            {
                System.Windows.Forms.CreateParams createParams = base.CreateParams;
                createParams.ExStyle |= 0x2000000;
                return createParams;
            }
        }
    }
}

