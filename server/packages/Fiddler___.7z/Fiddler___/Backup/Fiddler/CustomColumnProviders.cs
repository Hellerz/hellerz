﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Runtime.InteropServices;

    internal static class CustomColumnProviders
    {
        private static string[] arrSkipIfFound = new string[] { "Transfer-Encoding", "Content-Encoding" };

        private static string AnalyzeImage(Session oS, bool bFingerprint)
        {
            if (oS.bHasResponse && (oS.responseBodyBytes.Length >= 20))
            {
                try
                {
                    MemoryStream stream = new MemoryStream(oS.responseBodyBytes);
                    using (Image image = Image.FromStream(stream, false, false))
                    {
                        Size? nullable = new Size((int) image.PhysicalDimension.Width, (int) image.PhysicalDimension.Height);
                        if (!nullable.HasValue || (nullable.Value.Height == 0))
                        {
                            return "Malformed";
                        }
                        double flAspectRatio = ((double) nullable.Value.Width) / ((double) nullable.Value.Height);
                        if (bFingerprint)
                        {
                            return ComputeImageFingerprint(image, flAspectRatio);
                        }
                        return ComputeImageRGB(image, flAspectRatio);
                    }
                }
                catch (Exception)
                {
                }
            }
            return null;
        }

        private static string ComputeImageFingerprint(Image img, double flAspectRatio)
        {
            long num;
            long num2;
            long num3;
            long num4;
            CountThumbnailColors(img, flAspectRatio, out num2, out num4, out num3, out num);
            long num5 = (num2 + num3) + num4;
            num2 = (num2 / 0x10L) / num;
            num3 = (num3 / 0x10L) / num;
            num4 = (num4 / 0x10L) / num;
            long num6 = (100L * num5) / (0x2fdL * num);
            return string.Format("{0:N2}-{1:D2}-{2:X1}{3:X1}{4:X1}", new object[] { flAspectRatio, num6, num2, num4, num3 });
        }

        private static string ComputeImageRGB(Image img, double flAspectRatio)
        {
            long num;
            long num2;
            long num3;
            long num4;
            CountThumbnailColors(img, flAspectRatio, out num2, out num4, out num3, out num);
            num2 /= num;
            num3 /= num;
            num4 /= num;
            return string.Format("{0:X2}{1:X2}{2:X2}", num2, num4, num3);
        }

        private static void CountThumbnailColors(Image img, double flAspectRatio, out long lngRed, out long lngBlue, out long lngGreen, out long lngPixelCount)
        {
            int width = 120;
            int height = 120;
            if (flAspectRatio > 1.0)
            {
                height = (int) Math.Floor((double) (120.0 * (1.0 / flAspectRatio)));
            }
            else
            {
                width = (int) Math.Floor((double) (120.0 * flAspectRatio));
            }
            lngPixelCount = height * width;
            lngRed = 0L;
            lngBlue = 0L;
            lngGreen = 0L;
            Bitmap image = new Bitmap(width, height);
            using (Graphics graphics = Graphics.FromImage(image))
            {
                graphics.DrawImage(img, new Rectangle(0, 0, width, height));
            }
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color pixel = image.GetPixel(i, j);
                    lngRed += pixel.R;
                    lngBlue += pixel.B;
                    lngGreen += pixel.G;
                }
            }
        }

        internal static string GetAspect(Session oS)
        {
            Size? imgDimensions = GetImgDimensions(oS);
            SizeF? nullable = imgDimensions.HasValue ? new SizeF?(imgDimensions.GetValueOrDefault()) : null;
            if (nullable.HasValue && (nullable.Value.Height != 0f))
            {
                return string.Format("{0:N3}", nullable.Value.Width / nullable.Value.Height);
            }
            return "0";
        }

        internal static string GetBitFlags(Session oS)
        {
            return oS.BitFlags.ToString();
        }

        internal static string GetBytesPerPixel(Session oS)
        {
            string str;
            if ((!oS.bHasResponse || (oS.responseBodyBytes.Length < 0x18)) || oS.isTunnel)
            {
                return string.Empty;
            }
            try
            {
                Size? imgDimensions = GetImgDimensions(oS);
                if (!imgDimensions.HasValue)
                {
                    return string.Empty;
                }
                str = (((float) oS.responseBodyBytes.Length) / ((float) (imgDimensions.Value.Width * imgDimensions.Value.Height))).ToString("0.00");
            }
            catch (Exception)
            {
            }
            return str;
        }

        internal static string GetClientBeginRequest(Session oS)
        {
            DateTime clientBeginRequest = oS.Timers.ClientBeginRequest;
            if (clientBeginRequest > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", clientBeginRequest);
            }
            return string.Empty;
        }

        internal static string GetClientBeginResponse(Session oS)
        {
            DateTime clientBeginResponse = oS.Timers.ClientBeginResponse;
            if (clientBeginResponse > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", clientBeginResponse);
            }
            return string.Empty;
        }

        internal static string GetClientConnected(Session oS)
        {
            DateTime clientConnected = oS.Timers.ClientConnected;
            if (clientConnected > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", clientConnected);
            }
            return string.Empty;
        }

        internal static string GetClientDoneRequest(Session oS)
        {
            DateTime clientDoneRequest = oS.Timers.ClientDoneRequest;
            if (clientDoneRequest > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", clientDoneRequest);
            }
            return string.Empty;
        }

        internal static string GetClientDoneResponse(Session oS)
        {
            DateTime clientDoneResponse = oS.Timers.ClientDoneResponse;
            if (clientDoneResponse > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", clientDoneResponse);
            }
            return string.Empty;
        }

        internal static string GetClientPipeReuse(Session oS)
        {
            if (!oS.isFlagSet(SessionFlags.ClientPipeReused))
            {
                return "New";
            }
            return "Reused";
        }

        internal static string GetCompressionSavings(Session oS)
        {
            if ((!oS.bHasResponse || oS.HTTPMethodIs("CONNECT")) || (oS.responseBodyBytes.Length < 1))
            {
                return string.Empty;
            }
            CompressedEntityInfo entityInfo = GetEntityInfo(oS);
            if (entityInfo.bError)
            {
                return string.Empty;
            }
            int num = entityInfo.iOriginalSize - entityInfo.iCompressedSize;
            return num.ToString("N0");
        }

        internal static string GetCompressionSavingsPct(Session oS)
        {
            if ((!oS.bHasResponse || oS.HTTPMethodIs("CONNECT")) || (oS.responseBodyBytes.Length < 1))
            {
                return string.Empty;
            }
            CompressedEntityInfo entityInfo = GetEntityInfo(oS);
            if (entityInfo.bError)
            {
                return string.Empty;
            }
            float num = 100f * (1f - (((float) entityInfo.iCompressedSize) / ((float) entityInfo.iOriginalSize)));
            return string.Format("{0:00.#}%", num);
        }

        internal static string GetDNSTime(Session oS)
        {
            int dNSTime = oS.Timers.DNSTime;
            if (dNSTime > 0)
            {
                return dNSTime.ToString();
            }
            return string.Empty;
        }

        private static CompressedEntityInfo GetEntityInfo(Session oS)
        {
            CompressedEntityInfo info = new CompressedEntityInfo();
            try
            {
                if (!oS.oResponse.headers.Exists("Content-Encoding"))
                {
                    info.bError = true;
                    return info;
                }
                string inStr = oS.oResponse.headers.AllValues("Content-Encoding").Trim();
                byte[] responseBodyBytes = oS.responseBodyBytes;
                if (oS.oResponse.headers.ExistsAndContains("Transfer-Encoding", "chunked"))
                {
                    responseBodyBytes = Utilities.doUnchunk(responseBodyBytes, oS, true);
                }
                info.iCompressedSize = responseBodyBytes.Length;
                if (inStr.OICEndsWith("gzip"))
                {
                    if (((responseBodyBytes.Length < 0x10) || (responseBodyBytes[0] != 0x1f)) || (responseBodyBytes[1] != 0x8b))
                    {
                        throw new InvalidDataException("Not gzip");
                    }
                    info.iOriginalSize = ((responseBodyBytes[responseBodyBytes.Length - 4] + (responseBodyBytes[responseBodyBytes.Length - 3] << 8)) + (responseBodyBytes[responseBodyBytes.Length - 2] << 0x10)) + (responseBodyBytes[responseBodyBytes.Length - 1] << 0x18);
                    if (info.iOriginalSize > (0x408 * responseBodyBytes.Length))
                    {
                        throw new InvalidDataException("Impossible compression ratio");
                    }
                    return info;
                }
                HTTPResponseHeaders oHeaders = (HTTPResponseHeaders) oS.oResponse.headers.Clone();
                oHeaders.Remove("Transfer-Encoding");
                Utilities.utilDecodeHTTPBody(oHeaders, ref responseBodyBytes);
                info.iOriginalSize = responseBodyBytes.Length;
            }
            catch
            {
                info.bError = true;
            }
            return info;
        }

        private static string GetEXIFGeoLoc(byte[] arrImg, uint iPtr, int iSegmentLength)
        {
            bool flag;
            int length = arrImg.Length;
            if ((iSegmentLength < 0x10) || (iPtr > (length - 0x10)))
            {
                return string.Empty;
            }
            if ((((arrImg[iPtr++] != 0x45) || (arrImg[iPtr++] != 120)) || ((arrImg[iPtr++] != 0x69) || (arrImg[iPtr++] != 0x66))) || ((arrImg[iPtr++] != 0) || (arrImg[iPtr++] != 0)))
            {
                return string.Empty;
            }
            uint iXOrigin = iPtr;
            int num3 = arrImg[iPtr++];
            int num4 = arrImg[iPtr++];
            if (num3 == num4)
            {
                if (num3 == 0x4d)
                {
                    flag = false;
                    goto Label_00A2;
                }
                if (num3 == 0x49)
                {
                    flag = true;
                    goto Label_00A2;
                }
            }
            return "MalformedExif";
        Label_00A2:
            byte num1 = arrImg[iPtr++];
            byte num11 = arrImg[iPtr++];
            uint num5 = ReadUInt32(arrImg, ref iPtr, flag);
            if (num5 < 8)
            {
                return "MalformedIFD";
            }
            num5 -= 8;
            iPtr += num5;
            if (iPtr >= arrImg.Length)
            {
                return "MalformedIFD";
            }
            int num6 = ReadUInt16(arrImg, ref iPtr, flag);
            for (int i = 0; i < num6; i++)
            {
                if (iPtr <= (length - 12))
                {
                    int num8 = ReadUInt16(arrImg, ref iPtr, flag);
                    ReadUInt16(arrImg, ref iPtr, flag);
                    ReadUInt32(arrImg, ref iPtr, flag);
                    if (num8 == 0x8825)
                    {
                        byte[] dst = new byte[4];
                        Buffer.BlockCopy(arrImg, (int) iPtr, dst, 0, 4);
                        uint iOffset = 0;
                        uint num10 = iXOrigin + ReadUInt32(dst, ref iOffset, flag);
                        return ParseGeoLocIFD(arrImg, iXOrigin, num10, flag);
                    }
                    iPtr += 4;
                }
            }
            return string.Empty;
        }

        internal static string GetFiddlerBeginRequest(Session oS)
        {
            DateTime fiddlerBeginRequest = oS.Timers.FiddlerBeginRequest;
            if (fiddlerBeginRequest > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", fiddlerBeginRequest);
            }
            return string.Empty;
        }

        internal static string GetFiddlerGotRequestHeaders(Session oS)
        {
            DateTime fiddlerGotRequestHeaders = oS.Timers.FiddlerGotRequestHeaders;
            if (fiddlerGotRequestHeaders > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", fiddlerGotRequestHeaders);
            }
            return string.Empty;
        }

        internal static string GetFiddlerGotResponseHeaders(Session oS)
        {
            DateTime fiddlerGotResponseHeaders = oS.Timers.FiddlerGotResponseHeaders;
            if (fiddlerGotResponseHeaders > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", fiddlerGotResponseHeaders);
            }
            return string.Empty;
        }

        internal static string GetGatewayDeterminationTime(Session oS)
        {
            int gatewayDeterminationTime = oS.Timers.GatewayDeterminationTime;
            if (gatewayDeterminationTime > 0)
            {
                return gatewayDeterminationTime.ToString();
            }
            return string.Empty;
        }

        internal static string GetGeoLocation(Session oS)
        {
            int num4;
            if ((!oS.bHasResponse || (oS.responseBodyBytes.Length < 0x18)) || oS.HTTPMethodIs("CONNECT"))
            {
                return string.Empty;
            }
            if (oS.oResponse.headers.ExistsAndContains("Transfer-Encoding", "chunked"))
            {
                return string.Empty;
            }
            if ((0xff != oS.responseBodyBytes[0]) || (0xd8 != oS.responseBodyBytes[1]))
            {
                return string.Empty;
            }
            byte[] responseBodyBytes = oS.responseBodyBytes;
            int length = responseBodyBytes.Length;
            string str = string.Empty;
            for (int i = 2; (i < length) && (0xff == responseBodyBytes[i++]); i += num4)
            {
                int num3 = responseBodyBytes[i++];
                num4 = ((responseBodyBytes[i++] << 8) + responseBodyBytes[i++]) - 2;
                switch (num3)
                {
                    case 0xe1:
                    {
                        str = str + GetEXIFGeoLoc(responseBodyBytes, (uint) i, num4);
                    }
                }
            }
            if (string.IsNullOrEmpty(str))
            {
                return "no";
            }
            return str;
        }

        private static bool GetGIFDimensions(byte[] arrImg, ref Size? sizeResult)
        {
            if ((((0x47 == arrImg[0]) && (0x49 == arrImg[1])) && ((70 == arrImg[2]) && (0x38 == arrImg[3]))) && (0x61 == arrImg[5]))
            {
                sizeResult = new Size(arrImg[6] | (arrImg[7] << 8), arrImg[8] | (arrImg[9] << 8));
                return true;
            }
            return false;
        }

        internal static string GetHTTPSHandshakeTime(Session oS)
        {
            int hTTPSHandshakeTime = oS.Timers.HTTPSHandshakeTime;
            if (hTTPSHandshakeTime > 0)
            {
                return hTTPSHandshakeTime.ToString();
            }
            return string.Empty;
        }

        internal static string GetImageDimensions(Session oS)
        {
            Size? imgDimensions = GetImgDimensions(oS);
            if (!imgDimensions.HasValue)
            {
                return string.Empty;
            }
            return string.Format("{0}, {1}", imgDimensions.Value.Width, imgDimensions.Value.Height);
        }

        internal static string GetImageFingerprint(Session oS)
        {
            return AnalyzeImage(oS, true);
        }

        internal static string GetImageRGB(Session oS)
        {
            return AnalyzeImage(oS, false);
        }

        private static Size? GetImgDimensions(Session oS)
        {
            if (((oS.bHasResponse && (oS.responseBodyBytes.Length >= 0x18)) && !oS.isTunnel) && !oS.oResponse.headers.ExistsAny(arrSkipIfFound))
            {
                try
                {
                    byte[] responseBodyBytes = oS.responseBodyBytes;
                    Size? sizeResult = null;
                    switch (responseBodyBytes[0])
                    {
                        case 120:
                            return null;

                        case 0x89:
                            if (!GetPNGDimensions(responseBodyBytes, ref sizeResult))
                            {
                                break;
                            }
                            return sizeResult;

                        case 0xff:
                            if (!GetJPEGDimensions(responseBodyBytes, ref sizeResult))
                            {
                                break;
                            }
                            return sizeResult;

                        case 0x47:
                            if (!GetGIFDimensions(responseBodyBytes, ref sizeResult))
                            {
                                break;
                            }
                            return sizeResult;

                        case 0x49:
                            if (!GetJPEGXRDimensions(responseBodyBytes, ref sizeResult))
                            {
                                break;
                            }
                            return sizeResult;

                        case 0x52:
                            if (GetWebPDimensions(responseBodyBytes, ref sizeResult))
                            {
                                return sizeResult;
                            }
                            break;

                        case 0x1f:
                            if (responseBodyBytes[1] != 0x8b)
                            {
                                break;
                            }
                            return null;
                    }
                    MemoryStream stream = new MemoryStream(responseBodyBytes);
                    using (Image image = Image.FromStream(stream, false, false))
                    {
                        return new Size((int) image.PhysicalDimension.Width, (int) image.PhysicalDimension.Height);
                    }
                }
                catch (Exception)
                {
                }
            }
            return null;
        }

        private static bool GetJPEGDimensions(byte[] arrImg, ref Size? sizeResult)
        {
            if ((0xff == arrImg[0]) && (0xd8 == arrImg[1]))
            {
                int num3;
                for (int i = 2; (i < arrImg.Length) && (0xff == arrImg[i++]); i += num3)
                {
                    int num2 = arrImg[i++];
                    num3 = ((arrImg[i++] << 8) + arrImg[i++]) - 2;
                    switch (num2)
                    {
                        case 0xc0:
                        case 0xc2:
                            if ((i + num3) >= arrImg.Length)
                            {
                                break;
                            }
                            sizeResult = new Size((arrImg[i + 3] << 8) | arrImg[i + 4], (arrImg[i + 1] << 8) | arrImg[i + 2]);
                            return true;
                    }
                }
            }
            return false;
        }

        private static bool GetJPEGXRDimensions(byte[] arrImg, ref Size? sizeResult)
        {
            if (((0x49 == arrImg[0]) && (0x49 == arrImg[1])) && (0xbc == arrImg[2]))
            {
                uint iOffset = 4;
                iOffset = ReadUInt32(arrImg, ref iOffset, true);
                ushort num2 = ReadUInt16(arrImg, ref iOffset, true);
                uint num3 = 0;
                uint num4 = 0;
                for (int i = 0; i < num2; i++)
                {
                    ushort num6 = ReadUInt16(arrImg, ref iOffset, true);
                    if ((num6 ^ 0xbc80) > 1)
                    {
                        iOffset += 10;
                    }
                    else
                    {
                        iOffset += 6;
                        uint num7 = ReadUInt32(arrImg, ref iOffset, true);
                        switch (num6)
                        {
                            case 0xbc80:
                                num3 = num7;
                                break;

                            case 0xbc81:
                                num4 = num7;
                                break;
                        }
                        if ((num3 != 0) && (num4 != 0))
                        {
                            sizeResult = new Size((int) num3, (int) num4);
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        internal static string GetOverallElapsed(Session oS)
        {
            TimeSpan span = (TimeSpan) (oS.Timers.ClientDoneResponse - oS.Timers.ClientBeginRequest);
            if (span > TimeSpan.Zero)
            {
                return string.Format(@"{0:h\:mm\:ss\.fff}", span);
            }
            return string.Empty;
        }

        internal static string GetPixelCount(Session oS)
        {
            Size? imgDimensions = GetImgDimensions(oS);
            if (!imgDimensions.HasValue)
            {
                return "0";
            }
            return string.Format("{0:N0}", imgDimensions.Value.Width * imgDimensions.Value.Height);
        }

        private static bool GetPNGDimensions(byte[] arrImg, ref Size? sizeResult)
        {
            if (((0x89 == arrImg[0]) && (80 == arrImg[1])) && ((0x4e == arrImg[2]) && (0x47 == arrImg[3])))
            {
                sizeResult = new Size((((arrImg[0x10] << 0x18) | (arrImg[0x11] << 0x10)) | (arrImg[0x12] << 8)) | arrImg[0x13], (((arrImg[20] << 0x18) | (arrImg[0x15] << 0x10)) | (arrImg[0x16] << 8)) | arrImg[0x17]);
                return true;
            }
            return false;
        }

        internal static string GetRequestBodySize(Session oS)
        {
            if (oS.requestBodyBytes == null)
            {
                return "0";
            }
            return oS.requestBodyBytes.LongLength.ToString("N0");
        }

        internal static string GetRequestMethod(Session oS)
        {
            return oS.RequestMethod;
        }

        internal static string GetRequestSize(Session oS)
        {
            long longLength = 0L;
            if (oS.requestBodyBytes != null)
            {
                longLength = oS.requestBodyBytes.LongLength;
            }
            if (Utilities.HasHeaders(oS.oRequest))
            {
                longLength += oS.oRequest.headers.ByteCount();
            }
            return longLength.ToString("N0");
        }

        internal static string GetResponseMD5(Session oS)
        {
            if (Utilities.IsNullOrEmpty(oS.responseBodyBytes))
            {
                return string.Empty;
            }
            return oS.GetResponseBodyHash("md5");
        }

        internal static string GetResponseSize(Session oS)
        {
            long longLength = 0L;
            if (oS.responseBodyBytes != null)
            {
                longLength = oS.responseBodyBytes.LongLength;
            }
            if (Utilities.HasHeaders(oS.oResponse))
            {
                longLength += oS.oResponse.headers.ByteCount();
            }
            return longLength.ToString("N0");
        }

        internal static string GetResponseStatusText(Session oS)
        {
            if (!Utilities.HasHeaders(oS.oResponse))
            {
                return string.Empty;
            }
            return oS.oResponse.headers.StatusDescription;
        }

        internal static string GetResponseStreamed(Session oS)
        {
            if (!oS.isFlagSet(SessionFlags.ResponseStreamed))
            {
                return string.Empty;
            }
            return "Streamed";
        }

        internal static string GetSecurityHeaderSummary(Session oS)
        {
            if (oS.oResponse.headers == null)
            {
                return string.Empty;
            }
            HTTPResponseHeaders headers = oS.oResponse.headers;
            List<string> list = new List<string>();
            int num = headers.CountOf("Content-Security-Policy");
            if (num > 0)
            {
                if (num > 1)
                {
                    list.Insert(0, "CSP:!");
                }
                else
                {
                    list.Add("CSP");
                }
            }
            int num2 = headers.CountOf("Strict-Transport-Security");
            if (num2 > 0)
            {
                if ((num2 > 1) || !oS.isHTTPS)
                {
                    list.Insert(0, "STS:!");
                }
                else
                {
                    string sFullValue = headers["Strict-Transport-Security"];
                    string str2 = null;
                    long lMaxAge = Utilities.ExtractAttributeValue(sFullValue, "max-age", -1L);
                    str2 = str2 + GetSuccinctTime(lMaxAge);
                    if (sFullValue.OICContains("includeSubDomains"))
                    {
                        str2 = str2 + "+Sub";
                    }
                    list.Add(string.Format("STS:{0}", str2));
                }
            }
            int num4 = headers.CountOf("Public-Key-Pins");
            if (num4 > 0)
            {
                if ((num4 > 1) || !oS.isHTTPS)
                {
                    list.Insert(0, "PKP:!");
                }
                else
                {
                    string str3 = headers["Public-Key-Pins"];
                    string str4 = null;
                    long num5 = Utilities.ExtractAttributeValue(str3, "max-age", -1L);
                    str4 = str4 + GetSuccinctTime(num5);
                    if (str3.OICContains("includeSubDomains"))
                    {
                        str4 = str4 + "+Sub";
                    }
                    list.Add(string.Format("PKP:{0}", str4));
                }
            }
            string str5 = headers.AllValues("Access-Control-Allow-Origin");
            if (!string.IsNullOrEmpty(str5))
            {
                string str6 = null;
                if (str5.OICContains("*"))
                {
                    str6 = ":*";
                }
                list.Add(string.Format("ACAO{0}", str6));
            }
            string str7 = headers.AllValues("X-XSS-Protection");
            if (!string.IsNullOrEmpty(str7))
            {
                if (str7.OICContains("0"))
                {
                    if (str7.OICContains("block"))
                    {
                        str7 = "!";
                    }
                    else
                    {
                        str7 = "0";
                    }
                }
                if (str7.OICContains("mode=block"))
                {
                    if (!str7.OICContains("1"))
                    {
                        str7 = "!";
                    }
                    else
                    {
                        str7 = "block";
                    }
                }
                list.Add(string.Format("XXP:{0}", str7));
            }
            string str8 = headers.AllValues("X-Frame-Options");
            if (!string.IsNullOrEmpty(str8))
            {
                string str9 = null;
                if (str8.OICContains("deny"))
                {
                    str9 = "d";
                }
                if (str8.OICContains("sameorigin"))
                {
                    str9 = str9 + "s";
                }
                if (str8.OICContains("allow-from"))
                {
                    str9 = str9 + "a";
                }
                if (string.IsNullOrEmpty(str9))
                {
                    str9 = "!";
                }
                list.Add(string.Format("XFO:{0}", str9));
            }
            string str10 = headers.AllValues("X-Content-Type-Options");
            if (!string.IsNullOrEmpty(str10))
            {
                list.Add(str10.OICContains("nosniff") ? "NoSniff" : "XCTO:!");
            }
            return string.Join(", ", list.ToArray());
        }

        internal static string GetSentToGateway(Session oS)
        {
            if (!oS.isFlagSet(SessionFlags.SentToGateway))
            {
                return string.Empty;
            }
            return "UpstreamGW";
        }

        internal static string GetServerBeginResponse(Session oS)
        {
            DateTime serverBeginResponse = oS.Timers.ServerBeginResponse;
            if (serverBeginResponse > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", serverBeginResponse);
            }
            return string.Empty;
        }

        internal static string GetServerConnected(Session oS)
        {
            DateTime serverConnected = oS.Timers.ServerConnected;
            if (serverConnected > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", serverConnected);
            }
            return string.Empty;
        }

        internal static string GetServerDoneResponse(Session oS)
        {
            DateTime serverDoneResponse = oS.Timers.ServerDoneResponse;
            if (serverDoneResponse > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", serverDoneResponse);
            }
            return string.Empty;
        }

        internal static string GetServerGotRequest(Session oS)
        {
            DateTime serverGotRequest = oS.Timers.ServerGotRequest;
            if (serverGotRequest > DateTime.MinValue)
            {
                return string.Format("{0:HH:mm:ss.fff}", serverGotRequest);
            }
            return string.Empty;
        }

        internal static string GetServerPipeReuse(Session oS)
        {
            if (!oS.isFlagSet(SessionFlags.ServerPipeReused))
            {
                return "New";
            }
            return "Reused";
        }

        internal static string GetServerThinkTime(Session oS)
        {
            if (oS.Timers.ServerBeginResponse.Ticks == 0L)
            {
                return string.Empty;
            }
            TimeSpan span = (TimeSpan) (oS.Timers.ServerBeginResponse - oS.Timers.ServerGotRequest);
            if (span > TimeSpan.Zero)
            {
                return span.TotalMilliseconds.ToString("N2");
            }
            return "0";
        }

        private static string GetSuccinctTime(long lMaxAge)
        {
            if (lMaxAge < 0L)
            {
                return "!";
            }
            if (lMaxAge == 0L)
            {
                return "0";
            }
            if (lMaxAge < 0x15180L)
            {
                return string.Format("{0:0}h", ((float) lMaxAge) / 3600f);
            }
            float num = ((float) lMaxAge) / 86400f;
            if (num < 365f)
            {
                return string.Format("{0:0}d", num);
            }
            return string.Format("{0:0}M", num / 30f);
        }

        internal static string GetTCPConnectTime(Session oS)
        {
            int tCPConnectTime = oS.Timers.TCPConnectTime;
            if (tCPConnectTime > 0)
            {
                return tCPConnectTime.ToString();
            }
            return string.Empty;
        }

        internal static string GetTTFB(Session oS)
        {
            if (oS.Timers.ServerBeginResponse.Ticks == 0L)
            {
                return string.Empty;
            }
            TimeSpan span = (TimeSpan) (oS.Timers.ServerBeginResponse - oS.Timers.ClientBeginRequest);
            if (span > TimeSpan.Zero)
            {
                return span.TotalMilliseconds.ToString("N2");
            }
            return "0";
        }

        internal static string GetTTLB(Session oS)
        {
            if (oS.Timers.ServerDoneResponse.Ticks == 0L)
            {
                return string.Empty;
            }
            TimeSpan span = (TimeSpan) (oS.Timers.ServerDoneResponse - oS.Timers.ClientBeginRequest);
            if (span > TimeSpan.Zero)
            {
                return span.TotalMilliseconds.ToString("N2");
            }
            return "0";
        }

        private static bool GetWebPDimensions(byte[] arrImg, ref Size? sizeResult)
        {
            if (((((arrImg.Length > 30) && (0x52 == arrImg[0])) && ((0x49 == arrImg[1]) && (70 == arrImg[2]))) && (((70 == arrImg[3]) && (0x57 == arrImg[8])) && ((0x45 == arrImg[9]) && (0x42 == arrImg[10])))) && (80 == arrImg[11]))
            {
                switch (arrImg[15])
                {
                    case 0x20:
                        sizeResult = new Size((arrImg[0x1a] | (arrImg[0x1b] << 8)) & 0x3fff, (arrImg[0x1c] | (arrImg[0x1d] << 8)) & 0x3fff);
                        return true;

                    case 0x4c:
                        sizeResult = new Size(1 + (arrImg[0x15] | ((arrImg[0x16] & 0x3f) << 8)), 1 + ((((arrImg[0x18] & 15) << 10) | (arrImg[0x17] << 2)) | ((arrImg[0x16] & 0xc0) >> 6)));
                        return true;

                    case 0x58:
                        sizeResult = new Size(1 + ((arrImg[0x18] | (arrImg[0x19] << 8)) | (arrImg[0x1a] << 0x10)), 1 + ((arrImg[0x1b] | (arrImg[0x1c] << 8)) | (arrImg[0x1d] << 0x10)));
                        return true;
                }
            }
            return false;
        }

        private static string ParseGeoLocIFD(byte[] arrImg, uint iXOrigin, uint iPtr, bool bLittleEndian)
        {
            int num = ReadUInt16(arrImg, ref iPtr, bLittleEndian);
            string str = null;
            string str2 = null;
            float f = 0f;
            float num3 = 0f;
            for (int i = 0; i < num; i++)
            {
                int num5 = ReadUInt16(arrImg, ref iPtr, bLittleEndian);
                ReadUInt16(arrImg, ref iPtr, bLittleEndian);
                uint num6 = ReadUInt32(arrImg, ref iPtr, bLittleEndian);
                byte[] dst = new byte[4];
                Buffer.BlockCopy(arrImg, (int) iPtr, dst, 0, 4);
                iPtr += 4;
                switch (num5)
                {
                    case 1:
                        if (dst[0] != 0)
                        {
                            str = new string(new char[] { dst[0] });
                        }
                        break;

                    case 2:
                        if (num6 == 3)
                        {
                            uint iOffset = 0;
                            uint num8 = iXOrigin + ReadUInt32(dst, ref iOffset, bLittleEndian);
                            uint num9 = ReadUInt32(arrImg, ref num8, bLittleEndian);
                            uint num10 = ReadUInt32(arrImg, ref num8, bLittleEndian);
                            uint num11 = ReadUInt32(arrImg, ref num8, bLittleEndian);
                            uint num12 = ReadUInt32(arrImg, ref num8, bLittleEndian);
                            uint num13 = ReadUInt32(arrImg, ref num8, bLittleEndian);
                            uint num14 = ReadUInt32(arrImg, ref num8, bLittleEndian);
                            f = ((((float) num9) / ((float) num10)) + ((((float) num11) / ((float) num12)) / 60f)) + ((((float) num13) / ((float) num14)) / 3600f);
                        }
                        break;

                    case 3:
                        if (dst[0] != 0)
                        {
                            str2 = new string(new char[] { dst[0] });
                        }
                        break;

                    case 4:
                    {
                        uint num15 = 0;
                        uint num16 = iXOrigin + ReadUInt32(dst, ref num15, bLittleEndian);
                        uint num17 = ReadUInt32(arrImg, ref num16, bLittleEndian);
                        uint num18 = ReadUInt32(arrImg, ref num16, bLittleEndian);
                        uint num19 = ReadUInt32(arrImg, ref num16, bLittleEndian);
                        uint num20 = ReadUInt32(arrImg, ref num16, bLittleEndian);
                        uint num21 = ReadUInt32(arrImg, ref num16, bLittleEndian);
                        uint num22 = ReadUInt32(arrImg, ref num16, bLittleEndian);
                        num3 = ((((float) num17) / ((float) num18)) + ((((float) num19) / ((float) num20)) / 60f)) + ((((float) num21) / ((float) num22)) / 3600f);
                        break;
                    }
                }
            }
            if (((f == 0f) || float.IsNaN(f)) && ((num3 == 0f) || float.IsNaN(num3)))
            {
                return "NoLoc";
            }
            return string.Format("{0}{1}, {2}{3}", new object[] { f, str, num3, str2 });
        }

        private static ushort ReadUInt16(byte[] arrFrom, ref uint iOffset, bool bLittleEndian)
        {
            if (bLittleEndian)
            {
                return (ushort) (arrFrom[iOffset++] + (arrFrom[iOffset++] << 8));
            }
            return (ushort) ((arrFrom[iOffset++] << 8) + arrFrom[iOffset++]);
        }

        private static uint ReadUInt32(byte[] arrFrom, ref uint iOffset, bool bLittleEndian)
        {
            if (bLittleEndian)
            {
                return (uint) (((arrFrom[iOffset++] + (arrFrom[iOffset++] << 8)) + (arrFrom[iOffset++] << 0x10)) + (arrFrom[iOffset++] << 0x18));
            }
            return (uint) ((((arrFrom[iOffset++] << 0x18) + (arrFrom[iOffset++] << 0x10)) + (arrFrom[iOffset++] << 8)) + arrFrom[iOffset++]);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct CompressedEntityInfo
        {
            public bool bError;
            public int iOriginalSize;
            public int iCompressedSize;
        }
    }
}

