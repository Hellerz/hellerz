﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    public class CacheClearEventArgs : CancelEventArgs
    {
        [CompilerGenerated]
        private bool <ClearCacheFiles>k__BackingField;
        [CompilerGenerated]
        private bool <ClearCookies>k__BackingField;

        public CacheClearEventArgs(bool bClearFiles, bool bClearCookies)
        {
            this.ClearCacheFiles = bClearFiles;
            this.ClearCookies = bClearCookies;
        }

        public bool ClearCacheFiles
        {
            [CompilerGenerated]
            get
            {
                return this.<ClearCacheFiles>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<ClearCacheFiles>k__BackingField = value;
            }
        }

        public bool ClearCookies
        {
            [CompilerGenerated]
            get
            {
                return this.<ClearCookies>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<ClearCookies>k__BackingField = value;
            }
        }
    }
}

