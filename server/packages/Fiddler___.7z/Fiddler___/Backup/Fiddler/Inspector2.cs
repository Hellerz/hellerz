﻿namespace Fiddler
{
    using System;
    using System.Diagnostics;
    using System.Drawing;
    using System.Windows.Forms;

    public abstract class Inspector2
    {
        protected Inspector2()
        {
        }

        public abstract void AddToTab(TabPage o);
        public virtual void AssignSession(Session oS)
        {
            IRequestInspector2 inspector = this as IRequestInspector2;
            if (inspector != null)
            {
                inspector.headers = oS.oRequest.headers;
                inspector.body = oS.requestBodyBytes;
                inspector.bReadOnly = (oS.state != SessionStates.HandTamperRequest) && !oS.oFlags.ContainsKey("x-Unlocked");
            }
            else
            {
                IResponseInspector2 inspector2 = this as IResponseInspector2;
                if (inspector2 != null)
                {
                    inspector2.headers = oS.oResponse.headers;
                    inspector2.body = oS.responseBodyBytes;
                    inspector2.bReadOnly = (oS.state != SessionStates.HandTamperResponse) && !oS.oFlags.ContainsKey("x-Unlocked");
                }
            }
        }

        public virtual bool CommitAnyChanges(Session oS)
        {
            bool flag = false;
            IRequestInspector2 inspector = this as IRequestInspector2;
            if (inspector != null)
            {
                if (!inspector.bDirty)
                {
                    return false;
                }
                if (((oS.state != SessionStates.HandTamperRequest) && !oS.oFlags.ContainsKey("x-Unlocked")) && (((inspector as Inspector2).GetFlags() & InspectorFlags.AlwaysCommitEdits) == InspectorFlags.None))
                {
                    return false;
                }
                if (inspector.headers != null)
                {
                    flag = true;
                    oS.oRequest.headers = inspector.headers;
                }
                if (inspector.body != null)
                {
                    flag = true;
                    oS.requestBodyBytes = inspector.body;
                    if ((oS.oRequest.headers != null) && oS.oRequest.headers.Exists("Content-Length"))
                    {
                        oS.oRequest.headers["Content-Length"] = oS.requestBodyBytes.LongLength.ToString();
                    }
                }
                this.UnsetDirtyFlag();
                return flag;
            }
            IResponseInspector2 inspector2 = this as IResponseInspector2;
            if (inspector2 == null)
            {
                return false;
            }
            if (!inspector2.bDirty)
            {
                return false;
            }
            if (((oS.state != SessionStates.HandTamperResponse) && !oS.oFlags.ContainsKey("x-Unlocked")) && (((inspector2 as Inspector2).GetFlags() & InspectorFlags.AlwaysCommitEdits) == InspectorFlags.None))
            {
                return false;
            }
            if (inspector2.headers != null)
            {
                flag = true;
                oS.oResponse.headers = inspector2.headers;
            }
            if (inspector2.body != null)
            {
                flag = true;
                oS.responseBodyBytes = inspector2.body;
                if ((oS.oResponse.headers != null) && oS.oResponse.headers.Exists("Content-Length"))
                {
                    oS.oResponse.headers["Content-Length"] = oS.responseBodyBytes.LongLength.ToString();
                }
            }
            this.UnsetDirtyFlag();
            return flag;
        }

        public virtual void CopyAsImage(TabPage t)
        {
            if ((t.Width == 0) || (t.Height == 0))
            {
                FiddlerApplication.DoNotifyUser("To copy, the Inspector must be at least 1px tall and wide.", "Invalid Operation", MessageBoxIcon.Hand);
            }
            else
            {
                Bitmap bitmap = new Bitmap(t.Width, t.Height);
                t.DrawToBitmap(bitmap, t.ClientRectangle);
                Utilities.CopyToClipboard(new DataObject(bitmap));
            }
        }

        public virtual InspectorFlags GetFlags()
        {
            return InspectorFlags.None;
        }

        public abstract int GetOrder();
        public virtual int ScoreForContentType(string sMIMEType)
        {
            return 0;
        }

        public virtual int ScoreForSession(Session oS)
        {
            if (oS.isTunnel)
            {
                return 0;
            }
            string sString = string.Empty;
            if (this is IRequestInspector2)
            {
                if (Utilities.IsNullOrEmpty(oS.requestBodyBytes))
                {
                    return 0;
                }
                if (oS.oRequest != null)
                {
                    sString = oS.oRequest["Content-Type"];
                }
            }
            else
            {
                if (Utilities.IsNullOrEmpty(oS.responseBodyBytes))
                {
                    return 0;
                }
                if (oS.oResponse != null)
                {
                    sString = oS.oResponse["Content-Type"];
                }
            }
            sString = Utilities.TrimAfter(sString, ';');
            return this.ScoreForContentType(sString);
        }

        public virtual void SetFontSize(float flSizeInPoints)
        {
        }

        public virtual void ShowAboutBox()
        {
            FiddlerApplication.DoNotifyUser(this.ToString() + "\n\n" + FileVersionInfo.GetVersionInfo(base.GetType().Assembly.Location).ToString(), "About Inspector", MessageBoxIcon.Asterisk);
        }

        public virtual bool UnsetDirtyFlag()
        {
            return false;
        }
    }
}

