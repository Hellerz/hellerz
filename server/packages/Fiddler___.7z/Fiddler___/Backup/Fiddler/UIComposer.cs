﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    internal class UIComposer : UserControl
    {
        private static bool bHistoryDirty = false;
        private static bool bLoadedScratch = false;
        private Button btnBuilderExecute;
        private Button btnTearOff;
        private CheckBox cbAutoAuthenticate;
        private CheckBox cbComposerLogRequests;
        private CheckBox cbFixContentLength;
        private CheckBox cbFollowRedirects;
        private CheckBox cbSelectBuilderResult;
        private ComboBox cbxBuilderHTTPVersion;
        private ComboBox cbxBuilderMethod;
        private ComboBox cbxBuilderURL;
        private ColumnHeader colParsedHistory;
        private IContainer components;
        private static DateTime dtLastDblClick;
        private const int EM_GETLINE = 0xc4;
        private const uint EM_GETLINECOUNT = 0xba;
        private static Form frmFloatingBuilder = null;
        private GroupBox gbUIOptions;
        private ImageList imglComposer;
        private Label lblTearoff;
        private LinkLabel linkUpload;
        private LinkLabel lnkUnhideHistoryPane;
        private DoubleBufferedListView lvHistory;
        private ToolStripMenuItem miHideHistory;
        private ToolStripMenuItem miHistoryComment;
        private ToolStripMenuItem miHistoryRemoveDuplicates;
        private ToolStripMenuItem miHistorySaveOnExit;
        private ToolStripMenuItem miLoadHistory;
        private ToolStripMenuItem miRemoveHistory;
        private ToolStripMenuItem miSaveHistory;
        private ToolStripMenuItem miSelectAllHistory;
        private ContextMenuStrip mnuHistory;
        private static UIComposer oRequestBuilder;
        private TabPage pageOptions;
        private TabPage pageParsed;
        private TabPage pageRaw;
        private TabPage pageScratch;
        private Panel pnlHistory;
        private Panel pnlParsed;
        private static Rectangle rectLastDblClick;
        private static Size sizeDblClickArea;
        private SplitContainer splitHeaderBody;
        private SplitContainer splitOutside;
        private TabControl tabsBuilder;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripSeparator toolStripMenuItem3;
        private TextBox txtBuilderRequestBody;
        private TextBox txtBuilderRequestHeaders;
        private TextBox txtRaw;
        private TextBox txtScratch;

        private UIComposer()
        {
            this.InitializeComponent();
            this.cbFollowRedirects.UseCompatibleTextRendering = false;
            this.cbxBuilderHTTPVersion.SelectedIndex = 2;
            this.cbxBuilderMethod.SelectedIndex = 0;
            this.AllowDrop = true;
            base.DragEnter += new DragEventHandler(this.oRequestBuilder_DragEnter);
            base.DragLeave += new EventHandler(this.RequestBuilder_DragLeave);
            base.DragDrop += new DragEventHandler(this.RequestBuilder_DragDrop);
            this.cbFollowRedirects.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.composer.followredirects", true);
            this.cbAutoAuthenticate.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.composer.autoauth", false);
            this.cbSelectBuilderResult.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.composer.inspectsession", false);
            this.txtScratch.Font = new Font(this.txtScratch.Font.FontFamily, CONFIG.flFontSize);
            this.txtRaw.Font = new Font(this.txtRaw.Font.FontFamily, CONFIG.flFontSize);
            this.txtBuilderRequestHeaders.Font = new Font(this.txtBuilderRequestHeaders.Font.FontFamily, CONFIG.flFontSize);
            this.txtBuilderRequestBody.Font = new Font(this.txtBuilderRequestBody.Font.FontFamily, CONFIG.flFontSize);
            if (CONFIG.flFontSize >= 11f)
            {
                this.cbxBuilderURL.Font = new Font(this.cbxBuilderURL.Font.FontFamily, 11f);
                this.cbxBuilderMethod.Font = new Font(this.cbxBuilderURL.Font.FontFamily, 11f);
                this.cbxBuilderHTTPVersion.Font = new Font(this.cbxBuilderHTTPVersion.Font.FontFamily, 11f);
            }
            this.lvHistory.EmptyText = "No Requests logged";
            this.cbComposerLogRequests.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.composer.history.LogRequests", true);
            this.miHistoryRemoveDuplicates.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.composer.history.removeduplicates", true);
            this.miHistorySaveOnExit.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.composer.history.SaveOnExit", true);
            this.PopulateHistory(string.Concat(new object[] { CONFIG.GetPath("Captures"), Path.DirectorySeparatorChar, "Requests", Path.DirectorySeparatorChar, "ComposerHistory.raz" }), true, this.miHistoryRemoveDuplicates.Checked);
            bHistoryDirty = false;
        }

        private void _RemoveHeaderLines(params string[] arrToRemove)
        {
            string[] lines = this.txtBuilderRequestHeaders.Lines;
            StringBuilder builder = new StringBuilder();
            foreach (string str in lines)
            {
                if (!str.TrimStart(new char[0]).OICStartsWithAny(arrToRemove))
                {
                    builder.AppendLine(str);
                }
            }
            this.txtBuilderRequestHeaders.Text = builder.ToString();
        }

        private void actCommentOnHistory()
        {
            if (this.lvHistory.SelectedItems.Count >= 1)
            {
                string sDefault = (this.lvHistory.SelectedItems[0].Tag as HistoryItem).Session.oFlags["ui-comments"] ?? string.Empty;
                string str2 = frmPrompt.GetUserString("Set Comment", "Enter a comment to associate with the selected Requests:", sDefault, true);
                if (str2 != null)
                {
                    this.lvHistory.BeginUpdate();
                    foreach (ListViewItem item in this.lvHistory.SelectedItems)
                    {
                        Session session = (item.Tag as HistoryItem).Session;
                        if (str2.Length > 0)
                        {
                            session.oFlags["ui-comments"] = str2;
                            item.Text = str2;
                        }
                        else
                        {
                            session.oFlags.Remove("ui-comments");
                            item.Text = session.url;
                        }
                    }
                    this.lvHistory.EndUpdate();
                    bHistoryDirty = true;
                }
            }
        }

        private void actHistoryRemoveSelected()
        {
            this.lvHistory.BeginUpdate();
            foreach (ListViewItem item in this.lvHistory.SelectedItems)
            {
                item.Remove();
            }
            if (this.lvHistory.FocusedItem != null)
            {
                this.lvHistory.FocusedItem.Selected = true;
            }
            this.lvHistory.EndUpdate();
            bHistoryDirty = true;
        }

        private void actHistorySelectAll()
        {
            this.lvHistory.BeginUpdate();
            foreach (ListViewItem item in this.lvHistory.Items)
            {
                item.Selected = true;
            }
            this.lvHistory.EndUpdate();
        }

        private bool actSendRawRequest(bool bBreakRequest)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Composer.SendFromRaw");
            try
            {
                string text = this.txtRaw.Text;
                if ((text.IndexOf("\r\n\r\n") < 0) && (text.IndexOf("\n\n") < 0))
                {
                    FiddlerApplication.DoNotifyUser("The supplied HTTP Request is incomplete. Please ensure that there is a single empty line after the HTTP headers.", "Incomplete Request");
                    return false;
                }
                bool flag = bBreakRequest || this.cbSelectBuilderResult.Checked;
                if ((((flag || this.cbFixContentLength.Checked) || this.cbAutoAuthenticate.Checked) || this.cbFollowRedirects.Checked) || CONFIG.bIsViewOnly)
                {
                    StringDictionary oNewFlags = new StringDictionary();
                    if (bBreakRequest)
                    {
                        oNewFlags["x-breakrequest"] = "Builder";
                    }
                    if (flag)
                    {
                        oNewFlags["x-Builder-Inspect"] = "1";
                    }
                    if (this.cbAutoAuthenticate.Checked)
                    {
                        oNewFlags["x-AutoAuth"] = FiddlerApplication.Prefs.GetStringPref("fiddler.composer.AutoAuthCreds", "(default)");
                    }
                    if (this.cbFollowRedirects.Checked)
                    {
                        oNewFlags["x-Builder-MaxRedir"] = FiddlerApplication.Prefs.GetInt32Pref("fiddler.composer.followredirects.max", 10).ToString();
                    }
                    if (this.cbFixContentLength.Checked)
                    {
                        oNewFlags["x-Builder-FixContentLength"] = "1";
                    }
                    FiddlerApplication.oProxy.InjectCustomRequest(text, oNewFlags);
                }
                else
                {
                    FiddlerApplication.oProxy.InjectCustomRequest(text);
                }
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception.Message, "Custom Request Failed");
                return false;
            }
        }

        private bool actSendRequestFromWizard(bool bBreakRequest)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Composer.SendFromWizard");
            if (this.cbxBuilderURL.Text != this.cbxBuilderURL.Text.Trim())
            {
                this.cbxBuilderURL.Text = this.cbxBuilderURL.Text.Trim();
            }
            this.cbxBuilderURL.DroppedDown = false;
            this.cbxBuilderMethod.Text = this.cbxBuilderMethod.Text.Trim();
            this.cbxBuilderHTTPVersion.Text = this.cbxBuilderHTTPVersion.Text.Trim();
            if (!this.cbxBuilderURL.Text.OICStartsWithAny(new string[] { "http:", "https:", "ftp:" }))
            {
                if (this.cbxBuilderURL.Text.Contains("://"))
                {
                    MessageBox.Show("Only FTP://, HTTP://, and HTTPS:// URLs are supported.\n\nInvalid URI: " + this.cbxBuilderURL.Text, "Invalid URI");
                    return false;
                }
                this.cbxBuilderURL.Text = "http://" + this.cbxBuilderURL.Text;
            }
            string str = null;
            if (this.cbxBuilderURL.Text.StartsWith("http") && this.cbxBuilderURL.Text.Contains("@"))
            {
                string text = this.cbxBuilderURL.Text;
                int num = Utilities.IndexOfNth(text, 3, '/');
                if (num < 0)
                {
                    num = text.Length - 1;
                }
                int index = text.IndexOf("@");
                if (index < num)
                {
                    int num3 = Utilities.IndexOfNth(text, 2, '/');
                    if (num3 < index)
                    {
                        this.cbxBuilderURL.Text = text.Substring(0, num3 + 1) + text.Substring(index + 1);
                        string str3 = text.Substring(num3 + 1, (index - num3) - 1);
                        if (!string.IsNullOrEmpty(str3))
                        {
                            str = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(str3));
                        }
                    }
                }
            }
            if (!this.cbxBuilderURL.Items.Contains(this.cbxBuilderURL.Text))
            {
                this.cbxBuilderURL.Items.Add(this.cbxBuilderURL.Text);
            }
            bool flag = this.cbxBuilderURL.Text.Contains("#");
            string format = "d";
            int result = 0;
            int num5 = 10;
            if (flag)
            {
                string s = string.Empty;
                string str5 = frmPrompt.GetUserString("Sequential Requests Starting At", "# symbols in URL and Referer will be replaced by numbers. Prepend leading 0s if fixed-width padding is desired. Start numbers at:", "0", true, frmPrompt.PromptIcon.Numbers);
                if (str5 == null)
                {
                    flag = false;
                }
                else
                {
                    str5 = str5.Trim();
                    if (str5.StartsWith("0") && (str5 != "0"))
                    {
                        format = "d" + str5.Length;
                    }
                }
                if (flag)
                {
                    s = frmPrompt.GetUserString("Sequential Requests Ending At", "End numbers at: ", "10", true, frmPrompt.PromptIcon.Numbers);
                    if (s == null)
                    {
                        flag = false;
                    }
                }
                if (flag && (!int.TryParse(str5, out result) || !int.TryParse(s, out num5)))
                {
                    flag = false;
                }
            }
            try
            {
                StringBuilder builder;
                byte[] bytes;
            Label_02FF:
                builder = new StringBuilder(0x400);
                string str7 = this.cbxBuilderURL.Text;
                if (flag)
                {
                    str7 = str7.Replace("#", result.ToString(format));
                }
                builder.AppendFormat("{0} {1} {2}\r\n", this.cbxBuilderMethod.Text, str7, this.cbxBuilderHTTPVersion.Text);
                builder.Append(this.txtBuilderRequestHeaders.Text.Trim());
                builder.Append("\r\n\r\n");
                HTTPRequestHeaders oHeaders = Parser.ParseRequest(builder.ToString());
                builder = null;
                if (this.cbAutoAuthenticate.Checked)
                {
                    string inStr = oHeaders["Authorization"];
                    if ((!string.IsNullOrEmpty(str) || inStr.OICContains("NTLM")) || (inStr.OICContains("Negotiate") || inStr.OICContains("Digest")))
                    {
                        oHeaders.Remove("Authorization");
                    }
                    inStr = oHeaders["Proxy-Authorization"];
                    if ((inStr.OICContains("NTLM") || inStr.OICContains("Negotiate")) || inStr.OICContains("Digest"))
                    {
                        oHeaders.Remove("Proxy-Authorization");
                    }
                }
                if (!string.IsNullOrEmpty(str))
                {
                    oHeaders["Authorization"] = str;
                }
                Encoding oEncForText = Utilities.getEntityBodyEncoding(oHeaders, null);
                if (!this.txtBuilderRequestBody.Text.OICContains("<@INCLUDE"))
                {
                    bytes = oEncForText.GetBytes(this.txtBuilderRequestBody.Text);
                }
                else
                {
                    bytes = GetComposedUpload(this.txtBuilderRequestBody.Text, oEncForText);
                }
                string sString = str7;
                int num6 = sString.IndexOf("//", StringComparison.Ordinal);
                if (num6 > -1)
                {
                    sString = sString.Substring(num6 + 2);
                }
                if (str7.OICStartsWith("ftp"))
                {
                    sString = Utilities.TrimBefore(sString, '@');
                }
                int length = sString.IndexOfAny(new char[] { '/', '?' });
                if (length > -1)
                {
                    sString = sString.Substring(0, length).ToLower();
                }
                oHeaders["Host"] = sString;
                if ((this.cbFixContentLength.Checked && ((oHeaders.Exists("Content-Length") || (bytes.Length > 0)) || Utilities.HTTPMethodAllowsBody(this.cbxBuilderMethod.Text))) && !oHeaders.ExistsAndContains("Transfer-Encoding", "chunked"))
                {
                    oHeaders["Content-Length"] = bytes.Length.ToString();
                }
                this.txtBuilderRequestHeaders.Text = oHeaders.ToString(false, false);
                if (oHeaders.ExistsAndContains("Fiddler-Encoding", "base64"))
                {
                    oHeaders.Remove("Fiddler-Encoding");
                    if ((bytes != null) && (bytes.Length > 0))
                    {
                        try
                        {
                            bytes = Convert.FromBase64String(Encoding.ASCII.GetString(bytes));
                        }
                        catch
                        {
                            FiddlerApplication.DoNotifyUser("The content body is not valid base64-text. Fiddler-Encoding directive ignored.", "Non-encoded body");
                        }
                        if (!oHeaders.Exists("Transfer-Encoding"))
                        {
                            oHeaders["Content-Length"] = bytes.LongLength.ToString();
                        }
                    }
                }
                Session session = new Session((HTTPRequestHeaders) oHeaders.Clone(), bytes);
                session.SetBitFlag(SessionFlags.RequestGeneratedByFiddler, true);
                session.oFlags["x-From-Builder"] = "Parsed";
                session.propagateProcessInfo(null);
                if (this.cbComposerLogRequests.Checked)
                {
                    Session osHistory = new Session((HTTPRequestHeaders) oHeaders.Clone(), bytes);
                    this.AddToHistory(osHistory);
                    if (this.miHistoryRemoveDuplicates.Checked)
                    {
                        this.PruneDuplicateHistory();
                    }
                }
                string str10 = session.oRequest.headers["Fiddler-Host"];
                if (!string.IsNullOrEmpty(str10))
                {
                    session.oRequest.headers.Remove("Fiddler-Host");
                    session.oFlags["X-OverrideHost"] = str10;
                    session.oFlags["x-OverrideGateway"] = "DIRECT";
                    session.oFlags["X-IgnoreCertCNMismatch"] = "Overrode HOST";
                }
                bool flag2 = this.cbSelectBuilderResult.Checked;
                if (bBreakRequest)
                {
                    session.oFlags["x-breakrequest"] = "Builder";
                    flag2 = true;
                }
                if (flag)
                {
                    if (session.oRequest.headers.ExistsAndContains("Referer", "#"))
                    {
                        session.oRequest["Referer"] = session.oRequest["Referer"].Replace("#", result.ToString(format));
                    }
                }
                else if (flag2)
                {
                    session.oFlags["x-Builder-Inspect"] = "1";
                }
                if (this.cbAutoAuthenticate.Checked)
                {
                    session.oFlags["x-AutoAuth"] = FiddlerApplication.Prefs.GetStringPref("fiddler.composer.AutoAuthCreds", "(default)");
                }
                if (this.cbFollowRedirects.Checked)
                {
                    session.oFlags["x-Builder-MaxRedir"] = FiddlerApplication.Prefs.GetInt32Pref("fiddler.composer.followredirects.max", 10).ToString();
                }
                ThreadPool.UnsafeQueueUserWorkItem(new WaitCallback(session.Execute), DateTime.Now);
                if (flag && (result < num5))
                {
                    result++;
                    goto Label_02FF;
                }
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception.Message, "Custom Request Failed");
                return false;
            }
        }

        private bool actSendScratchRequest(bool bBreakRequest)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Composer.SendFromScratch");
            try
            {
                HTTPRequestHeaders headers;
                byte[] buffer;
                string inStr = this.txtScratch.SelectedText.Trim();
                if ((inStr.OICStartsWith("curl") && (inStr.OICStartsWith("curl ") || inStr.OICStartsWith("curl."))) && frmViewer.GetRequestFromCURLString(inStr, out headers, out buffer))
                {
                    inStr = headers.ToString(true, true, true) + Encoding.UTF8.GetString(buffer);
                }
                if (!inStr.Contains(" ") && inStr.Contains("://"))
                {
                    Uri uri = new Uri(inStr);
                    string authority = uri.Authority;
                    inStr = string.Format("GET {0} HTTP/1.1\r\nHost: {1}\r\n\r\n", inStr, authority);
                }
                if (!inStr.Contains("\r\n\r\n"))
                {
                    inStr = inStr + "\r\n\r\n";
                }
                bool flag = bBreakRequest || this.cbSelectBuilderResult.Checked;
                StringDictionary oNewFlags = new StringDictionary();
                if (bBreakRequest)
                {
                    oNewFlags["x-breakrequest"] = "Builder";
                }
                oNewFlags["x-From-Builder"] = "Scratchpad";
                if (flag)
                {
                    oNewFlags["x-Builder-Inspect"] = "1";
                }
                if (this.cbAutoAuthenticate.Checked)
                {
                    oNewFlags["x-AutoAuth"] = FiddlerApplication.Prefs.GetStringPref("fiddler.composer.AutoAuthCreds", "(default)");
                }
                if (this.cbFollowRedirects.Checked)
                {
                    oNewFlags["x-Builder-MaxRedir"] = FiddlerApplication.Prefs.GetInt32Pref("fiddler.composer.followredirects.max", 10).ToString();
                }
                if (this.cbFixContentLength.Checked)
                {
                    oNewFlags["x-Builder-FixContentLength"] = "1";
                }
                FiddlerApplication.oProxy.InjectCustomRequest(inStr, oNewFlags);
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception.Message, "Custom Request Failed");
                return false;
            }
        }

        internal static bool AddSessionsToScratch(Session[] oSessions)
        {
            EnsureReady();
            byte[] bytes = Encoding.UTF8.GetBytes("\r\n==========================================================\r\n\r\n");
            MemoryStream oFS = new MemoryStream();
            foreach (Session session in oSessions)
            {
                oFS.Write(bytes, 0, bytes.Length);
                session.WriteRequestToStream(session.HTTPMethodIs("CONNECT"), true, true, oFS);
            }
            string text = Encoding.UTF8.GetString(oFS.GetBuffer());
            oRequestBuilder.txtScratch.AppendText(text);
            oRequestBuilder.txtScratch.Modified = true;
            return true;
        }

        internal static bool AddTextToScratch(string sText)
        {
            EnsureReady();
            oRequestBuilder.txtScratch.AppendText(sText);
            return true;
        }

        private void AddToHistory(Session osHistory)
        {
            string url;
            int imageIndex = 0;
            string requestMethod = osHistory.RequestMethod;
            if (requestMethod != null)
            {
                if (!(requestMethod == "GET"))
                {
                    if (requestMethod == "POST")
                    {
                        imageIndex = 1;
                        goto Label_0055;
                    }
                    if ((requestMethod == "OPTIONS") || (requestMethod == "HEAD"))
                    {
                        imageIndex = 2;
                        goto Label_0055;
                    }
                }
                else
                {
                    imageIndex = 0;
                    goto Label_0055;
                }
            }
            imageIndex = 3;
        Label_0055:
            url = osHistory.oFlags["ui-comments"];
            if (!Utilities.IsCommentUserSupplied(url))
            {
                url = osHistory.url;
            }
            ListViewItem item = this.lvHistory.Items.Insert(0, url, imageIndex);
            string str2 = Utilities.IsNullOrEmpty(osHistory.requestBodyBytes) ? string.Empty : string.Format("\n{0} body bytes", osHistory.requestBodyBytes.Length);
            item.ToolTipText = string.Format("{0}\n{1}{2}", osHistory.RequestMethod, osHistory.fullUrl, str2);
            item.Tag = new HistoryItem(osHistory);
            bHistoryDirty = true;
        }

        private void btnBuilderExecute_Click(object sender, EventArgs e)
        {
            bool bBreakRequest = Keys.Shift == (Control.ModifierKeys & Keys.Shift);
            if (this.tabsBuilder.SelectedTab == this.pageRaw)
            {
                this.actSendRawRequest(bBreakRequest);
            }
            else if (this.tabsBuilder.SelectedTab == this.pageScratch)
            {
                if (this.txtScratch.SelectionLength < 10)
                {
                    MessageBox.Show("In the box below, please highlight the complete HTTP request to be sent before pressing Execute.", "Invalid Selection");
                }
                else
                {
                    this.actSendScratchRequest(bBreakRequest);
                }
            }
            else
            {
                this.actSendRequestFromWizard(bBreakRequest);
            }
        }

        private void btnTearOff_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Composer.TearOff");
            this.UndockBuilder();
        }

        private void Builder_BodyOrMethodChanged(object sender, EventArgs e)
        {
            if (Utilities.HTTPMethodAllowsBody(this.cbxBuilderMethod.Text.Trim().ToUpperInvariant()))
            {
                this.txtBuilderRequestBody.BackColor = Color.FromKnownColor(KnownColor.Window);
            }
            else
            {
                this.txtBuilderRequestBody.BackColor = (this.txtBuilderRequestBody.Text.Length > 0) ? Color.Red : Color.FromKnownColor(KnownColor.Control);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void DockBuilder()
        {
            FiddlerApplication.UI.tabsViews.Controls.Add(FiddlerApplication.UI.pageBuilder);
            FiddlerApplication.UI.pageBuilder.Dock = DockStyle.Fill;
            oRequestBuilder.Parent = FiddlerApplication.UI.pageBuilder;
            oRequestBuilder.Dock = DockStyle.Fill;
            this.gbUIOptions.Visible = true;
            this.cbSelectBuilderResult.Checked = false;
            frmFloatingBuilder = null;
        }

        internal static void EnsureReady()
        {
            if (oRequestBuilder == null)
            {
                FiddlerApplication.UI.pageBuilder.SuspendLayout();
                oRequestBuilder = new UIComposer();
                oRequestBuilder.Dock = DockStyle.Fill;
                oRequestBuilder.Parent = FiddlerApplication.UI.pageBuilder;
                oRequestBuilder.txtBuilderRequestBody.MaxLength = FiddlerApplication.Prefs.GetInt32Pref("fiddler.composer.MaxBodyLength", oRequestBuilder.txtBuilderRequestBody.MaxLength);
                oRequestBuilder.txtScratch.MaxLength = FiddlerApplication.Prefs.GetInt32Pref("fiddler.composer.MaxScratchLength", oRequestBuilder.txtScratch.MaxLength);
                FiddlerApplication.UI.pageBuilder.ResumeLayout();
                sizeDblClickArea = new Size(SystemInformation.DoubleClickSize.Width / 2, SystemInformation.DoubleClickSize.Height / 2);
            }
        }

        private void EnsureScratch()
        {
            if (!bLoadedScratch)
            {
                bLoadedScratch = true;
                try
                {
                    this.txtScratch.Text = File.ReadAllText(CONFIG.GetPath("Root") + "Composer_Scratch.txt", Encoding.UTF8);
                }
                catch
                {
                }
            }
        }

        internal static void EnsureShowing()
        {
            if (frmFloatingBuilder != null)
            {
                frmFloatingBuilder.BringToFront();
            }
            else if (FiddlerApplication.UI.pageBuilder != null)
            {
                if (!FiddlerApplication.UI.tabsViews.Contains(FiddlerApplication.UI.pageBuilder))
                {
                    FiddlerApplication.UI.tabsViews.Controls.Add(FiddlerApplication.UI.pageBuilder);
                }
                FiddlerApplication.UI.tabsViews.SelectedTab = FiddlerApplication.UI.pageBuilder;
            }
        }

        internal static bool FillUIFromSession(Session oSession)
        {
            EnsureReady();
            oRequestBuilder.cbxBuilderHTTPVersion.Text = oSession.oRequest.headers.HTTPVersion;
            oRequestBuilder.cbxBuilderMethod.Text = oSession.RequestMethod;
            oRequestBuilder.cbxBuilderURL.Text = oSession.fullUrl;
            bool flag = ((oSession.requestBodyBytes != null) && !oSession.HTTPMethodIs("CONNECT")) && Utilities.arrayContainsNonText(oSession.requestBodyBytes);
            if (oSession.oRequest.headers != null)
            {
                HTTPRequestHeaders headers = (HTTPRequestHeaders) oSession.oRequest.headers.Clone();
                if (flag)
                {
                    headers["Fiddler-Encoding"] = "base64";
                }
                oRequestBuilder.txtBuilderRequestHeaders.Text = headers.ToString(false, false);
                oRequestBuilder.txtRaw.Text = headers.ToString(true, true, true);
            }
            else
            {
                oRequestBuilder.txtBuilderRequestHeaders.Clear();
                oRequestBuilder.txtRaw.Clear();
            }
            if ((oSession.requestBodyBytes != null) && !oSession.HTTPMethodIs("CONNECT"))
            {
                if (flag)
                {
                    oRequestBuilder.txtBuilderRequestBody.Text = Convert.ToBase64String(oSession.requestBodyBytes);
                }
                else
                {
                    oRequestBuilder.txtBuilderRequestBody.Text = Utilities.GetStringFromArrayRemovingBOM(oSession.requestBodyBytes, oSession.GetRequestBodyEncoding());
                }
                oRequestBuilder.txtRaw.Text = oRequestBuilder.txtRaw.Text + oRequestBuilder.txtBuilderRequestBody.Text;
            }
            else
            {
                oRequestBuilder.txtBuilderRequestBody.Clear();
            }
            return true;
        }

        private void FloodSelectText()
        {
            try
            {
                int lineNumber = Math.Min(this.txtScratch.GetLineFromCharIndex(this.txtScratch.SelectionStart), this.GetLineCount());
                int firstCharIndexFromLine = this.txtScratch.GetFirstCharIndexFromLine(lineNumber);
                if (firstCharIndexFromLine < this.txtScratch.TextLength)
                {
                    int lineLength = this.GetLineLength(lineNumber);
                    int iLineNum = lineNumber;
                    while (--iLineNum >= 0)
                    {
                        if (!this.isValidLine(iLineNum, false))
                        {
                            break;
                        }
                        firstCharIndexFromLine = this.txtScratch.GetFirstCharIndexFromLine(iLineNum);
                        lineLength += this.GetLineLength(iLineNum);
                    }
                    bool bBreakOnlyOnEqualLine = false;
                    if (this.txtScratch.Text[firstCharIndexFromLine] == 'P')
                    {
                        bBreakOnlyOnEqualLine = true;
                    }
                    int num5 = lineNumber;
                    while (++num5 < this.GetLineCount())
                    {
                        if (!this.isValidLine(num5, bBreakOnlyOnEqualLine))
                        {
                            break;
                        }
                        lineLength += this.GetLineLength(num5);
                    }
                    this.txtScratch.SelectionStart = firstCharIndexFromLine;
                    this.txtScratch.SelectionLength = lineLength;
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Unable to FloodSelect");
            }
        }

        private void frmFloatingBuilder_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.DockBuilder();
        }

        private static byte[] GetComposedUpload(string sUpload, Encoding oEncForText)
        {
            MemoryStream stream = new MemoryStream();
            int startIndex = 0;
            for (int i = sUpload.IndexOf("<@INCLUDE", startIndex, StringComparison.OrdinalIgnoreCase); i > -1; i = sUpload.IndexOf("<@INCLUDE", startIndex, StringComparison.OrdinalIgnoreCase))
            {
                if (i > startIndex)
                {
                    byte[] bytes = oEncForText.GetBytes(sUpload.Substring(startIndex, i - startIndex));
                    stream.Write(bytes, 0, bytes.Length);
                    startIndex += i - startIndex;
                }
                bool flag = false;
                while ((i < sUpload.Length) && ('*' != sUpload[i]))
                {
                    if (((sUpload[i] == 'b') || (sUpload[i] == 'B')) && ((i < (sUpload.Length - 6)) && (string.Compare(sUpload, i, "base64", 0, 6, true) == 0)))
                    {
                        flag = true;
                    }
                    i++;
                }
                if (i < sUpload.Length)
                {
                    i++;
                    int index = sUpload.IndexOf('*', i);
                    byte[] inArray = File.ReadAllBytes(sUpload.Substring(i, index - i));
                    if (flag)
                    {
                        inArray = Encoding.ASCII.GetBytes(Convert.ToBase64String(inArray));
                    }
                    stream.Write(inArray, 0, inArray.Length);
                    startIndex = sUpload.IndexOf("@>", index);
                    if (startIndex < 0)
                    {
                        startIndex = sUpload.Length;
                    }
                    else
                    {
                        startIndex += 2;
                    }
                }
            }
            if (startIndex < sUpload.Length)
            {
                byte[] buffer = oEncForText.GetBytes(sUpload.Substring(startIndex));
                stream.Write(buffer, 0, buffer.Length);
            }
            return stream.ToArray();
        }

        private int GetLineCount()
        {
            return (int) Utilities.SendMessage(this.txtScratch.Handle, 0xba, IntPtr.Zero, IntPtr.Zero);
        }

        private int GetLineLength(int iLine)
        {
            int firstCharIndexFromLine = this.txtScratch.GetFirstCharIndexFromLine(iLine);
            int lineNumber = iLine + 1;
            if (lineNumber >= this.GetLineCount())
            {
                return (this.txtScratch.TextLength - firstCharIndexFromLine);
            }
            return (this.txtScratch.GetFirstCharIndexFromLine(lineNumber) - firstCharIndexFromLine);
        }

        private void HandleSelectAllKeydown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.A))
            {
                (sender as TextBox).SelectAll();
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(UIComposer));
            this.cbAutoAuthenticate = new CheckBox();
            this.cbFollowRedirects = new CheckBox();
            this.cbFixContentLength = new CheckBox();
            this.cbSelectBuilderResult = new CheckBox();
            this.lnkUnhideHistoryPane = new LinkLabel();
            this.btnBuilderExecute = new Button();
            this.tabsBuilder = new TabControl();
            this.pageParsed = new TabPage();
            this.splitOutside = new SplitContainer();
            this.pnlParsed = new Panel();
            this.splitHeaderBody = new SplitContainer();
            this.cbxBuilderHTTPVersion = new ComboBox();
            this.txtBuilderRequestHeaders = new TextBox();
            this.cbxBuilderURL = new ComboBox();
            this.cbxBuilderMethod = new ComboBox();
            this.txtBuilderRequestBody = new TextBox();
            this.linkUpload = new LinkLabel();
            this.pnlHistory = new Panel();
            this.lvHistory = new DoubleBufferedListView();
            this.colParsedHistory = new ColumnHeader();
            this.mnuHistory = new ContextMenuStrip(this.components);
            this.miHistoryComment = new ToolStripMenuItem();
            this.miRemoveHistory = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripSeparator();
            this.miSelectAllHistory = new ToolStripMenuItem();
            this.miHistoryRemoveDuplicates = new ToolStripMenuItem();
            this.toolStripMenuItem3 = new ToolStripSeparator();
            this.miLoadHistory = new ToolStripMenuItem();
            this.miSaveHistory = new ToolStripMenuItem();
            this.miHistorySaveOnExit = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.miHideHistory = new ToolStripMenuItem();
            this.imglComposer = new ImageList(this.components);
            this.cbComposerLogRequests = new CheckBox();
            this.pageRaw = new TabPage();
            this.txtRaw = new TextBox();
            this.pageScratch = new TabPage();
            this.txtScratch = new TextBox();
            this.pageOptions = new TabPage();
            this.gbUIOptions = new GroupBox();
            this.lblTearoff = new Label();
            this.btnTearOff = new Button();
            Label label = new Label();
            Label label2 = new Label();
            GroupBox box = new GroupBox();
            LinkLabel label3 = new LinkLabel();
            Label label4 = new Label();
            box.SuspendLayout();
            this.tabsBuilder.SuspendLayout();
            this.pageParsed.SuspendLayout();
            this.splitOutside.Panel1.SuspendLayout();
            this.splitOutside.Panel2.SuspendLayout();
            this.splitOutside.SuspendLayout();
            this.pnlParsed.SuspendLayout();
            this.splitHeaderBody.Panel1.SuspendLayout();
            this.splitHeaderBody.Panel2.SuspendLayout();
            this.splitHeaderBody.SuspendLayout();
            this.pnlHistory.SuspendLayout();
            this.mnuHistory.SuspendLayout();
            this.pageRaw.SuspendLayout();
            this.pageScratch.SuspendLayout();
            this.pageOptions.SuspendLayout();
            this.gbUIOptions.SuspendLayout();
            base.SuspendLayout();
            label.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            label.BackColor = Color.Gray;
            label.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            label.ForeColor = Color.White;
            label.Location = new Point(3, 3);
            label.Name = "lblHintBuilder";
            label.Padding = new Padding(4);
            label.Size = new Size(0x2af, 0x26);
            label.TabIndex = 0x11;
            label.Text = "Use this page to compose a Request. You can clone a prior request by dragging and dropping a session from the Web Sessions list.";
            label.TextAlign = ContentAlignment.MiddleLeft;
            label2.BackColor = Color.LightGoldenrodYellow;
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(3, 3);
            label2.Name = "lblExplainScratch";
            label2.Padding = new Padding(4);
            label2.Size = new Size(0x2e2, 0x26);
            label2.TabIndex = 0x12;
            label2.Text = "Use this tab to store a collection of Requests. To issue a request, select its text and press Execute.";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            box.Controls.Add(this.cbAutoAuthenticate);
            box.Controls.Add(this.cbFollowRedirects);
            box.Controls.Add(this.cbFixContentLength);
            box.Controls.Add(this.cbSelectBuilderResult);
            box.Location = new Point(0x12, 0x10);
            box.Name = "gbRequestOptions";
            box.Size = new Size(0x184, 0x7e);
            box.TabIndex = 0;
            box.TabStop = false;
            box.Text = "Request Options";
            box.UseCompatibleTextRendering = true;
            this.cbAutoAuthenticate.Location = new Point(9, 0x59);
            this.cbAutoAuthenticate.Name = "cbAutoAuthenticate";
            this.cbAutoAuthenticate.Size = new Size(0x110, 0x11);
            this.cbAutoAuthenticate.TabIndex = 3;
            this.cbAutoAuthenticate.Text = "Automatically Authenticate";
            this.cbAutoAuthenticate.UseVisualStyleBackColor = true;
            this.cbFollowRedirects.Checked = true;
            this.cbFollowRedirects.CheckState = CheckState.Checked;
            this.cbFollowRedirects.Location = new Point(9, 0x42);
            this.cbFollowRedirects.Name = "cbFollowRedirects";
            this.cbFollowRedirects.Size = new Size(0xec, 0x11);
            this.cbFollowRedirects.TabIndex = 2;
            this.cbFollowRedirects.Text = "Follow Redirects";
            this.cbFollowRedirects.UseVisualStyleBackColor = true;
            this.cbFixContentLength.Checked = true;
            this.cbFixContentLength.CheckState = CheckState.Checked;
            this.cbFixContentLength.Location = new Point(9, 0x2b);
            this.cbFixContentLength.Name = "cbFixContentLength";
            this.cbFixContentLength.Size = new Size(0xfe, 0x11);
            this.cbFixContentLength.TabIndex = 1;
            this.cbFixContentLength.Text = "Fix Content-Length header";
            this.cbFixContentLength.UseVisualStyleBackColor = true;
            this.cbSelectBuilderResult.Location = new Point(9, 20);
            this.cbSelectBuilderResult.Name = "cbSelectBuilderResult";
            this.cbSelectBuilderResult.Size = new Size(0xec, 0x11);
            this.cbSelectBuilderResult.TabIndex = 0;
            this.cbSelectBuilderResult.Text = "Inspect Session";
            this.cbSelectBuilderResult.UseVisualStyleBackColor = true;
            label3.AutoSize = true;
            label3.LinkBehavior = LinkBehavior.HoverUnderline;
            label3.Location = new Point(15, 0xfb);
            label3.Name = "lnkBuilderHelp";
            label3.Size = new Size(0x5b, 13);
            label3.TabIndex = 0x1f;
            label3.TabStop = true;
            label3.Text = "Composer Help...";
            label3.TextAlign = ContentAlignment.MiddleLeft;
            label3.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkBuilderHelp_LinkClicked);
            label4.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(3, 0);
            label4.Name = "lblBuilderRequestBody";
            label4.Size = new Size(0x88, 13);
            label4.TabIndex = 0x20;
            label4.Text = "Request Body";
            this.lnkUnhideHistoryPane.AutoSize = true;
            this.lnkUnhideHistoryPane.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkUnhideHistoryPane.Location = new Point(6, 0x52);
            this.lnkUnhideHistoryPane.Name = "lnkUnhideHistoryPane";
            this.lnkUnhideHistoryPane.Size = new Size(0x93, 13);
            this.lnkUnhideHistoryPane.TabIndex = 0x20;
            this.lnkUnhideHistoryPane.TabStop = true;
            this.lnkUnhideHistoryPane.Text = "Unhide Request History Pane";
            this.lnkUnhideHistoryPane.TextAlign = ContentAlignment.MiddleLeft;
            this.lnkUnhideHistoryPane.Visible = false;
            this.lnkUnhideHistoryPane.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkUnhideHistoryPane_LinkClicked);
            this.btnBuilderExecute.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.btnBuilderExecute.Location = new Point(0x2b4, 3);
            this.btnBuilderExecute.Name = "btnBuilderExecute";
            this.btnBuilderExecute.Size = new Size(0x3e, 0x26);
            this.btnBuilderExecute.TabIndex = 14;
            this.btnBuilderExecute.Text = "E&xecute";
            this.btnBuilderExecute.Click += new EventHandler(this.btnBuilderExecute_Click);
            this.tabsBuilder.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.tabsBuilder.Controls.Add(this.pageParsed);
            this.tabsBuilder.Controls.Add(this.pageRaw);
            this.tabsBuilder.Controls.Add(this.pageScratch);
            this.tabsBuilder.Controls.Add(this.pageOptions);
            this.tabsBuilder.ItemSize = new Size(0x2d, 0x12);
            this.tabsBuilder.Location = new Point(3, 0x2c);
            this.tabsBuilder.Multiline = true;
            this.tabsBuilder.Name = "tabsBuilder";
            this.tabsBuilder.SelectedIndex = 0;
            this.tabsBuilder.Size = new Size(0x2f0, 0x22d);
            this.tabsBuilder.TabIndex = 0;
            this.tabsBuilder.SelectedIndexChanged += new EventHandler(this.tabsBuilder_SelectedIndexChanged);
            this.pageParsed.Controls.Add(this.splitOutside);
            this.pageParsed.Location = new Point(4, 0x16);
            this.pageParsed.Name = "pageParsed";
            this.pageParsed.Padding = new Padding(3);
            this.pageParsed.Size = new Size(0x2e8, 0x213);
            this.pageParsed.TabIndex = 0;
            this.pageParsed.Text = "Parsed";
            this.pageParsed.UseVisualStyleBackColor = true;
            this.splitOutside.Dock = DockStyle.Fill;
            this.splitOutside.Location = new Point(3, 3);
            this.splitOutside.Name = "splitOutside";
            this.splitOutside.Panel1.Controls.Add(this.pnlParsed);
            this.splitOutside.Panel1.RightToLeft = RightToLeft.No;
            this.splitOutside.Panel2.Controls.Add(this.pnlHistory);
            this.splitOutside.Panel2.RightToLeft = RightToLeft.No;
            this.splitOutside.Size = new Size(0x2e2, 0x20d);
            this.splitOutside.SplitterDistance = 0x247;
            this.splitOutside.SplitterWidth = 2;
            this.splitOutside.TabIndex = 0x22;
            this.pnlParsed.Controls.Add(this.splitHeaderBody);
            this.pnlParsed.Dock = DockStyle.Fill;
            this.pnlParsed.Location = new Point(0, 0);
            this.pnlParsed.Margin = new Padding(1);
            this.pnlParsed.Name = "pnlParsed";
            this.pnlParsed.Size = new Size(0x247, 0x20d);
            this.pnlParsed.TabIndex = 0x20;
            this.splitHeaderBody.Dock = DockStyle.Fill;
            this.splitHeaderBody.Location = new Point(0, 0);
            this.splitHeaderBody.Name = "splitHeaderBody";
            this.splitHeaderBody.Orientation = Orientation.Horizontal;
            this.splitHeaderBody.Panel1.Controls.Add(this.cbxBuilderHTTPVersion);
            this.splitHeaderBody.Panel1.Controls.Add(this.txtBuilderRequestHeaders);
            this.splitHeaderBody.Panel1.Controls.Add(this.cbxBuilderURL);
            this.splitHeaderBody.Panel1.Controls.Add(this.cbxBuilderMethod);
            this.splitHeaderBody.Panel1MinSize = 60;
            this.splitHeaderBody.Panel2.Controls.Add(this.txtBuilderRequestBody);
            this.splitHeaderBody.Panel2.Controls.Add(label4);
            this.splitHeaderBody.Panel2.Controls.Add(this.linkUpload);
            this.splitHeaderBody.Size = new Size(0x247, 0x20d);
            this.splitHeaderBody.SplitterDistance = 0xd8;
            this.splitHeaderBody.TabIndex = 5;
            this.cbxBuilderHTTPVersion.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.cbxBuilderHTTPVersion.Items.AddRange(new object[] { "HTTP/2.0", "HTTP/1.2", "HTTP/1.1", "HTTP/1.0", "HTTP/0.9" });
            this.cbxBuilderHTTPVersion.Location = new Point(0x1e7, 4);
            this.cbxBuilderHTTPVersion.Name = "cbxBuilderHTTPVersion";
            this.cbxBuilderHTTPVersion.Size = new Size(0x5d, 0x15);
            this.cbxBuilderHTTPVersion.TabIndex = 7;
            this.txtBuilderRequestHeaders.AcceptsReturn = true;
            this.txtBuilderRequestHeaders.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtBuilderRequestHeaders.BackColor = SystemColors.Window;
            this.txtBuilderRequestHeaders.Location = new Point(3, 0x1f);
            this.txtBuilderRequestHeaders.MaxLength = 0x400000;
            this.txtBuilderRequestHeaders.Multiline = true;
            this.txtBuilderRequestHeaders.Name = "txtBuilderRequestHeaders";
            this.txtBuilderRequestHeaders.ScrollBars = ScrollBars.Both;
            this.txtBuilderRequestHeaders.Size = new Size(0x241, 0xb8);
            this.txtBuilderRequestHeaders.TabIndex = 8;
            this.txtBuilderRequestHeaders.Text = "User-Agent: Fiddler";
            this.txtBuilderRequestHeaders.WordWrap = false;
            this.txtBuilderRequestHeaders.KeyDown += new KeyEventHandler(this.HandleSelectAllKeydown);
            this.cbxBuilderURL.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.cbxBuilderURL.Location = new Point(0x5d, 4);
            this.cbxBuilderURL.Name = "cbxBuilderURL";
            this.cbxBuilderURL.Size = new Size(0x184, 0x15);
            this.cbxBuilderURL.TabIndex = 6;
            this.cbxBuilderURL.Text = "http://www.example.com/";
            this.cbxBuilderURL.TextChanged += new EventHandler(this.txtBuilderURL_TextChanged);
            this.cbxBuilderURL.KeyDown += new KeyEventHandler(this.txtBuilderURL_KeyDown);
            this.cbxBuilderURL.KeyPress += new KeyPressEventHandler(this.txtBuilderURL_KeyPress);
            this.cbxBuilderMethod.Items.AddRange(new object[] { 
                "GET", "POST", "PUT", "HEAD", "TRACE", "DELETE", "SEARCH", "CONNECT", "PROPFIND", "PROPPATCH", "PATCH", "MKCOL", "COPY", "MOVE", "LOCK", "UNLOCK", 
                "OPTIONS"
             });
            this.cbxBuilderMethod.Location = new Point(3, 4);
            this.cbxBuilderMethod.Name = "cbxBuilderMethod";
            this.cbxBuilderMethod.Size = new Size(0x56, 0x15);
            this.cbxBuilderMethod.TabIndex = 5;
            this.cbxBuilderMethod.TextChanged += new EventHandler(this.Builder_BodyOrMethodChanged);
            this.txtBuilderRequestBody.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtBuilderRequestBody.BackColor = SystemColors.Control;
            this.txtBuilderRequestBody.Location = new Point(3, 0x10);
            this.txtBuilderRequestBody.MaxLength = 0x1000000;
            this.txtBuilderRequestBody.Multiline = true;
            this.txtBuilderRequestBody.Name = "txtBuilderRequestBody";
            this.txtBuilderRequestBody.ScrollBars = ScrollBars.Both;
            this.txtBuilderRequestBody.Size = new Size(0x241, 0x11e);
            this.txtBuilderRequestBody.TabIndex = 0x21;
            this.txtBuilderRequestBody.WordWrap = false;
            this.txtBuilderRequestBody.TextChanged += new EventHandler(this.Builder_BodyOrMethodChanged);
            this.txtBuilderRequestBody.KeyDown += new KeyEventHandler(this.HandleSelectAllKeydown);
            this.linkUpload.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.linkUpload.AutoSize = true;
            this.linkUpload.LinkBehavior = LinkBehavior.HoverUnderline;
            this.linkUpload.Location = new Point(0x1ff, 0);
            this.linkUpload.Name = "linkUpload";
            this.linkUpload.Size = new Size(0x45, 13);
            this.linkUpload.TabIndex = 0x22;
            this.linkUpload.TabStop = true;
            this.linkUpload.Text = "Upload file...";
            this.linkUpload.TextAlign = ContentAlignment.TopRight;
            this.linkUpload.LinkClicked += new LinkLabelLinkClickedEventHandler(this.linkUpload_LinkClicked);
            this.pnlHistory.BackColor = Color.AliceBlue;
            this.pnlHistory.Controls.Add(this.lvHistory);
            this.pnlHistory.Controls.Add(this.cbComposerLogRequests);
            this.pnlHistory.Dock = DockStyle.Fill;
            this.pnlHistory.Location = new Point(0, 0);
            this.pnlHistory.Margin = new Padding(0);
            this.pnlHistory.Name = "pnlHistory";
            this.pnlHistory.Padding = new Padding(3);
            this.pnlHistory.Size = new Size(0x99, 0x20d);
            this.pnlHistory.TabIndex = 0;
            this.lvHistory.BorderStyle = BorderStyle.None;
            this.lvHistory.Columns.AddRange(new ColumnHeader[] { this.colParsedHistory });
            this.lvHistory.ContextMenuStrip = this.mnuHistory;
            this.lvHistory.Dock = DockStyle.Fill;
            this.lvHistory.EmptyText = null;
            this.lvHistory.Location = new Point(3, 20);
            this.lvHistory.Name = "lvHistory";
            this.lvHistory.ShowItemToolTips = true;
            this.lvHistory.Size = new Size(0x93, 0x1f6);
            this.lvHistory.SmallImageList = this.imglComposer;
            this.lvHistory.TabIndex = 0;
            this.lvHistory.UseCompatibleStateImageBehavior = false;
            this.lvHistory.View = View.Details;
            this.lvHistory.ItemActivate += new EventHandler(this.lvHistory_ItemActivate);
            this.lvHistory.KeyDown += new KeyEventHandler(this.lvHistory_KeyDown);
            this.colParsedHistory.Text = "History";
            this.colParsedHistory.Width = 0x8e;
            this.mnuHistory.Items.AddRange(new ToolStripItem[] { this.miHistoryComment, this.miRemoveHistory, this.toolStripMenuItem2, this.miSelectAllHistory, this.miHistoryRemoveDuplicates, this.toolStripMenuItem3, this.miLoadHistory, this.miSaveHistory, this.miHistorySaveOnExit, this.toolStripMenuItem1, this.miHideHistory });
            this.mnuHistory.Name = "mnuHistory";
            this.mnuHistory.Size = new Size(0xb0, 0xc6);
            this.mnuHistory.Opening += new CancelEventHandler(this.mnuHistory_Opening);
            this.miHistoryComment.Name = "miHistoryComment";
            this.miHistoryComment.Size = new Size(0xaf, 0x16);
            this.miHistoryComment.Text = "Co&mment...";
            this.miHistoryComment.Click += new EventHandler(this.miHistoryComment_Click);
            this.miRemoveHistory.Name = "miRemoveHistory";
            this.miRemoveHistory.Size = new Size(0xaf, 0x16);
            this.miRemoveHistory.Text = "&Remove";
            this.miRemoveHistory.Click += new EventHandler(this.miRemoveHistory_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0xac, 6);
            this.miSelectAllHistory.Name = "miSelectAllHistory";
            this.miSelectAllHistory.Size = new Size(0xaf, 0x16);
            this.miSelectAllHistory.Text = "Select &All";
            this.miSelectAllHistory.Click += new EventHandler(this.miSelectAllHistory_Click);
            this.miHistoryRemoveDuplicates.Checked = true;
            this.miHistoryRemoveDuplicates.CheckOnClick = true;
            this.miHistoryRemoveDuplicates.CheckState = CheckState.Checked;
            this.miHistoryRemoveDuplicates.Name = "miHistoryRemoveDuplicates";
            this.miHistoryRemoveDuplicates.Size = new Size(0xaf, 0x16);
            this.miHistoryRemoveDuplicates.Text = "Remove &Duplicates";
            this.miHistoryRemoveDuplicates.CheckedChanged += new EventHandler(this.miHistoryRemoveDuplicates_CheckedChanged);
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new Size(0xac, 6);
            this.miLoadHistory.Name = "miLoadHistory";
            this.miLoadHistory.Size = new Size(0xaf, 0x16);
            this.miLoadHistory.Text = "&Load...";
            this.miLoadHistory.Click += new EventHandler(this.miLoadHistory_Click);
            this.miSaveHistory.Name = "miSaveHistory";
            this.miSaveHistory.Size = new Size(0xaf, 0x16);
            this.miSaveHistory.Text = "&Save All...";
            this.miSaveHistory.Click += new EventHandler(this.miSaveHistory_Click);
            this.miHistorySaveOnExit.Checked = true;
            this.miHistorySaveOnExit.CheckOnClick = true;
            this.miHistorySaveOnExit.CheckState = CheckState.Checked;
            this.miHistorySaveOnExit.Name = "miHistorySaveOnExit";
            this.miHistorySaveOnExit.Size = new Size(0xaf, 0x16);
            this.miHistorySaveOnExit.Text = "AutoSave on &Exit";
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0xac, 6);
            this.miHideHistory.Name = "miHideHistory";
            this.miHideHistory.Size = new Size(0xaf, 0x16);
            this.miHideHistory.Text = "&Hide History";
            this.miHideHistory.Click += new EventHandler(this.miHideHistory_Click);
            this.imglComposer.ImageStream = (ImageListStreamer) manager.GetObject("imglComposer.ImageStream");
            this.imglComposer.TransparentColor = Color.Magenta;
            this.imglComposer.Images.SetKeyName(0, "VerbGET");
            this.imglComposer.Images.SetKeyName(1, "VerbPOST");
            this.imglComposer.Images.SetKeyName(2, "VerbHEAD");
            this.imglComposer.Images.SetKeyName(3, "VerbUnknown");
            this.cbComposerLogRequests.AutoSize = true;
            this.cbComposerLogRequests.BackColor = Color.AliceBlue;
            this.cbComposerLogRequests.Checked = true;
            this.cbComposerLogRequests.CheckState = CheckState.Checked;
            this.cbComposerLogRequests.Dock = DockStyle.Top;
            this.cbComposerLogRequests.Location = new Point(3, 3);
            this.cbComposerLogRequests.Name = "cbComposerLogRequests";
            this.cbComposerLogRequests.Size = new Size(0x93, 0x11);
            this.cbComposerLogRequests.TabIndex = 2;
            this.cbComposerLogRequests.Text = "Log Requests";
            this.cbComposerLogRequests.UseVisualStyleBackColor = false;
            this.pageRaw.Controls.Add(this.txtRaw);
            this.pageRaw.Location = new Point(4, 0x16);
            this.pageRaw.Name = "pageRaw";
            this.pageRaw.Padding = new Padding(3);
            this.pageRaw.Size = new Size(0x2e8, 0x213);
            this.pageRaw.TabIndex = 1;
            this.pageRaw.Text = "Raw";
            this.pageRaw.UseVisualStyleBackColor = true;
            this.txtRaw.AcceptsReturn = true;
            this.txtRaw.BackColor = SystemColors.Window;
            this.txtRaw.Dock = DockStyle.Fill;
            this.txtRaw.Location = new Point(3, 3);
            this.txtRaw.MaxLength = 0x400000;
            this.txtRaw.Multiline = true;
            this.txtRaw.Name = "txtRaw";
            this.txtRaw.ScrollBars = ScrollBars.Both;
            this.txtRaw.Size = new Size(0x2e2, 0x20d);
            this.txtRaw.TabIndex = 0x1c;
            this.txtRaw.WordWrap = false;
            this.txtRaw.KeyDown += new KeyEventHandler(this.HandleSelectAllKeydown);
            this.pageScratch.Controls.Add(this.txtScratch);
            this.pageScratch.Controls.Add(label2);
            this.pageScratch.Location = new Point(4, 0x16);
            this.pageScratch.Name = "pageScratch";
            this.pageScratch.Padding = new Padding(3);
            this.pageScratch.Size = new Size(0x2e8, 0x213);
            this.pageScratch.TabIndex = 3;
            this.pageScratch.Text = "Scratchpad";
            this.pageScratch.UseVisualStyleBackColor = true;
            this.txtScratch.AcceptsReturn = true;
            this.txtScratch.BackColor = SystemColors.Window;
            this.txtScratch.Dock = DockStyle.Fill;
            this.txtScratch.HideSelection = false;
            this.txtScratch.Location = new Point(3, 0x29);
            this.txtScratch.MaxLength = 0x400000;
            this.txtScratch.Multiline = true;
            this.txtScratch.Name = "txtScratch";
            this.txtScratch.ScrollBars = ScrollBars.Both;
            this.txtScratch.Size = new Size(0x2e2, 0x1e7);
            this.txtScratch.TabIndex = 0x1d;
            this.txtScratch.WordWrap = false;
            this.txtScratch.MouseClick += new MouseEventHandler(this.txtScratch_MouseClick);
            this.txtScratch.KeyDown += new KeyEventHandler(this.HandleSelectAllKeydown);
            this.txtScratch.MouseDoubleClick += new MouseEventHandler(this.txtScratch_MouseDoubleClick);
            this.pageOptions.Controls.Add(label3);
            this.pageOptions.Controls.Add(box);
            this.pageOptions.Controls.Add(this.gbUIOptions);
            this.pageOptions.Location = new Point(4, 0x16);
            this.pageOptions.Name = "pageOptions";
            this.pageOptions.Padding = new Padding(3);
            this.pageOptions.Size = new Size(0x2e8, 0x213);
            this.pageOptions.TabIndex = 2;
            this.pageOptions.Text = "Options";
            this.pageOptions.UseVisualStyleBackColor = true;
            this.gbUIOptions.Controls.Add(this.lnkUnhideHistoryPane);
            this.gbUIOptions.Controls.Add(this.lblTearoff);
            this.gbUIOptions.Controls.Add(this.btnTearOff);
            this.gbUIOptions.Location = new Point(0x12, 0x94);
            this.gbUIOptions.Name = "gbUIOptions";
            this.gbUIOptions.Size = new Size(0x184, 100);
            this.gbUIOptions.TabIndex = 1;
            this.gbUIOptions.TabStop = false;
            this.gbUIOptions.Text = "UI Options";
            this.lblTearoff.AutoSize = true;
            this.lblTearoff.Location = new Point(6, 0x1a);
            this.lblTearoff.Name = "lblTearoff";
            this.lblTearoff.Size = new Size(0x113, 13);
            this.lblTearoff.TabIndex = 0;
            this.lblTearoff.Text = "You can \"tear off\" the Composer into a floating window.";
            this.btnTearOff.Location = new Point(9, 0x33);
            this.btnTearOff.Name = "btnTearOff";
            this.btnTearOff.Size = new Size(0x4b, 0x17);
            this.btnTearOff.TabIndex = 1;
            this.btnTearOff.Text = "Tear off";
            this.btnTearOff.UseVisualStyleBackColor = true;
            this.btnTearOff.Click += new EventHandler(this.btnTearOff_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.Controls.Add(this.tabsBuilder);
            base.Controls.Add(this.btnBuilderExecute);
            base.Controls.Add(label);
            this.DoubleBuffered = true;
            this.Font = new Font("Tahoma", 8.25f);
            base.Name = "UIComposer";
            base.Size = new Size(0x2f5, 0x25c);
            box.ResumeLayout(false);
            this.tabsBuilder.ResumeLayout(false);
            this.pageParsed.ResumeLayout(false);
            this.splitOutside.Panel1.ResumeLayout(false);
            this.splitOutside.Panel2.ResumeLayout(false);
            this.splitOutside.ResumeLayout(false);
            this.pnlParsed.ResumeLayout(false);
            this.splitHeaderBody.Panel1.ResumeLayout(false);
            this.splitHeaderBody.Panel1.PerformLayout();
            this.splitHeaderBody.Panel2.ResumeLayout(false);
            this.splitHeaderBody.Panel2.PerformLayout();
            this.splitHeaderBody.ResumeLayout(false);
            this.pnlHistory.ResumeLayout(false);
            this.pnlHistory.PerformLayout();
            this.mnuHistory.ResumeLayout(false);
            this.pageRaw.ResumeLayout(false);
            this.pageRaw.PerformLayout();
            this.pageScratch.ResumeLayout(false);
            this.pageScratch.PerformLayout();
            this.pageOptions.ResumeLayout(false);
            this.pageOptions.PerformLayout();
            this.gbUIOptions.ResumeLayout(false);
            this.gbUIOptions.PerformLayout();
            base.ResumeLayout(false);
        }

        internal static void invokeCommand(string[] sArgs)
        {
            EnsureReady();
            if ("undock".OICEquals(sArgs[0]))
            {
                oRequestBuilder.UndockBuilder();
            }
            else if ("dock".OICEquals(sArgs[0]))
            {
                if (frmFloatingBuilder != null)
                {
                    frmFloatingBuilder.Close();
                }
            }
            else if ("move".OICEquals(sArgs[0]))
            {
                if (sArgs.Length < 2)
                {
                    FiddlerApplication.DoNotifyUser("Syntax:\n\n\t!composer move x,y,w,h", "Missing argument");
                }
                else
                {
                    oRequestBuilder.UndockBuilder();
                    Utilities.MoveForm(frmFloatingBuilder, sArgs[1]);
                }
            }
            else if ("activate".OICEquals(sArgs[0]))
            {
                if (sArgs.Length < 2)
                {
                    FiddlerApplication.DoNotifyUser("Syntax:\n\n\t!composer activate [Parsed|Raw|Scratchpad]", "Missing argument");
                }
                else
                {
                    Utilities.activateTabByTitle(sArgs[1], oRequestBuilder.tabsBuilder);
                }
            }
        }

        private bool isValidLine(int iLineNum, bool bBreakOnlyOnEqualLine)
        {
            int lineCount = this.GetLineCount();
            if (iLineNum > (lineCount - 1))
            {
                return false;
            }
            StringBuilder lParam = new StringBuilder(0x400);
            lParam.Append(new string(' ', 0x400));
            lParam[0] = 'Ѐ';
            SendMessage_Ex(this.txtScratch.Handle, 0xc4, iLineNum, lParam);
            string str = lParam.ToString();
            Trace.WriteLine(string.Concat(new object[] { iLineNum.ToString(), "(", str.Length, "): *", str, "*" }));
            if (!bBreakOnlyOnEqualLine && (str.Length < 1))
            {
                return false;
            }
            if (str.StartsWith("=") && str.EndsWith("="))
            {
                return false;
            }
            return true;
        }

        private void linkUpload_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Composer.SelectFileForUpload");
            bool flag = "PUT".OICEquals(this.cbxBuilderMethod.Text.Trim());
            string[] strArray = Utilities.ObtainFilenames(string.Format("Select file{0} for upload", flag ? string.Empty : "(s)"), "All files (*.*)|*.*", null, !flag);
            if (strArray != null)
            {
                this._RemoveHeaderLines(new string[] { "Content-Type:", "Fiddler-Encoding:" });
                if (flag)
                {
                    string sFilename = strArray[0];
                    string str2 = Utilities.ContentTypeForFilename(sFilename);
                    this.txtBuilderRequestHeaders.Text = string.Format("Content-Type: {0}\r\n{1}", str2, this.txtBuilderRequestHeaders.Text);
                    this.txtBuilderRequestBody.Text = string.Format("<@INCLUDE *{0}*@>", sFilename);
                }
                else
                {
                    this.cbxBuilderMethod.Text = "POST";
                    string str3 = "-------------------------acebdf13572468";
                    string str4 = string.Format("Content-Type: multipart/form-data; boundary={0}\r\n", str3);
                    if (!this.txtBuilderRequestHeaders.Text.Contains(str4))
                    {
                        this.txtBuilderRequestHeaders.Text = string.Format("{0}{1}", str4, this.txtBuilderRequestHeaders.Text);
                    }
                    StringBuilder builder = new StringBuilder();
                    foreach (string str5 in strArray)
                    {
                        string str6 = Utilities.ContentTypeForFilename(str5);
                        string fileName = Path.GetFileName(str5);
                        builder.AppendFormat("--{0}\r\nContent-Disposition: form-data; name=\"fieldNameHere\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n<@INCLUDE *{3}*@>\r\n", new object[] { str3, fileName, str6, str5 });
                    }
                    builder.AppendFormat("--{0}--\r\n", str3);
                    this.txtBuilderRequestBody.Text = builder.ToString();
                }
            }
        }

        private void lnkBuilderHelp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("COMPOSER"));
        }

        private void lnkUnhideHistoryPane_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.lnkUnhideHistoryPane.Visible = this.splitOutside.Panel2Collapsed = false;
            this.tabsBuilder.SelectedTab = this.pageParsed;
        }

        private void lvHistory_ItemActivate(object sender, EventArgs e)
        {
            if (this.lvHistory.SelectedItems.Count >= 1)
            {
                ListViewItem item = this.lvHistory.SelectedItems[0];
                FillUIFromSession((item.Tag as HistoryItem).Session);
            }
        }

        private void lvHistory_KeyDown(object sender, KeyEventArgs e)
        {
            Keys keyData = e.KeyData;
            if (keyData != Keys.Delete)
            {
                if (keyData != Keys.M)
                {
                    if (keyData != (Keys.Control | Keys.A))
                    {
                        return;
                    }
                }
                else
                {
                    this.actCommentOnHistory();
                    e.SuppressKeyPress = e.Handled = true;
                    return;
                }
                this.actHistorySelectAll();
                e.SuppressKeyPress = e.Handled = true;
            }
            else
            {
                this.actHistoryRemoveSelected();
                e.SuppressKeyPress = e.Handled = true;
            }
        }

        private void miHideHistory_Click(object sender, EventArgs e)
        {
            this.splitOutside.Panel2Collapsed = this.lnkUnhideHistoryPane.Visible = true;
        }

        private void miHistoryComment_Click(object sender, EventArgs e)
        {
            this.actCommentOnHistory();
        }

        private void miHistoryRemoveDuplicates_CheckedChanged(object sender, EventArgs e)
        {
            if (this.miHistoryRemoveDuplicates.Checked)
            {
                this.PruneDuplicateHistory();
            }
            FiddlerApplication.Prefs.SetBoolPref("fiddler.composer.history.removeduplicates", this.miHistoryRemoveDuplicates.Checked);
        }

        private void miLoadHistory_Click(object sender, EventArgs e)
        {
            string str = Utilities.ObtainOpenFilename("Load History", "Archive Files (*.raz;*.saz)|*.saz;*.raz");
            if (!string.IsNullOrEmpty(str))
            {
                this.PopulateHistory(str, false, this.miHistoryRemoveDuplicates.Checked);
            }
        }

        private void miRemoveHistory_Click(object sender, EventArgs e)
        {
            this.actHistoryRemoveSelected();
        }

        private void miSaveHistory_Click(object sender, EventArgs e)
        {
            try
            {
                string str = Utilities.ObtainSaveFilename("Save Requests", "Request Archive Zip (*.raz)|*.raz");
                if (!string.IsNullOrEmpty(str) && ((!str.OICEndsWith(".saz") || !File.Exists(str)) || (DialogResult.Cancel != MessageBox.Show("Are you sure you wish to overwrite the Session Archive with a Request Archive?\n\nThe Request Archive will NOT include response data.", "Responses Will Be Lost", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2))))
                {
                    this.StoreHistory(str, false);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Failed to Save Requests");
            }
        }

        private void miSelectAllHistory_Click(object sender, EventArgs e)
        {
            this.actHistorySelectAll();
        }

        private void mnuHistory_Opening(object sender, CancelEventArgs e)
        {
            this.miHistoryComment.Enabled = this.miRemoveHistory.Enabled = this.lvHistory.SelectedItems.Count > 0;
            this.miSaveHistory.Enabled = this.miSelectAllHistory.Enabled = this.lvHistory.Items.Count > 0;
        }

        private void oRequestBuilder_DragEnter(object sender, DragEventArgs e)
        {
            bool dataPresent = e.Data.GetDataPresent("Fiddler.Session[]");
            if ((!dataPresent && (this.tabsBuilder.SelectedTab == this.pageScratch)) && e.Data.GetDataPresent(DataFormats.Text))
            {
                dataPresent = true;
            }
            if (dataPresent)
            {
                e.Effect = DragDropEffects.Link | DragDropEffects.Copy;
                this.BackColor = Color.Lime;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void PopulateHistory(string sFilename, bool bQuiet, bool bPruneDuplicates)
        {
            try
            {
                this.lvHistory.BeginUpdate();
                try
                {
                    Session[] sessionArray = Utilities.ReadSessionArchive(sFilename, !bQuiet, "ComposerHistory");
                    if ((sessionArray == null) || (sessionArray.Length < 1))
                    {
                        return;
                    }
                    foreach (Session session in sessionArray)
                    {
                        session.responseBodyBytes = null;
                        session.oResponse = null;
                        this.AddToHistory(session);
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception, "Failed to Load Requests");
                }
                if (bPruneDuplicates)
                {
                    this.PruneDuplicateHistory();
                }
            }
            finally
            {
                this.lvHistory.EndUpdate();
            }
        }

        private void PruneDuplicateHistory()
        {
            if (this.lvHistory.Items.Count >= 2)
            {
                Dictionary<string, ListViewItem> dictionary = new Dictionary<string, ListViewItem>();
                List<ListViewItem> list = new List<ListViewItem>();
                foreach (ListViewItem item in this.lvHistory.Items)
                {
                    HistoryItem tag = item.Tag as HistoryItem;
                    if (dictionary.ContainsKey(tag.Hash))
                    {
                        list.Add(item);
                    }
                    else
                    {
                        dictionary.Add(tag.Hash, item);
                    }
                }
                this.lvHistory.BeginUpdate();
                foreach (ListViewItem item3 in list)
                {
                    item3.Remove();
                }
                this.lvHistory.EndUpdate();
            }
        }

        private void RequestBuilder_DragDrop(object sender, DragEventArgs e)
        {
            this.BackColor = Color.FromKnownColor(KnownColor.Control);
            Session[] data = (Session[]) e.Data.GetData("Fiddler.Session[]");
            if ((data != null) && (data.Length > 0))
            {
                if (this.tabsBuilder.SelectedTab == this.pageScratch)
                {
                    AddSessionsToScratch(data);
                }
                else
                {
                    FillUIFromSession(data[0]);
                }
            }
            else if ((this.tabsBuilder.SelectedTab == this.pageScratch) && e.Data.GetDataPresent(DataFormats.Text))
            {
                AddTextToScratch(Environment.NewLine + ((string) e.Data.GetData(DataFormats.Text)));
            }
        }

        private void RequestBuilder_DragLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromKnownColor(KnownColor.Control);
        }

        private void SavePreferences()
        {
            FiddlerApplication.Prefs.SetBoolPref("fiddler.composer.followredirects", this.cbFollowRedirects.Checked);
            FiddlerApplication.Prefs.SetBoolPref("fiddler.composer.autoauth", this.cbAutoAuthenticate.Checked);
            FiddlerApplication.Prefs.SetBoolPref("fiddler.composer.inspectsession", this.cbSelectBuilderResult.Checked);
            FiddlerApplication.Prefs.SetBoolPref("fiddler.composer.history.LogRequests", this.cbComposerLogRequests.Checked);
            FiddlerApplication.Prefs.SetBoolPref("fiddler.composer.history.SaveOnExit", this.miHistorySaveOnExit.Checked);
            try
            {
                if (this.miHistorySaveOnExit.Checked && bHistoryDirty)
                {
                    this.StoreHistory(string.Concat(new object[] { CONFIG.GetPath("Captures"), Path.DirectorySeparatorChar, "Requests", Path.DirectorySeparatorChar, "ComposerHistory.raz" }), true);
                }
            }
            catch
            {
            }
            try
            {
                if (bLoadedScratch && this.txtScratch.Modified)
                {
                    File.WriteAllText(CONFIG.GetPath("Root") + "Composer_Scratch.txt", this.txtScratch.Text, Encoding.UTF8);
                }
            }
            catch
            {
            }
        }

        internal static void SavePrefs()
        {
            if (oRequestBuilder != null)
            {
                oRequestBuilder.SavePreferences();
            }
        }

        [DllImport("user32.dll", EntryPoint="SendMessage")]
        private static extern int SendMessage_Ex(IntPtr hwnd, int wMsg, int wParam, StringBuilder lParam);
        internal static void SetFontSize(float flFontSize)
        {
            try
            {
                if (oRequestBuilder != null)
                {
                    float emSize = flFontSize;
                    if (emSize > 14f)
                    {
                        emSize = 14f;
                    }
                    oRequestBuilder.tabsBuilder.Font = new Font(oRequestBuilder.tabsBuilder.Font.FontFamily, emSize);
                    oRequestBuilder.txtBuilderRequestBody.Font = new Font(oRequestBuilder.txtBuilderRequestBody.Font.FontFamily, emSize);
                    oRequestBuilder.txtBuilderRequestHeaders.Font = new Font(oRequestBuilder.txtBuilderRequestHeaders.Font.FontFamily, emSize);
                    oRequestBuilder.txtRaw.Font = new Font(oRequestBuilder.txtRaw.Font.FontFamily, emSize);
                    oRequestBuilder.txtScratch.Font = new Font(oRequestBuilder.txtScratch.Font.FontFamily, emSize);
                    if (emSize > 10f)
                    {
                        emSize = 10f;
                    }
                    oRequestBuilder.pageOptions.Font = new Font(oRequestBuilder.pageOptions.Font.FontFamily, emSize);
                }
            }
            catch
            {
            }
        }

        private void StoreHistory(string sFilename, bool bQuiet)
        {
            List<Session> list = new List<Session>();
            foreach (ListViewItem item in this.lvHistory.Items)
            {
                Session session = (item.Tag as HistoryItem).Session;
                list.Add(session);
            }
            if (list.Count < 1)
            {
                try
                {
                    File.Delete(sFilename);
                    return;
                }
                catch
                {
                }
            }
            list.Reverse();
            Utilities.WriteSessionArchive(sFilename, list.ToArray(), null, !bQuiet);
            if (!bQuiet)
            {
                FiddlerApplication.UI.SetStatusText(string.Format("Stored {0} requests to '{1}'", list.Count, sFilename));
            }
        }

        private void tabsBuilder_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.btnBuilderExecute.Enabled = this.tabsBuilder.SelectedTab != this.pageOptions;
            if (this.tabsBuilder.SelectedTab == this.pageScratch)
            {
                this.EnsureScratch();
            }
        }

        private void txtBuilderURL_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.A))
            {
                this.cbxBuilderURL.SelectAll();
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        private void txtBuilderURL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.Handled = true;
                this.btnBuilderExecute_Click(this, null);
            }
        }

        private void txtBuilderURL_TextChanged(object sender, EventArgs e)
        {
            string str = this.cbxBuilderURL.Text.Trim();
            if (str.Length < 1)
            {
                this.cbxBuilderURL.BackColor = Color.Red;
            }
            else if (str.IndexOfAny(new char[] { ' ', '\t' }) > -1)
            {
                this.cbxBuilderURL.BackColor = Color.Red;
            }
            else
            {
                this.cbxBuilderURL.BackColor = Color.FromKnownColor(KnownColor.Window);
            }
        }

        private void txtScratch_MouseClick(object sender, MouseEventArgs e)
        {
            if (((e.Button == MouseButtons.Left) && rectLastDblClick.Contains(e.Location)) && (DateTime.Now < dtLastDblClick.AddMilliseconds((double) SystemInformation.DoubleClickTime)))
            {
                dtLastDblClick = DateTime.MinValue;
                this.FloodSelectText();
            }
        }

        private void txtScratch_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dtLastDblClick = DateTime.Now;
                rectLastDblClick = new Rectangle(e.Location, sizeDblClickArea);
            }
        }

        private void UndockBuilder()
        {
            if (frmFloatingBuilder == null)
            {
                frmFloatingBuilder = new Form();
                frmFloatingBuilder.FormBorderStyle = FormBorderStyle.SizableToolWindow;
                frmFloatingBuilder.Width = 0x1d8;
                frmFloatingBuilder.Height = 500;
                frmFloatingBuilder.StartPosition = FormStartPosition.Manual;
                frmFloatingBuilder.Left = (base.Left + base.Width) - 500;
                frmFloatingBuilder.Top = base.Top + 100;
                frmFloatingBuilder.Text = "Composer";
                FiddlerApplication.UI.tabsViews.TabPages.Remove(FiddlerApplication.UI.pageBuilder);
                frmFloatingBuilder.Controls.Add(this);
                this.cbSelectBuilderResult.Checked = true;
                this.gbUIOptions.Visible = false;
                frmFloatingBuilder.Icon = FiddlerApplication.UI.Icon;
                frmFloatingBuilder.FormClosing += new FormClosingEventHandler(this.frmFloatingBuilder_FormClosing);
                frmFloatingBuilder.Show(FiddlerApplication.UI);
            }
        }
    }
}

