﻿namespace Fiddler
{
    using System;
    using System.IO;

    internal class PipeReadBuffer : MemoryStream
    {
        private uint _HintedSize;
        private static readonly uint GROWTH_RATE = 0x4000000;
        private static readonly uint LARGE_BUFFER = 0x1fffffff;
        private const uint LARGE_OBJECT_HEAP_SIZE = 0x14000;
        private const uint MAX_ARRAY_INDEX = 0x7fffffc7;

        static PipeReadBuffer()
        {
            if (IntPtr.Size == 4)
            {
                LARGE_BUFFER = 0x4000000;
                GROWTH_RATE = 0x1000000;
            }
        }

        public PipeReadBuffer(bool bIsRequest) : base(bIsRequest ? 0 : 0x1000)
        {
            this._HintedSize = 0x7fffffc7;
        }

        public PipeReadBuffer(int iDefaultCapacity) : base(iDefaultCapacity)
        {
            this._HintedSize = 0x7fffffc7;
        }

        internal void HintTotalSize(uint iHint)
        {
            if (iHint >= 0)
            {
                this._HintedSize = iHint;
            }
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            int capacity = base.Capacity;
            uint num2 = (uint) (base.Position + count);
            if (num2 > capacity)
            {
                if (num2 > 0x7fffffc7)
                {
                    FiddlerApplication.oTelemetry.TrackEvent("Scenario.Over2GBStream");
                    throw new InsufficientMemoryException(string.Format("Sorry, the .NET Framework (and Fiddler) cannot handle streams larger than 2 gigabytes. This stream requires {0:N0} bytes", num2));
                }
                if (num2 < 0x14000)
                {
                    if ((this._HintedSize < 0x14000) && (this._HintedSize >= num2))
                    {
                        this.Capacity = (int) this._HintedSize;
                    }
                    else if (((capacity * 2) > 0x14000L) || ((this._HintedSize < 0x7fffffc7) && (this._HintedSize >= num2)))
                    {
                        this.Capacity = 0x14000;
                    }
                }
                else if (((this._HintedSize < 0x7fffffc7) && (this._HintedSize >= num2)) && (this._HintedSize < (0x200000 + (capacity * 2))))
                {
                    this.Capacity = (int) this._HintedSize;
                }
                else if (num2 > LARGE_BUFFER)
                {
                    uint num3 = num2 + GROWTH_RATE;
                    if (num3 < 0x7fffffc7)
                    {
                        this.Capacity = (int) num3;
                    }
                    else
                    {
                        this.Capacity = (int) num2;
                    }
                }
            }
            base.Write(buffer, offset, count);
        }
    }
}

