﻿namespace Fiddler
{
    using System;

    internal enum ProcessingStates : byte
    {
        ConnectEnd = 13,
        ConnectStart = 12,
        Created = 0,
        DetermineGatewayEnd = 9,
        DetermineGatewayStart = 8,
        DNSEnd = 11,
        DNSStart = 10,
        DoAfterSessionEventEnd = 0x1c,
        DoAfterSessionEventStart = 0x1b,
        Finished = 0x1d,
        GetRequestEnd = 5,
        GetRequestHeadersEnd = 2,
        GetRequestStart = 1,
        GetResponseHeadersEnd = 0x13,
        HTTPSHandshakeEnd = 15,
        HTTPSHandshakeStart = 14,
        PauseForRequestTampering = 3,
        PauseForResponseTampering = 0x17,
        ReadResponseEnd = 20,
        ReadResponseStart = 0x12,
        ResumeFromRequestTampering = 4,
        ResumeFromResponseTampering = 0x18,
        ReturnBufferedResponseEnd = 0x1a,
        ReturnBufferedResponseStart = 0x19,
        RunRequestRulesEnd = 7,
        RunRequestRulesStart = 6,
        RunResponseRulesEnd = 0x16,
        RunResponseRulesStart = 0x15,
        SendRequestEnd = 0x11,
        SendRequestStart = 0x10
    }
}

