﻿namespace Fiddler
{
    using System;
    using System.Diagnostics;
    using System.Net;
    using System.Net.Security;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;
    using System.Security.Authentication;
    using System.Security.Cryptography.X509Certificates;

    public class ClientPipe : BasePipe
    {
        private byte[] _arrReceivedAndPutBack;
        private static bool _bWantClientCert = FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.requestclientcertificate", false);
        internal static int _cbLimitRequestHeaders = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.limit.maxrequestheaders", 0x100000);
        private int _iProcessID;
        internal static bool _ProcessLookupSkipsLoopbackCheck = FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.ProcessLookupSkipsLoopbackCheck", false);
        private string _sProcessName;
        internal static int _timeoutFirstReceive = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.clientpipe.receive.initial", 0xafc8);
        internal static int _timeoutIdle = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.clientpipe.idle", 0x1c138);
        internal static int _timeoutReceiveLoop = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.clientpipe.receive.loop", 0xea60);
        [CompilerGenerated]
        private DateTime <dtAccepted>k__BackingField;

        internal ClientPipe(Socket oSocket, DateTime dtCreationTime) : base(oSocket, "C")
        {
            try
            {
                this.dtAccepted = dtCreationTime;
                oSocket.NoDelay = true;
                if (ClientChatter.s_SO_RCVBUF_Option >= 0)
                {
                    oSocket.ReceiveBufferSize = ClientChatter.s_SO_RCVBUF_Option;
                }
                if (ClientChatter.s_SO_SNDBUF_Option >= 0)
                {
                    oSocket.SendBufferSize = ClientChatter.s_SO_SNDBUF_Option;
                }
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("[ClientPipe]\n SendBufferSize:\t{0}\n ReceiveBufferSize:\t{1}\n SendTimeout:\t{2}\n ReceiveTimeOut:\t{3}\n NoDelay:\t{4}", new object[] { oSocket.SendBufferSize, oSocket.ReceiveBufferSize, oSocket.SendTimeout, oSocket.ReceiveTimeout, oSocket.NoDelay });
                }
                this._setProcessName();
            }
            catch
            {
            }
        }

        private void _setProcessName()
        {
            if (CONFIG.bMapSocketToProcess && ((!CONFIG.bAllowRemoteConnections || _ProcessLookupSkipsLoopbackCheck) || (base._baseSocket.LocalEndPoint as IPEndPoint).Address.Equals((base._baseSocket.RemoteEndPoint as IPEndPoint).Address)))
            {
                this._iProcessID = Winsock.MapLocalPortToProcessId(base.Port);
                if (this._iProcessID > 0)
                {
                    this._sProcessName = ProcessHelper.GetProcessName(this._iProcessID);
                }
            }
        }

        public override bool HasDataAvailable()
        {
            try
            {
                return ((this._arrReceivedAndPutBack != null) || base.HasDataAvailable());
            }
            catch
            {
                return true;
            }
        }

        internal void putBackSomeBytes(byte[] toPutback)
        {
            this._arrReceivedAndPutBack = toPutback;
        }

        internal int Receive(byte[] arrBuffer)
        {
            if (this._arrReceivedAndPutBack == null)
            {
                return base.Receive(arrBuffer);
            }
            int length = this._arrReceivedAndPutBack.Length;
            Buffer.BlockCopy(this._arrReceivedAndPutBack, 0, arrBuffer, 0, length);
            this._arrReceivedAndPutBack = null;
            return length;
        }

        internal bool SecureClientPipe(string sHostname, HTTPResponseHeaders oHeaders)
        {
            X509Certificate2 certificate;
            try
            {
                certificate = CertMaker.FindCert(sHostname);
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("fiddler.https> Failed to obtain certificate for {0} due to {1}", new object[] { sHostname, exception.Message });
                certificate = null;
            }
            try
            {
                if (certificate == null)
                {
                    FiddlerApplication.Log.LogFormat("!WARNING: Unable to find or create Certificate for {0}", new object[] { sHostname });
                    oHeaders.SetStatus(0x1f6, "Fiddler unable to find or create certificate");
                }
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("SecureClientPipe for: " + this.ToString() + " sending data to client:\n" + Utilities.ByteArrayToHexView(oHeaders.ToByteArray(true, true), 0x20));
                }
                base.Send(oHeaders.ToByteArray(true, true));
                if (oHeaders.HTTPResponseCode != 200)
                {
                    FiddlerApplication.DebugSpew("SecureClientPipe returning FALSE because HTTPResponseCode != 200");
                    return false;
                }
                base._httpsStream = new SslStream(new NetworkStream(base._baseSocket, false), false);
                base._httpsStream.AuthenticateAsServer(certificate, _bWantClientCert, CONFIG.oAcceptedClientHTTPSProtocols, false);
                return true;
            }
            catch (Exception exception2)
            {
                FiddlerApplication.Log.LogFormat("SecureClientPipe ({0} failed: {1}.", new object[] { sHostname, Utilities.DescribeException(exception2) });
                try
                {
                    base.End();
                }
                catch (Exception)
                {
                }
            }
            return false;
        }

        internal bool SecureClientPipeDirect(X509Certificate2 certServer)
        {
            try
            {
                FiddlerApplication.DebugSpew("SecureClientPipeDirect({0})", new object[] { certServer.Subject });
                SslStream stream1 = base._httpsStream;
                base._httpsStream = new SslStream(new NetworkStream(base._baseSocket, false), false);
                base._httpsStream.AuthenticateAsServer(certServer, _bWantClientCert, CONFIG.oAcceptedClientHTTPSProtocols, false);
                return true;
            }
            catch (AuthenticationException exception)
            {
                FiddlerApplication.Log.LogFormat("!SecureClientPipeDirect failed: {1} for pipe ({0}).", new object[] { certServer.Subject, Utilities.DescribeException(exception) });
                Trace.WriteLine(string.Format("!SecureClientPipeDirect failed: {1} for pipe ({0}).", certServer.Subject, Utilities.DescribeException(exception)));
                base.End();
            }
            catch (Exception exception2)
            {
                FiddlerApplication.Log.LogFormat("!SecureClientPipeDirect failed: {1} for pipe ({0})", new object[] { certServer.Subject, Utilities.DescribeException(exception2) });
                base.End();
            }
            return false;
        }

        internal void setReceiveTimeout(bool bFirstRead)
        {
            try
            {
                base._baseSocket.ReceiveTimeout = bFirstRead ? _timeoutFirstReceive : _timeoutReceiveLoop;
            }
            catch
            {
            }
        }

        public override string ToString()
        {
            return string.Format("[ClientPipe: {0}:{1}; UseCnt: {2}[{3}]; Port: {4}; {5} established {6}]", new object[] { this._sProcessName, this._iProcessID, base.iUseCount, string.Empty, base.Port, base.bIsSecured ? "SECURE" : "PLAINTTEXT", this.dtAccepted });
        }

        internal DateTime dtAccepted
        {
            [CompilerGenerated]
            get
            {
                return this.<dtAccepted>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<dtAccepted>k__BackingField = value;
            }
        }

        public int LocalProcessID
        {
            get
            {
                return this._iProcessID;
            }
        }

        public string LocalProcessName
        {
            get
            {
                return (this._sProcessName ?? string.Empty);
            }
        }
    }
}

