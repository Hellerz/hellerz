﻿namespace Fiddler
{
    using Microsoft.Win32;
    using System;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Windows.Forms;

    internal static class Updater
    {
        private static void _IndicateUpdatePending()
        {
            try
            {
                RegistryKey oReg = Registry.CurrentUser.OpenSubKey(CONFIG.GetRegPath("Root"), true);
                if (oReg != null)
                {
                    Utilities.SetRegistryString(oReg, "UpdatePending", "True");
                    oReg.Close();
                }
            }
            catch
            {
            }
        }

        internal static void CheckForUpdates(bool bVerbose)
        {
            try
            {
                VersionStruct latestVersion = GetLatestVersion(FiddlerApplication.Prefs.GetBoolPref("fiddler.updater.OfferBetaBuilds", CONFIG.bIsBeta));
                FiddlerApplication.Prefs.SetStringPref("fiddler.welcomemsg", latestVersion.sWelcomeMsg);
                int num = CompareVersions(ref latestVersion, CONFIG.FiddlerVersionInfo);
                if ((num > 1) || ((num > 0) && (bVerbose || FiddlerApplication.Prefs.GetBoolPref("fiddler.updater.BleedingEdge", false))))
                {
                    latestVersion.sWhatIsNew = latestVersion.sWhatIsNew + string.Format("\r\n\r\n------------------------------\r\nWould you like to learn more?\r\n{0}&v={1}&IsBeta={2}", CONFIG.GetRedirUrl("ChangeList"), Application.ProductVersion, CONFIG.bIsBeta.ToString());
                    frmUpdate oUpdatePrompt = new frmUpdate("Update Announcement (from v" + Application.ProductVersion + " to v" + latestVersion.Major.ToString() + "." + latestVersion.Minor.ToString() + "." + latestVersion.Build.ToString() + "." + latestVersion.Private.ToString() + ")", "Good news! An improved version of Fiddler is now available.\r\n\r\n" + latestVersion.sWhatIsNew, !latestVersion.bMustCleanInstall, MessageBoxDefaultButton.Button2);
                    oUpdatePrompt.StartPosition = FormStartPosition.CenterScreen;
                    FiddlerApplication.oTelemetry.TrackEvent("Updater.FoundNewer");
                    switch (FiddlerApplication.UI.GetUpdateDecision(oUpdatePrompt))
                    {
                        case DialogResult.Retry:
                            FiddlerApplication.oTelemetry.TrackEvent("Updater.ChoseNextTime");
                            _IndicateUpdatePending();
                            return;

                        case DialogResult.Ignore:
                            return;

                        case DialogResult.Yes:
                            try
                            {
                                FiddlerApplication.oTelemetry.TrackEvent("Updater.ChoseUpgradeNow");
                                try
                                {
                                    FiddlerApplication.UI.actDetachProxy();
                                }
                                catch (Exception)
                                {
                                }
                                Process.Start(Path.GetDirectoryName(Application.ExecutablePath) + @"\UpdateFiddler.exe", "-WaitForExit");
                                FiddlerApplication.UI.actExit();
                            }
                            catch (Exception exception)
                            {
                                FiddlerApplication.ReportException(exception, "AutoUpgrade failed");
                            }
                            return;

                        case DialogResult.OK:
                            FiddlerApplication.oTelemetry.TrackEvent("Updater.ChoseOpenBrowser");
                            Utilities.LaunchHyperlink(CONFIG.GetUrl("InstallLatest"));
                            return;
                    }
                }
                else if (bVerbose)
                {
                    FiddlerApplication.DoNotifyUser(FiddlerApplication.UI, "Your version of Fiddler is up-to-date.\n\nThanks for checking!", "FiddlerUpdate", MessageBoxIcon.Asterisk);
                }
            }
            catch (Exception exception2)
            {
                if (bVerbose)
                {
                    MessageBox.Show(FiddlerApplication.UI, "There was an error retrieving version information. You can check for updates manually by visiting https://fiddler2.com/\n\n" + exception2.ToString(), "Error retrieving version information");
                }
            }
        }

        private static int CompareVersions(ref VersionStruct verServer, Version verClient)
        {
            if (verServer.Major > verClient.Major)
            {
                return 4;
            }
            if (verClient.Major > verServer.Major)
            {
                return -4;
            }
            if (verServer.Minor > verClient.Minor)
            {
                return 3;
            }
            if (verClient.Minor > verServer.Minor)
            {
                return -3;
            }
            if (verServer.Build > verClient.Build)
            {
                return 2;
            }
            if (verClient.Build > verServer.Build)
            {
                return -2;
            }
            if (verServer.Private > verClient.Revision)
            {
                return 1;
            }
            if (verClient.Revision > verServer.Private)
            {
                return -1;
            }
            return 0;
        }

        private static VersionStruct GetLatestVersion(bool includeBetaVersions)
        {
            VersionStruct struct2 = new VersionStruct();
            string str = string.Format("User-Agent: Fiddler/{0}{1} ({2}.NET {3}; {4}; {5}; {6}x{7})", new object[] { Application.ProductVersion, CONFIG.bIsBeta ? " beta" : string.Empty, string.Empty, Environment.Version.ToString(), Utilities.GetOSVerString(), CultureInfo.CurrentCulture.Name, Environment.ProcessorCount, Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE") });
            HTTPRequestHeaders oHeaders = new HTTPRequestHeaders("/UpdateCheck.aspx?isBeta=" + includeBetaVersions.ToString(), new string[] { str, "Pragma: no-cache", "Host: www.telerik.com", "Accept-Language: " + CultureInfo.CurrentCulture.Name, "Referer: " + string.Format("http://fiddler2.com/client/{0}{1}", CONFIG.bEnableAnalytics ? "TELE/" : string.Empty, CONFIG.FiddlerVersionInfo.ToString()), "Accept-Encoding: gzip, deflate", "Connection: close" });
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.updater.UseHTTPS", Environment.OSVersion.Version.Major > 5))
            {
                oHeaders.UriScheme = "https";
            }
            StringDictionary oNewFlags = new StringDictionary();
            oNewFlags["x-AutoAuth"] = "(default)";
            oNewFlags["x-Builder-MaxRedir"] = "3";
            oNewFlags["ui-color"] = "gray";
            Session session = FiddlerApplication.oProxy.SendRequestAndWait(oHeaders, null, oNewFlags, null);
            if (session.responseCode == 200)
            {
                using (StringReader reader = new StringReader(session.GetResponseBodyAsString()))
                {
                    struct2.Major = int.Parse(reader.ReadLine());
                    struct2.Minor = int.Parse(reader.ReadLine());
                    struct2.Build = int.Parse(reader.ReadLine());
                    struct2.Private = int.Parse(reader.ReadLine());
                    struct2.sWhatIsNew = reader.ReadToEnd().Trim();
                    struct2.bMustCleanInstall = struct2.sWhatIsNew.Contains("CleanInstall");
                    int index = struct2.sWhatIsNew.IndexOf("@WELCOME@");
                    if (index > 0)
                    {
                        struct2.sWelcomeMsg = struct2.sWhatIsNew.Substring(index + 9).Trim();
                        struct2.sWhatIsNew = struct2.sWhatIsNew.Substring(0, index).Trim();
                    }
                    return struct2;
                }
            }
            throw new InvalidDataException("VersionCheckFailed: Server Response Code = " + session.responseCode);
        }
    }
}

