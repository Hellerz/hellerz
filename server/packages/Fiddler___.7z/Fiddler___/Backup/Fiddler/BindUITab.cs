﻿namespace Fiddler
{
    using System;
    using System.Windows.Forms;

    [AttributeUsage(AttributeTargets.Method, Inherited=false)]
    public sealed class BindUITab : Attribute
    {
        internal bool _bHTML;
        internal CalculateReportHandler _oDel;
        internal MenuItem _oMI;
        internal TabPage _oTabPage;
        internal string _sOptions;
        internal string _sTabTitle;

        public BindUITab(string sTabTitle)
        {
            this._sTabTitle = sTabTitle;
        }

        public BindUITab(string sTabTitle, bool bHTML)
        {
            this._sTabTitle = sTabTitle;
            this._bHTML = bHTML;
        }

        public BindUITab(string sTabTitle, string sOptions)
        {
            this._sTabTitle = sTabTitle;
            if (sOptions.OICContains("<html>"))
            {
                this._bHTML = true;
            }
            this._sOptions = sOptions;
        }
    }
}

