﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    internal delegate void updateUIDelegate(Session oSession);
}

