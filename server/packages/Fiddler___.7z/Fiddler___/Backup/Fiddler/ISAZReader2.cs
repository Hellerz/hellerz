﻿namespace Fiddler
{
    using System;

    public interface ISAZReader2 : ISAZReader
    {
        GetPasswordDelegate PasswordCallback { get; set; }
    }
}

