﻿namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;

    public class HTTPRequestHeaders : HTTPHeaders, ICloneable, IEnumerable<HTTPHeaderItem>, IEnumerable
    {
        private string _Path;
        private byte[] _RawPath;
        private string _UriScheme;
        private string _uriUserInfo;
        [CodeDescription("HTTP Method or Verb from HTTP Request.")]
        public string HTTPMethod;

        public HTTPRequestHeaders()
        {
            this._UriScheme = "http";
            this.HTTPMethod = string.Empty;
            this._RawPath = Utilities.emptyByteArray;
            this._Path = string.Empty;
        }

        public HTTPRequestHeaders(Encoding encodingForHeaders)
        {
            this._UriScheme = "http";
            this.HTTPMethod = string.Empty;
            this._RawPath = Utilities.emptyByteArray;
            this._Path = string.Empty;
            base._HeaderEncoding = encodingForHeaders;
        }

        public HTTPRequestHeaders(string sPath, string[] sHeaders)
        {
            this._UriScheme = "http";
            this.HTTPMethod = string.Empty;
            this._RawPath = Utilities.emptyByteArray;
            this._Path = string.Empty;
            this.HTTPMethod = "GET";
            this.RequestPath = sPath.Trim();
            if (sHeaders != null)
            {
                string sErrors = string.Empty;
                Parser.ParseNVPHeaders(this, sHeaders, 0, ref sErrors);
            }
        }

        [CodeDescription("Replaces the current Request header set using a string representing the new HTTP headers.")]
        public override bool AssignFromString(string sHeaders)
        {
            if (string.IsNullOrEmpty(sHeaders))
            {
                throw new ArgumentException("Header string must not be null or empty");
            }
            if (!sHeaders.Contains("\r\n\r\n"))
            {
                sHeaders = sHeaders + "\r\n\r\n";
            }
            HTTPRequestHeaders headers = null;
            try
            {
                headers = Parser.ParseRequest(sHeaders);
            }
            catch (Exception)
            {
            }
            if (headers == null)
            {
                return false;
            }
            this.HTTPMethod = headers.HTTPMethod;
            this._Path = headers._Path;
            this._RawPath = headers._RawPath;
            this._UriScheme = headers._UriScheme;
            base.HTTPVersion = headers.HTTPVersion;
            this._uriUserInfo = headers._uriUserInfo;
            base.storage = headers.storage;
            return true;
        }

        public override int ByteCount()
        {
            int num = 4;
            num += this.HTTPMethod.StrLen();
            num += this.RequestPath.StrLen();
            num += base.HTTPVersion.StrLen();
            if (!"CONNECT".OICEquals(this.HTTPMethod))
            {
                num += this._UriScheme.StrLen();
                num += this._uriUserInfo.StrLen();
                num += base["Host"].StrLen();
                num += 3;
            }
            try
            {
                base.GetReaderLock();
                for (int i = 0; i < base.storage.Count; i++)
                {
                    num += 4;
                    num += base.storage[i].Name.StrLen();
                    num += base.storage[i].Value.StrLen();
                }
            }
            finally
            {
                base.FreeReaderLock();
            }
            return (num + 2);
        }

        public object Clone()
        {
            HTTPRequestHeaders headers = (HTTPRequestHeaders) base.MemberwiseClone();
            try
            {
                base.GetReaderLock();
                headers.storage = new List<HTTPHeaderItem>(base.storage.Count);
                foreach (HTTPHeaderItem item in base.storage)
                {
                    headers.storage.Add(new HTTPHeaderItem(item.Name, item.Value));
                }
                return headers;
            }
            finally
            {
                base.FreeReaderLock();
            }
            return headers;
        }

        public IEnumerator<HTTPHeaderItem> GetEnumerator()
        {
            return base.storage.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return base.storage.GetEnumerator();
        }

        [CodeDescription("Returns current Request Headers as a byte array.")]
        public byte[] ToByteArray(bool prependVerbLine, bool appendEmptyLine, bool includeProtocolInPath)
        {
            return this.ToByteArray(prependVerbLine, appendEmptyLine, includeProtocolInPath, null);
        }

        [CodeDescription("Returns current Request Headers as a byte array.")]
        public byte[] ToByteArray(bool prependVerbLine, bool appendEmptyLine, bool includeProtocolInPath, string sVerbLineHost)
        {
            if (!prependVerbLine)
            {
                return base._HeaderEncoding.GetBytes(this.ToString(false, appendEmptyLine, false));
            }
            byte[] bytes = Encoding.ASCII.GetBytes(this.HTTPMethod);
            byte[] buffer = Encoding.ASCII.GetBytes(base.HTTPVersion);
            byte[] buffer3 = base._HeaderEncoding.GetBytes(this.ToString(false, appendEmptyLine, false));
            MemoryStream stream = new MemoryStream(buffer3.Length + 0x400);
            stream.Write(bytes, 0, bytes.Length);
            stream.WriteByte(0x20);
            if (includeProtocolInPath && !"CONNECT".OICEquals(this.HTTPMethod))
            {
                if (sVerbLineHost == null)
                {
                    sVerbLineHost = base["Host"];
                }
                byte[] buffer4 = base._HeaderEncoding.GetBytes(this._UriScheme + "://" + this._uriUserInfo + sVerbLineHost);
                stream.Write(buffer4, 0, buffer4.Length);
            }
            if ("CONNECT".OICEquals(this.HTTPMethod) && (sVerbLineHost != null))
            {
                byte[] buffer5 = base._HeaderEncoding.GetBytes(sVerbLineHost);
                stream.Write(buffer5, 0, buffer5.Length);
            }
            else
            {
                stream.Write(this._RawPath, 0, this._RawPath.Length);
            }
            stream.WriteByte(0x20);
            stream.Write(buffer, 0, buffer.Length);
            stream.WriteByte(13);
            stream.WriteByte(10);
            stream.Write(buffer3, 0, buffer3.Length);
            return stream.ToArray();
        }

        [CodeDescription("Returns a string representing the HTTP Request.")]
        public override string ToString()
        {
            return this.ToString(true, false, false);
        }

        [CodeDescription("Returns a string representing the HTTP Request.")]
        public string ToString(bool prependVerbLine, bool appendEmptyLine)
        {
            return this.ToString(prependVerbLine, appendEmptyLine, false);
        }

        [CodeDescription("Returns current Request Headers as a string.")]
        public string ToString(bool prependVerbLine, bool appendEmptyLine, bool includeProtocolAndHostInPath)
        {
            StringBuilder builder = new StringBuilder(0x200);
            if (prependVerbLine)
            {
                if (includeProtocolAndHostInPath && !"CONNECT".OICEquals(this.HTTPMethod))
                {
                    builder.AppendFormat("{0} {1}://{2}{3}{4} {5}\r\n", new object[] { this.HTTPMethod, this._UriScheme, this._uriUserInfo, base["Host"], this.RequestPath, base.HTTPVersion });
                }
                else
                {
                    builder.AppendFormat("{0} {1} {2}\r\n", this.HTTPMethod, this.RequestPath, base.HTTPVersion);
                }
            }
            try
            {
                base.GetReaderLock();
                for (int i = 0; i < base.storage.Count; i++)
                {
                    builder.AppendFormat("{0}: {1}\r\n", base.storage[i].Name, base.storage[i].Value);
                }
            }
            finally
            {
                base.FreeReaderLock();
            }
            if (appendEmptyLine)
            {
                builder.Append("\r\n");
            }
            return builder.ToString();
        }

        [CodeDescription("Byte array representing the HTTP Request path.")]
        public byte[] RawPath
        {
            get
            {
                return (this._RawPath ?? Utilities.emptyByteArray);
            }
            set
            {
                if (value == null)
                {
                    value = Utilities.emptyByteArray;
                }
                this._RawPath = Utilities.Dupe(value);
                this._Path = base._HeaderEncoding.GetString(this._RawPath);
            }
        }

        [CodeDescription("String representing the HTTP Request path, e.g. '/path.htm'.")]
        public string RequestPath
        {
            get
            {
                return (this._Path ?? string.Empty);
            }
            set
            {
                if (value == null)
                {
                    value = string.Empty;
                }
                this._Path = value;
                this._RawPath = base._HeaderEncoding.GetBytes(value);
            }
        }

        [CodeDescription("URI Scheme for this HTTP Request; usually 'http' or 'https'")]
        public string UriScheme
        {
            get
            {
                return (this._UriScheme ?? string.Empty);
            }
            set
            {
                this._UriScheme = value.ToLowerInvariant();
            }
        }

        [CodeDescription("For FTP URLs, returns either null or user:pass@")]
        public string UriUserInfo
        {
            get
            {
                return this._uriUserInfo;
            }
            internal set
            {
                if (string.Empty == value)
                {
                    value = null;
                }
                this._uriUserInfo = value;
            }
        }
    }
}

