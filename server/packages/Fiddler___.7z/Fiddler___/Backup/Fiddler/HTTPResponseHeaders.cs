﻿namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;

    public class HTTPResponseHeaders : HTTPHeaders, ICloneable, IEnumerable<HTTPHeaderItem>, IEnumerable
    {
        [CodeDescription("Status code from HTTP Response. Call SetStatus() instead of manipulating directly.")]
        public int HTTPResponseCode;
        [CodeDescription("Status text from HTTP Response (e.g. '200 OK'). Call SetStatus() instead of manipulating directly.")]
        public string HTTPResponseStatus;

        public HTTPResponseHeaders()
        {
            this.HTTPResponseStatus = string.Empty;
        }

        public HTTPResponseHeaders(Encoding encodingForHeaders)
        {
            this.HTTPResponseStatus = string.Empty;
            base._HeaderEncoding = encodingForHeaders;
        }

        public HTTPResponseHeaders(int iStatus, string[] sHeaders) : this(iStatus, "Generated", sHeaders)
        {
        }

        public HTTPResponseHeaders(int iStatusCode, string sStatusText, string[] sHeaders)
        {
            this.HTTPResponseStatus = string.Empty;
            this.SetStatus(iStatusCode, sStatusText);
            if (sHeaders != null)
            {
                string sErrors = string.Empty;
                Parser.ParseNVPHeaders(this, sHeaders, 0, ref sErrors);
            }
        }

        [CodeDescription("Replaces the current Response header set using a string representing the new HTTP headers.")]
        public override bool AssignFromString(string sHeaders)
        {
            if (string.IsNullOrEmpty(sHeaders))
            {
                throw new ArgumentException("Header string must not be null or empty");
            }
            if (!sHeaders.Contains("\r\n\r\n"))
            {
                sHeaders = sHeaders + "\r\n\r\n";
            }
            HTTPResponseHeaders headers = null;
            try
            {
                headers = Parser.ParseResponse(sHeaders);
            }
            catch (Exception)
            {
            }
            if (headers == null)
            {
                return false;
            }
            this.SetStatus(headers.HTTPResponseCode, headers.StatusDescription);
            base.HTTPVersion = headers.HTTPVersion;
            base.storage = headers.storage;
            return true;
        }

        public override int ByteCount()
        {
            int num = 3;
            num += base.HTTPVersion.StrLen();
            num += this.HTTPResponseStatus.StrLen();
            try
            {
                base.GetReaderLock();
                for (int i = 0; i < base.storage.Count; i++)
                {
                    num += 4;
                    num += base.storage[i].Name.StrLen();
                    num += base.storage[i].Value.StrLen();
                }
            }
            finally
            {
                base.FreeReaderLock();
            }
            return (num + 2);
        }

        public object Clone()
        {
            HTTPResponseHeaders headers = (HTTPResponseHeaders) base.MemberwiseClone();
            try
            {
                base.GetReaderLock();
                headers.storage = new List<HTTPHeaderItem>(base.storage.Count);
                foreach (HTTPHeaderItem item in base.storage)
                {
                    headers.storage.Add(new HTTPHeaderItem(item.Name, item.Value));
                }
                return headers;
            }
            finally
            {
                base.FreeReaderLock();
            }
            return headers;
        }

        public IEnumerator<HTTPHeaderItem> GetEnumerator()
        {
            return base.storage.GetEnumerator();
        }

        public void SetStatus(int iCode, string sDescription)
        {
            this.HTTPResponseCode = iCode;
            this.HTTPResponseStatus = string.Format("{0} {1}", iCode, sDescription);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return base.storage.GetEnumerator();
        }

        [CodeDescription("Returns a byte[] representing the HTTP headers.")]
        public byte[] ToByteArray(bool prependStatusLine, bool appendEmptyLine)
        {
            return base._HeaderEncoding.GetBytes(this.ToString(prependStatusLine, appendEmptyLine));
        }

        [CodeDescription("Returns a string containing the HTTP Response headers.")]
        public override string ToString()
        {
            return this.ToString(true, false);
        }

        [CodeDescription("Returns a string representing the HTTP headers.")]
        public string ToString(bool prependStatusLine, bool appendEmptyLine)
        {
            StringBuilder builder = new StringBuilder(0x200);
            if (prependStatusLine)
            {
                builder.AppendFormat("{0} {1}\r\n", base.HTTPVersion, this.HTTPResponseStatus);
            }
            try
            {
                base.GetReaderLock();
                for (int i = 0; i < base.storage.Count; i++)
                {
                    builder.AppendFormat("{0}: {1}\r\n", base.storage[i].Name, base.storage[i].Value);
                }
            }
            finally
            {
                base.FreeReaderLock();
            }
            if (appendEmptyLine)
            {
                builder.Append("\r\n");
            }
            return builder.ToString();
        }

        public string StatusDescription
        {
            get
            {
                if (string.IsNullOrEmpty(this.HTTPResponseStatus))
                {
                    return string.Empty;
                }
                if (this.HTTPResponseStatus.IndexOf(' ') < 1)
                {
                    return string.Empty;
                }
                return Utilities.TrimBefore(this.HTTPResponseStatus, ' ');
            }
            set
            {
                this.HTTPResponseStatus = string.Format("{0} {1}", this.HTTPResponseCode, value);
            }
        }
    }
}

