﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public class QuickExecEventArgs : EventArgs
    {
        [CompilerGenerated]
        private bool <bAddToHistory>k__BackingField;
        [CompilerGenerated]
        private bool <bHandled>k__BackingField;
        [CompilerGenerated]
        private string <sCommand>k__BackingField;

        public QuickExecEventArgs(string sCmd)
        {
            this.sCommand = sCmd;
            this.bAddToHistory = true;
        }

        public bool bAddToHistory
        {
            [CompilerGenerated]
            get
            {
                return this.<bAddToHistory>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<bAddToHistory>k__BackingField = value;
            }
        }

        public bool bHandled
        {
            [CompilerGenerated]
            get
            {
                return this.<bHandled>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<bHandled>k__BackingField = value;
            }
        }

        public string sCommand
        {
            [CompilerGenerated]
            get
            {
                return this.<sCommand>k__BackingField;
            }
            private [CompilerGenerated]
            set
            {
                this.<sCommand>k__BackingField = value;
            }
        }
    }
}

