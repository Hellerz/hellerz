﻿namespace Fiddler
{
    using Microsoft.JScript.Vsa;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class FiddlerScript : IDisposable
    {
        private IJSVsaEngine _engine;
        private MethodInfo _methodExecAction;
        private Action<Session> _methodOnBeforeRequest;
        private Action<Session> _methodOnBeforeResponse;
        private Action<Session> _methodOnPeekAtRequestHeaders;
        private Action<Session> _methodOnPeekAtResponseHeaders;
        private Action<Session> _methodOnReturningError;
        private Action<Session> _methodOnSessionCompleted;
        private Action<WebSocketMessage> _methodOnWebSocketMessage;
        private static int _scriptCount = 0;
        private System.Type _typeScriptHandlers;
        [CompilerGenerated]
        private bool <_playSounds>k__BackingField;
        private RulesAfterCompileHandler AfterRulesCompile;
        private static bool bBusyReportingScriptError;
        private RulesBeforeCompileHandler BeforeRulesCompile;
        private static Dictionary<FieldInfo, string> dictFieldBackingPrefs = new Dictionary<FieldInfo, string>();
        private static Hashtable htMenuScripts = new Hashtable();
        private static ulong lastScriptLoadTickCount = 0L;
        private List<BindUITab> listTabs = new List<BindUITab>();
        private List<PreferenceBag.PrefWatcher> listWeaklyHeldWatchers = new List<PreferenceBag.PrefWatcher>();
        private IJSVsaSite objVSASite;
        private bool Ready;
        private RulesCompileFailedHandler RulesCompileFailed;
        private FileSystemWatcher scriptsFolderWatcher;

        public event RulesAfterCompileHandler AfterRulesCompile
        {
            add
            {
                RulesAfterCompileHandler handler2;
                RulesAfterCompileHandler afterRulesCompile = this.AfterRulesCompile;
                do
                {
                    handler2 = afterRulesCompile;
                    RulesAfterCompileHandler handler3 = (RulesAfterCompileHandler) Delegate.Combine(handler2, value);
                    afterRulesCompile = Interlocked.CompareExchange<RulesAfterCompileHandler>(ref this.AfterRulesCompile, handler3, handler2);
                }
                while (afterRulesCompile != handler2);
            }
            remove
            {
                RulesAfterCompileHandler handler2;
                RulesAfterCompileHandler afterRulesCompile = this.AfterRulesCompile;
                do
                {
                    handler2 = afterRulesCompile;
                    RulesAfterCompileHandler handler3 = (RulesAfterCompileHandler) Delegate.Remove(handler2, value);
                    afterRulesCompile = Interlocked.CompareExchange<RulesAfterCompileHandler>(ref this.AfterRulesCompile, handler3, handler2);
                }
                while (afterRulesCompile != handler2);
            }
        }

        public event RulesBeforeCompileHandler BeforeRulesCompile
        {
            add
            {
                RulesBeforeCompileHandler handler2;
                RulesBeforeCompileHandler beforeRulesCompile = this.BeforeRulesCompile;
                do
                {
                    handler2 = beforeRulesCompile;
                    RulesBeforeCompileHandler handler3 = (RulesBeforeCompileHandler) Delegate.Combine(handler2, value);
                    beforeRulesCompile = Interlocked.CompareExchange<RulesBeforeCompileHandler>(ref this.BeforeRulesCompile, handler3, handler2);
                }
                while (beforeRulesCompile != handler2);
            }
            remove
            {
                RulesBeforeCompileHandler handler2;
                RulesBeforeCompileHandler beforeRulesCompile = this.BeforeRulesCompile;
                do
                {
                    handler2 = beforeRulesCompile;
                    RulesBeforeCompileHandler handler3 = (RulesBeforeCompileHandler) Delegate.Remove(handler2, value);
                    beforeRulesCompile = Interlocked.CompareExchange<RulesBeforeCompileHandler>(ref this.BeforeRulesCompile, handler3, handler2);
                }
                while (beforeRulesCompile != handler2);
            }
        }

        public event RulesCompileFailedHandler RulesCompileFailed
        {
            add
            {
                RulesCompileFailedHandler handler2;
                RulesCompileFailedHandler rulesCompileFailed = this.RulesCompileFailed;
                do
                {
                    handler2 = rulesCompileFailed;
                    RulesCompileFailedHandler handler3 = (RulesCompileFailedHandler) Delegate.Combine(handler2, value);
                    rulesCompileFailed = Interlocked.CompareExchange<RulesCompileFailedHandler>(ref this.RulesCompileFailed, handler3, handler2);
                }
                while (rulesCompileFailed != handler2);
            }
            remove
            {
                RulesCompileFailedHandler handler2;
                RulesCompileFailedHandler rulesCompileFailed = this.RulesCompileFailed;
                do
                {
                    handler2 = rulesCompileFailed;
                    RulesCompileFailedHandler handler3 = (RulesCompileFailedHandler) Delegate.Remove(handler2, value);
                    rulesCompileFailed = Interlocked.CompareExchange<RulesCompileFailedHandler>(ref this.RulesCompileFailed, handler3, handler2);
                }
                while (rulesCompileFailed != handler2);
            }
        }

        public FiddlerScript()
        {
            this.objVSASite = new ScriptEngineSite(this);
            this.scriptsFolderWatcher = new FileSystemWatcher();
            this.scriptsFolderWatcher.Filter = "CustomRules.js";
            this.scriptsFolderWatcher.NotifyFilter = NotifyFilters.LastWrite;
            this.scriptsFolderWatcher.SynchronizingObject = FiddlerApplication.UI;
            this.scriptsFolderWatcher.Deleted += new FileSystemEventHandler(this.scriptsFolderWatcher_Notify);
            this.scriptsFolderWatcher.Created += new FileSystemEventHandler(this.scriptsFolderWatcher_Notify);
            this.scriptsFolderWatcher.Changed += new FileSystemEventHandler(this.scriptsFolderWatcher_Notify);
            try
            {
                this.scriptsFolderWatcher.Path = CONFIG.GetPath("Scripts");
                this.scriptsFolderWatcher.EnableRaisingEvents = true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("!Unable to register for file-system change notifications for '{0}'.\nClick Tools > Reset Script to manually reload the script.\nError was '{1}'", new object[] { CONFIG.GetPath("Scripts"), Utilities.DescribeException(exception) });
            }
        }

        private void _ClearCachedMethodPointers()
        {
            this._methodOnBeforeRequest = this._methodOnBeforeResponse = this._methodOnPeekAtRequestHeaders = this._methodOnPeekAtResponseHeaders = this._methodOnReturningError = (Action<Session>) (this._methodOnSessionCompleted = null);
            this._methodOnWebSocketMessage = null;
            this._methodExecAction = null;
        }

        private void _ExtractMethodPointersFromScript()
        {
            this._methodOnBeforeRequest = this._GetDelegateFromScript("OnBeforeRequest");
            this._methodOnBeforeResponse = this._GetDelegateFromScript("OnBeforeResponse");
            this._methodOnReturningError = this._GetDelegateFromScript("OnReturningError");
            this._methodOnSessionCompleted = this._GetDelegateFromScript("OnDone");
            this._methodOnWebSocketMessage = this._GetWSMDelegateFromScript("OnWebSocketMessage");
            this._methodOnPeekAtResponseHeaders = this._GetDelegateFromScript("OnPeekAtResponseHeaders");
            this._methodOnPeekAtRequestHeaders = this._GetDelegateFromScript("OnPeekAtRequestHeaders");
            this._methodExecAction = this._typeScriptHandlers.GetMethod("OnExecAction");
        }

        private Action<Session> _GetDelegateFromScript(string sMethodName)
        {
            try
            {
                MethodInfo method = this._typeScriptHandlers.GetMethod(sMethodName);
                if (null == method)
                {
                    return null;
                }
                return (Action<Session>) Delegate.CreateDelegate(typeof(Action<Session>), method);
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "There was a problem with your FiddlerScript '", sMethodName, "' method.\n\n", exception.Message, "\n", exception.StackTrace, "\n\n", exception.InnerException }), "Invalid Method");
                return null;
            }
        }

        private Action<WebSocketMessage> _GetWSMDelegateFromScript(string sMethodName)
        {
            try
            {
                MethodInfo method = this._typeScriptHandlers.GetMethod(sMethodName);
                if (null == method)
                {
                    return null;
                }
                return (Action<WebSocketMessage>) Delegate.CreateDelegate(typeof(Action<WebSocketMessage>), method);
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "There was a problem with your FiddlerScript '", sMethodName, "' method.\n\n", exception.Message, "\n", exception.StackTrace, "\n\n", exception.InnerException }), "Invalid Method");
                return null;
            }
        }

        private void _IterateScriptFieldsForRulesOptions()
        {
            foreach (FieldInfo info in this._typeScriptHandlers.GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                if (info.FieldType == typeof(bool))
                {
                    BindPref customAttribute = (BindPref) Attribute.GetCustomAttribute(info, typeof(BindPref));
                    if (customAttribute != null)
                    {
                        dictFieldBackingPrefs.Add(info, customAttribute.PrefName);
                        bool boolPref = FiddlerApplication.Prefs.GetBoolPref(customAttribute.PrefName, (bool) info.GetValue(null));
                        info.SetValue(null, boolPref);
                    }
                    RulesOption oRule = (RulesOption) Attribute.GetCustomAttribute(info, typeof(RulesOption));
                    if (oRule != null)
                    {
                        this.CreateRulesMenuItem(info, oRule);
                    }
                }
                else if (info.FieldType == typeof(string))
                {
                    BindPref pref2 = (BindPref) Attribute.GetCustomAttribute(info, typeof(BindPref));
                    if (pref2 != null)
                    {
                        dictFieldBackingPrefs.Add(info, pref2.PrefName);
                        string stringPref = FiddlerApplication.Prefs.GetStringPref(pref2.PrefName, (string) info.GetValue(null));
                        info.SetValue(null, stringPref);
                    }
                    RulesString str2 = (RulesString) Attribute.GetCustomAttribute(info, typeof(RulesString));
                    if (str2 != null)
                    {
                        RulesStringValue[] customAttributes = (RulesStringValue[]) Attribute.GetCustomAttributes(info, typeof(RulesStringValue));
                        if ((customAttributes != null) && (customAttributes.Length > 0))
                        {
                            Array.Sort<RulesStringValue>(customAttributes);
                            this.CreateRulesMenuForStrings(info, str2, customAttributes);
                        }
                    }
                }
            }
        }

        private void _IterateScriptMethodsForActions()
        {
            bool flag = true;
            foreach (MethodInfo info in this._typeScriptHandlers.GetMethods())
            {
                MenuItem item;
                ToolsAction customAttribute = (ToolsAction) Attribute.GetCustomAttribute(info, typeof(ToolsAction));
                if (customAttribute != null)
                {
                    item = new MenuItem(customAttribute.Name);
                    htMenuScripts.Add(item, info);
                    item.Click += new EventHandler(this.HandleScriptToolsClick);
                    if (!string.IsNullOrEmpty(customAttribute.SubMenu))
                    {
                        MenuItem item2 = this.FindSubMenu(FiddlerApplication._frmMain.mnuTools.MenuItems, customAttribute.SubMenu);
                        if (item2 == null)
                        {
                            item2 = new MenuItem(customAttribute.SubMenu);
                            FiddlerApplication._frmMain.mnuTools.MenuItems.Add(item2);
                            htMenuScripts.Add(item2, null);
                        }
                        item2.MenuItems.Add(item);
                    }
                    else
                    {
                        FiddlerApplication._frmMain.mnuTools.MenuItems.Add(item);
                    }
                }
                ContextAction action2 = (ContextAction) Attribute.GetCustomAttribute(info, typeof(ContextAction));
                if (action2 != null)
                {
                    if (flag)
                    {
                        item = new MenuItem("-");
                        htMenuScripts.Add(item, null);
                        FiddlerApplication._frmMain.mnuSessionContext.MenuItems.Add(0, item);
                        flag = false;
                    }
                    item = new MenuItem(action2.Name);
                    htMenuScripts.Add(item, info);
                    item.Click += new EventHandler(this.HandleScriptToolsClick);
                    if (!string.IsNullOrEmpty(action2.SubMenu))
                    {
                        MenuItem item3 = this.FindSubMenu(FiddlerApplication._frmMain.mnuSessionContext.MenuItems, action2.SubMenu);
                        if (item3 == null)
                        {
                            item3 = new MenuItem(action2.SubMenu);
                            FiddlerApplication._frmMain.mnuSessionContext.MenuItems.Add(0, item3);
                            htMenuScripts.Add(item3, null);
                        }
                        item3.MenuItems.Add(item);
                    }
                    else
                    {
                        FiddlerApplication._frmMain.mnuSessionContext.MenuItems.Add(0, item);
                    }
                }
                BindUIColumn oBUIC = (BindUIColumn) Attribute.GetCustomAttribute(info, typeof(BindUIColumn));
                if (oBUIC != null)
                {
                    if (info.ReturnType != typeof(string))
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("Unable to bind column to function '{0}'. The function returns type '{1}' but it must return a String.", info.Name, info.ReturnType), "Custom Column Error");
                    }
                    else
                    {
                        getColumnStringDelegate oDel = (getColumnStringDelegate) Delegate.CreateDelegate(typeof(getColumnStringDelegate), info);
                        FiddlerApplication._frmMain.lvSessions.AddBoundColumn(oBUIC, oDel);
                    }
                }
                BindUITab oItem = (BindUITab) Attribute.GetCustomAttribute(info, typeof(BindUITab));
                if (oItem != null)
                {
                    if (info.ReturnType != typeof(string))
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("Unable to bind tab to function '{0}'. The function returns type '{1}' but it must return a String.", info.Name, info.ReturnType), "Custom Column Error");
                    }
                    else
                    {
                        this.CreateBoundTab(oItem, info);
                    }
                }
                QuickLinkMenu menu = (QuickLinkMenu) Attribute.GetCustomAttribute(info, typeof(QuickLinkMenu));
                if (menu != null)
                {
                    QuickLinkItem[] customAttributes = (QuickLinkItem[]) Attribute.GetCustomAttributes(info, typeof(QuickLinkItem));
                    if ((customAttributes != null) && (customAttributes.Length > 0))
                    {
                        Array.Sort<QuickLinkItem>(customAttributes);
                        this.CreateQuickLinkMenu(menu.Name, info, customAttributes);
                    }
                }
            }
        }

        private bool _LoadScript(string sScriptFilename, bool bPlaySounds)
        {
            if (!CONFIG.bLoadScript)
            {
                return false;
            }
            if (string.IsNullOrEmpty(sScriptFilename))
            {
                return false;
            }
            if (!File.Exists(sScriptFilename))
            {
                return false;
            }
            this._playSounds = bPlaySounds;
            this.ClearScript();
            _scriptCount++;
            if (this.BeforeRulesCompile != null)
            {
                this.BeforeRulesCompile(sScriptFilename);
            }
            string text = null;
            TabPage selectedTab = FiddlerApplication.UI.tabsViews.SelectedTab;
            if (selectedTab != null)
            {
                text = selectedTab.Text;
            }
            this.RemoveScriptCreatedUI();
            StreamReader reader = new StreamReader(new FileStream(sScriptFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.UTF8, true);
            string str2 = reader.ReadToEnd();
            reader.Close();
            try
            {
                this._engine = new VsaEngine();
                this._engine.RootMoniker = "fiddler://script/" + _scriptCount;
                this._engine.Site = this.objVSASite;
                this._engine.InitNew();
                this._engine.RootNamespace = "Fiddler.ScriptNamespace";
                bool boolPref = FiddlerApplication.Prefs.GetBoolPref("fiddler.script.GenerateDebugInfo", false);
                this._engine.GenerateDebugInfo = boolPref;
                if (boolPref)
                {
                    this._engine.SetOption("DebugDirectory", Path.GetTempPath());
                }
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.script.AutoRef", true))
                {
                    this._engine.SetOption("AutoRef", true);
                }
                string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.script.CompileToFilename", null);
                if (stringPref != null)
                {
                    this._engine.SetOption("output", stringPref);
                }
                string str4 = FiddlerApplication.Prefs.GetStringPref("fiddler.script.LibPath", null);
                if (str4 != null)
                {
                    this._engine.SetOption("LibPath", str4);
                }
            }
            catch (EntryPointNotFoundException)
            {
                FiddlerApplication.DoNotifyUser("Unable to initialize FiddlerScript. This typically indicates that you are attempting to run Fiddler on .NET Framework v4.\n\nYour machine may have the unsupported OnlyUseLatestCLR registry key set.", "Unsupported configuration", MessageBoxIcon.Hand);
                return false;
            }
            IJSVsaItems items = this._engine.Items;
            foreach (string str5 in CONFIG.sScriptReferences.Split(new char[] { ';' }))
            {
                if (str5.Trim().Length > 0)
                {
                    IJSVsaReferenceItem item1 = (IJSVsaReferenceItem) items.CreateItem(str5, JSVsaItemType.Reference, JSVsaItemFlag.None);
                }
            }
            IJSVsaGlobalItem item = (IJSVsaGlobalItem) items.CreateItem("FiddlerObject", JSVsaItemType.AppGlobal, JSVsaItemFlag.None);
            item.TypeString = "Fiddler.FiddlerScript";
            item = (IJSVsaGlobalItem) items.CreateItem("FiddlerScript", JSVsaItemType.AppGlobal, JSVsaItemFlag.None);
            item.TypeString = "Fiddler.FiddlerScript";
            item = (IJSVsaGlobalItem) items.CreateItem("UI", JSVsaItemType.AppGlobal, JSVsaItemFlag.None);
            item.TypeString = "Fiddler.frmViewer";
            IJSVsaCodeItem item2 = (IJSVsaCodeItem) items.CreateItem("Handlers", JSVsaItemType.Code, JSVsaItemFlag.None);
            item2.SourceText = str2;
            try
            {
                Environment.CurrentDirectory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Failed to set CurrentDirectory during script compile: {0}", new object[] { Utilities.DescribeException(exception) });
            }
            if (!this._engine.Compile())
            {
                return false;
            }
            this._engine.Run();
            this._typeScriptHandlers = this._engine.Assembly.GetType("Fiddler.ScriptNamespace.Handlers");
            if (null != this._typeScriptHandlers)
            {
                this.Ready = true;
                this._ExtractMethodPointersFromScript();
                this._IterateScriptFieldsForRulesOptions();
                this._IterateScriptMethodsForActions();
                MenuExt.ReadRegistry(FiddlerApplication.UI.mnuTools, htMenuScripts);
                this._RunMainMethodIfPresent();
            }
            if (!string.IsNullOrEmpty(text))
            {
                Utilities.activateTabByTitle(text, FiddlerApplication.UI.tabsViews);
            }
            if (this._playSounds)
            {
                _PlayResultSound(true);
            }
            if (this.AfterRulesCompile != null)
            {
                this.AfterRulesCompile();
            }
            return true;
        }

        private static void _NotifyUserOfError(string sTitle, Exception eX)
        {
            FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "There was a problem with your FiddlerScript.\n\n", eX.Message, "\n", eX.StackTrace, "\n\n", eX.InnerException }), sTitle);
        }

        private static void _PlayResultSound(bool bSuccess)
        {
            string stringPref;
            if (bSuccess)
            {
                stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.sounds.ScriptCompile", CONFIG.GetPath("App") + "LoadScript.wav");
            }
            else
            {
                stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.sounds.ScriptError", CONFIG.GetPath("App") + "LoadScriptError.wav");
            }
            if (!string.IsNullOrEmpty(stringPref))
            {
                Utilities.PlaySoundFile(stringPref);
            }
        }

        private void _RunMainMethodIfPresent()
        {
            try
            {
                MethodInfo method = this._typeScriptHandlers.GetMethod("Main");
                if (method != null)
                {
                    method.Invoke(null, null);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "There was a problem with your FiddlerScript.\n\n", exception.Message, "\n", exception.StackTrace, "\n\n", exception.InnerException }), "JScript main() failed.");
            }
        }

        [CodeDescription("Show a simple dialog with string sMessage.")]
        public void alert(string sMessage)
        {
            if (!CONFIG.QuietMode)
            {
                MessageBox.Show(sMessage, "FiddlerScript", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        public void ClearScript()
        {
            this.Retire();
            if (this._engine != null)
            {
                try
                {
                    this._engine.Close();
                }
                catch (Exception)
                {
                }
                this._engine = null;
            }
        }

        private void CreateBoundTab(BindUITab oItem, MethodInfo oMI)
        {
            EventHandler handler2 = null;
            string inStr = oItem._sOptions ?? string.Empty;
            if (inStr.OICContains("<hidden>"))
            {
                oItem._sOptions = inStr.Replace("<hidden>", "");
                oItem._oMI = new MenuItem(oItem._sTabTitle);
                if (handler2 == null)
                {
                    handler2 = delegate (object o, EventArgs ea) {
                        if (oItem._oTabPage == null)
                        {
                            this.CreateBoundTab(oItem, oMI);
                        }
                        if (!FiddlerApplication.UI.tabsViews.Contains(oItem._oTabPage))
                        {
                            FiddlerApplication.UI.tabsViews.Controls.Add(oItem._oTabPage);
                        }
                        FiddlerApplication.UI.tabsViews.SelectedTab = oItem._oTabPage;
                    };
                }
                oItem._oMI.Click += handler2;
                FiddlerApplication.UI.mnuViewTabs.MenuItems.Add(oItem._oMI);
            }
            else
            {
                CalculateReportHandler handler;
                <>c__DisplayClass4 class4;
                getTabStringDelegate oFn = (getTabStringDelegate) Delegate.CreateDelegate(typeof(getTabStringDelegate), oMI);
                oItem._oTabPage = new TabPage(oItem._sTabTitle);
                if (oItem._bHTML)
                {
                    <>c__DisplayClass4 CS$<>8__locals5 = class4;
                    WebBrowser oWB = new WebBrowser();
                    oWB.AllowWebBrowserDrop = false;
                    oWB.ScriptErrorsSuppressed = true;
                    oItem._oTabPage.Controls.Add(oWB);
                    oWB.Dock = DockStyle.Fill;
                    handler = delegate (Session[] arrSess) {
                        if (FiddlerApplication.UI.tabsViews.SelectedTab == CS$<>8__locals5.oItem._oTabPage)
                        {
                            string str = CS$<>8__locals5.oFn(arrSess);
                            oWB.DocumentText = str;
                        }
                    };
                }
                else
                {
                    <>c__DisplayClass4 CS$<>8__locals5 = class4;
                    RichTextBox oRTB = new RichTextBox();
                    if (inStr.OICContains("<nowrap>"))
                    {
                        oRTB.WordWrap = false;
                    }
                    if (inStr.OICContains("<nolink>"))
                    {
                        oRTB.DetectUrls = false;
                    }
                    string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.fixedfont.face", "Lucida Console");
                    oRTB.Font = new Font(stringPref, CONFIG.flFontSize);
                    oRTB.ReadOnly = true;
                    oRTB.BackColor = CONFIG.colorDisabledEdit;
                    oItem._oTabPage.Controls.Add(oRTB);
                    oRTB.Dock = DockStyle.Fill;
                    handler = delegate (Session[] arrSess) {
                        if (FiddlerApplication.UI.tabsViews.SelectedTab == CS$<>8__locals5.oItem._oTabPage)
                        {
                            string str = CS$<>8__locals5.oFn(arrSess);
                            oRTB.Text = str;
                        }
                    };
                }
                FiddlerApplication.UI.tabsViews.TabPages.Add(oItem._oTabPage);
                oItem._oDel = handler;
                FiddlerApplication.CalculateReport += handler;
                this.listTabs.Add(oItem);
            }
        }

        [CodeDescription("Creates a simple Dictionary<string, object>, used to pass option strings into the DoImport or DoExport methods on the FiddlerApplication object.")]
        public Dictionary<string, object> createDictionary()
        {
            return new Dictionary<string, object>();
        }

        private void CreateQuickLinkMenu(string sMenuText, MethodInfo oMethod, QuickLinkItem[] oValues)
        {
            MenuItem key = new MenuItem(sMenuText);
            htMenuScripts.Add(key, null);
            FiddlerApplication.UI.Menu.MenuItems.Add(key);
            foreach (QuickLinkItem item3 in oValues)
            {
                MenuItem item2 = new MenuItem(item3.MenuText);
                item2.Tag = item3.Action;
                item2.Click += new EventHandler(this.HandleScriptQuickLinkClick);
                htMenuScripts.Add(item2, oMethod);
                key.MenuItems.Add(item2);
            }
        }

        private void CreateRulesMenuForStrings(FieldInfo oField, RulesString oRule, RulesStringValue[] oValues)
        {
            MenuItem item2;
            MenuItem key = new MenuItem(oRule.Name);
            htMenuScripts.Add(key, null);
            FiddlerApplication._frmMain.mnuRules.MenuItems.Add(key);
            string str = (string) oField.GetValue(null);
            if (str == null)
            {
                foreach (RulesStringValue value2 in oValues)
                {
                    if (value2.IsDefault)
                    {
                        if (value2.Value != "%CUSTOM%")
                        {
                            oField.SetValue(null, value2.Value);
                        }
                        str = value2.Value;
                        break;
                    }
                }
            }
            else
            {
                bool flag = false;
                foreach (RulesStringValue value3 in oValues)
                {
                    if (str == value3.Value)
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    str = "%CUSTOM%";
                }
            }
            bool flag2 = false;
            foreach (RulesStringValue value4 in oValues)
            {
                item2 = new MenuItem(value4.MenuText);
                item2.Tag = value4.Value;
                item2.RadioCheck = true;
                if (!flag2 && (str == value4.Value))
                {
                    flag2 = true;
                    item2.Checked = true;
                }
                item2.Click += new EventHandler(this.HandleScriptRulesStringClick);
                htMenuScripts.Add(item2, oField);
                key.MenuItems.Add(item2);
            }
            if (oRule.ShowDisabledOption)
            {
                htMenuScripts.Add(key.MenuItems.Add("-"), null);
                item2 = new MenuItem("Disabled");
                item2.Tag = null;
                item2.RadioCheck = true;
                if (!flag2)
                {
                    item2.Checked = true;
                }
                item2.Click += new EventHandler(this.HandleScriptRulesStringClick);
                htMenuScripts.Add(item2, oField);
                key.MenuItems.Add(item2);
            }
        }

        private void CreateRulesMenuItem(FieldInfo oField, RulesOption oRule)
        {
            MenuItem key = new MenuItem(oRule.Name);
            htMenuScripts.Add(key, oField);
            key.Click += new EventHandler(this.HandleScriptRulesClick);
            if ((bool) oField.GetValue(null))
            {
                key.Checked = true;
            }
            if (oRule.SubMenu == null)
            {
                FiddlerApplication._frmMain.mnuRules.MenuItems.Add(key);
            }
            else
            {
                if (oRule.IsExclusive)
                {
                    key.RadioCheck = true;
                }
                MenuItem item2 = this.FindSubMenu(FiddlerApplication._frmMain.mnuRules.MenuItems, oRule.SubMenu);
                if (item2 == null)
                {
                    item2 = FiddlerApplication._frmMain.mnuRules.MenuItems.Add(oRule.SubMenu);
                    htMenuScripts.Add(item2, null);
                }
                item2.MenuItems.Add(key);
                if (oRule.followingSplitter)
                {
                    htMenuScripts.Add(item2.MenuItems.Add("-"), null);
                }
            }
        }

        internal void DoBeforeRequest(Session oSession)
        {
            if (this.Ready && (this._methodOnBeforeRequest != null))
            {
                try
                {
                    this._methodOnBeforeRequest(oSession);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnBeforeRequest() failed.", exception);
                }
            }
        }

        internal void DoBeforeResponse(Session oSession)
        {
            if (this.Ready && (this._methodOnBeforeResponse != null))
            {
                try
                {
                    this._methodOnBeforeResponse(oSession);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnBeforeResponse() failed.", exception);
                }
            }
        }

        internal bool DoExecAction(string strData)
        {
            if (!this.Ready || (null == this._methodExecAction))
            {
                return false;
            }
            try
            {
                object[] parameters = new object[] { Utilities.Parameterize(strData) };
                if (parameters.Length > 0)
                {
                    object obj2 = this._methodExecAction.Invoke(null, parameters);
                    return ((obj2 is bool) && ((bool) obj2));
                }
                return false;
            }
            catch (Exception exception)
            {
                _NotifyUserOfError("FiddlerScript DoExecAction() failed.", exception);
                return false;
            }
        }

        public bool DoMethod(string sMethodName)
        {
            return this.DoMethod(sMethodName, null);
        }

        public bool DoMethod(string sMethodName, object[] oParams)
        {
            object obj2;
            return this.DoMethod(sMethodName, oParams, out obj2);
        }

        public bool DoMethod(string sMethodName, object[] oParams, out object oResult)
        {
            oResult = null;
            if (!this.Ready || (null == this._typeScriptHandlers))
            {
                return false;
            }
            try
            {
                MethodInfo method = this._typeScriptHandlers.GetMethod(sMethodName);
                if (null == method)
                {
                    return false;
                }
                oResult = method.Invoke(null, oParams);
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "There was a problem with your FiddlerScript.\n\n", exception.Message, "\n", exception.StackTrace, "\n\n", exception.InnerException }), "FiddlerScript Error invoking " + sMethodName);
                return false;
            }
        }

        internal void DoOnAttach()
        {
            this.DoMethod("OnAttach");
        }

        internal void DoOnBoot()
        {
            this.DoMethod("OnBoot");
        }

        internal void DoOnDetach()
        {
            this.DoMethod("OnDetach");
        }

        internal void DoOnShutdown()
        {
            this.DoMethod("OnShutdown");
        }

        internal void DoPeekAtRequestHeaders(Session oSession)
        {
            if (this.Ready && (this._methodOnPeekAtRequestHeaders != null))
            {
                try
                {
                    this._methodOnPeekAtRequestHeaders(oSession);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnPeekAtRequestHeaders() failed.", exception);
                }
            }
        }

        internal void DoPeekAtResponseHeaders(Session oSession)
        {
            if (this.Ready && (this._methodOnPeekAtResponseHeaders != null))
            {
                try
                {
                    this._methodOnPeekAtResponseHeaders(oSession);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnPeekAtResponseHeaders() failed.", exception);
                }
            }
        }

        internal void DoReturningError(Session oSession)
        {
            if (this.Ready && (this._methodOnReturningError != null))
            {
                try
                {
                    this._methodOnReturningError(oSession);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnReturningError() failed.", exception);
                }
            }
        }

        internal void DoSessionCompleted(Session oSession)
        {
            if (this.Ready && (this._methodOnSessionCompleted != null))
            {
                try
                {
                    this._methodOnSessionCompleted(oSession);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnDone() failed.", exception);
                }
            }
        }

        internal void DoWebSocketMessage(WebSocketMessage wsmMsg)
        {
            if (this.Ready && (this._methodOnWebSocketMessage != null))
            {
                try
                {
                    this._methodOnWebSocketMessage(wsmMsg);
                }
                catch (Exception exception)
                {
                    _NotifyUserOfError("FiddlerScript OnWebSocketMessage() failed.", exception);
                }
            }
        }

        private MenuItem FindSubMenu(Menu.MenuItemCollection oItems, string sItemName)
        {
            foreach (MenuItem item in oItems)
            {
                if (item.Text == sItemName)
                {
                    return item;
                }
            }
            return null;
        }

        [CodeDescription("Flash Fiddler's taskbar icon if Fiddler is not the active window.")]
        public void flashWindow()
        {
            if (FiddlerApplication._frmMain != null)
            {
                Utilities.DoFlash(FiddlerApplication._frmMain.Handle);
            }
        }

        private void HandleScriptQuickLinkClick(object sender, EventArgs e)
        {
            try
            {
                MethodInfo info = (MethodInfo) htMenuScripts[sender];
                if (((info.GetParameters().Length != 2) || (info.GetParameters()[0].ParameterType != typeof(string))) || (info.GetParameters()[1].ParameterType != typeof(string)))
                {
                    throw new InvalidDataException("Handler function was incorrectly defined. Should be function(string,string);");
                }
                MenuItem item = (MenuItem) sender;
                info.Invoke(null, new object[] { item.Text, item.Tag as string });
            }
            catch (Exception innerException)
            {
                if ((innerException is TargetInvocationException) && (innerException.InnerException != null))
                {
                    innerException = innerException.InnerException;
                }
                FiddlerApplication.ReportException(innerException, "Script Error", "Your QuickLink script threw an exception.");
            }
        }

        private void HandleScriptRulesClick(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;
            item.Checked = !item.Checked;
            FieldInfo info = (FieldInfo) htMenuScripts[item];
            info.SetValue(null, item.Checked);
            if (item.RadioCheck)
            {
                foreach (MenuItem item2 in item.Parent.MenuItems)
                {
                    if ((item != item2) && item2.RadioCheck)
                    {
                        item2.Checked = false;
                        ((FieldInfo) htMenuScripts[item2]).SetValue(null, false);
                    }
                }
            }
        }

        private void HandleScriptRulesStringClick(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;
            FieldInfo info = (FieldInfo) htMenuScripts[item];
            string tag = (string) item.Tag;
            if ((tag != null) && tag.OICStartsWith("%CUSTOM%"))
            {
                tag = frmPrompt.GetUserString("Input custom value", "Input the custom value", (string) info.GetValue(null));
                item.Checked = true;
            }
            else
            {
                if (item.Checked)
                {
                    return;
                }
                item.Checked = !item.Checked;
            }
            info.SetValue(null, tag);
            foreach (MenuItem item2 in item.Parent.MenuItems)
            {
                if (item != item2)
                {
                    item2.Checked = false;
                }
            }
        }

        private void HandleScriptToolsClick(object sender, EventArgs e)
        {
            try
            {
                MethodInfo info = (MethodInfo) htMenuScripts[sender];
                if ((info.GetParameters().Length == 1) && (info.GetParameters()[0].ParameterType == typeof(Session[])))
                {
                    info.Invoke(null, new object[] { FiddlerApplication._frmMain.GetSelectedSessions() });
                }
                else
                {
                    info.Invoke(null, null);
                }
            }
            catch (Exception innerException)
            {
                if ((innerException is TargetInvocationException) && (innerException.InnerException != null))
                {
                    innerException = innerException.InnerException;
                }
                FiddlerApplication.ReportException(innerException, "Script Error", "Your ToolsAction script threw an exception.");
            }
        }

        public bool HasMethod(string sMethodName)
        {
            if (!this.Ready || (null == this._typeScriptHandlers))
            {
                return false;
            }
            MethodInfo method = this._typeScriptHandlers.GetMethod(sMethodName);
            return (null != method);
        }

        public bool LoadRulesScript()
        {
            return this.LoadRulesScript(false);
        }

        public bool LoadRulesScript(bool bPlaySounds)
        {
            if (bBusyReportingScriptError)
            {
                Trace.WriteLine("Skipping script load because an error message is up. We don't like reentrancy!");
                return false;
            }
            bool flag = false;
            try
            {
                string path = CONFIG.GetPath("CustomRules");
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.script.delaycreate", true) && !File.Exists(path))
                {
                    path = CONFIG.GetPath("SampleRules");
                }
                flag = this._LoadScript(path, bPlaySounds);
            }
            catch (Exception exception)
            {
                string str2;
                string str3;
                bool flag2 = !string.IsNullOrEmpty(CONFIG.m_sAdditionalScriptReferences);
                if ((exception is JSVsaException) && ((exception as JSVsaException).ErrorCode == JSVsaError.AssemblyExpected))
                {
                    str2 = "Script compilation failed due to " + exception.ToString() + "\n\nAdjust script references inside Tools > Fiddler Options > Extensions.";
                    str3 = "Script Reference Missing";
                }
                else
                {
                    str2 = string.Concat(new object[] { "Failed to load script.\n ", exception.Message, "\n", exception.InnerException, exception.StackTrace, flag2 ? "\n\nAdjust script references inside Tools > Fiddler Options > Extensions." : string.Empty });
                    str3 = "Script Failure";
                }
                FiddlerApplication.DoNotifyUser(str2, str3, MessageBoxIcon.Hand);
                this.ClearScript();
            }
            return flag;
        }

        [CodeDescription("Log a simple string.")]
        public void log(string sMessage)
        {
            FiddlerApplication.Log.LogString(sMessage);
        }

        internal void NotifyOfCompilerError(IJSVsaError e)
        {
            try
            {
                bBusyReportingScriptError = true;
                if (this._playSounds)
                {
                    _PlayResultSound(false);
                }
                if (this.RulesCompileFailed == null)
                {
                    string[] strArray = e.LineText.Split(new char[] { '\n' });
                    StringBuilder builder = new StringBuilder();
                    int index = e.Line - 1;
                    if (index >= 1)
                    {
                        builder.Append("\t\t");
                        builder.AppendLine(strArray[index - 1].Trim());
                    }
                    else
                    {
                        builder.AppendLine("\t\t{start-of-file}");
                    }
                    builder.Append("ERROR LINE -->\t");
                    builder.AppendLine(strArray[index].Trim());
                    if (index < (strArray.Length - 1))
                    {
                        builder.Append("\t\t");
                        builder.AppendLine(strArray[index + 1].Trim());
                    }
                    else
                    {
                        builder.AppendLine("\t\t{end-of-file}");
                    }
                    FiddlerApplication.DoNotifyUser(FiddlerApplication.UI, string.Format("FiddlerScript compilation failed on line {0}:\n\n----------------------  SOURCE  -------------------------------\n\n{1}\n\n-------------------------------------------------------------------\n\n{2}", e.Line, builder.ToString(), e.Description), "FiddlerScript Error", MessageBoxIcon.Hand);
                }
                else
                {
                    this.RulesCompileFailed(e.Description, e.Line, e.StartColumn, e.EndColumn);
                }
            }
            finally
            {
                bBusyReportingScriptError = false;
            }
        }

        [CodeDescription("Play the specified sound file.")]
        public void playSound(string sSoundname)
        {
            Utilities.PlaySoundFile(sSoundname);
        }

        [CodeDescription("Retrieve a string from an input box labeled by sMessage.")]
        public string prompt(string sMessage)
        {
            return this.prompt(sMessage, string.Empty, "FiddlerScript Prompt");
        }

        [CodeDescription("Retrieve a string from an input box labeled by sMessage.")]
        public string prompt(string sMessage, string sDefaultValue)
        {
            return this.prompt(sMessage, sDefaultValue, "FiddlerScript Prompt");
        }

        [CodeDescription("Retrieve a string from an input box labeled by sMessage.")]
        public string prompt(string sMessage, string sDefaultValue, string sWindowTitle)
        {
            if (FiddlerApplication._frmMain != null)
            {
                Utilities.DoFlash(FiddlerApplication._frmMain.Handle);
            }
            return frmPrompt.GetUserString(sWindowTitle, sMessage, sDefaultValue);
        }

        [CodeDescription("Forces Fiddler to reload the rules script from disk.")]
        public void ReloadScript()
        {
            FiddlerApplication._frmMain.actLoadScripts();
        }

        private void RemoveScriptCreatedUI()
        {
            foreach (object obj2 in htMenuScripts.Keys)
            {
                MenuItem item = (MenuItem) obj2;
                item.Parent.MenuItems.RemoveAt(item.Index);
            }
            htMenuScripts.Clear();
            foreach (BindUITab tab in this.listTabs)
            {
                FiddlerApplication.CalculateReport -= tab._oDel;
                if (tab._oTabPage != null)
                {
                    FiddlerApplication.UI.tabsViews.TabPages.Remove(tab._oTabPage);
                    tab._oTabPage.Dispose();
                    tab._oTabPage = null;
                }
                if (tab._oMI != null)
                {
                    FiddlerApplication.UI.mnuViewTabs.MenuItems.Remove(tab._oMI);
                    tab._oMI.Dispose();
                    tab._oMI = null;
                }
            }
            this.listTabs.Clear();
        }

        internal void Retire()
        {
            foreach (PreferenceBag.PrefWatcher watcher in this.listWeaklyHeldWatchers)
            {
                FiddlerApplication.Prefs.RemoveWatcher(watcher);
            }
            this.listWeaklyHeldWatchers.Clear();
            foreach (KeyValuePair<FieldInfo, string> pair in dictFieldBackingPrefs)
            {
                if (pair.Key.FieldType == typeof(bool))
                {
                    FiddlerApplication.Prefs.SetBoolPref(pair.Value, (bool) pair.Key.GetValue(null));
                }
                else if (pair.Key.FieldType == typeof(string))
                {
                    FiddlerApplication.Prefs.SetStringPref(pair.Value, (string) pair.Key.GetValue(null));
                }
            }
            dictFieldBackingPrefs.Clear();
            this.DoMethod("OnRetire", null);
            this.Ready = false;
            this._ClearCachedMethodPointers();
        }

        private void scriptsFolderWatcher_Notify(object sender, FileSystemEventArgs e)
        {
            if (((CONFIG.bAutoLoadScript && CONFIG.bLoadScript) && "CustomRules.js".OICEquals(e.Name)) && ((Utilities.GetTickCount() - lastScriptLoadTickCount) >= ((ulong) CONFIG.iScriptReloadInterval)))
            {
                FiddlerApplication.oTelemetry.TrackEvent("FiddlerScript.ReloadedAtRuntime");
                lastScriptLoadTickCount = Utilities.GetTickCount();
                Thread.Sleep(50);
                string sMsg = this.LoadRulesScript(true) ? "Reloaded the updated FiddlerScript rules." : "FiddlerScript rules failed to load.";
                FiddlerApplication.Log.LogString(sMsg);
            }
        }

        void IDisposable.Dispose()
        {
            if (this._engine != null)
            {
                this._engine.Close();
            }
            this.scriptsFolderWatcher.Dispose();
        }

        [CodeDescription("Sends a HTTP request; sRequest represents a full request. Warning: Method may throw exceptions.")]
        public void utilIssueRequest(string sRequest)
        {
            FiddlerApplication.oProxy.SendRequest(sRequest, null);
        }

        [CodeDescription("Enable notification of preference changes. For proper GC, use this function instead of Prefs.AddWatcher.")]
        public void WatchPreference(string sPref, EventHandler<PrefChangeEventArgs> oFN)
        {
            PreferenceBag.PrefWatcher item = FiddlerApplication.Prefs.AddWatcher(sPref, oFN);
            this.listWeaklyHeldWatchers.Add(item);
        }

        internal bool _playSounds
        {
            [CompilerGenerated]
            get
            {
                return this.<_playSounds>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<_playSounds>k__BackingField = value;
            }
        }

        [CodeDescription("Set the text on Fiddler's status bar.")]
        public string StatusText
        {
            set
            {
                FiddlerApplication.UI.SetStatusText(value);
                Application.DoEvents();
            }
        }

        public frmViewer UI
        {
            get
            {
                return FiddlerApplication._frmMain;
            }
        }
    }
}

