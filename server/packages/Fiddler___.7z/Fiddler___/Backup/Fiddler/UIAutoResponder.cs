﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;

    internal class UIAutoResponder : UserControl
    {
        private Button btnRespondAdd;
        private Button btnRespondImport;
        private Button btnSaveRule;
        internal CheckBox cbAutoRespond;
        private CheckBox cbAutoRespondOnce;
        internal CheckBox cbRespondPassthrough;
        internal CheckBox cbRespondUseLatency;
        internal ComboBox cbxRuleAction;
        internal ComboBox cbxRuleURI;
        private ColumnHeader colComments;
        private ColumnHeader colRespondLatency;
        private ColumnHeader colRespondMatch;
        private ColumnHeader colRespondWith;
        private IContainer components;
        private GroupBox gbResponderEditor;
        private Label lblAutoRespondHeader;
        private Label lblMultipleMatch;
        private LinkLabel lnkAutoRespondHelp;
        private LinkLabel lnkTestRule;
        internal DoubleBufferedListView lvRespondRules;
        private ToolStripMenuItem miAREdit;
        private ToolStripMenuItem miAutoResponderGenerate;
        private ToolStripMenuItem miDemoteRule;
        private ToolStripMenuItem miEditARFileWith;
        private ToolStripMenuItem miExportRules;
        private ToolStripMenuItem miFindRule;
        private ToolStripMenuItem miPromoteRule;
        private ToolStripMenuItem miRemoveRule;
        private ToolStripMenuItem miRespondCloneRule;
        private ToolStripMenuItem miRespondComment;
        private ToolStripMenuItem miRespondSetLatency;
        private ToolStripMenuItem miRuleOpenURL;
        private ContextMenuStrip mnuContextAutoResponder;
        private Panel pnlAutoResponders;
        private Panel pnlResponderActions;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripSeparator toolStripMenuItem2;

        internal UIAutoResponder()
        {
            this.InitializeComponent();
            this.lvRespondRules.Font = new Font(this.lvRespondRules.Font.FontFamily, CONFIG.flFontSize);
            Utilities.SetCueText(this.cbxRuleURI, "Request URL Pattern");
            Utilities.SetCueText(this.cbxRuleAction, "Local file to return or *Action to execute");
            this.lvRespondRules.EmptyText = "Click [Add Rule] above to create a rule.";
        }

        private void _SelectMostRecentLVRespondRule()
        {
            if (this.lvRespondRules.Items.Count > -1)
            {
                this.lvRespondRules.SelectedItems.Clear();
                this.lvRespondRules.Items[this.lvRespondRules.Items.Count - 1].Selected = true;
            }
        }

        private void actCloneRule()
        {
            if (this.lvRespondRules.SelectedItems.Count == 1)
            {
                ResponderRule tag = (ResponderRule) this.lvRespondRules.SelectedItems[0].Tag;
                byte[] arrResponseBody = null;
                HTTPResponseHeaders oRH = null;
                if (tag.HasImportedResponse)
                {
                    oRH = (HTTPResponseHeaders) tag._oResponseHeaders.Clone();
                    arrResponseBody = Utilities.Dupe(tag._arrResponseBodyBytes);
                }
                FiddlerApplication._AutoResponder.AddRule(tag.sMatch, oRH, arrResponseBody, tag.sAction, tag.sComment, tag.iLatency, tag.IsEnabled);
            }
        }

        private void actDemoteRule()
        {
            if (this.lvRespondRules.SelectedItems.Count == 1)
            {
                ListViewItem item = this.lvRespondRules.SelectedItems[0];
                if (FiddlerApplication._AutoResponder.DemoteRule((ResponderRule) item.Tag))
                {
                    int index = item.Index + 1;
                    item.Remove();
                    this.lvRespondRules.Items.Insert(index, item);
                    item.Focused = true;
                    item.EnsureVisible();
                }
            }
        }

        private static void actLaunchEditor(ResponderRule oRR)
        {
            if (oRR.HasImportedResponse)
            {
                if ((oRR._oEditor == null) || oRR._oEditor.IsDisposed)
                {
                    oRR._oEditor = new UIARRuleEditor(oRR);
                    oRR._oEditor.Show();
                }
                else
                {
                    oRR._oEditor.BringToFront();
                }
            }
        }

        private void actPromoteRule()
        {
            if (this.lvRespondRules.SelectedItems.Count == 1)
            {
                ListViewItem item = this.lvRespondRules.SelectedItems[0];
                if (FiddlerApplication._AutoResponder.PromoteRule((ResponderRule) item.Tag))
                {
                    int index = item.Index - 1;
                    item.Remove();
                    this.lvRespondRules.Items.Insert(index, item);
                    item.Focused = true;
                    item.EnsureVisible();
                }
            }
        }

        private void actRemoveSelectedRules()
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvRespondRules.SelectedItems;
            if (selectedItems.Count >= 1)
            {
                this.lvRespondRules.BeginUpdate();
                foreach (ListViewItem item in selectedItems)
                {
                    FiddlerApplication._AutoResponder.RemoveRule((ResponderRule) item.Tag);
                }
                this.lvRespondRules.EndUpdate();
                this.cbxRuleURI.Text = this.cbxRuleAction.Text = string.Empty;
                if (this.lvRespondRules.FocusedItem != null)
                {
                    this.lvRespondRules.FocusedItem.Selected = true;
                }
            }
        }

        private void actSetRuleComment()
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvRespondRules.SelectedItems;
            if (selectedItems.Count >= 1)
            {
                ResponderRule tag = selectedItems[0].Tag as ResponderRule;
                string sComment = tag.sComment;
                sComment = frmPrompt.GetUserString("Set Comment", "Enter a comment describing this Rule:", sComment, true, frmPrompt.PromptIcon.Default);
                if (sComment != null)
                {
                    sComment = sComment.Trim();
                    foreach (ListViewItem item in selectedItems)
                    {
                        tag = item.Tag as ResponderRule;
                        tag.sComment = sComment;
                        item.SubItems[3].Text = sComment;
                    }
                    if (this.lvRespondRules.Columns[3].Width < 10)
                    {
                        this.lvRespondRules.Columns[3].Width = 70;
                    }
                    FiddlerApplication._AutoResponder.IsRuleListDirty = true;
                }
            }
        }

        private void actSetRuleLatency()
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvRespondRules.SelectedItems;
            if (selectedItems.Count >= 1)
            {
                if (!this.cbRespondUseLatency.Checked)
                {
                    this.cbRespondUseLatency.Checked = true;
                }
                int result = 0;
                string sDefault = "0";
                if (selectedItems.Count == 1)
                {
                    sDefault = ((ResponderRule) selectedItems[0].Tag).iLatency.ToString();
                }
                string s = frmPrompt.GetUserString("Adjust Latency", "Enter the exact number of milliseconds by which to delay the response, or use a leading + or - to adjust the current latency.", sDefault, true, frmPrompt.PromptIcon.Numbers);
                if ((s != null) && int.TryParse(s, out result))
                {
                    bool flag = s.StartsWith("+") || s.StartsWith("-");
                    this.lvRespondRules.BeginUpdate();
                    foreach (ListViewItem item in selectedItems)
                    {
                        int num2;
                        if (flag)
                        {
                            num2 = Math.Max(((ResponderRule) item.Tag).iLatency + result, 0);
                        }
                        else
                        {
                            num2 = result;
                        }
                        ((ResponderRule) item.Tag).iLatency = num2;
                        item.SubItems[2].Text = num2.ToString();
                    }
                    this.lvRespondRules.EndUpdate();
                    FiddlerApplication._AutoResponder.IsRuleListDirty = true;
                }
            }
        }

        private void btnRespondAdd_Click(object sender, EventArgs e)
        {
            string str;
            if (FiddlerApplication.UI.lvSessions.SelectedItems.Count == 1)
            {
                str = "EXACT:" + FiddlerApplication.UI.GetFirstSelectedSession().fullUrl;
            }
            else
            {
                str = "StringToMatch[" + ((this.lvRespondRules.Items.Count + 1)).ToString() + "]";
            }
            this.lvRespondRules.SelectedItems.Clear();
            ResponderRule rule = FiddlerApplication._AutoResponder.AddRule(str, string.Empty, true);
            if (rule != null)
            {
                rule.ViewItem.EnsureVisible();
                rule.ViewItem.Selected = true;
            }
            this.cbxRuleURI.Focus();
        }

        private void btnRespondImport_Click(object sender, EventArgs e)
        {
            string fileName;
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.DefaultExt = "saz";
            dialog.RestoreDirectory = true;
            dialog.InitialDirectory = CONFIG.GetPath("Captures");
            dialog.Title = "Import file for replay";
            dialog.Filter = "SAZ / Rules (*.saz;*.farx)|*.saz;*.farx|SAZ for Playback (*.saz)|*.saz";
            bool bUsePlaybackHeuristics = false;
            if (DialogResult.OK == dialog.ShowDialog(this))
            {
                fileName = dialog.FileName;
                bUsePlaybackHeuristics = 2 == dialog.FilterIndex;
            }
            else
            {
                dialog.Dispose();
                return;
            }
            dialog.Dispose();
            if (fileName.OICEndsWith(".farx"))
            {
                FiddlerApplication._AutoResponder.ImportFARX(fileName);
            }
            else
            {
                FiddlerApplication._AutoResponder.ImportSAZ(fileName, bUsePlaybackHeuristics);
            }
        }

        private void btnSaveRule_Click(object sender, EventArgs e)
        {
            if (this.lvRespondRules.SelectedItems.Count >= 1)
            {
                foreach (ListViewItem item in this.lvRespondRules.SelectedItems)
                {
                    ResponderRule tag = (ResponderRule) item.Tag;
                    if (this.cbxRuleURI.Visible)
                    {
                        tag.sMatch = this.cbxRuleURI.Text;
                        item.Text = tag.sMatch;
                        tag.bDisableOnMatch = this.cbAutoRespondOnce.Checked;
                    }
                    else if (this.cbAutoRespondOnce.CheckState != CheckState.Indeterminate)
                    {
                        tag.bDisableOnMatch = this.cbAutoRespondOnce.Checked;
                    }
                    if (tag.sAction != this.cbxRuleAction.Text)
                    {
                        bool flag = false;
                        if (this.cbxRuleAction.Text == AutoResponder.STR_CREATE_NEW)
                        {
                            flag = true;
                            this.cbxRuleAction.Text = "NEW_RESPONSE_" + DateTime.Now.ToString("HH_mm_ss");
                            tag._arrResponseBodyBytes = Encoding.UTF8.GetBytes("Response body goes here...");
                            string[] sHeaders = new string[] { "Content-Length: " + tag._arrResponseBodyBytes.Length.ToString(), "Content-Type: text/plain; charset=utf-8" };
                            tag._oResponseHeaders = new HTTPResponseHeaders(200, sHeaders);
                        }
                        else
                        {
                            tag._arrResponseBodyBytes = null;
                            tag._oResponseHeaders = null;
                        }
                        tag.sAction = this.cbxRuleAction.Text;
                        this.cbxRuleAction.Text = tag.sAction;
                        item.SubItems[1].Text = tag.sAction;
                        if (flag)
                        {
                            actLaunchEditor(tag);
                        }
                    }
                }
                FiddlerApplication._AutoResponder.IsRuleListDirty = true;
            }
        }

        private void cbAutoRespond_CheckedChanged(object sender, EventArgs e)
        {
            bool flag = this.cbAutoRespond.Checked;
            FiddlerApplication._AutoResponder.IsEnabled = flag;
            this.lblAutoRespondHeader.BackColor = flag ? Color.Green : Color.Gray;
            this.lvRespondRules.BackColor = flag ? SystemColors.Window : SystemColors.Control;
            FiddlerApplication.UI.pageResponder.ImageIndex = this.cbAutoRespond.Checked ? 0x18 : 0x17;
        }

        private void cbRespondPassthrough_CheckedChanged(object sender, EventArgs e)
        {
            FiddlerApplication._AutoResponder.PermitFallthrough = this.cbRespondPassthrough.Checked;
        }

        private void cbRespondUseLatency_CheckedChanged(object sender, EventArgs e)
        {
            FiddlerApplication._AutoResponder.UseLatency = this.cbRespondUseLatency.Checked;
        }

        private void cbxRuleAction_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.A))
            {
                this.cbxRuleAction.SelectAll();
                e.Handled = e.SuppressKeyPress = true;
            }
            else if ((e.KeyCode == Keys.Return) && !this.cbxRuleAction.DroppedDown)
            {
                base.ActiveControl = base.GetNextControl(base.ActiveControl, true);
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        private void cbxRuleAction_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (this.cbxRuleAction.SelectedIndex == (this.cbxRuleAction.Items.Count - 1))
            {
                bool flag = false;
                this.cbxRuleAction.Text = string.Empty;
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.DefaultExt = "dat";
                dialog.Title = "Choose response file";
                dialog.Filter = "All Files (*.*)|*.*|Response Files (*.dat)|*.dat";
                if (DialogResult.OK == dialog.ShowDialog(this))
                {
                    this.cbxRuleAction.Items.Insert(0, dialog.FileName);
                    flag = true;
                }
                dialog.Dispose();
                if (this.cbxRuleAction.Items.Count > 0)
                {
                    this.cbxRuleAction.SelectedIndex = 0;
                }
                if (flag)
                {
                    this.btnSaveRule_Click(null, null);
                }
            }
        }

        private void cbxRuleURI_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.A))
            {
                this.cbxRuleURI.SelectAll();
                e.Handled = e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.Return)
            {
                base.ActiveControl = base.GetNextControl(base.ActiveControl, true);
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private string GetSelectedHyperlink()
        {
            if (this.lvRespondRules.SelectedItems.Count != 1)
            {
                return string.Empty;
            }
            ListViewItem item = this.lvRespondRules.SelectedItems[0];
            string sMatch = (item.Tag as ResponderRule).sMatch;
            if (sMatch.OICContains("REGEX:"))
            {
                return string.Empty;
            }
            if (sMatch.OICStartsWith("METHOD:"))
            {
                sMatch = Utilities.TrimBefore(sMatch, ' ');
            }
            if (sMatch.OICStartsWith("URLWithBody:"))
            {
                sMatch = Utilities.TrimAfter(sMatch.Substring(12), ' ');
            }
            if (sMatch.OICStartsWith("EXACT:"))
            {
                sMatch = sMatch.Substring(6);
            }
            if (!sMatch.OICStartsWithAny(new string[] { "http://", "https://", "ftp://" }))
            {
                sMatch = "http://" + sMatch;
            }
            return sMatch;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.lnkAutoRespondHelp = new LinkLabel();
            this.cbAutoRespond = new CheckBox();
            this.pnlAutoResponders = new Panel();
            this.lvRespondRules = new DoubleBufferedListView();
            this.colRespondMatch = new ColumnHeader();
            this.colRespondWith = new ColumnHeader();
            this.colRespondLatency = new ColumnHeader();
            this.colComments = new ColumnHeader();
            this.mnuContextAutoResponder = new ContextMenuStrip(this.components);
            this.miRemoveRule = new ToolStripMenuItem();
            this.miPromoteRule = new ToolStripMenuItem();
            this.miDemoteRule = new ToolStripMenuItem();
            this.miRespondCloneRule = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripSeparator();
            this.miRespondSetLatency = new ToolStripMenuItem();
            this.miRespondComment = new ToolStripMenuItem();
            this.miAREdit = new ToolStripMenuItem();
            this.miAutoResponderGenerate = new ToolStripMenuItem();
            this.miEditARFileWith = new ToolStripMenuItem();
            this.miRuleOpenURL = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.miFindRule = new ToolStripMenuItem();
            this.miExportRules = new ToolStripMenuItem();
            this.gbResponderEditor = new GroupBox();
            this.cbAutoRespondOnce = new CheckBox();
            this.lnkTestRule = new LinkLabel();
            this.cbxRuleURI = new ComboBox();
            this.lblMultipleMatch = new Label();
            this.cbxRuleAction = new ComboBox();
            this.btnSaveRule = new Button();
            this.pnlResponderActions = new Panel();
            this.btnRespondImport = new Button();
            this.btnRespondAdd = new Button();
            this.cbRespondUseLatency = new CheckBox();
            this.cbRespondPassthrough = new CheckBox();
            this.lblAutoRespondHeader = new Label();
            this.pnlAutoResponders.SuspendLayout();
            this.mnuContextAutoResponder.SuspendLayout();
            this.gbResponderEditor.SuspendLayout();
            this.pnlResponderActions.SuspendLayout();
            base.SuspendLayout();
            this.lnkAutoRespondHelp.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lnkAutoRespondHelp.AutoSize = true;
            this.lnkAutoRespondHelp.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkAutoRespondHelp.Location = new Point(0x222, 6);
            this.lnkAutoRespondHelp.Name = "lnkAutoRespondHelp";
            this.lnkAutoRespondHelp.Size = new Size(0x1c, 13);
            this.lnkAutoRespondHelp.TabIndex = 9;
            this.lnkAutoRespondHelp.TabStop = true;
            this.lnkAutoRespondHelp.Text = "Help";
            this.lnkAutoRespondHelp.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkAutoRespondHelp_LinkClicked);
            this.cbAutoRespond.Font = new Font("Tahoma", 8.25f);
            this.cbAutoRespond.Location = new Point(7, 30);
            this.cbAutoRespond.Name = "cbAutoRespond";
            this.cbAutoRespond.Size = new Size(0x60, 0x12);
            this.cbAutoRespond.TabIndex = 0;
            this.cbAutoRespond.Text = "Enable rules";
            this.cbAutoRespond.UseVisualStyleBackColor = false;
            this.cbAutoRespond.CheckedChanged += new EventHandler(this.cbAutoRespond_CheckedChanged);
            this.pnlAutoResponders.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.pnlAutoResponders.AutoScroll = true;
            this.pnlAutoResponders.Controls.Add(this.lvRespondRules);
            this.pnlAutoResponders.Controls.Add(this.gbResponderEditor);
            this.pnlAutoResponders.Controls.Add(this.pnlResponderActions);
            this.pnlAutoResponders.Location = new Point(3, 0x36);
            this.pnlAutoResponders.Name = "pnlAutoResponders";
            this.pnlAutoResponders.Size = new Size(0x240, 0x147);
            this.pnlAutoResponders.TabIndex = 7;
            this.lvRespondRules.AllowDrop = true;
            this.lvRespondRules.BackColor = SystemColors.Control;
            this.lvRespondRules.CheckBoxes = true;
            this.lvRespondRules.Columns.AddRange(new ColumnHeader[] { this.colRespondMatch, this.colRespondWith, this.colRespondLatency, this.colComments });
            this.lvRespondRules.ContextMenuStrip = this.mnuContextAutoResponder;
            this.lvRespondRules.Dock = DockStyle.Fill;
            this.lvRespondRules.EmptyText = null;
            this.lvRespondRules.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lvRespondRules.FullRowSelect = true;
            this.lvRespondRules.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            this.lvRespondRules.HideSelection = false;
            this.lvRespondRules.Location = new Point(0, 0x1b);
            this.lvRespondRules.Name = "lvRespondRules";
            this.lvRespondRules.Size = new Size(0x240, 0xdd);
            this.lvRespondRules.TabIndex = 1;
            this.lvRespondRules.UseCompatibleStateImageBehavior = false;
            this.lvRespondRules.View = View.Details;
            this.lvRespondRules.ItemCheck += new ItemCheckEventHandler(this.lvRespondRules_ItemCheck);
            this.lvRespondRules.SelectedIndexChanged += new EventHandler(this.lvRespondRules_SelectedIndexChanged);
            this.lvRespondRules.DragDrop += new DragEventHandler(this.lvRespondRules_DragDrop);
            this.lvRespondRules.DragOver += new DragEventHandler(this.lvRespondRules_DragOver);
            this.lvRespondRules.KeyDown += new KeyEventHandler(this.lvRespondRules_KeyDown);
            this.colRespondMatch.Text = "If request matches...";
            this.colRespondMatch.Width = 250;
            this.colRespondWith.Text = "then respond with...";
            this.colRespondWith.Width = 250;
            this.colRespondLatency.Text = "Latency";
            this.colRespondLatency.Width = 0;
            this.colComments.Text = "Comments";
            this.colComments.Width = 0;
            this.mnuContextAutoResponder.Items.AddRange(new ToolStripItem[] { this.miRemoveRule, this.miPromoteRule, this.miDemoteRule, this.miRespondCloneRule, this.toolStripMenuItem2, this.miRespondSetLatency, this.miRespondComment, this.miAREdit, this.miAutoResponderGenerate, this.miEditARFileWith, this.miRuleOpenURL, this.toolStripMenuItem1, this.miFindRule, this.miExportRules });
            this.mnuContextAutoResponder.Name = "mnuContextAutoResponder";
            this.mnuContextAutoResponder.ShowImageMargin = false;
            this.mnuContextAutoResponder.ShowItemToolTips = false;
            this.mnuContextAutoResponder.Size = new Size(0x97, 280);
            this.mnuContextAutoResponder.Opening += new CancelEventHandler(this.mnuContextAutoResponder_Opening);
            this.miRemoveRule.Name = "miRemoveRule";
            this.miRemoveRule.ShortcutKeyDisplayString = "Del";
            this.miRemoveRule.Size = new Size(150, 0x16);
            this.miRemoveRule.Text = "&Remove";
            this.miRemoveRule.Click += new EventHandler(this.miRemoveRule_Click);
            this.miPromoteRule.Name = "miPromoteRule";
            this.miPromoteRule.ShortcutKeyDisplayString = "+";
            this.miPromoteRule.Size = new Size(150, 0x16);
            this.miPromoteRule.Text = "&Promote";
            this.miPromoteRule.Click += new EventHandler(this.miPromoteRule_Click);
            this.miDemoteRule.Name = "miDemoteRule";
            this.miDemoteRule.ShortcutKeyDisplayString = "-";
            this.miDemoteRule.Size = new Size(150, 0x16);
            this.miDemoteRule.Text = "&Demote";
            this.miDemoteRule.Click += new EventHandler(this.miDemoteRule_Click);
            this.miRespondCloneRule.Name = "miRespondCloneRule";
            this.miRespondCloneRule.ShortcutKeyDisplayString = "D";
            this.miRespondCloneRule.Size = new Size(150, 0x16);
            this.miRespondCloneRule.Text = "&Clone";
            this.miRespondCloneRule.Click += new EventHandler(this.miRespondCloneRule_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0x93, 6);
            this.miRespondSetLatency.Name = "miRespondSetLatency";
            this.miRespondSetLatency.Size = new Size(150, 0x16);
            this.miRespondSetLatency.Text = "Set &Latency...";
            this.miRespondSetLatency.Click += new EventHandler(this.miRespondSetLatency_Click);
            this.miRespondComment.Name = "miRespondComment";
            this.miRespondComment.ShortcutKeyDisplayString = "M";
            this.miRespondComment.Size = new Size(150, 0x16);
            this.miRespondComment.Text = "Set Co&mment...";
            this.miRespondComment.Click += new EventHandler(this.miRespondComment_Click);
            this.miAREdit.Name = "miAREdit";
            this.miAREdit.ShortcutKeyDisplayString = "F2";
            this.miAREdit.ShortcutKeys = Keys.F2;
            this.miAREdit.Size = new Size(150, 0x16);
            this.miAREdit.Text = "&Edit Response...";
            this.miAREdit.Click += new EventHandler(this.miAREdit_Click);
            this.miAutoResponderGenerate.Name = "miAutoResponderGenerate";
            this.miAutoResponderGenerate.Size = new Size(150, 0x16);
            this.miAutoResponderGenerate.Text = "&Generate File";
            this.miAutoResponderGenerate.Click += new EventHandler(this.miAutoResponderGenerate_Click);
            this.miEditARFileWith.Name = "miEditARFileWith";
            this.miEditARFileWith.Size = new Size(150, 0x16);
            this.miEditARFileWith.Text = "Edit &File With...";
            this.miEditARFileWith.Click += new EventHandler(this.miEditARFileWith_Click);
            this.miRuleOpenURL.Name = "miRuleOpenURL";
            this.miRuleOpenURL.Size = new Size(150, 0x16);
            this.miRuleOpenURL.Text = "&Open URL...";
            this.miRuleOpenURL.Click += new EventHandler(this.miRuleOpenURL_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x93, 6);
            this.miFindRule.Name = "miFindRule";
            this.miFindRule.Size = new Size(150, 0x16);
            this.miFindRule.Text = "F&ind...";
            this.miFindRule.Click += new EventHandler(this.miFindRule_Click);
            this.miExportRules.Name = "miExportRules";
            this.miExportRules.Size = new Size(150, 0x16);
            this.miExportRules.Text = "E&xport All...";
            this.miExportRules.Click += new EventHandler(this.miExportRules_Click);
            this.gbResponderEditor.BackColor = SystemColors.Control;
            this.gbResponderEditor.Controls.Add(this.cbAutoRespondOnce);
            this.gbResponderEditor.Controls.Add(this.lnkTestRule);
            this.gbResponderEditor.Controls.Add(this.cbxRuleURI);
            this.gbResponderEditor.Controls.Add(this.lblMultipleMatch);
            this.gbResponderEditor.Controls.Add(this.cbxRuleAction);
            this.gbResponderEditor.Controls.Add(this.btnSaveRule);
            this.gbResponderEditor.Dock = DockStyle.Bottom;
            this.gbResponderEditor.Enabled = false;
            this.gbResponderEditor.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.gbResponderEditor.Location = new Point(0, 0xf8);
            this.gbResponderEditor.Name = "gbResponderEditor";
            this.gbResponderEditor.Size = new Size(0x240, 0x4f);
            this.gbResponderEditor.TabIndex = 2;
            this.gbResponderEditor.TabStop = false;
            this.gbResponderEditor.Text = "Rule Editor";
            this.cbAutoRespondOnce.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.cbAutoRespondOnce.AutoSize = true;
            this.cbAutoRespondOnce.Location = new Point(0x1d2, 0x2d);
            this.cbAutoRespondOnce.Name = "cbAutoRespondOnce";
            this.cbAutoRespondOnce.Size = new Size(0x68, 0x11);
            this.cbAutoRespondOnce.TabIndex = 5;
            this.cbAutoRespondOnce.Text = "Match only once";
            this.cbAutoRespondOnce.UseVisualStyleBackColor = true;
            this.lnkTestRule.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lnkTestRule.AutoSize = true;
            this.lnkTestRule.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkTestRule.Location = new Point(0x1d3, 20);
            this.lnkTestRule.Name = "lnkTestRule";
            this.lnkTestRule.Size = new Size(40, 13);
            this.lnkTestRule.TabIndex = 4;
            this.lnkTestRule.TabStop = true;
            this.lnkTestRule.Text = "Test...";
            this.lnkTestRule.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkTestRule_LinkClicked);
            this.cbxRuleURI.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.cbxRuleURI.FormattingEnabled = true;
            this.cbxRuleURI.Items.AddRange(new object[] { @"regex:(?inx).+\.jpg$ #Match strings ending with JPG", @"regex:(?inx).+\.(gif|png|jpg)$ #Match strings ending with img types", @"regex:(?inx)^https://.+\.gif$ #Match HTTPS-delivered GIFs", "URLWithBody:Upload.php regex:^.*BodyText.*$", "method:OPTIONS XHRCors.php", "flag:x-ProcessInfo=iexplore", "Header:Accept=html", "65%PartialUrl" });
            this.cbxRuleURI.Location = new Point(8, 0x10);
            this.cbxRuleURI.Name = "cbxRuleURI";
            this.cbxRuleURI.Size = new Size(0x1c5, 0x15);
            this.cbxRuleURI.TabIndex = 0;
            this.cbxRuleURI.KeyDown += new KeyEventHandler(this.cbxRuleURI_KeyDown);
            this.lblMultipleMatch.AutoSize = true;
            this.lblMultipleMatch.Font = new Font("Tahoma", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.lblMultipleMatch.Location = new Point(10, 20);
            this.lblMultipleMatch.Name = "lblMultipleMatch";
            this.lblMultipleMatch.Size = new Size(0xdf, 13);
            this.lblMultipleMatch.TabIndex = 3;
            this.lblMultipleMatch.Text = "Update all selected matches to respond with:";
            this.lblMultipleMatch.Visible = false;
            this.cbxRuleAction.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.cbxRuleAction.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            this.cbxRuleAction.AutoCompleteSource = AutoCompleteSource.FileSystem;
            this.cbxRuleAction.Font = new Font("Tahoma", 8.25f);
            this.cbxRuleAction.ItemHeight = 13;
            this.cbxRuleAction.Location = new Point(8, 0x2b);
            this.cbxRuleAction.MaxDropDownItems = 20;
            this.cbxRuleAction.Name = "cbxRuleAction";
            this.cbxRuleAction.Size = new Size(0x1c5, 0x15);
            this.cbxRuleAction.TabIndex = 1;
            this.cbxRuleAction.SelectionChangeCommitted += new EventHandler(this.cbxRuleAction_SelectionChangeCommitted);
            this.cbxRuleAction.KeyDown += new KeyEventHandler(this.cbxRuleAction_KeyDown);
            this.btnSaveRule.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.btnSaveRule.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnSaveRule.Location = new Point(0x200, 0x10);
            this.btnSaveRule.Name = "btnSaveRule";
            this.btnSaveRule.Size = new Size(0x3a, 0x15);
            this.btnSaveRule.TabIndex = 2;
            this.btnSaveRule.Text = "Save";
            this.btnSaveRule.Click += new EventHandler(this.btnSaveRule_Click);
            this.pnlResponderActions.Controls.Add(this.btnRespondImport);
            this.pnlResponderActions.Controls.Add(this.btnRespondAdd);
            this.pnlResponderActions.Dock = DockStyle.Top;
            this.pnlResponderActions.Location = new Point(0, 0);
            this.pnlResponderActions.Name = "pnlResponderActions";
            this.pnlResponderActions.Size = new Size(0x240, 0x1b);
            this.pnlResponderActions.TabIndex = 0;
            this.btnRespondImport.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnRespondImport.Location = new Point(0x51, 2);
            this.btnRespondImport.Name = "btnRespondImport";
            this.btnRespondImport.Size = new Size(0x44, 0x16);
            this.btnRespondImport.TabIndex = 1;
            this.btnRespondImport.Text = "Import...";
            this.btnRespondImport.Click += new EventHandler(this.btnRespondImport_Click);
            this.btnRespondAdd.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnRespondAdd.Location = new Point(0, 2);
            this.btnRespondAdd.Name = "btnRespondAdd";
            this.btnRespondAdd.Size = new Size(0x4b, 0x16);
            this.btnRespondAdd.TabIndex = 0;
            this.btnRespondAdd.Text = "Add Rule";
            this.btnRespondAdd.Click += new EventHandler(this.btnRespondAdd_Click);
            this.cbRespondUseLatency.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.cbRespondUseLatency.Location = new Point(310, 30);
            this.cbRespondUseLatency.Name = "cbRespondUseLatency";
            this.cbRespondUseLatency.Size = new Size(0x6a, 0x12);
            this.cbRespondUseLatency.TabIndex = 2;
            this.cbRespondUseLatency.Text = "Enable Latency";
            this.cbRespondUseLatency.CheckedChanged += new EventHandler(this.cbRespondUseLatency_CheckedChanged);
            this.cbRespondPassthrough.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.cbRespondPassthrough.Location = new Point(0x6d, 30);
            this.cbRespondPassthrough.Name = "cbRespondPassthrough";
            this.cbRespondPassthrough.Size = new Size(0xc3, 0x12);
            this.cbRespondPassthrough.TabIndex = 1;
            this.cbRespondPassthrough.Text = "Unmatched requests passthrough";
            this.cbRespondPassthrough.CheckedChanged += new EventHandler(this.cbRespondPassthrough_CheckedChanged);
            this.lblAutoRespondHeader.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.lblAutoRespondHeader.BackColor = Color.Gray;
            this.lblAutoRespondHeader.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lblAutoRespondHeader.ForeColor = Color.White;
            this.lblAutoRespondHeader.Location = new Point(3, 0);
            this.lblAutoRespondHeader.Name = "lblAutoRespondHeader";
            this.lblAutoRespondHeader.Padding = new Padding(4);
            this.lblAutoRespondHeader.Size = new Size(0x219, 0x18);
            this.lblAutoRespondHeader.TabIndex = 5;
            this.lblAutoRespondHeader.Text = "Fiddler can return previously generated responses instead of using the network.";
            this.lblAutoRespondHeader.TextAlign = ContentAlignment.MiddleLeft;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.Controls.Add(this.cbRespondPassthrough);
            base.Controls.Add(this.cbRespondUseLatency);
            base.Controls.Add(this.cbAutoRespond);
            base.Controls.Add(this.lnkAutoRespondHelp);
            base.Controls.Add(this.pnlAutoResponders);
            base.Controls.Add(this.lblAutoRespondHeader);
            this.Font = new Font("Tahoma", 8.25f);
            base.Name = "UIAutoResponder";
            base.Size = new Size(0x246, 0x180);
            this.pnlAutoResponders.ResumeLayout(false);
            this.mnuContextAutoResponder.ResumeLayout(false);
            this.gbResponderEditor.ResumeLayout(false);
            this.gbResponderEditor.PerformLayout();
            this.pnlResponderActions.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lnkAutoRespondHelp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("AutoResponder"));
        }

        private void lnkTestRule_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.cbxRuleURI.Text.OICStartsWithAny(new string[] { "header:", "method:", "flag:" }))
            {
                MessageBox.Show("Sorry, the TEST command can only be used with Rules that evaluate the URL.", "Untestable Expression");
            }
            else
            {
                UIARRuleTester tester = new UIARRuleTester(this.cbxRuleURI.Items, this.cbxRuleURI.Text);
                if (DialogResult.OK == tester.ShowDialog(FiddlerApplication.UI))
                {
                    this.cbxRuleURI.Text = tester.cbxPattern.Text;
                    this.btnSaveRule_Click(null, null);
                }
            }
        }

        private void lvRespondRules_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                this.lvRespondRules.BeginUpdate();
                string[] data = (string[]) e.Data.GetData("FileDrop", false);
                foreach (string str in data)
                {
                    if (Directory.Exists(str))
                    {
                        FiddlerApplication._AutoResponder.CreateRulesForFolder(str);
                    }
                    if (str.OICEndsWith(".saz"))
                    {
                        FiddlerApplication._AutoResponder.ImportSAZ(str);
                    }
                    else
                    {
                        FiddlerApplication._AutoResponder.CreateRuleForFile(str, null);
                    }
                }
                this.lvRespondRules.EndUpdate();
                this._SelectMostRecentLVRespondRule();
            }
            else
            {
                Session[] oSessions = (Session[]) e.Data.GetData("Fiddler.Session[]");
                if ((oSessions != null) && (oSessions.Length >= 1))
                {
                    FiddlerApplication._AutoResponder.ImportSessions(oSessions);
                    this._SelectMostRecentLVRespondRule();
                }
            }
        }

        private void lvRespondRules_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("Fiddler.Session[]") || e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void lvRespondRules_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            ListViewItem item = this.lvRespondRules.Items[e.Index];
            ResponderRule tag = (ResponderRule) item.Tag;
            if (tag != null)
            {
                bool flag = e.CurrentValue == CheckState.Checked;
                bool isEnabled = tag.IsEnabled;
                bool flag3 = e.NewValue == CheckState.Checked;
                if ((flag == isEnabled) && (flag3 != isEnabled))
                {
                    tag.IsEnabled = e.NewValue == CheckState.Checked;
                    FiddlerApplication._AutoResponder.IsRuleListDirty = true;
                }
            }
            item.ForeColor = (e.NewValue == CheckState.Checked) ? SystemColors.WindowText : SystemColors.ControlDark;
        }

        private void lvRespondRules_KeyDown(object sender, KeyEventArgs e)
        {
            Keys keyCode = e.KeyCode;
            if (keyCode <= Keys.D)
            {
                if (keyCode != Keys.Return)
                {
                    switch (keyCode)
                    {
                        case Keys.A:
                            if (e.Modifiers == Keys.Control)
                            {
                                this.lvRespondRules.BeginUpdate();
                                foreach (ListViewItem item in this.lvRespondRules.Items)
                                {
                                    item.Selected = true;
                                }
                                this.lvRespondRules.EndUpdate();
                            }
                            return;

                        case Keys.B:
                            return;

                        case Keys.C:
                            if ((e.Modifiers == Keys.Control) && (this.lvRespondRules.SelectedItems.Count >= 1))
                            {
                                StringBuilder builder = new StringBuilder();
                                foreach (ListViewItem item2 in this.lvRespondRules.SelectedItems)
                                {
                                    builder.AppendFormat("{0}\t{1}\r\n", item2.Text, item2.SubItems[1].Text);
                                }
                                Utilities.CopyToClipboard(builder.ToString());
                                e.SuppressKeyPress = true;
                                return;
                            }
                            return;

                        case Keys.D:
                            this.actCloneRule();
                            e.SuppressKeyPress = true;
                            return;

                        case Keys.Delete:
                            this.actRemoveSelectedRules();
                            e.SuppressKeyPress = true;
                            return;
                    }
                }
                else if (this.lvRespondRules.SelectedItems.Count == 1)
                {
                    ListViewItem item3 = this.lvRespondRules.SelectedItems[0];
                    actLaunchEditor(item3.Tag as ResponderRule);
                }
            }
            else if (keyCode <= Keys.U)
            {
                if (keyCode != Keys.M)
                {
                    if (((keyCode == Keys.U) && (e.Modifiers == Keys.Control)) && (this.lvRespondRules.SelectedItems.Count == 1))
                    {
                        Utilities.CopyToClipboard(this.GetSelectedHyperlink());
                    }
                }
                else
                {
                    this.actSetRuleComment();
                    e.SuppressKeyPress = true;
                }
            }
            else
            {
                switch (keyCode)
                {
                    case Keys.Add:
                    case Keys.Oemplus:
                        this.actPromoteRule();
                        e.SuppressKeyPress = true;
                        return;

                    case Keys.Separator:
                    case Keys.Oemcomma:
                        return;

                    case Keys.Subtract:
                    case Keys.OemMinus:
                        this.actDemoteRule();
                        e.SuppressKeyPress = true;
                        return;

                    default:
                        return;
                }
            }
        }

        private void lvRespondRules_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lvRespondRules.SelectedItems.Count == 0)
            {
                this.gbResponderEditor.Enabled = false;
            }
            else if (this.lvRespondRules.SelectedItems.Count > 1)
            {
                this.cbxRuleURI.Visible = this.lnkTestRule.Visible = false;
                this.cbAutoRespondOnce.CheckState = CheckState.Indeterminate;
                this.lblMultipleMatch.Visible = true;
                this.lblMultipleMatch.Text = "Update " + this.lvRespondRules.SelectedItems.Count + " selected matches to respond with:";
            }
            else
            {
                ListViewItem item = this.lvRespondRules.SelectedItems[0];
                ResponderRule tag = (ResponderRule) item.Tag;
                this.cbxRuleURI.Visible = this.lnkTestRule.Visible = true;
                this.lblMultipleMatch.Visible = false;
                this.cbxRuleURI.Text = tag.sMatch;
                this.cbxRuleAction.Text = tag.sAction;
                this.cbAutoRespondOnce.CheckState = tag.bDisableOnMatch ? CheckState.Checked : CheckState.Unchecked;
                this.gbResponderEditor.Enabled = true;
            }
        }

        private void miAREdit_Click(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvRespondRules.SelectedItems;
            if (selectedItems.Count == 1)
            {
                ResponderRule tag = (ResponderRule) selectedItems[0].Tag;
                if (tag.HasImportedResponse)
                {
                    actLaunchEditor(tag);
                }
                else
                {
                    string firstLocalResponse = Utilities.GetFirstLocalResponse(tag.sAction);
                    if (!File.Exists(firstLocalResponse))
                    {
                        MessageBox.Show("No local file exists for this rule.", "Error");
                    }
                    else
                    {
                        ProcessStartInfo startInfo = new ProcessStartInfo();
                        startInfo.UseShellExecute = true;
                        startInfo.FileName = firstLocalResponse;
                        startInfo.ErrorDialog = true;
                        startInfo.Verb = "Edit";
                        try
                        {
                            using (Process.Start(startInfo))
                            {
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        private void miAutoResponderGenerate_Click(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvRespondRules.SelectedItems;
            if (selectedItems.Count >= 1)
            {
                this.lvRespondRules.BeginUpdate();
                foreach (ListViewItem item in selectedItems)
                {
                    ResponderRule tag = (ResponderRule) item.Tag;
                    if (tag != null)
                    {
                        tag.EnsureRuleIsFileBacked();
                    }
                }
                this.lvRespondRules.SelectedItems.Clear();
                this.lvRespondRules.EndUpdate();
            }
        }

        private void miDemoteRule_Click(object sender, EventArgs e)
        {
            this.actDemoteRule();
        }

        private void miEditARFileWith_Click(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvRespondRules.SelectedItems;
            if (selectedItems.Count == 1)
            {
                ResponderRule tag = (ResponderRule) selectedItems[0].Tag;
                if (tag != null)
                {
                    tag.EnsureRuleIsFileBacked();
                }
                if (!File.Exists(Utilities.GetFirstLocalResponse(tag.sAction)))
                {
                    MessageBox.Show("No local file exists for this rule", "Error");
                }
                else
                {
                    Utilities.DoOpenFileWith(tag.sAction);
                }
            }
        }

        private void miExportRules_Click(object sender, EventArgs e)
        {
            string str = Utilities.ObtainSaveFilename("Export rules...", "AutoResponder Ruleset|*.farx");
            if (!string.IsNullOrEmpty(str))
            {
                if (!str.OICEndsWith(".farx"))
                {
                    str = str + ".farx";
                }
                if (FiddlerApplication._AutoResponder.ExportFARX(str))
                {
                    FiddlerApplication.UI.sbpInfo.Text = "Exported AutoResponder Rules to: " + str;
                }
                else
                {
                    FiddlerApplication.UI.sbpInfo.Text = "Failed to export AutoResponder Rules.";
                }
            }
        }

        private void miFindRule_Click(object sender, EventArgs e)
        {
            string toMatch = frmPrompt.GetUserString("Find Rule", "Enter the string to find...", string.Empty, true);
            if (toMatch != null)
            {
                this.lvRespondRules.BeginUpdate();
                int num = 0;
                foreach (ListViewItem item in this.lvRespondRules.Items)
                {
                    if (item.Text.OICContains(toMatch) || item.SubItems[1].Text.OICContains(toMatch))
                    {
                        num++;
                        if (num == 1)
                        {
                            item.EnsureVisible();
                        }
                        item.BackColor = Color.Yellow;
                        continue;
                    }
                    item.BackColor = this.lvRespondRules.BackColor;
                }
                this.lvRespondRules.EndUpdate();
                FiddlerApplication.UI.SetStatusText(string.Format("Found {0} matching rules.", num));
            }
        }

        private void miPromoteRule_Click(object sender, EventArgs e)
        {
            this.actPromoteRule();
        }

        private void miRemoveRule_Click(object sender, EventArgs e)
        {
            this.actRemoveSelectedRules();
        }

        private void miRespondCloneRule_Click(object sender, EventArgs e)
        {
            this.actCloneRule();
        }

        private void miRespondComment_Click(object sender, EventArgs e)
        {
            this.actSetRuleComment();
        }

        private void miRespondSetLatency_Click(object sender, EventArgs e)
        {
            this.actSetRuleLatency();
        }

        private void miRuleOpenURL_Click(object sender, EventArgs e)
        {
            string selectedHyperlink = this.GetSelectedHyperlink();
            if (!string.IsNullOrEmpty(selectedHyperlink))
            {
                Utilities.LaunchHyperlink(selectedHyperlink);
            }
        }

        private void mnuContextAutoResponder_Opening(object sender, CancelEventArgs e)
        {
            this.miAutoResponderGenerate.Enabled = this.miRemoveRule.Enabled = this.miRespondSetLatency.Enabled = this.miRespondComment.Enabled = this.lvRespondRules.SelectedItems.Count > 0;
            this.miAREdit.Enabled = this.miEditARFileWith.Enabled = this.miRespondCloneRule.Enabled = this.miDemoteRule.Enabled = this.miPromoteRule.Enabled = this.lvRespondRules.SelectedItems.Count == 1;
            if (this.lvRespondRules.SelectedItems.Count == 1)
            {
                this.miRuleOpenURL.Enabled = !(this.lvRespondRules.SelectedItems[0].Tag as ResponderRule).sMatch.OICStartsWith("REGEX:");
            }
            else
            {
                this.miRuleOpenURL.Enabled = false;
            }
            this.miExportRules.Enabled = this.lvRespondRules.Items.Count > 0;
        }

        internal void SetFontSize(float flFontSize)
        {
            try
            {
                float emSize = flFontSize;
                if (emSize > 14f)
                {
                    emSize = 14f;
                }
                this.lvRespondRules.Font = new Font(this.lvRespondRules.Font.FontFamily, emSize);
                if (emSize > 12f)
                {
                    emSize = 12f;
                }
                this.cbxRuleURI.Font = new Font(this.cbxRuleURI.Font.FontFamily, emSize);
                this.cbxRuleAction.Font = new Font(this.cbxRuleAction.Font.FontFamily, emSize);
            }
            catch
            {
            }
        }
    }
}

