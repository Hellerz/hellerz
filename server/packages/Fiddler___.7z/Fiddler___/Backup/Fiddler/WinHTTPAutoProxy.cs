﻿namespace Fiddler
{
    using System;
    using System.IO;
    using System.Net;
    using System.Runtime.InteropServices;

    internal class WinHTTPAutoProxy : IDisposable
    {
        private readonly bool _bUseAutoDiscovery = true;
        private readonly IntPtr _hSession;
        private WinHTTPNative.WINHTTP_AUTOPROXY_OPTIONS _oAPO;
        private readonly string _sPACScriptLocation;
        private bool bIsDisposed;
        internal int iAutoProxySuccessCount;

        public WinHTTPAutoProxy(bool bAutoDiscover, string sAutoConfigUrl)
        {
            this._bUseAutoDiscovery = bAutoDiscover;
            if (!string.IsNullOrEmpty(sAutoConfigUrl))
            {
                if ((sAutoConfigUrl.OICStartsWith("file:") || sAutoConfigUrl.StartsWith(@"\\")) || ((sAutoConfigUrl.Length > 2) && (sAutoConfigUrl[1] == ':')))
                {
                    Proxy.sUpstreamPACScript = GetPACFileText(sAutoConfigUrl);
                    if (!string.IsNullOrEmpty(Proxy.sUpstreamPACScript))
                    {
                        FiddlerApplication.Log.LogFormat("!WARNING: System proxy was configured to use a file-protocol sourced script ({0}). Proxy scripts delivered by the file protocol are not supported by many clients. Please see http://blogs.msdn.com/b/ieinternals/archive/2013/10/11/web-proxy-configuration-and-ie11-changes.aspx for more information.", new object[] { sAutoConfigUrl });
                        sAutoConfigUrl = "http://" + CONFIG.sFiddlerListenHostPort + "/UpstreamProxy.pac";
                    }
                }
                this._sPACScriptLocation = sAutoConfigUrl;
            }
            this._oAPO = GetAutoProxyOptionsStruct(this._sPACScriptLocation, this._bUseAutoDiscovery);
            this._hSession = WinHTTPNative.WinHttpOpen("Fiddler", 1, IntPtr.Zero, IntPtr.Zero, 0);
        }

        public void Dispose()
        {
            this.bIsDisposed = true;
            WinHTTPNative.WinHttpCloseHandle(this._hSession);
        }

        public bool GetAutoProxyForUrl(string sUrl, out IPEndPoint ipepResult)
        {
            WinHTTPNative.WINHTTP_PROXY_INFO winhttp_proxy_info;
            if (this.bIsDisposed)
            {
                ipepResult = null;
                return false;
            }
            int num = 0;
            bool flag = WinHTTPNative.WinHttpGetProxyForUrl(this._hSession, sUrl, ref this._oAPO, out winhttp_proxy_info);
            if (!flag)
            {
                num = Marshal.GetLastWin32Error();
            }
            if (flag)
            {
                if (IntPtr.Zero != winhttp_proxy_info.lpszProxy)
                {
                    string sHostAndPort = Marshal.PtrToStringUni(winhttp_proxy_info.lpszProxy);
                    ipepResult = Utilities.IPEndPointFromHostPortString(sHostAndPort);
                    if (ipepResult == null)
                    {
                        FiddlerApplication.Log.LogFormat("Proxy Configuration Script specified an unreachable proxy: {0} for URL: {1}", new object[] { sHostAndPort, sUrl });
                    }
                }
                else
                {
                    ipepResult = null;
                }
                Utilities.GlobalFreeIfNonZero(winhttp_proxy_info.lpszProxy);
                Utilities.GlobalFreeIfNonZero(winhttp_proxy_info.lpszProxyBypass);
                return true;
            }
            int num2 = num;
            if (num2 <= 0x2eef)
            {
                switch (num2)
                {
                    case 0x2ee6:
                        FiddlerApplication._Log.LogFormat("Fiddler.Network.ProxyPAC> PAC Script download failure; Fiddler only supports HTTP/HTTPS for PAC script URLs; WPAD returned '{0}'.", new object[] { GetWPADUrl().Replace("\n", @"\n") });
                        goto Label_0173;

                    case 0x2eef:
                        FiddlerApplication._Log.LogString("Fiddler.Network.ProxyPAC> PAC Script download failure; you must set the AutoProxyLogon registry key to TRUE.");
                        goto Label_0173;
                }
            }
            else
            {
                switch (num2)
                {
                    case 0x2f86:
                        FiddlerApplication._Log.LogString("Fiddler.Network.ProxyPAC> PAC Script contents were not valid.");
                        goto Label_0173;

                    case 0x2f87:
                        FiddlerApplication._Log.LogString("Fiddler.Network.ProxyPAC> PAC Script download failed.");
                        goto Label_0173;

                    default:
                        if (num2 != 0x2f94)
                        {
                            goto Label_0159;
                        }
                        FiddlerApplication._Log.LogString("Fiddler.Network.AutoProxy> AutoProxy Detection failed.");
                        goto Label_0173;
                }
            }
        Label_0159:
            FiddlerApplication._Log.LogString("Fiddler.Network.ProxyPAC> Proxy determination failed with error code: " + num);
        Label_0173:
            Utilities.GlobalFreeIfNonZero(winhttp_proxy_info.lpszProxy);
            Utilities.GlobalFreeIfNonZero(winhttp_proxy_info.lpszProxyBypass);
            ipepResult = null;
            return false;
        }

        private static WinHTTPNative.WINHTTP_AUTOPROXY_OPTIONS GetAutoProxyOptionsStruct(string sPAC, bool bUseAutoDetect)
        {
            WinHTTPNative.WINHTTP_AUTOPROXY_OPTIONS winhttp_autoproxy_options = new WinHTTPNative.WINHTTP_AUTOPROXY_OPTIONS();
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.network.gateway.DetermineInProcess", false))
            {
                winhttp_autoproxy_options.dwFlags = 0x10000;
            }
            else
            {
                winhttp_autoproxy_options.dwFlags = 0;
            }
            if (bUseAutoDetect)
            {
                winhttp_autoproxy_options.dwFlags |= 1;
                winhttp_autoproxy_options.dwAutoDetectFlags = 3;
            }
            if (sPAC != null)
            {
                winhttp_autoproxy_options.dwFlags |= 2;
                winhttp_autoproxy_options.lpszAutoConfigUrl = sPAC;
            }
            winhttp_autoproxy_options.fAutoLoginIfChallenged = CONFIG.bAutoProxyLogon;
            return winhttp_autoproxy_options;
        }

        private static string GetPACFileText(string sURI)
        {
            try
            {
                Uri uri = new Uri(sURI);
                if (!uri.IsFile)
                {
                    return null;
                }
                string localPath = uri.LocalPath;
                if (!System.IO.File.Exists(localPath))
                {
                    FiddlerApplication.Log.LogFormat("! Failed to find the configured PAC script '{0}'", new object[] { localPath });
                    return null;
                }
                return System.IO.File.ReadAllText(localPath);
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("! Failed to host the configured PAC script {0}", new object[] { exception });
                return null;
            }
        }

        private static string GetWPADUrl()
        {
            IntPtr ptr;
            string str;
            bool flag = WinHTTPNative.WinHttpDetectAutoProxyConfigUrl(3, out ptr);
            if (!flag)
            {
                Marshal.GetLastWin32Error();
            }
            if (flag && (IntPtr.Zero != ptr))
            {
                str = Marshal.PtrToStringUni(ptr);
            }
            else
            {
                str = string.Empty;
            }
            Utilities.GlobalFreeIfNonZero(ptr);
            return str;
        }

        public override string ToString()
        {
            string str = null;
            if (this.iAutoProxySuccessCount < 0)
            {
                str = "\tOffline/disabled\n";
            }
            else
            {
                if (this._bUseAutoDiscovery)
                {
                    string wPADUrl = GetWPADUrl();
                    if (string.IsNullOrEmpty(wPADUrl))
                    {
                        wPADUrl = "Not detected";
                    }
                    str = string.Format("\tWPAD: {0}\n", wPADUrl);
                }
                if (this._sPACScriptLocation != null)
                {
                    str = str + "\tConfig script: " + this._sPACScriptLocation + "\n";
                }
            }
            return (str ?? "\tDisabled");
        }
    }
}

