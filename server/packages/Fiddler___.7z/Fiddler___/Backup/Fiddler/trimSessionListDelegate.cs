﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    internal delegate void trimSessionListDelegate(int iTrimTo);
}

