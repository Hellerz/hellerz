﻿namespace Fiddler
{
    using System;
    using System.Windows.Forms;

    internal class LinkLabelEx : LinkLabel
    {
        protected override bool ProcessMnemonic(char charCode)
        {
            if (!base.ProcessMnemonic(charCode))
            {
                return false;
            }
            if (base.Links.Count == 0)
            {
                return false;
            }
            this.OnLinkClicked(new LinkLabelLinkClickedEventArgs(base.Links[0]));
            return true;
        }
    }
}

