﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Reflection;
    using System.Text;
    using System.Windows.Forms;

    public class frmPrompt : Form
    {
        private Button btnCancel;
        private Button btnOk;
        private Container components;
        private Label lblAnalysis;
        private PictureBox pbImage;
        internal TextBox txtInput;
        internal RichTextBox txtMessage;

        private frmPrompt()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void EnableAnalysis()
        {
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.MaskPasswords", false))
            {
                this.txtInput.UseSystemPasswordChar = true;
            }
            this.ReanalyzeText();
            this.lblAnalysis.Visible = true;
            this.txtInput.TextChanged += delegate (object o, EventArgs e) {
                this.ReanalyzeText();
            };
        }

        private string GetFletcher(byte[] arrBytes)
        {
            if ((arrBytes.Length < 1) || ((arrBytes.Length < 2) && this.txtInput.UseSystemPasswordChar))
            {
                return "----";
            }
            short num = 0;
            short num2 = 0;
            for (int i = 0; i < arrBytes.Length; i++)
            {
                num = (short) ((num + arrBytes[i]) % 0xff);
                num2 = (short) ((num2 + num) % 0xff);
            }
            int num4 = (num2 << 8) + num;
            return num4.ToString("x4");
        }

        [CodeDescription("Get a string value from the user.")]
        public static string GetUserString(string sTitle, string sPrompt, string sDefault)
        {
            return GetUserString(sTitle, sPrompt, sDefault, false, PromptIcon.Default);
        }

        [CodeDescription("Get a string value from the user.")]
        public static string GetUserString(string sTitle, string sPrompt, string sDefault, bool bReturnNullIfCancelled)
        {
            return GetUserString(FiddlerApplication._frmMain, sTitle, sPrompt, sDefault, bReturnNullIfCancelled, PromptIcon.Default);
        }

        public static string GetUserString(string sTitle, string sPrompt, string sDefault, bool bReturnNullIfCancelled, PromptIcon piIcon)
        {
            return GetUserString(FiddlerApplication._frmMain, sTitle, sPrompt, sDefault, bReturnNullIfCancelled, piIcon);
        }

        public static string GetUserString(IWin32Window wndOwner, string sTitle, string sPrompt, string sDefault, bool bReturnNullIfCancelled, PromptIcon piIcon)
        {
            DialogResult result;
            frmPrompt prompt = new frmPrompt();
            prompt.StartPosition = FormStartPosition.CenterScreen;
            prompt.Text = sTitle;
            prompt.txtMessage.Text = sPrompt;
            prompt.txtInput.Text = sDefault;
            try
            {
                switch (piIcon)
                {
                    case PromptIcon.Password:
                        prompt.pbImage.Image = Image.FromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Fiddler.Common.Application.password.png"));
                        prompt.EnableAnalysis();
                        goto Label_0092;

                    case PromptIcon.Numbers:
                        prompt.pbImage.Image = Image.FromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Fiddler.Common.Application.numbers.png"));
                        goto Label_0092;
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        Label_0092:
            result = prompt.ShowDialog(wndOwner);
            if (DialogResult.OK == result)
            {
                sDefault = prompt.txtInput.Text;
            }
            prompt.Dispose();
            if (bReturnNullIfCancelled && (DialogResult.OK != result))
            {
                return null;
            }
            return sDefault;
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmPrompt));
            this.btnCancel = new Button();
            this.txtMessage = new RichTextBox();
            this.btnOk = new Button();
            this.pbImage = new PictureBox();
            this.txtInput = new TextBox();
            this.lblAnalysis = new Label();
            ((ISupportInitialize) this.pbImage).BeginInit();
            base.SuspendLayout();
            this.btnCancel.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnCancel.DialogResult = DialogResult.No;
            this.btnCancel.Location = new Point(0x12d, 0x6f);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(0x4b, 0x17);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.txtMessage.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtMessage.BackColor = SystemColors.Control;
            this.txtMessage.BorderStyle = BorderStyle.None;
            this.txtMessage.Location = new Point(0x30, 11);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ReadOnly = true;
            this.txtMessage.Size = new Size(0x150, 0x41);
            this.txtMessage.TabIndex = 3;
            this.txtMessage.Text = "Codito Ergo Sum Codito Ergo Sum Codito Ergo Sum ";
            this.btnOk.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnOk.DialogResult = DialogResult.OK;
            this.btnOk.Location = new Point(220, 0x6f);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new Size(0x4b, 0x17);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "OK";
            this.pbImage.Image = (Image) manager.GetObject("pbImage.Image");
            this.pbImage.Location = new Point(8, 10);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new Size(0x20, 0x20);
            this.pbImage.SizeMode = PictureBoxSizeMode.CenterImage;
            this.pbImage.TabIndex = 7;
            this.pbImage.TabStop = false;
            this.pbImage.DoubleClick += new EventHandler(this.pbImage_DoubleClick);
            this.txtInput.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
            this.txtInput.Location = new Point(0x30, 0x4f);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new Size(0x148, 0x15);
            this.txtInput.TabIndex = 0;
            this.txtInput.KeyDown += new KeyEventHandler(this.txtInput_KeyDown);
            this.lblAnalysis.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.lblAnalysis.AutoSize = true;
            this.lblAnalysis.Location = new Point(13, 0x72);
            this.lblAnalysis.Name = "lblAnalysis";
            this.lblAnalysis.Size = new Size(0x38, 13);
            this.lblAnalysis.TabIndex = 8;
            this.lblAnalysis.Text = "lblAnalysis";
            this.lblAnalysis.Visible = false;
            base.AcceptButton = this.btnOk;
            this.AutoScaleBaseSize = new Size(5, 14);
            base.CancelButton = this.btnCancel;
            base.ClientSize = new Size(0x188, 0x8f);
            base.Controls.Add(this.lblAnalysis);
            base.Controls.Add(this.txtInput);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.txtMessage);
            base.Controls.Add(this.btnOk);
            base.Controls.Add(this.pbImage);
            this.Font = new Font("Tahoma", 8.25f);
            base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.KeyPreview = true;
            base.MinimizeBox = false;
            this.MinimumSize = new Size(200, 110);
            base.Name = "frmPrompt";
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.Manual;
            this.Text = " Fiddler Prompt";
            ((ISupportInitialize) this.pbImage).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void pbImage_DoubleClick(object sender, EventArgs e)
        {
            this.txtInput.UseSystemPasswordChar = !this.txtInput.UseSystemPasswordChar;
        }

        private void ReanalyzeText()
        {
            string fletcher = this.GetFletcher(Encoding.UTF8.GetBytes(this.txtInput.Text));
            this.lblAnalysis.Text = string.Format("Length: {0} Check: {1}", this.txtInput.TextLength, fletcher);
        }

        private void txtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.V))
            {
                this.txtInput.SelectedText = Utilities.GetClipboardAsString();
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        public enum PromptIcon
        {
            Default,
            Password,
            Numbers
        }
    }
}

