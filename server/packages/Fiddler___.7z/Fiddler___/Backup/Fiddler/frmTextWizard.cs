﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;

    internal class frmTextWizard : Form
    {
        private byte[] arrLastOutput;
        private Button btnSendOutput;
        private CheckBox cbShowHex;
        private ComboBox cbxInputEncoding;
        private ComboBox cbxOutputEncoding;
        private ComboBox cbxTransform;
        private IContainer components;
        private GroupBox gbEncoding;
        private Label label2;
        private Label lblConversion;
        private Label lblInputEncoding;
        private Label lblInstructions;
        private Label lblSaveOutput;
        private LinkLabel lnkEncoding;
        private LinkLabel lnkSaveOutputAsFile;
        private LinkLabel lnkSaveOutputAsSession;
        private Encoding oInputEncoding;
        private Encoding oOutputEncoding;
        private Panel pnlBottom;
        private Panel pnlBotTop;
        private Splitter splitter1;
        private ToolTip toolTip1;
        private TextBox txtInputString;
        private TextBox txtOutputString;

        internal frmTextWizard(string sInitialText)
        {
            this.InitializeComponent();
            this.txtOutputString.BackColor = CONFIG.colorDisabledEdit;
            this.txtInputString.Font = new Font(this.txtInputString.Font.FontFamily, CONFIG.flFontSize);
            this.txtOutputString.Font = new Font(this.txtOutputString.Font.FontFamily, CONFIG.flFontSize);
            try
            {
                this.oInputEncoding = Encoding.GetEncoding(FiddlerApplication.Prefs.GetStringPref("fiddler.textwizard.InputEncoding", "UTF-8"));
            }
            catch
            {
                this.oInputEncoding = Encoding.UTF8;
            }
            try
            {
                this.oOutputEncoding = Encoding.GetEncoding(FiddlerApplication.Prefs.GetStringPref("fiddler.textwizard.OutputEncoding", "UTF-8"));
            }
            catch
            {
                this.oOutputEncoding = Encoding.UTF8;
            }
            if (sInitialText != null)
            {
                this.txtInputString.Text = sInitialText.Replace("\n", "\r\n");
                base.ActiveControl = this.txtOutputString;
            }
            else if (Clipboard.ContainsText() && (Clipboard.GetText().Length < 0x8000))
            {
                this.txtInputString.Text = Clipboard.GetText();
            }
            try
            {
                this.cbxTransform.SelectedIndex = FiddlerApplication.Prefs.GetInt32Pref("fiddler.textwizard.LastConversion", 0);
            }
            catch
            {
            }
        }

        private void _AllowExport(bool bAllow)
        {
            this.lblSaveOutput.Visible = this.lnkSaveOutputAsSession.Visible = this.lnkSaveOutputAsFile.Visible = bAllow;
        }

        private static string _PrepareForBase64Decode(string sText)
        {
            sText = sText.Replace('-', '+').Replace('_', '/');
            switch ((sText.Length % 4))
            {
                case 0:
                    return sText;

                case 2:
                    sText = sText + "==";
                    return sText;

                case 3:
                    sText = sText + "=";
                    return sText;
            }
            throw new Exception("Invalid length for a base64 string.");
        }

        private void actDoRecalc(object sender, EventArgs e)
        {
            if ((sender as RadioButton).Checked)
            {
                this.Recalc();
            }
        }

        private void btnSendOutput_Click(object sender, EventArgs e)
        {
            this.txtInputString.Text = this.txtOutputString.Text;
        }

        private void cbShowHex_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cbShowHex.Checked)
            {
                this.txtOutputString.Font = new Font("Lucida Console", 8.25f);
            }
            else
            {
                this.txtOutputString.Font = new Font("Arial Unicode MS", 8.25f);
            }
            this.Recalc();
        }

        private void cbxInputEncoding_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                KeyValuePair<Encoding, string> selectedItem = (KeyValuePair<Encoding, string>) this.cbxInputEncoding.SelectedItem;
                this.oInputEncoding = selectedItem.Key;
                this.Recalc();
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void cbxOutputEncoding_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                KeyValuePair<Encoding, string> selectedItem = (KeyValuePair<Encoding, string>) this.cbxOutputEncoding.SelectedItem;
                this.oOutputEncoding = selectedItem.Key;
                this.Recalc();
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void cbxTransform_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Recalc();
            FiddlerApplication.Prefs.SetInt32Pref("fiddler.textwizard.LastConversion", this.cbxTransform.SelectedIndex);
        }

        private static void CreateFakeSession(byte[] arrData)
        {
            HTTPRequestHeaders headers = new HTTPRequestHeaders();
            headers.HTTPMethod = "GET";
            headers.Add("Host", "localhost");
            headers.RequestPath = "/TextWizard_" + DateTime.Now.ToString("H-mm-ss") + ".dat";
            byte[] arrRequest = headers.ToByteArray(true, true, false);
            byte[] bytes = Encoding.UTF8.GetBytes("HTTP/1.1 200 OK\r\r\nConnection: close\r\n\r\n");
            MemoryStream stream = new MemoryStream();
            stream.Write(bytes, 0, bytes.Length);
            stream.Write(arrData, 0, arrData.Length);
            Session oSession = new Session(arrRequest, stream.ToArray(), SessionFlags.ServedFromCache | SessionFlags.ImportedFromOtherTool | SessionFlags.ResponseGeneratedByFiddler | SessionFlags.RequestGeneratedByFiddler);
            if (FiddlerApplication.UI.InvokeRequired)
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(FiddlerApplication._frmMain.finishSession), new object[] { oSession });
            }
            else
            {
                FiddlerApplication._frmMain.finishSession(oSession);
            }
        }

        private static string DecodeJSString(string s)
        {
            if (string.IsNullOrEmpty(s) || !s.Contains(@"\"))
            {
                return s;
            }
            StringBuilder builder = new StringBuilder();
            int length = s.Length;
            for (int i = 0; i < length; i++)
            {
                char ch = s[i];
                if (ch == '\\')
                {
                    if ((i < (length - 5)) && (s[i + 1] == 'u'))
                    {
                        int num3 = HexToInt(s[i + 2]);
                        int num4 = HexToInt(s[i + 3]);
                        int num5 = HexToInt(s[i + 4]);
                        int num6 = HexToInt(s[i + 5]);
                        if (((num3 < 0) || (num4 < 0)) || ((num5 < 0) || (num6 < 0)))
                        {
                            goto Label_0188;
                        }
                        ch = (char) ((((num3 << 12) | (num4 << 8)) | (num5 << 4)) | num6);
                        i += 5;
                        builder.Append(ch);
                        continue;
                    }
                    if ((i < (length - 3)) && (s[i + 1] == 'x'))
                    {
                        int num7 = HexToInt(s[i + 2]);
                        int num8 = HexToInt(s[i + 3]);
                        if ((num7 < 0) || (num8 < 0))
                        {
                            goto Label_0188;
                        }
                        ch = (char) ((num7 << 4) | num8);
                        i += 3;
                        builder.Append(ch);
                        continue;
                    }
                    if (i < (length - 1))
                    {
                        switch (s[i + 1])
                        {
                            case '\\':
                            {
                                builder.Append(@"\");
                                i++;
                                continue;
                            }
                            case 'n':
                            {
                                builder.Append("\n");
                                i++;
                                continue;
                            }
                            case 't':
                            {
                                builder.Append("\t");
                                i++;
                                continue;
                            }
                        }
                    }
                }
            Label_0188:
                builder.Append(ch);
            }
            return builder.ToString();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private static string EncodeJSString(string sInput)
        {
            StringBuilder builder = new StringBuilder(sInput);
            builder.Replace(@"\", @"\\");
            builder.Replace("\r", @"\r");
            builder.Replace("\n", @"\n");
            builder.Replace("\"", "\\\"");
            sInput = builder.ToString();
            builder = new StringBuilder();
            foreach (char ch in sInput)
            {
                if ('\x007f' < ch)
                {
                    builder.AppendFormat(@"\u{0:X4}", (int) ch);
                }
                else
                {
                    builder.Append(ch);
                }
            }
            return builder.ToString();
        }

        private void frmTextWizard_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                base.Close();
            }
        }

        private static int HexToInt(char h)
        {
            if ((h >= '0') && (h <= '9'))
            {
                return (h - '0');
            }
            if ((h >= 'a') && (h <= 'f'))
            {
                return ((h - 'a') + 10);
            }
            if ((h >= 'A') && (h <= 'F'))
            {
                return ((h - 'A') + 10);
            }
            return -1;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmTextWizard));
            this.txtInputString = new TextBox();
            this.splitter1 = new Splitter();
            this.pnlBottom = new Panel();
            this.txtOutputString = new TextBox();
            this.pnlBotTop = new Panel();
            this.lblConversion = new Label();
            this.cbxTransform = new ComboBox();
            this.lblSaveOutput = new Label();
            this.lnkSaveOutputAsSession = new LinkLabel();
            this.lnkSaveOutputAsFile = new LinkLabel();
            this.lnkEncoding = new LinkLabel();
            this.btnSendOutput = new Button();
            this.cbShowHex = new CheckBox();
            this.toolTip1 = new ToolTip(this.components);
            this.lblInstructions = new Label();
            this.gbEncoding = new GroupBox();
            this.label2 = new Label();
            this.lblInputEncoding = new Label();
            this.cbxOutputEncoding = new ComboBox();
            this.cbxInputEncoding = new ComboBox();
            this.pnlBottom.SuspendLayout();
            this.pnlBotTop.SuspendLayout();
            this.gbEncoding.SuspendLayout();
            base.SuspendLayout();
            this.txtInputString.Dock = DockStyle.Top;
            this.txtInputString.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtInputString.Location = new Point(0, 0x42);
            this.txtInputString.MaxLength = 0xf4240;
            this.txtInputString.Multiline = true;
            this.txtInputString.Name = "txtInputString";
            this.txtInputString.ScrollBars = ScrollBars.Both;
            this.txtInputString.Size = new Size(0x2d2, 0x92);
            this.txtInputString.TabIndex = 0;
            this.txtInputString.TextChanged += new EventHandler(this.txtInputString_TextChanged);
            this.txtInputString.KeyDown += new KeyEventHandler(this.txtInputString_KeyDown);
            this.splitter1.Dock = DockStyle.Top;
            this.splitter1.Location = new Point(0, 0xd4);
            this.splitter1.MinExtra = 50;
            this.splitter1.MinSize = 50;
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new Size(0x2d2, 3);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            this.pnlBottom.Controls.Add(this.txtOutputString);
            this.pnlBottom.Controls.Add(this.pnlBotTop);
            this.pnlBottom.Dock = DockStyle.Fill;
            this.pnlBottom.Location = new Point(0, 0xd7);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new Size(0x2d2, 0xca);
            this.pnlBottom.TabIndex = 9;
            this.txtOutputString.BorderStyle = BorderStyle.FixedSingle;
            this.txtOutputString.Dock = DockStyle.Fill;
            this.txtOutputString.Font = new Font("Arial Unicode MS", 8.25f);
            this.txtOutputString.Location = new Point(0, 0x1f);
            this.txtOutputString.MaxLength = 0xf4240;
            this.txtOutputString.Multiline = true;
            this.txtOutputString.Name = "txtOutputString";
            this.txtOutputString.ReadOnly = true;
            this.txtOutputString.ScrollBars = ScrollBars.Both;
            this.txtOutputString.Size = new Size(0x2d2, 0xab);
            this.txtOutputString.TabIndex = 1;
            this.txtOutputString.KeyDown += new KeyEventHandler(this.txtOutputString_KeyDown);
            this.pnlBotTop.Controls.Add(this.lblConversion);
            this.pnlBotTop.Controls.Add(this.cbxTransform);
            this.pnlBotTop.Controls.Add(this.lblSaveOutput);
            this.pnlBotTop.Controls.Add(this.lnkSaveOutputAsSession);
            this.pnlBotTop.Controls.Add(this.lnkSaveOutputAsFile);
            this.pnlBotTop.Controls.Add(this.lnkEncoding);
            this.pnlBotTop.Controls.Add(this.btnSendOutput);
            this.pnlBotTop.Controls.Add(this.cbShowHex);
            this.pnlBotTop.Dock = DockStyle.Top;
            this.pnlBotTop.Location = new Point(0, 0);
            this.pnlBotTop.Name = "pnlBotTop";
            this.pnlBotTop.Size = new Size(0x2d2, 0x1f);
            this.pnlBotTop.TabIndex = 0;
            this.lblConversion.AutoSize = true;
            this.lblConversion.Location = new Point(6, 6);
            this.lblConversion.Name = "lblConversion";
            this.lblConversion.Size = new Size(60, 13);
            this.lblConversion.TabIndex = 0;
            this.lblConversion.Text = "&Transform:";
            this.cbxTransform.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxTransform.FormattingEnabled = true;
            this.cbxTransform.Items.AddRange(new object[] { 
                "To Base64", "To Base64URL", "From Base64", "URLEncode", "URLDecode", "HexEncode", "HexDecode", "To C# byte[]", "To JS string", "From JS string", "HTML Encode", "HTML Decode", "To UTF-7", "From UTF-7", "To DeflatedSAML", "From DeflatedSAML", 
                "To MD5", "To SHA1", "To SHA256", "To SHA384", "To SHA512"
             });
            this.cbxTransform.Location = new Point(0x48, 3);
            this.cbxTransform.Name = "cbxTransform";
            this.cbxTransform.Size = new Size(0x79, 0x15);
            this.cbxTransform.TabIndex = 1;
            this.cbxTransform.SelectedIndexChanged += new EventHandler(this.cbxTransform_SelectedIndexChanged);
            this.lblSaveOutput.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblSaveOutput.AutoSize = true;
            this.lblSaveOutput.Location = new Point(0x17f, 6);
            this.lblSaveOutput.Name = "lblSaveOutput";
            this.lblSaveOutput.Size = new Size(0x48, 13);
            this.lblSaveOutput.TabIndex = 4;
            this.lblSaveOutput.Text = "Save Output:";
            this.lnkSaveOutputAsSession.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lnkSaveOutputAsSession.AutoSize = true;
            this.lnkSaveOutputAsSession.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkSaveOutputAsSession.Location = new Point(0x1cd, 6);
            this.lnkSaveOutputAsSession.Name = "lnkSaveOutputAsSession";
            this.lnkSaveOutputAsSession.Size = new Size(0x3a, 13);
            this.lnkSaveOutputAsSession.TabIndex = 5;
            this.lnkSaveOutputAsSession.TabStop = true;
            this.lnkSaveOutputAsSession.Text = "As Session";
            this.toolTip1.SetToolTip(this.lnkSaveOutputAsSession, "Saves the output of this conversion to a new Session in the Web Sessions list");
            this.lnkSaveOutputAsSession.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkSaveOutputAsSession_LinkClicked);
            this.lnkSaveOutputAsFile.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lnkSaveOutputAsFile.AutoSize = true;
            this.lnkSaveOutputAsFile.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkSaveOutputAsFile.Location = new Point(0x20d, 6);
            this.lnkSaveOutputAsFile.Name = "lnkSaveOutputAsFile";
            this.lnkSaveOutputAsFile.Size = new Size(50, 13);
            this.lnkSaveOutputAsFile.TabIndex = 6;
            this.lnkSaveOutputAsFile.TabStop = true;
            this.lnkSaveOutputAsFile.Text = "To File...";
            this.toolTip1.SetToolTip(this.lnkSaveOutputAsFile, "Saves the output of this conversion to a file");
            this.lnkSaveOutputAsFile.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkSaveOutput_LinkClicked);
            this.lnkEncoding.AutoSize = true;
            this.lnkEncoding.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkEncoding.Location = new Point(310, 6);
            this.lnkEncoding.Name = "lnkEncoding";
            this.lnkEncoding.Size = new Size(0x43, 13);
            this.lnkEncoding.TabIndex = 3;
            this.lnkEncoding.TabStop = true;
            this.lnkEncoding.Text = "Encodings...";
            this.lnkEncoding.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkEncoding_LinkClicked);
            this.btnSendOutput.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.btnSendOutput.Image = (Image) manager.GetObject("btnSendOutput.Image");
            this.btnSendOutput.ImageAlign = ContentAlignment.MiddleRight;
            this.btnSendOutput.Location = new Point(0x245, 2);
            this.btnSendOutput.Name = "btnSendOutput";
            this.btnSendOutput.Size = new Size(0x8a, 0x17);
            this.btnSendOutput.TabIndex = 7;
            this.btnSendOutput.Text = "Se&nd output to input";
            this.btnSendOutput.TextImageRelation = TextImageRelation.TextBeforeImage;
            this.toolTip1.SetToolTip(this.btnSendOutput, "Replace the Input text above with the Output text below.");
            this.btnSendOutput.UseVisualStyleBackColor = true;
            this.btnSendOutput.Click += new EventHandler(this.btnSendOutput_Click);
            this.cbShowHex.Location = new Point(0xd0, 3);
            this.cbShowHex.Name = "cbShowHex";
            this.cbShowHex.Size = new Size(0x60, 0x18);
            this.cbShowHex.TabIndex = 2;
            this.cbShowHex.Text = "&View bytes";
            this.cbShowHex.CheckedChanged += new EventHandler(this.cbShowHex_CheckedChanged);
            this.lblInstructions.BackColor = Color.Gray;
            this.lblInstructions.Dock = DockStyle.Top;
            this.lblInstructions.ForeColor = Color.White;
            this.lblInstructions.Location = new Point(0, 0);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Padding = new Padding(4);
            this.lblInstructions.Size = new Size(0x2d2, 0x16);
            this.lblInstructions.TabIndex = 11;
            this.lblInstructions.Text = "The TextWizard encodes and decodes text. Input text and select a transform from the dropdown.";
            this.gbEncoding.Controls.Add(this.label2);
            this.gbEncoding.Controls.Add(this.lblInputEncoding);
            this.gbEncoding.Controls.Add(this.cbxOutputEncoding);
            this.gbEncoding.Controls.Add(this.cbxInputEncoding);
            this.gbEncoding.Dock = DockStyle.Top;
            this.gbEncoding.Location = new Point(0, 0x16);
            this.gbEncoding.Name = "gbEncoding";
            this.gbEncoding.Size = new Size(0x2d2, 0x2c);
            this.gbEncoding.TabIndex = 13;
            this.gbEncoding.TabStop = false;
            this.gbEncoding.Text = "Encoding";
            this.gbEncoding.Visible = false;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x160, 0x12);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x29, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "&Output";
            this.lblInputEncoding.AutoSize = true;
            this.lblInputEncoding.Location = new Point(6, 0x12);
            this.lblInputEncoding.Name = "lblInputEncoding";
            this.lblInputEncoding.Size = new Size(0x21, 13);
            this.lblInputEncoding.TabIndex = 0;
            this.lblInputEncoding.Text = "&Input";
            this.cbxOutputEncoding.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.cbxOutputEncoding.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxOutputEncoding.FormattingEnabled = true;
            this.cbxOutputEncoding.Location = new Point(0x189, 15);
            this.cbxOutputEncoding.Name = "cbxOutputEncoding";
            this.cbxOutputEncoding.Size = new Size(0x141, 0x15);
            this.cbxOutputEncoding.Sorted = true;
            this.cbxOutputEncoding.TabIndex = 3;
            this.cbxOutputEncoding.SelectionChangeCommitted += new EventHandler(this.cbxOutputEncoding_SelectionChangeCommitted);
            this.cbxInputEncoding.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxInputEncoding.FormattingEnabled = true;
            this.cbxInputEncoding.Location = new Point(0x2d, 15);
            this.cbxInputEncoding.Name = "cbxInputEncoding";
            this.cbxInputEncoding.Size = new Size(0x12d, 0x15);
            this.cbxInputEncoding.Sorted = true;
            this.cbxInputEncoding.TabIndex = 1;
            this.cbxInputEncoding.SelectionChangeCommitted += new EventHandler(this.cbxInputEncoding_SelectionChangeCommitted);
            this.AutoScaleBaseSize = new Size(5, 14);
            base.ClientSize = new Size(0x2d2, 0x1a1);
            base.Controls.Add(this.pnlBottom);
            base.Controls.Add(this.splitter1);
            base.Controls.Add(this.txtInputString);
            base.Controls.Add(this.gbEncoding);
            base.Controls.Add(this.lblInstructions);
            this.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.KeyPreview = true;
            this.MinimumSize = new Size(0x11e, 0x11e);
            base.Name = "frmTextWizard";
            base.StartPosition = FormStartPosition.Manual;
            this.Text = " TextWizard";
            base.KeyUp += new KeyEventHandler(this.frmTextWizard_KeyUp);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlBotTop.ResumeLayout(false);
            this.pnlBotTop.PerformLayout();
            this.gbEncoding.ResumeLayout(false);
            this.gbEncoding.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lnkEncoding_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.gbEncoding.Visible)
            {
                this.gbEncoding.Visible = false;
            }
            else
            {
                this.PrepAndShowEncodingPanel();
            }
        }

        private void lnkSaveOutput_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (this.arrLastOutput == null)
                {
                    this.arrLastOutput = Encoding.UTF8.GetBytes(this.txtOutputString.Text);
                }
                string str = Utilities.ObtainSaveFilename("Save output to file...", "All files|*.*");
                if (!string.IsNullOrEmpty(str))
                {
                    File.WriteAllBytes(str, this.arrLastOutput);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Export failed");
            }
        }

        private void lnkSaveOutputAsSession_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (this.arrLastOutput == null)
                {
                    this.arrLastOutput = Encoding.UTF8.GetBytes(this.txtOutputString.Text);
                }
                CreateFakeSession(this.arrLastOutput);
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Export failed");
            }
        }

        private void PrepAndShowEncodingPanel()
        {
            if (this.cbxInputEncoding.Items.Count < 1)
            {
                Dictionary<Encoding, string> dataSource = new Dictionary<Encoding, string>();
                foreach (EncodingInfo info in Encoding.GetEncodings())
                {
                    Encoding key = info.GetEncoding();
                    string str = string.Format("{0}{1} [{2} - {3}])", new object[] { (Encoding.Default.CodePage == key.CodePage) ? " * " : string.Empty, key.EncodingName, key.CodePage, key.WebName });
                    dataSource.Add(key, str);
                }
                this.cbxInputEncoding.DataSource = new BindingSource(dataSource, null);
                this.cbxInputEncoding.DisplayMember = "Value";
                this.cbxInputEncoding.ValueMember = "Key";
                foreach (KeyValuePair<Encoding, string> pair in this.cbxInputEncoding.Items)
                {
                    if (pair.Key == this.oInputEncoding)
                    {
                        this.cbxInputEncoding.SelectedItem = pair;
                    }
                }
                this.cbxOutputEncoding.DataSource = new BindingSource(dataSource, null);
                this.cbxOutputEncoding.DisplayMember = "Value";
                this.cbxOutputEncoding.ValueMember = "Key";
                foreach (KeyValuePair<Encoding, string> pair2 in this.cbxOutputEncoding.Items)
                {
                    if (pair2.Key == this.oOutputEncoding)
                    {
                        this.cbxOutputEncoding.SelectedItem = pair2;
                    }
                }
            }
            this.gbEncoding.Visible = true;
        }

        private void Recalc()
        {
            string text = this.txtInputString.Text;
            string s = string.Empty;
            try
            {
                StringBuilder builder;
                MemoryStream stream;
                string str3;
                StringBuilder builder2;
                byte num;
                MemoryStream stream2;
                int num2;
                char ch;
                StringBuilder builder3;
                byte[] buffer3;
                byte num4;
                byte[] buffer5;
                string[] strArray2;
                int num6;
                byte[] buffer6;
                int num7;
                string str7;
                int num8;
                byte[] buffer7;
                int num9;
                this.arrLastOutput = null;
                switch (this.cbxTransform.SelectedIndex)
                {
                    case -1:
                        s = string.Empty;
                        goto Label_05B4;

                    case 0:
                        s = Convert.ToBase64String(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    case 1:
                        s = Convert.ToBase64String(this.oInputEncoding.GetBytes(text)).TrimEnd(new char[] { '=' }).Replace('+', '-').Replace('/', '_');
                        goto Label_05B4;

                    case 2:
                        text = Regex.Replace(text, @"\s+", string.Empty);
                        if (!text.Contains("."))
                        {
                            goto Label_019D;
                        }
                        builder = new StringBuilder();
                        stream = new MemoryStream();
                        strArray2 = text.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
                        num6 = 0;
                        goto Label_017D;

                    case 3:
                        s = Utilities.UrlEncode(text, this.oOutputEncoding);
                        goto Label_05B4;

                    case 4:
                        this.arrLastOutput = Utilities.UrlDecodeToBytes(text, this.oInputEncoding);
                        s = Utilities.UrlDecode(text, this.oInputEncoding);
                        goto Label_05B4;

                    case 5:
                        builder2 = new StringBuilder();
                        buffer6 = this.oOutputEncoding.GetBytes(text);
                        num7 = 0;
                        goto Label_023C;

                    case 6:
                        stream2 = new MemoryStream();
                        num2 = -1;
                        str7 = text;
                        num8 = 0;
                        goto Label_02DA;

                    case 7:
                        builder3 = new StringBuilder();
                        builder3.Append("byte[] arrOutput = {");
                        buffer3 = this.oOutputEncoding.GetBytes(text);
                        buffer7 = buffer3;
                        num9 = 0;
                        goto Label_0358;

                    case 8:
                        s = EncodeJSString(text);
                        goto Label_05B4;

                    case 9:
                        s = DecodeJSString(text);
                        goto Label_05B4;

                    case 10:
                        s = Utilities.HtmlEncode(text);
                        goto Label_05B4;

                    case 11:
                        s = Utilities.HtmlDecode(text);
                        goto Label_05B4;

                    case 12:
                        s = Encoding.ASCII.GetString(Encoding.UTF7.GetBytes(((char) 0xfeff) + text));
                        goto Label_05B4;

                    case 13:
                        s = Encoding.UTF7.GetString(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    case 14:
                        s = Utilities.UrlEncode(Convert.ToBase64String(Utilities.DeflaterCompress(Encoding.UTF8.GetBytes(text))), Encoding.UTF8);
                        goto Label_05B4;

                    case 15:
                        buffer5 = Convert.FromBase64String(Utilities.UrlDecode(Regex.Replace(text, @"\s+", string.Empty), Encoding.UTF8).Replace(' ', '+'));
                        if ((buffer5.Length <= 0) || (buffer5[0] != 60))
                        {
                            goto Label_0488;
                        }
                        s = Encoding.UTF8.GetString(buffer5);
                        goto Label_05B4;

                    case 0x10:
                        s = Utilities.GetHashAsBase64("md5", this.oInputEncoding.GetBytes(text)) + "\r\n\r\n" + Utilities.GetMD5Hash(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    case 0x11:
                        s = Utilities.GetHashAsBase64("sha1", this.oInputEncoding.GetBytes(text)) + "\r\n\r\n" + Utilities.GetSHA1Hash(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    case 0x12:
                        s = Utilities.GetHashAsBase64("sha256", this.oInputEncoding.GetBytes(text)) + "\r\n\r\n" + Utilities.GetSHA256Hash(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    case 0x13:
                        s = Utilities.GetHashAsBase64("sha384", this.oInputEncoding.GetBytes(text)) + "\r\n\r\n" + Utilities.GetSHA384Hash(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    case 20:
                        s = Utilities.GetHashAsBase64("sha512", this.oInputEncoding.GetBytes(text)) + "\r\n\r\n" + Utilities.GetSHA512Hash(this.oInputEncoding.GetBytes(text));
                        goto Label_05B4;

                    default:
                        throw new IndexOutOfRangeException("Invalid conversion requested");
                }
            Label_013D:
                str3 = strArray2[num6];
                byte[] bytes = Convert.FromBase64String(_PrepareForBase64Decode(str3));
                builder.AppendLine(this.oInputEncoding.GetString(bytes));
                stream.Write(bytes, 0, bytes.Length);
                num6++;
            Label_017D:
                if (num6 < strArray2.Length)
                {
                    goto Label_013D;
                }
                s = builder.ToString();
                this.arrLastOutput = stream.ToArray();
                goto Label_05B4;
            Label_019D:
                text = _PrepareForBase64Decode(text);
                this.arrLastOutput = Convert.FromBase64String(text);
                s = this.oInputEncoding.GetString(Convert.FromBase64String(text));
                goto Label_05B4;
            Label_021B:
                num = buffer6[num7];
                builder2.AppendFormat("%{0:x2}", num);
                num7++;
            Label_023C:
                if (num7 < buffer6.Length)
                {
                    goto Label_021B;
                }
                s = builder2.ToString();
                goto Label_05B4;
            Label_0263:
                ch = str7[num8];
                switch (ch)
                {
                    case '\t':
                    case '\n':
                    case '\r':
                    case ' ':
                    case '$':
                    case '%':
                        break;

                    default:
                    {
                        int num3 = HexToInt(ch);
                        if (num3 >= 0)
                        {
                            if (num2 < 0)
                            {
                                num2 = num3;
                            }
                            else
                            {
                                stream2.WriteByte((byte) ((num2 * 0x10) + num3));
                                num2 = -1;
                            }
                        }
                        break;
                    }
                }
                num8++;
            Label_02DA:
                if (num8 < str7.Length)
                {
                    goto Label_0263;
                }
                this.arrLastOutput = stream2.ToArray();
                s = this.oInputEncoding.GetString(this.arrLastOutput);
                goto Label_05B4;
            Label_0337:
                num4 = buffer7[num9];
                builder3.AppendFormat(" 0x{0:X2},", num4);
                num9++;
            Label_0358:
                if (num9 < buffer7.Length)
                {
                    goto Label_0337;
                }
                if (buffer3.Length > 1)
                {
                    builder3.Length--;
                }
                builder3.Append(" };");
                s = builder3.ToString();
                goto Label_05B4;
            Label_0488:
                s = Encoding.UTF8.GetString(Utilities.DeflaterExpand(buffer5));
            Label_05B4:
                this.Text = string.Format("TextWizard [{0} => {1} chars]", this.txtInputString.TextLength, s.Length);
                this._AllowExport(s.Length > 0);
                if (this.cbShowHex.Checked)
                {
                    if (this.arrLastOutput != null)
                    {
                        s = Utilities.ByteArrayToHexView(this.arrLastOutput, 20);
                        string[] strArray3 = new string[] { "TextWizard [", this.txtInputString.TextLength.ToString(), " => ", this.arrLastOutput.Length.ToString(), " bytes]" };
                        this.Text = string.Concat(strArray3);
                    }
                    else
                    {
                        s = Utilities.ByteArrayToHexView(Encoding.UTF8.GetBytes(s), 20);
                    }
                }
                else
                {
                    s = s.Replace("\r\n", "\n").Replace("\n", "\r\n").Replace('\0', 0xfffd);
                }
            }
            catch (Exception exception)
            {
                s = "Error: " + exception.Message;
                this.Text = "TextWizard [Invalid Conversion]";
                this._AllowExport(false);
            }
            this.txtOutputString.WordWrap = !this.cbShowHex.Checked;
            this.txtOutputString.Text = s;
            this.btnSendOutput.Enabled = !this.cbShowHex.Checked && (this.txtOutputString.TextLength > 0);
        }

        private void txtInputString_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.A))
            {
                this.txtInputString.SelectAll();
                e.Handled = e.SuppressKeyPress = true;
            }
        }

        private void txtInputString_TextChanged(object sender, EventArgs e)
        {
            this.Recalc();
        }

        private void txtOutputString_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.A))
            {
                this.txtOutputString.SelectAll();
                e.Handled = e.SuppressKeyPress = true;
            }
        }
    }
}

