﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Threading;
    using System.Windows.Forms;
    using WebSocketView;

    public class WebSocketTab
    {
        private bool _bIsMain;
        private bool _isUIActive;
        private Session _mySession;
        private WebSocket _myWebSocket;
        private string _sUpdateTaskName;
        private TabControl _tcParent;
        private int iLatestShownID;
        private TabPage oPage;
        private WSView oView;

        internal WebSocketTab() : this(null)
        {
        }

        internal WebSocketTab(TabControl tcParentTo)
        {
            this.iLatestShownID = -1;
            this._bIsMain = null == tcParentTo;
            if (this._bIsMain)
            {
                FiddlerApplication.BeforeInspectSession += new CancelEventHandler(this.FiddlerApplication_BeforeInspectSession);
                this._tcParent = FiddlerApplication.UI.tabsViews;
            }
            else
            {
                this._tcParent = tcParentTo;
            }
            this._sUpdateTaskName = "WebSocketViewUpdate_" + this.GetHashCode().ToString("x");
        }

        private string _GetPayloadPreview(WebSocketMessage oWSM)
        {
            if ((oWSM.FrameType == WebSocketFrameTypes.Close) && (oWSM.iCloseReason > 0))
            {
                return ("Reason:" + ((WebSocketCloseReasons) ((short) oWSM.iCloseReason)).ToString());
            }
            return Utilities.TrimTo(oWSM.PayloadAsString(), 0x40);
        }

        private void actInspectWSM()
        {
            IWSMInspector tag = this.oView.tabsWSMInspectors.SelectedTab.Tag as IWSMInspector;
            if (this.oView.lvMessages.SelectedItems.Count != 1)
            {
                try
                {
                    if (tag != null)
                    {
                        tag.Clear();
                    }
                }
                catch
                {
                }
                this.oView.txtMetadata.Text = "Please select one message to inspect";
                this.oView.btnGenFauxResponse.Enabled = this.oView.lvMessages.SelectedItems.Count > 0;
            }
            else
            {
                ListViewItem item = this.oView.lvMessages.SelectedItems[0];
                WebSocketMessage oWSM = item.Tag as WebSocketMessage;
                this.oView.wsmInspecting = oWSM;
                if (oWSM != null)
                {
                    this.oView.tabsWSMInspectors.Enabled = true;
                    this.oView.strInspecting = string.Format("/ws{0}-msg{1}", this._mySession.id, oWSM.ID);
                    this.oView.txtMetadata.Text = string.Format("{0}\n{1}\n", oWSM.Timers.ToString(true), (oWSM.MaskingKey == null) ? "Not masked" : ("Data masked by key: " + Utilities.ByteArrayToString(oWSM.MaskingKey)));
                    byte[] bIn = oWSM.PayloadAsBytes();
                    if ((oWSM.FrameType == WebSocketFrameTypes.Close) && (bIn.Length == 2))
                    {
                        int num = (bIn[0] << 8) + bIn[1];
                        this.oView.txtMetadata.Text = this.oView.txtMetadata.Text + string.Format("\r\nClose Reason: {0}\r\n", ((WebSocketCloseReasons) ((short) num)).ToString());
                    }
                    this.oView.btnGenFauxResponse.Enabled = !Utilities.IsNullOrEmpty(bIn);
                    if (tag != null)
                    {
                        try
                        {
                            if (oWSM == null)
                            {
                                tag.Clear();
                            }
                            else
                            {
                                tag.bReadOnly = true;
                                tag.AssignMessage(oWSM);
                            }
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.LogAddonException(exception, "WSMInspector Failed");
                        }
                    }
                }
            }
        }

        private void btnGenFauxResponse_Click(object sender, EventArgs e)
        {
            foreach (WebSocketMessage message in this.GetSelectedMessages())
            {
                byte[] bIn = message.PayloadAsBytes();
                if (Utilities.IsNullOrEmpty(bIn))
                {
                    break;
                }
                List<string> list = new List<string>();
                list.Add("Content-Length: " + bIn.Length.ToString());
                if (message.FrameType == WebSocketFrameTypes.Text)
                {
                    list.Add("Content-Type: text/plain; charset=utf-8");
                }
                else
                {
                    list.Add("Content-Type: application/octet-stream");
                }
                Session session = FiddlerApplication.UI.AddMockSession(new HTTPRequestHeaders(string.Format("/ws{0}-msg{1}", this._mySession.id, message.ID), new string[] { "Host: localhost", "Date: " + message.Timers.dtDoneRead.ToUniversalTime().ToString("r") }), Utilities.emptyByteArray, new HTTPResponseHeaders(200, "Generated from WebSocket body", list.ToArray()), bIn);
                if (message.IsOutbound)
                {
                    session.Timers.ClientConnected = session.Timers.ClientBeginRequest = session.Timers.FiddlerGotRequestHeaders = session.Timers.ClientDoneRequest = message.Timers.dtDoneRead;
                    session.Timers.FiddlerBeginRequest = message.Timers.dtBeginSend;
                    session.Timers.ClientDoneResponse = message.Timers.dtDoneSend;
                }
                else
                {
                    session.Timers.ClientConnected = session.Timers.ClientBeginRequest = session.Timers.FiddlerGotRequestHeaders = session.Timers.ClientDoneRequest = session.Timers.FiddlerGotResponseHeaders = session.Timers.ServerBeginResponse = session.Timers.ServerDoneResponse = message.Timers.dtDoneRead;
                    session.Timers.ClientBeginResponse = message.Timers.dtBeginSend;
                    session.Timers.ClientDoneResponse = message.Timers.dtDoneSend;
                }
            }
        }

        private void btnUnfragment_Click(object sender, EventArgs e)
        {
            if (this._myWebSocket != null)
            {
                this._myWebSocket.UnfragmentMessages();
                this.UIThreadClear();
                this.iLatestShownID = -1;
                this.UIThreadUpdate();
            }
        }

        internal void DoInspectSession(Session oS)
        {
            this._mySession = oS;
            if (this._mySession == null)
            {
                this._myWebSocket = null;
            }
            else
            {
                this.EnsureUI();
                this.OnTabActivate();
            }
        }

        private void EnsureListIsCurrent()
        {
            if (this._myWebSocket == null)
            {
                this.iLatestShownID = -1;
                this.oView.lblSessionID.Text = string.Empty;
                this.oView.lvMessages.Items.Clear();
                this.actInspectWSM();
            }
            else
            {
                if (this._myWebSocket.IsOpen && this._isUIActive)
                {
                    ScheduledTasks.ScheduleWork(this._sUpdateTaskName, 300, new SimpleEventHandler(this.EnsureListIsCurrent));
                }
                FiddlerApplication.UI.Invoke(new MethodInvoker(this.UIThreadUpdate));
            }
        }

        private void EnsureUI()
        {
            if (!this.isUIReady)
            {
                this.oPage = new TabPage("WebSocket");
                this.oView = new WSView();
                this.oPage.Controls.Add(this.oView);
                this.oView.Dock = DockStyle.Fill;
                this.oPage.ImageIndex = 0x22;
                this._tcParent.TabPages.Add(this.oPage);
                if (FiddlerApplication.oInspectors != null)
                {
                    FiddlerApplication.oInspectors.AddWSMInspectorsToTabControl(this.oView.tabsWSMInspectors, InspectorFlags.None);
                }
                if (this._bIsMain)
                {
                    FiddlerApplication.UI.lvSessions.SelectedIndexChanged += new EventHandler(this.lvSessions_SelectedIndexChanged);
                }
                this._tcParent.Deselecting += new TabControlCancelEventHandler(this.tabsViews_Changing);
                this._tcParent.Selecting += new TabControlCancelEventHandler(this.tabsViews_Changing);
                this.oView.lvMessages.SelectedIndexChanged += new EventHandler(this.lvMessages_SelectedIndexChanged);
                this.oView.lvMessages.ItemActivate += new EventHandler(this.lvMessages_ItemActivate);
                this.oView.tabsWSMInspectors.SelectedIndexChanged += new EventHandler(this.tabsWSMInspectors_SelectedIndexChanged);
                this.oView.btnGenFauxResponse.Click += new EventHandler(this.btnGenFauxResponse_Click);
                this.oView.btnUnfragment.Click += new EventHandler(this.btnUnfragment_Click);
            }
        }

        private void FiddlerApplication_BeforeInspectSession(object sender, CancelEventArgs e)
        {
            if (FiddlerApplication.UI.lvSessions.SelectedCount == 1)
            {
                this._mySession = sender as Session;
                if (this._mySession == null)
                {
                    this._myWebSocket = null;
                }
                else if (!this._mySession.bHasWebSocketMessages)
                {
                    this._mySession = null;
                    this._myWebSocket = null;
                }
                else
                {
                    e.Cancel = true;
                    this.EnsureUI();
                    FiddlerApplication.UI.tabsViews.SelectedTab = this.oPage;
                    this.OnTabActivate();
                }
            }
        }

        private WebSocketMessage[] GetSelectedMessages()
        {
            List<WebSocketMessage> list = new List<WebSocketMessage>();
            foreach (ListViewItem item in this.oView.lvMessages.SelectedItems)
            {
                list.Add(item.Tag as WebSocketMessage);
            }
            return list.ToArray();
        }

        private void lvMessages_ItemActivate(object sender, EventArgs e)
        {
        }

        private void lvMessages_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.actInspectWSM();
        }

        private void lvSessions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((!FiddlerApplication.isClosing && this.isUIReady) && this._isUIActive)
            {
                if (FiddlerApplication.UI.lvSessions.SelectedCount != 1)
                {
                    this._mySession = null;
                    this._myWebSocket = null;
                    this.iLatestShownID = -1;
                }
                else
                {
                    this._mySession = FiddlerApplication.UI.GetFirstSelectedSession();
                }
                this.OnTabActivate();
            }
        }

        private void OnTabActivate()
        {
            this._isUIActive = true;
            if (((this._mySession == null) || this._mySession.HTTPMethodIs("CONNECT")) || !this._mySession.isAnyFlagSet(SessionFlags.IsWebSocketTunnel))
            {
                this._myWebSocket = null;
                this.oView.lblSessionID.Text = "Select a single WebSocket to see its traffic";
                this.oView.lvMessages.Items.Clear();
                this.actInspectWSM();
            }
            else
            {
                this._myWebSocket = this._mySession.__oTunnel as WebSocket;
                if (this._myWebSocket == null)
                {
                    this.oView.lblSessionID.Text = string.Format("Session {0} WebSocket data is not available", this._mySession.id);
                    this.oView.lvMessages.Items.Clear();
                    this.actInspectWSM();
                }
                else
                {
                    this.UIThreadUpdate();
                    if (this._myWebSocket.IsOpen)
                    {
                        ScheduledTasks.ScheduleWork("WebSocketViewUpdate", 300, new SimpleEventHandler(this.EnsureListIsCurrent));
                    }
                }
            }
        }

        private void OnTabDeactivate()
        {
            this._isUIActive = false;
            ScheduledTasks.CancelWork(this._sUpdateTaskName);
        }

        private void tabsViews_Changing(object sender, TabControlCancelEventArgs e)
        {
            if (!FiddlerApplication.isClosing && this.isUIReady)
            {
                if ((e.Action == TabControlAction.Deselecting) && (e.TabPage == this.oPage))
                {
                    this.OnTabActivate();
                }
                else if ((e.Action == TabControlAction.Selecting) && (e.TabPage == this.oPage))
                {
                    this.OnTabDeactivate();
                }
            }
        }

        private void tabsWSMInspectors_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing && (this.oView.tabsWSMInspectors.SelectedIndex >= 0))
            {
                this.actInspectWSM();
            }
        }

        private void UIThreadClear()
        {
            this.oView.lblSessionID.Text = string.Empty;
            this.oView.lvMessages.BeginUpdate();
            this.oView.lvMessages.Items.Clear();
            this.oView.lvMessages.EndUpdate();
            this.actInspectWSM();
        }

        private void UIThreadUpdate()
        {
            List<WebSocketMessage> list;
            this.oView.lblSessionID.Text = string.Format("WebSocket #{0} transferred {1} messages {2}", this._mySession.id, this._myWebSocket.listMessages.Count, this._myWebSocket.IsOpen ? "and remains open." : "before closing.");
            this.oView.lvMessages.BeginUpdate();
            bool lockTaken = false;
            try
            {
                Monitor.Enter(list = this._myWebSocket.listMessages, ref lockTaken);
                foreach (WebSocketMessage message in this._myWebSocket.listMessages)
                {
                    int num;
                    if (message.ID <= this.iLatestShownID)
                    {
                        continue;
                    }
                    this.iLatestShownID = message.ID;
                    ListViewItem item = new ListViewItem(this.iLatestShownID.ToString());
                    if (message.FrameType == WebSocketFrameTypes.Close)
                    {
                        num = message.IsOutbound ? 4 : 5;
                    }
                    else
                    {
                        num = message.IsOutbound ? 0 : 2;
                        if ((message.FrameType == WebSocketFrameTypes.Continuation) || !message.IsFinalFrame)
                        {
                            num++;
                        }
                    }
                    item.ImageIndex = num;
                    string str = null;
                    if (!message.IsFinalFrame)
                    {
                        if (message.FrameType != WebSocketFrameTypes.Continuation)
                        {
                            str = " (partial)";
                        }
                    }
                    else if (message.FrameType == WebSocketFrameTypes.Continuation)
                    {
                        str = " (final)";
                    }
                    if ((message.FrameType == WebSocketFrameTypes.Ping) || (message.FrameType == WebSocketFrameTypes.Pong))
                    {
                        item.ForeColor = Color.Gray;
                    }
                    item.SubItems.Add(message.FrameType.ToString() + str);
                    item.SubItems.Add(message.PayloadLength.ToString("N0"));
                    item.SubItems.Add(this._GetPayloadPreview(message));
                    if (message.FrameType == WebSocketFrameTypes.Continuation)
                    {
                        item.IndentCount = 1;
                    }
                    this.oView.lvMessages.Items.Add(item);
                    item.Tag = message;
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(list);
                }
            }
            this.oView.lvMessages.EndUpdate();
        }

        private bool isUIReady
        {
            get
            {
                return (null != this.oPage);
            }
        }
    }
}

