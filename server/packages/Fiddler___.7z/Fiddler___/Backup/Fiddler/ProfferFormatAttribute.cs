﻿namespace Fiddler
{
    using System;

    [AttributeUsage(AttributeTargets.Class, Inherited=false, AllowMultiple=true)]
    public sealed class ProfferFormatAttribute : Attribute
    {
        private string _sExtensions;
        private string _sFormatDesc;
        private string _sFormatName;

        public ProfferFormatAttribute(string sFormatName, string sDescription) : this(sFormatName, sDescription, string.Empty)
        {
        }

        public ProfferFormatAttribute(string sFormatName, string sDescription, string sExtensions)
        {
            this._sFormatName = sFormatName;
            this._sFormatDesc = sDescription;
            this._sExtensions = sExtensions;
        }

        internal string[] getExtensions()
        {
            if (string.IsNullOrEmpty(this._sExtensions))
            {
                return new string[0];
            }
            return this._sExtensions.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
        }

        public string FormatDescription
        {
            get
            {
                return this._sFormatDesc;
            }
        }

        public string FormatName
        {
            get
            {
                return this._sFormatName;
            }
        }
    }
}

