﻿namespace Fiddler
{
    using System;

    [AttributeUsage(AttributeTargets.Method, Inherited=false)]
    public sealed class BindUIColumn : Attribute
    {
        internal bool _bSortColumnNumerically;
        internal string _colName;
        internal int _iColWidth;
        internal int _iDisplayOrder;

        public BindUIColumn(string colName) : this(colName, 50, -1, colName.StartsWith("#") || colName.EndsWith("#"))
        {
        }

        public BindUIColumn(string colName, bool bSortColumnNumerically) : this(colName, 50, -1, bSortColumnNumerically)
        {
        }

        public BindUIColumn(string colName, int iColWidth) : this(colName, iColWidth, -1, colName.StartsWith("#") || colName.EndsWith("#"))
        {
        }

        public BindUIColumn(string colName, int iColWidth, int iDisplayOrder) : this(colName, iColWidth, iDisplayOrder, colName.StartsWith("#") || colName.EndsWith("#"))
        {
        }

        public BindUIColumn(string colName, int iColWidth, int iDisplayOrder, bool bSortColumnNumerically)
        {
            this._colName = colName;
            this._iColWidth = iColWidth;
            this._iDisplayOrder = iDisplayOrder;
            this._bSortColumnNumerically = bSortColumnNumerically;
        }
    }
}

