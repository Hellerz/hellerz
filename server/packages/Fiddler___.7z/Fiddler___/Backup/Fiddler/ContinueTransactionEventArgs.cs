﻿namespace Fiddler
{
    using System;

    public class ContinueTransactionEventArgs : EventArgs
    {
        private ContinueTransactionReason _reason;
        private Session _sessNew;
        private Session _sessOriginal;

        internal ContinueTransactionEventArgs(Session originalSession, Session newSession, ContinueTransactionReason reason)
        {
            this._sessOriginal = originalSession;
            this._sessNew = newSession;
            this._reason = reason;
        }

        public Session newSession
        {
            get
            {
                return this._sessNew;
            }
        }

        public Session originalSession
        {
            get
            {
                return this._sessOriginal;
            }
        }

        public ContinueTransactionReason reason
        {
            get
            {
                return this._reason;
            }
        }
    }
}

