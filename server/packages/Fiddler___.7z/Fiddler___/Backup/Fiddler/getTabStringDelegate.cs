﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate string getTabStringDelegate(Session[] arrSessions);
}

