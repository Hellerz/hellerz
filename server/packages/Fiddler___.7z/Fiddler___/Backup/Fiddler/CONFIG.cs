﻿namespace Fiddler
{
    using Microsoft.Win32;
    using System;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.Net.NetworkInformation;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Security.Authentication;
    using System.Text;
    using System.Windows.Forms;

    public static class CONFIG
    {
        private static bool _bEnableAnalytics;
        internal static int _cb_STREAM_LARGE_FILES = 0x20000000;
        private static int _iReverseProxyForPort;
        private static ProcessFilterCategories _pfcDecyptFilter = ProcessFilterCategories.All;
        private static PreferenceBag _Prefs = null;
        private static GatewayType _UpstreamGateway = GatewayType.System;
        [CompilerGenerated]
        private static bool <bRevertToDefaultLayout>k__BackingField;
        internal static bool bAlwaysShowTrayIcon = false;
        public static bool bAttachOnBoot = true;
        public static bool bAutoLoadScript = true;
        public static bool bAutoProxyLogon = false;
        public static bool bAutoScroll = true;
        public static bool bBreakOnImages = false;
        public static bool bCaptureCONNECT = true;
        public static bool bCaptureFTP = false;
        internal static bool bCheckCompressionIntegrity = false;
        public static bool bDebugCertificateGeneration = true;
        internal static bool bDebugSpew = false;
        public static bool bEnableIPv6 = (Environment.OSVersion.Version.Major > 5);
        [Obsolete]
        public static bool bForwardToGateway = true;
        public static bool bHideOnMinimize = false;
        internal static bool bHookAllConnections = true;
        internal static bool bHookWithPAC = false;
        private static bool bIgnoreServerCertErrors = false;
        internal static bool bIsBeta = false;
        internal static bool bIsViewOnly = false;
        public static bool bLoadExtensions = true;
        public static bool bLoadInspectors = true;
        public static bool bLoadScript = true;
        public static bool bMapSocketToProcess = true;
        internal static bool bMimicClientHTTPSProtocols = true;
        public static bool bMITM_HTTPS = false;
        private static bool bQuietMode = !Environment.UserInteractive;
        internal static bool bReloadSessionIDAsFlag = false;
        public static bool bReportHTTPErrors = true;
        internal static bool bReportHTTPLintErrors = false;
        public static bool bResetCounterOnClear = true;
        public static bool bReuseClientSockets = true;
        public static bool bReuseServerSockets = true;
        internal static bool bRunningOnCLRv4 = true;
        public static bool bSearchUnmarkOldHits = true;
        internal static bool bShowDefaultClientCertificateNeededPrompt = true;
        public static bool bSmartScroll = true;
        [Obsolete("Do not use this field. Watch the preference fiddler.ui.layout.mode instead.")]
        public static bool bStackedLayout = false;
        internal static bool bStreamAudioVideo = true;
        public static bool bUseAESForSAZ = true;
        public static bool bUseEventLogForExceptions = false;
        internal static bool bUseSNIForCN = false;
        internal static bool bUseXceedDecompressForDeflate = true;
        internal static bool bUseXceedDecompressForGZIP = false;
        internal static bool bUsingPortOverride = false;
        public static bool bVersionCheck = true;
        internal static bool bVersionCheckBlocked;
        internal static int cbAutoStreamAndForget = 0x7fffffc7;
        private static readonly System.Drawing.Color COLOR_DEFAULT_DISABLEDEDIT = System.Drawing.Color.AliceBlue;
        private static readonly System.Drawing.Color COLOR_HICONTRASTDARK_DISABLEDEDIT = System.Drawing.Color.FromArgb(0, 0, 50);
        internal static System.Drawing.Color colorBodyDropped = System.Drawing.Color.FromArgb(0xf4, 0xff, 0xc7);
        public static System.Drawing.Color colorDisabledEdit = COLOR_DEFAULT_DISABLEDEDIT;
        internal static System.Drawing.Color colorIsAuth = System.Drawing.Color.Olive;
        internal static System.Drawing.Color colorIsHTML = System.Drawing.Color.Blue;
        internal static System.Drawing.Color colorIsScript = System.Drawing.Color.ForestGreen;
        internal static System.Drawing.Color colorLoadedFromSAZ = System.Drawing.Color.FromArgb(0xf2, 0xff, 240);
        public static Version FiddlerVersionInfo = Assembly.GetExecutingAssembly().GetName().Version;
        public static float flFontSize = 8.25f;
        private static bool fNeedToMaximizeOnload;
        internal const int I_MAX_CONNECTION_QUEUE = 50;
        public static int iHotkey = 70;
        public static int iHotkeyMod = 3;
        public static int iReporterUpdateInterval = 350;
        public static int iScriptReloadInterval = 0xbb8;
        internal static ProcessFilterCategories iShowProcessFilter;
        internal static uint iStartupCount = 0;
        private static bool m_bAllowRemoteConnections;
        private static bool m_bCheckForISA = true;
        private static bool m_bForceExclusivePort;
        private static string m_CompareTool = "windiff.exe";
        private static string m_JSEditor;
        private static int m_ListenPort = 0x22b8;
        public static string m_sAdditionalScriptReferences;
        private static string m_sHostsThatBypassFiddler;
        private static string m_TextEditor = "notepad.exe";
        public static SslProtocols oAcceptedClientHTTPSProtocols = (SslProtocols.Tls12 | SslProtocols.Tls11 | SslProtocols.Default | SslProtocols.Ssl2);
        public static SslProtocols oAcceptedServerHTTPSProtocols = SslProtocols.Default;
        public static Encoding oBodyEncoding = Encoding.UTF8;
        public static Encoding oHeaderEncoding = Encoding.UTF8;
        internal static HostList oHLSkipDecryption = null;
        internal static RetryMode RetryOnReceiveFailure = RetryMode.Always;
        public static string sAlternateHostname = "?";
        internal static string sDefaultBrowserExe = "iexplore.exe";
        internal static string sDefaultBrowserParams = string.Empty;
        internal static string sFiddlerListenHostPort = "127.0.0.1:8888";
        public static string sGatewayPassword;
        public static string sGatewayUsername;
        internal static string sHookConnectionNamed = "DefaultLAN";
        private static string sLVColInfo = null;
        internal static string sMachineDomain = string.Empty;
        internal static string sMachineName = string.Empty;
        internal static string sMakeCertParamsEE = "-pe -ss my -n \"CN={0}{1}\" -sky exchange -in {2} -is my -eku 1.3.6.1.5.5.7.3.1 -cy end -a {3} -m 132 -b {4} {5}";
        internal static string sMakeCertParamsRoot = "-r -ss my -n \"CN={0}{1}\" -sky signature -eku 1.3.6.1.5.5.7.3.1 -h 1 -cy authority -a {3} -m 132 -b {4} {5}";
        internal static string sMakeCertRootCN = "DO_NOT_TRUST_FiddlerRoot";
        internal static string sMakeCertSubjectO = ", O=DO_NOT_TRUST, OU=Created by http://www.fiddler2.com";
        internal static string sReverseProxyHostname = "localhost";
        internal static string sRootKey = @"SOFTWARE\Microsoft\Fiddler2\";
        private static string sRootUrl = "http://fiddler2.com/fiddler2/";
        private static string sScriptPath = string.Concat(new object[] { sUserPath, "Scripts", Path.DirectorySeparatorChar, "CustomRules.js" });
        private static string sSecureRootUrl = "https://fiddler2.com/";
        private static string sUserPath = string.Concat(new object[] { GetPath("MyDocs"), Path.DirectorySeparatorChar, "Fiddler2", Path.DirectorySeparatorChar });

        static CONFIG()
        {
            try
            {
                RegistryKey key;
                try
                {
                    IPGlobalProperties iPGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
                    sMachineDomain = iPGlobalProperties.DomainName.ToLowerInvariant();
                    sMachineName = iPGlobalProperties.HostName.ToLowerInvariant();
                    iPGlobalProperties = null;
                }
                catch (Exception)
                {
                }
                try
                {
                    key = Registry.LocalMachine.OpenSubKey(GetRegPath("LMIsBeta"), RegistryKeyPermissionCheck.ReadSubTree);
                    if (key != null)
                    {
                        bIsBeta = Utilities.GetRegistryBool(key, "IsBeta", bIsBeta);
                        bVersionCheckBlocked = Utilities.GetRegistryBool(key, "BlockUpdateCheck", bVersionCheckBlocked);
                        if (Utilities.GetRegistryBool(key, "ForceViewerMode", false))
                        {
                            bIsViewOnly = true;
                        }
                        if (bVersionCheckBlocked)
                        {
                            bEnableAnalytics = bVersionCheck = false;
                        }
                        key.Close();
                    }
                }
                catch (Exception)
                {
                }
                try
                {
                    key = Registry.CurrentUser.OpenSubKey(sRootKey, RegistryKeyPermissionCheck.ReadSubTree);
                    if (key != null)
                    {
                        m_bForceExclusivePort = Utilities.GetRegistryBool(key, "ExclusivePort", m_bForceExclusivePort);
                        bUseEventLogForExceptions = Utilities.GetRegistryBool(key, "UseEventLogForExceptions", bUseEventLogForExceptions);
                        m_bCheckForISA = Utilities.GetRegistryBool(key, "CheckForISA", m_bCheckForISA);
                        m_TextEditor = (string) key.GetValue("TextEditor", m_TextEditor);
                        m_CompareTool = (string) key.GetValue("CompareTool", m_CompareTool);
                        bBreakOnImages = Utilities.GetRegistryBool(key, "BreakOnImages", bBreakOnImages);
                        sHostsThatBypassFiddler = (string) key.GetValue("FiddlerBypass", string.Empty);
                        sGatewayUsername = (string) key.GetValue("GatewayUsername", sGatewayUsername);
                        sGatewayPassword = (string) key.GetValue("GatewayPassword", sGatewayPassword);
                        sMakeCertParamsRoot = (string) key.GetValue("MakeCertParamsRoot", sMakeCertParamsRoot);
                        sMakeCertParamsEE = (string) key.GetValue("MakeCertParamsEE", sMakeCertParamsEE);
                        sMakeCertRootCN = (string) key.GetValue("MakeCertRootCN", sMakeCertRootCN);
                        sMakeCertSubjectO = (string) key.GetValue("MakeCertSubjectO", sMakeCertSubjectO);
                        m_JSEditor = (string) key.GetValue("JSEditor", m_JSEditor);
                        ListenPort = Utilities.GetRegistryInt(key, "ListenPort", m_ListenPort);
                        bLoadScript = Utilities.GetRegistryBool(key, "LoadScript", bLoadScript);
                        bLoadInspectors = Utilities.GetRegistryBool(key, "LoadInspectors", bLoadInspectors);
                        bLoadExtensions = Utilities.GetRegistryBool(key, "LoadExtensions", bLoadExtensions);
                        iHotkeyMod = Utilities.GetRegistryInt(key, "HotkeyMod", iHotkeyMod);
                        iHotkey = Utilities.GetRegistryInt(key, "Hotkey", iHotkey);
                        flFontSize = Utilities.EnsureInRange<float>(Utilities.GetRegistryFloat(key, "FontSize", flFontSize), 4f, 24f);
                        int argb = Utilities.GetRegistryInt(key, "colorDisabledEdit", -1);
                        if (argb != -1)
                        {
                            colorDisabledEdit = System.Drawing.Color.FromArgb(argb);
                        }
                        if ((SystemInformation.HighContrast && (colorDisabledEdit == COLOR_DEFAULT_DISABLEDEDIT)) && (System.Drawing.Color.FromKnownColor(KnownColor.WindowText).GetBrightness() > 0.2))
                        {
                            colorDisabledEdit = COLOR_HICONTRASTDARK_DISABLEDEDIT;
                        }
                        bAttachOnBoot = Utilities.GetRegistryBool(key, "AttachOnBoot", bAttachOnBoot);
                        iStartupCount = (uint) (1 + Utilities.GetRegistryInt(key, "StartupCount", 0));
                        bAutoLoadScript = Utilities.GetRegistryBool(key, "AutoReloadScript", bAutoLoadScript);
                        m_bAllowRemoteConnections = Utilities.GetRegistryBool(key, "AllowRemote", m_bAllowRemoteConnections);
                        bReuseServerSockets = Utilities.GetRegistryBool(key, "ReuseServerSockets", bReuseServerSockets);
                        bReuseClientSockets = Utilities.GetRegistryBool(key, "ReuseClientSockets", bReuseClientSockets);
                        bAutoProxyLogon = Utilities.GetRegistryBool(key, "AutoProxyLogon", bAutoProxyLogon);
                        bDebugSpew = Utilities.GetRegistryBool(key, "DebugSpew", bDebugSpew);
                        bReportHTTPErrors = Utilities.GetRegistryBool(key, "ReportHTTPErrors", bReportHTTPErrors);
                        if (bDebugSpew)
                        {
                            Trace.WriteLine("Fiddler DebugSpew is enabled.");
                        }
                        bHideOnMinimize = Utilities.GetRegistryBool(key, "HideOnMinimize", bHideOnMinimize);
                        bAlwaysShowTrayIcon = Utilities.GetRegistryBool(key, "AlwaysShowTrayIcon", bAlwaysShowTrayIcon);
                        UpstreamGateway = (GatewayType) ((byte) Utilities.GetRegistryInt(key, "GatewayType", (int) _UpstreamGateway));
                        bEnableIPv6 = Utilities.GetRegistryBool(key, "EnableIPv6", bEnableIPv6);
                        SessionTimers.EnableHighResolutionTimers = Utilities.GetRegistryBool(key, "EnableHighResTimers", false);
                        bCaptureCONNECT = Utilities.GetRegistryBool(key, "CaptureCONNECT", bCaptureCONNECT);
                        bCaptureFTP = Utilities.GetRegistryBool(key, "CaptureFTP", bCaptureFTP);
                        bMapSocketToProcess = Utilities.GetRegistryBool(key, "MapSocketToProcess", bMapSocketToProcess);
                        bUseXceedDecompressForGZIP = Utilities.GetRegistryBool(key, "UseXceedDecompressForGZIP", bUseXceedDecompressForGZIP);
                        bUseXceedDecompressForDeflate = Utilities.GetRegistryBool(key, "UseXceedDecompressForDeflate", bUseXceedDecompressForDeflate);
                        bUseAESForSAZ = !Utilities.GetRegistryBool(key, "UseLegacyEncryptionForSaz", false);
                        bStreamAudioVideo = Utilities.GetRegistryBool(key, "AutoStreamAudioVideo", bStreamAudioVideo);
                        bShowDefaultClientCertificateNeededPrompt = Utilities.GetRegistryBool(key, "ShowDefaultClientCertificateNeededPrompt", bShowDefaultClientCertificateNeededPrompt);
                        bMITM_HTTPS = Utilities.GetRegistryBool(key, "CaptureHTTPS", bMITM_HTTPS);
                        bIgnoreServerCertErrors = Utilities.GetRegistryBool(key, "IgnoreServerCertErrors", bIgnoreServerCertErrors);
                        iReverseProxyForPort = Utilities.GetRegistryInt(key, "ReverseProxyForPort", iReverseProxyForPort);
                        sReverseProxyHostname = (string) key.GetValue("ReverseProxyHostname", sReverseProxyHostname);
                        iShowProcessFilter = (ProcessFilterCategories) Utilities.GetRegistryInt(key, "ShowProcessFilter", (int) iShowProcessFilter);
                        DecryptWhichProcesses = (ProcessFilterCategories) Utilities.GetRegistryInt(key, "HTTPSProcessFilter", (int) DecryptWhichProcesses);
                        if (!bVersionCheckBlocked)
                        {
                            bVersionCheck = Utilities.GetRegistryBool(key, "CheckForUpdates", bVersionCheck);
                            bEnableAnalytics = Utilities.GetRegistryBool(key, "SendTelemetry", bEnableAnalytics);
                        }
                        m_sAdditionalScriptReferences = (string) key.GetValue("ScriptReferences", string.Empty);
                        sHookConnectionNamed = (string) key.GetValue("HookConnectionNamed", sHookConnectionNamed);
                        bHookAllConnections = Utilities.GetRegistryBool(key, "HookAllConnections", bHookAllConnections);
                        bHookWithPAC = Utilities.GetRegistryBool(key, "HookWithPAC", bHookWithPAC);
                        if (key.GetValue("HeaderEncoding") != null)
                        {
                            try
                            {
                                oHeaderEncoding = Utilities.GetTextEncoding((string) key.GetValue("HeaderEncoding"));
                            }
                            catch (Exception exception)
                            {
                                FiddlerApplication.DoNotifyUser(exception, "Invalid HeaderEncoding specified in registry");
                                oHeaderEncoding = Encoding.UTF8;
                            }
                        }
                        sUserPath = (string) key.GetValue("UserPath", sUserPath);
                        if (!sUserPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
                        {
                            sUserPath = sUserPath + Path.DirectorySeparatorChar;
                        }
                        sScriptPath = (string) key.GetValue("ScriptFullPath", string.Concat(new object[] { sUserPath, "Scripts", Path.DirectorySeparatorChar, "CustomRules.js" }));
                        key.Close();
                    }
                    _ApplyCommandLineOverrides();
                }
                catch (Exception exception2)
                {
                    FiddlerApplication.ReportException(exception2, "Initialization of CONFIG Failed");
                }
                _LoadPreferences();
                if ((Environment.OSVersion.Version.Major < 6) && (Environment.OSVersion.Version.Minor < 1))
                {
                    bMapSocketToProcess = false;
                }
            }
            catch (Exception exception3)
            {
                FiddlerApplication.ReportException(exception3, "Initialization of CONFIG Prefs Failed");
            }
        }

        private static void _ApplyCommandLineOverrides()
        {
            foreach (string str in Environment.GetCommandLineArgs())
            {
                if (str.StartsWith("-") || str.StartsWith("/"))
                {
                    if (str.IndexOf("port:", StringComparison.OrdinalIgnoreCase) == 1)
                    {
                        int result = 0;
                        if (int.TryParse(str.Substring(str.IndexOf("port:", StringComparison.OrdinalIgnoreCase) + 5), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out result))
                        {
                            ListenPort = result;
                            bUsingPortOverride = true;
                        }
                    }
                    else if (str.IndexOf("quiet", StringComparison.OrdinalIgnoreCase) == 1)
                    {
                        bQuietMode = true;
                    }
                    else if (str.IndexOf("extoff", StringComparison.OrdinalIgnoreCase) == 1)
                    {
                        bLoadExtensions = bLoadInspectors = false;
                    }
                    else if (str.IndexOf("noscript", StringComparison.OrdinalIgnoreCase) == 1)
                    {
                        bLoadScript = false;
                    }
                    else if (str.IndexOf("viewer", StringComparison.OrdinalIgnoreCase) == 1)
                    {
                        bIsViewOnly = true;
                    }
                    else if (str.IndexOf("?", StringComparison.OrdinalIgnoreCase) == 1)
                    {
                        _ShowCommandLineArgs();
                    }
                }
            }
        }

        private static void _LoadPreferences()
        {
            _Prefs = new PreferenceBag(GetRegPath("Prefs"));
            colorIsHTML = GetColor("fiddler.ui.Colors.IsHTML", colorIsHTML);
            colorIsScript = GetColor("fiddler.ui.Colors.IsScript", colorIsScript);
            colorIsAuth = GetColor("fiddler.ui.Colors.IsAuth", colorIsAuth);
            colorLoadedFromSAZ = GetColor("fiddler.ui.Colors.LoadedFromSAZ", colorLoadedFromSAZ);
            if (bReportHTTPErrors)
            {
                bReportHTTPLintErrors = FiddlerApplication.Prefs.GetBoolPref("fiddler.lint.HTTP", false);
            }
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.filters.ResetOnRestart", false))
            {
                iShowProcessFilter = ProcessFilterCategories.All;
                DecryptWhichProcesses = ProcessFilterCategories.All;
            }
            iReporterUpdateInterval = FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.ReporterUpdateInterval", 400);
            bReloadSessionIDAsFlag = FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.ReloadIDAsFlag", bReloadSessionIDAsFlag);
            bDebugCertificateGeneration = FiddlerApplication.Prefs.GetBoolPref("fiddler.certmaker.Debug", bDebugCertificateGeneration);
            bUseSNIForCN = FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.SetCNFromSNI", false);
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.network.https.SupportedClientProtocolVersions", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                SslProtocols protocols = Utilities.ParseSSLProtocolString(stringPref);
                if (protocols != SslProtocols.None)
                {
                    oAcceptedClientHTTPSProtocols = protocols;
                }
            }
            stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.network.https.SupportedServerProtocolVersions", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                SslProtocols protocols2 = Utilities.ParseSSLProtocolString(stringPref);
                if (protocols2 != SslProtocols.None)
                {
                    oAcceptedServerHTTPSProtocols = protocols2;
                }
                bMimicClientHTTPSProtocols = stringPref.OICContains("<client>");
            }
            _cb_STREAM_LARGE_FILES = FiddlerApplication.Prefs.GetInt32Pref("fiddler.memory.DropIfOver", _cb_STREAM_LARGE_FILES);
            int num = FiddlerApplication.Prefs.GetInt32Pref("fiddler.memory.StreamAndForgetIfOver", -1);
            if (num < 0)
            {
                if (8 == IntPtr.Size)
                {
                    num = 0x7fffffc7;
                }
                else
                {
                    num = 0x2000000;
                }
            }
            cbAutoStreamAndForget = num;
        }

        internal static void _RestoreSessionListLayout()
        {
            if (((sLVColInfo != null) && (FiddlerApplication.UI != null)) && !bRevertToDefaultLayout)
            {
                int num = 0;
                string[] strArray = sLVColInfo.Split(new char[] { '\x00a7' }, StringSplitOptions.RemoveEmptyEntries);
                int num2 = FiddlerApplication.UI.lvSessions.Columns.Count - 1;
                foreach (string str in strArray)
                {
                    int num3;
                    string sColumnTitle = Utilities.TrimAfter(str, "~");
                    if (!int.TryParse(Utilities.TrimBefore(str, "~"), out num3))
                    {
                        num3 = -1;
                    }
                    ColumnHeader header = FiddlerApplication.UI.lvSessions.FindColumnByTitle(sColumnTitle);
                    if (header != null)
                    {
                        if (num3 > -1)
                        {
                            header.Width = num3;
                        }
                        int num4 = num++;
                        if (num4 > num2)
                        {
                            num4 = num2;
                        }
                        header.DisplayIndex = num4;
                    }
                }
            }
        }

        private static void _ShowCommandLineArgs()
        {
            string sMessage = "Usage:\n\tfiddler.exe [options] [FileToLoad.saz]\n\nOptions:\n\n-viewer\t\tLoad a new Fiddler window in non-proxy 'Viewer' mode\n-quiet\t\tSuppress prompts and alerts, minimize to the tray\n-noattach\t\tDo not register as the system proxy on startup\n-noversioncheck\tDo not check for new versions on startup\n-extoff\t\tDo not load Fiddler extensions\n-noscript\t\tDo not load FiddlerScript\n-port:####\tRun proxy on specified port\n-?\t\tShow this help content\n";
            FiddlerApplication.DoNotifyUser(sMessage, "Fiddler Command-Line Help");
        }

        internal static void EnsureFoldersExist()
        {
            try
            {
                if (!Directory.Exists(GetPath("Captures")))
                {
                    Directory.CreateDirectory(GetPath("Captures"));
                }
                if (!Directory.Exists(GetPath("Requests")))
                {
                    Directory.CreateDirectory(GetPath("Requests"));
                }
                if (!Directory.Exists(GetPath("Responses")))
                {
                    Directory.CreateDirectory(GetPath("Responses"));
                }
                if (!Directory.Exists(GetPath("Scripts")))
                {
                    Directory.CreateDirectory(GetPath("Scripts"));
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception, "Folder Creation Failed");
            }
            try
            {
                if ((!FiddlerApplication.Prefs.GetBoolPref("fiddler.script.delaycreate", true) && !File.Exists(GetPath("CustomRules"))) && File.Exists(GetPath("SampleRules")))
                {
                    File.Copy(GetPath("SampleRules"), GetPath("CustomRules"));
                }
            }
            catch (Exception exception2)
            {
                FiddlerApplication.DoNotifyUser(exception2, "Initial file copies failed");
            }
        }

        internal static void EnsurePanelSplittersAreVisible(frmViewer f)
        {
            try
            {
                if (f.pnlSessions.Width > (f.ClientRectangle.Width - 100))
                {
                    f.pnlSessions.Width = f.ClientRectangle.Width - 100;
                }
                if (f.tabsRequest.Height > (f.tabsViews.ClientRectangle.Height - 0x7d))
                {
                    f.tabsRequest.Height = f.tabsViews.ClientRectangle.Height - 0x7d;
                }
            }
            catch
            {
            }
        }

        public static System.Drawing.Color GetColor(string sPrefName, System.Drawing.Color colorDefault)
        {
            string stringPref = FiddlerApplication.Prefs.GetStringPref(sPrefName, null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                return Utilities.ParseColor(stringPref);
            }
            return colorDefault;
        }

        [CodeDescription("Return a filesystem path.")]
        public static string GetPath(string sWhatPath)
        {
            string folderPath;
            switch (sWhatPath)
            {
                case "App":
                    return (Path.GetDirectoryName(Application.ExecutablePath) + Path.DirectorySeparatorChar);

                case "AutoFiddlers_Machine":
                    return string.Concat(new object[] { Path.GetDirectoryName(Application.ExecutablePath), Path.DirectorySeparatorChar, "Scripts", Path.DirectorySeparatorChar });

                case "AutoFiddlers_User":
                    return (sUserPath + "Scripts" + Path.DirectorySeparatorChar);

                case "AutoResponderDefaultRules":
                    return (sUserPath + "AutoResponder.xml");

                case "Captures":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.captures", sUserPath + "Captures" + Path.DirectorySeparatorChar);

                case "CustomRules":
                    return sScriptPath;

                case "DefaultClientCertificate":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.defaultclientcert", sUserPath + "ClientCertificate.cer");

                case "FiddlerRootCert":
                    return (sUserPath + "DO_NOT_TRUST_FiddlerRoot.cer");

                case "Filters":
                    return (sUserPath + "Filters" + Path.DirectorySeparatorChar);

                case "Inspectors":
                    return string.Concat(new object[] { Path.GetDirectoryName(Application.ExecutablePath), Path.DirectorySeparatorChar, "Inspectors", Path.DirectorySeparatorChar });

                case "Inspectors_User":
                    return (sUserPath + "Inspectors" + Path.DirectorySeparatorChar);

                case "PerUser-ISA-Config":
                    folderPath = @"C:\";
                    try
                    {
                        folderPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                    }
                    catch (Exception)
                    {
                    }
                    return (folderPath + @"\microsoft\firewall client 2004\management.ini");

                case "PerMachine-ISA-Config":
                    folderPath = @"C:\";
                    try
                    {
                        folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                    }
                    catch (Exception)
                    {
                    }
                    return (folderPath + @"\microsoft\firewall client 2004\management.ini");

                case "MakeCert":
                    folderPath = FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.makecert", Path.GetDirectoryName(Application.ExecutablePath) + Path.DirectorySeparatorChar + "MakeCert.exe");
                    if (!File.Exists(folderPath))
                    {
                        folderPath = "MakeCert.exe";
                    }
                    return folderPath;

                case "MyDocs":
                    folderPath = @"C:\";
                    try
                    {
                        folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.Log.LogFormat("!!Initialization Error: Failed to retrieve path to your Documents folder.\nThis generally means you have a relative environment variable.\nDefaulting to {0}\n\n{1}", new object[] { folderPath, exception.Message });
                    }
                    return folderPath;

                case "Pac":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.pac", string.Concat(new object[] { sUserPath, "Scripts", Path.DirectorySeparatorChar, "BrowserPAC.js" }));

                case "Requests":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.requests", string.Concat(new object[] { sUserPath, "Captures", Path.DirectorySeparatorChar, "Requests", Path.DirectorySeparatorChar }));

                case "Responses":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.responses", string.Concat(new object[] { sUserPath, "Captures", Path.DirectorySeparatorChar, "Responses", Path.DirectorySeparatorChar }));

                case "Root":
                    return sUserPath;

                case "QuickExecHistory":
                    return (sUserPath + Path.DirectorySeparatorChar + "QuickExecHistory.txt");

                case "SafeTemp":
                    folderPath = @"C:\";
                    try
                    {
                        folderPath = Environment.GetFolderPath(Environment.SpecialFolder.InternetCache);
                        if (folderPath[folderPath.Length - 1] != Path.DirectorySeparatorChar)
                        {
                            folderPath = folderPath + Path.DirectorySeparatorChar;
                        }
                    }
                    catch (Exception exception2)
                    {
                        FiddlerApplication.DoNotifyUser("Failed to retrieve path to your Internet Cache folder.\nThis generally means you have a relative environment variable.\nDefaulting to C:\\\n\n" + exception2.Message, "GetPath(SafeTemp) Failed");
                    }
                    return folderPath;

                case "SampleRules":
                    return string.Concat(new object[] { Path.GetDirectoryName(Application.ExecutablePath), Path.DirectorySeparatorChar, "Scripts", Path.DirectorySeparatorChar, "SampleRules.js" });

                case "Scripts":
                    return (sUserPath + "Scripts" + Path.DirectorySeparatorChar);

                case "TemplateResponses":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.templateresponses", string.Concat(new object[] { Path.GetDirectoryName(Application.ExecutablePath), Path.DirectorySeparatorChar, "ResponseTemplates", Path.DirectorySeparatorChar }));

                case "TextEditor":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.texteditor", m_TextEditor);

                case "Tools":
                    return FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.Tools", string.Concat(new object[] { Path.GetDirectoryName(Application.ExecutablePath), Path.DirectorySeparatorChar, "Tools", Path.DirectorySeparatorChar }));

                case "Transcoders_Machine":
                    return string.Concat(new object[] { Path.GetDirectoryName(Application.ExecutablePath), Path.DirectorySeparatorChar, "ImportExport", Path.DirectorySeparatorChar });

                case "Transcoders_User":
                    return (sUserPath + "ImportExport" + Path.DirectorySeparatorChar);

                case "WINDIFF":
                {
                    string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.config.path.differ", null);
                    if (!string.IsNullOrEmpty(stringPref))
                    {
                        return stringPref;
                    }
                    if (m_CompareTool.OICEquals("windiff.exe"))
                    {
                        if (File.Exists(GetPath("App") + "windiff.exe"))
                        {
                            return (GetPath("App") + "windiff.exe");
                        }
                        try
                        {
                            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WinMerge.exe", false))
                            {
                                if (key != null)
                                {
                                    string str3 = (string) key.GetValue(string.Empty, null);
                                    if (str3 != null)
                                    {
                                        return str3;
                                    }
                                }
                            }
                        }
                        catch (Exception)
                        {
                        }
                    }
                    return m_CompareTool;
                }
            }
            return @"C:\";
        }

        public static string GetRedirUrl(string sKeyword)
        {
            return string.Format("{0}{1}", GetUrl("REDIR"), sKeyword);
        }

        public static string GetRegPath(string sWhatPath)
        {
            switch (sWhatPath)
            {
                case "Root":
                    return sRootKey;

                case "LMIsBeta":
                    return sRootKey;

                case "MenuExt":
                    return (sRootKey + @"MenuExt\");

                case "UI":
                    return (sRootKey + @"UI\");

                case "MRU":
                    return sRootKey;

                case "Dynamic":
                    return (sRootKey + @"Dynamic\");

                case "Prefs":
                    return (sRootKey + @"Prefs\");
            }
            return sRootKey;
        }

        [CodeDescription("Return a special Url.")]
        public static string GetUrl(string sWhatUrl)
        {
            switch (sWhatUrl)
            {
                case "AutoResponderHelp":
                    return (sRootUrl + "help/AutoResponder.asp");

                case "ChangeList":
                    return "http://www.telerik.com/support/whats-new/fiddler/release-history/fiddler-v2.x?";

                case "FiltersHelp":
                    return (sRootUrl + "help/Filters.asp");

                case "HelpContents":
                    return (sRootUrl + "help/?ver=");

                case "REDIR":
                    return "http://fiddler2.com/r/?";

                case "VerCheck":
                    return ((FiddlerApplication.Prefs.GetBoolPref("fiddler.updater.UseHTTPS", Environment.OSVersion.Version.Major > 5) ? "https" : "http") + "://www.telerik.com/UpdateCheck.aspx?isBeta=");

                case "InstallLatest":
                    if (!bIsBeta)
                    {
                        return (sSecureRootUrl + "r/?GetFiddler4");
                    }
                    return (sSecureRootUrl + "r/?GetFiddler4Beta");

                case "ShopAmazon":
                    return "http://www.fiddlerbook.com/r/?shop";

                case "PrioritySupport":
                    return "http://www.telerik.com/purchase/fiddler";
            }
            return sRootUrl;
        }

        internal static void MaximizeIfNeeded(frmViewer f)
        {
            if (fNeedToMaximizeOnload && !bQuietMode)
            {
                f.WindowState = FormWindowState.Maximized;
                if (f.pnlSessions.Width > (f.Width - 50))
                {
                    f.pnlSessions.Width = f.Width - 0x2d;
                }
                if (f.tabsRequest.Height > (f.Height - 250))
                {
                    f.tabsRequest.Height = f.Height - 0xf5;
                }
                if (f.pnlSessions.Width < 0x19)
                {
                    f.pnlSessions.Width = 0x19;
                }
                if (f.tabsRequest.Height < 0x19)
                {
                    f.tabsRequest.Height = 0x19;
                }
            }
        }

        internal static void PerformAppContainerCheck()
        {
            if ((!bIsViewOnly && !bQuietMode) && Utilities.IsWin8OrLater())
            {
                FiddlerApplication.Log.LogFormat("Windows 8+ AppContainer isolation feature detected.", new object[0]);
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.WarnAboutAppContainers", true))
                {
                    switch (MessageBox.Show(null, "Windows uses an isolation technology called 'AppContainer' that may interfere with traffic capture from Immersive Applications and the Edge browser. Use the WinConfig button in Fiddler's toolbar to enable traffic capture.\n\nWould you like to learn more?\n\nTo disable this warning, click 'Cancel'.", "AppContainer Configuration", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button2))
                    {
                        case DialogResult.Yes:
                            Utilities.LaunchHyperlink(GetRedirUrl("Win8EL"));
                            return;

                        case DialogResult.Cancel:
                            FiddlerApplication.Prefs.SetBoolPref("fiddler.proxy.WarnAboutAppContainers", false);
                            break;
                    }
                }
            }
        }

        internal static void PerformChromeGPOProxyCheck()
        {
            if (!bIsViewOnly && !bQuietMode)
            {
                try
                {
                    using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"Software\Policies\Google\Chrome", false))
                    {
                        if (key != null)
                        {
                            string str = (string) key.GetValue("ProxyMode");
                            if (str != null)
                            {
                                FiddlerApplication.Log.LogFormat("!WARNING Fiddler has detected that Chrome GPO specifies proxy configuration '{0}'.", new object[] { str });
                            }
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        internal static void PerformISAFirewallCheck()
        {
            if ((m_bCheckForISA && !bQuietMode) && !bIsViewOnly)
            {
                try
                {
                    if (File.Exists(GetPath("PerUser-ISA-Config")))
                    {
                        string inStr = string.Empty;
                        using (StreamReader reader = File.OpenText(GetPath("PerUser-ISA-Config")))
                        {
                            inStr = reader.ReadToEnd();
                        }
                        if (inStr.OICContains("EnableWebProxyAutoConfig=1"))
                        {
                            ShowISAFirewallWarning();
                            return;
                        }
                        if (inStr.OICContains("EnableWebProxyAutoConfig=0"))
                        {
                            return;
                        }
                    }
                    if (File.Exists(GetPath("PerMachine-ISA-Config")))
                    {
                        using (StreamReader reader2 = File.OpenText(GetPath("PerMachine-ISA-Config")))
                        {
                            if (reader2.ReadToEnd().OICContains("EnableWebProxyAutoConfig=1"))
                            {
                                ShowISAFirewallWarning();
                            }
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        internal static void PerformProxySettingsPerUserCheck()
        {
            if (!bIsViewOnly && !bQuietMode)
            {
                try
                {
                    using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings", false))
                    {
                        if ((key != null) && (Utilities.GetRegistryInt(key, "ProxySettingsPerUser", 1) == 0))
                        {
                            bool flag = Utilities.IsUserAnAdmin();
                            FiddlerApplication.Log.LogFormat("!WARNING Fiddler has detected that system or domain Group Policy has set ProxySettingsPerUser to 0. Unless Fiddler is run Elevated (e.g. Run As Administrator), it may not capture traffic from Internet Explorer and other programs. Current process {0} running Elevated.", new object[] { flag ? "IS" : "IS NOT" });
                            if (!flag && FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.WarnIfElevationRequired", true))
                            {
                                switch (MessageBox.Show("Fiddler has detected that system policy requires per-Machine proxy settings. Fiddler may not be able to watch traffic from Internet Explorer and other programs unless run as Adminstrator.\n\nWould you like to learn more?\n\nTo disable this warning, click 'Cancel'.", "Possible Conflict Detected", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk))
                                {
                                    case DialogResult.Yes:
                                        Utilities.LaunchHyperlink(GetRedirUrl("PerMachineProxy"));
                                        return;

                                    case DialogResult.Cancel:
                                        FiddlerApplication.Prefs.SetBoolPref("fiddler.proxy.WarnIfElevationRequired", false);
                                        break;
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        internal static void ReadFormSettings()
        {
            if (!bRevertToDefaultLayout)
            {
                try
                {
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(GetRegPath("UI"), RegistryKeyPermissionCheck.ReadSubTree))
                    {
                        if (key != null)
                        {
                            bAutoScroll = Utilities.GetRegistryBool(key, "AutoScroll", bSmartScroll);
                            bSearchUnmarkOldHits = Utilities.GetRegistryBool(key, "SearchUnmarkOldHits", bSearchUnmarkOldHits);
                            bSmartScroll = Utilities.GetRegistryBool(key, "SmartScroll", bSmartScroll);
                            bResetCounterOnClear = Utilities.GetRegistryBool(key, "ResetCounterOnClear", bResetCounterOnClear);
                            sLVColInfo = (string) key.GetValue("lvSessions_Columns");
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        internal static void RetrieveFormSettings(frmViewer f)
        {
            if (!bRevertToDefaultLayout)
            {
                f.StartPosition = FormStartPosition.Manual;
                try
                {
                    RegistryKey oReg = Registry.CurrentUser.OpenSubKey(GetRegPath("UI"), RegistryKeyPermissionCheck.ReadSubTree);
                    if (oReg != null)
                    {
                        f.miSessionListScroll.Checked = bAutoScroll;
                        f.miViewAutoScroll.Checked = bAutoScroll;
                        f.Bounds = new Rectangle(Utilities.GetRegistryInt(oReg, f.Name + "_Left", f.Left), Utilities.GetRegistryInt(oReg, f.Name + "_Top", f.Top), Utilities.GetRegistryInt(oReg, f.Name + "_Width", f.Width), Utilities.GetRegistryInt(oReg, f.Name + "_Height", f.Height));
                        f.pnlSessions.Width = (int) oReg.GetValue("pnlSessions_Width", f.pnlSessions.Width);
                        f.tabsRequest.Height = (int) oReg.GetValue("tabsRequest_Height", f.tabsRequest.Height);
                    }
                    Screen screen = Screen.FromRectangle(f.DesktopBounds);
                    Rectangle rectangle = Rectangle.Intersect(f.DesktopBounds, screen.WorkingArea);
                    if (rectangle.IsEmpty || ((rectangle.Width * rectangle.Height) < ((0.2 * f.Width) * f.Height)))
                    {
                        f.SetDesktopLocation(screen.WorkingArea.Left + 20, screen.WorkingArea.Top + 20);
                    }
                    if (oReg != null)
                    {
                        FormWindowState state = (FormWindowState) oReg.GetValue(f.Name + "_WState", f.WindowState);
                        if (state == FormWindowState.Maximized)
                        {
                            fNeedToMaximizeOnload = true;
                        }
                        oReg.Close();
                    }
                    int iLayoutMode = FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.layout.mode", 0);
                    if (iLayoutMode > 0)
                    {
                        f.actChangeToLayout(iLayoutMode);
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        internal static void RevertToDefaultLayout()
        {
            bRevertToDefaultLayout = true;
            flFontSize = 8.25f;
            colorDisabledEdit = COLOR_DEFAULT_DISABLEDEDIT;
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.toolbar.visible");
            FiddlerApplication.Prefs.RemovePref("fiddler.inspectors.hidelist");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.font.size");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.font.face");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.lastview");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.stayontop");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.rules.hideimages");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.layout.mode");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.rules.hideconnects");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.rules.removeencoding");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.sessionlist.updateinterval");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.WizardColumnSet");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.Colors.AutoResponded");
            FiddlerApplication.Prefs.RemovePref("fiddler.ui.Colors.LoadedFromSAZ");
            FiddlerApplication.Prefs.RemovePref("fiddler.inspectors.images.textwidth");
        }

        internal static void SaveNonUISettings()
        {
            if (!bIsViewOnly)
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(sRootKey))
                {
                    key.SetValue("StartupCount", iStartupCount);
                    Utilities.SetRegistryString(key, "FontSize", flFontSize.ToString(CultureInfo.InvariantCulture));
                    if (AppRecovery.IsRecovering)
                    {
                        key.SetValue("LastRecoveryWrite", DateTime.UtcNow.ToString("r"));
                    }
                    if (colorDisabledEdit != (SystemInformation.HighContrast ? COLOR_HICONTRASTDARK_DISABLEDEDIT : COLOR_DEFAULT_DISABLEDEDIT))
                    {
                        key.SetValue("colorDisabledEdit", colorDisabledEdit.ToArgb());
                    }
                    else
                    {
                        key.DeleteValue("colorDisabledEdit", false);
                    }
                    key.SetValue("AttachOnBoot", bAttachOnBoot);
                    key.SetValue("AllowRemote", m_bAllowRemoteConnections);
                    key.SetValue("ReuseServerSockets", bReuseServerSockets);
                    key.SetValue("ReuseClientSockets", bReuseClientSockets);
                    Utilities.SetRegistryString(key, "FiddlerBypass", sHostsThatBypassFiddler);
                    key.SetValue("ReportHTTPErrors", bReportHTTPErrors);
                    key.SetValue("GatewayType", (int) _UpstreamGateway);
                    key.SetValue("CaptureCONNECT", bCaptureCONNECT);
                    key.SetValue("CaptureFTP", bCaptureFTP);
                    key.SetValue("EnableIPv6", bEnableIPv6);
                    key.SetValue("EnableHighResTimers", SessionTimers.EnableHighResolutionTimers);
                    key.SetValue("BreakOnImages", bBreakOnImages);
                    key.SetValue("MapSocketToProcess", bMapSocketToProcess);
                    key.SetValue("UseLegacyEncryptionForSaz", !bUseAESForSAZ);
                    key.SetValue("AutoStreamAudioVideo", bStreamAudioVideo);
                    key.SetValue("CaptureHTTPS", bMITM_HTTPS);
                    key.SetValue("IgnoreServerCertErrors", bIgnoreServerCertErrors);
                    key.SetValue("CheckForUpdates", bVersionCheck);
                    key.SetValue("SendTelemetry", bEnableAnalytics);
                    key.SetValue("HookAllConnections", bHookAllConnections);
                    key.SetValue("HookWithPAC", bHookWithPAC);
                    key.SetValue("ShowProcessFilter", (int) iShowProcessFilter);
                    key.SetValue("HTTPSProcessFilter", (int) DecryptWhichProcesses);
                    key.SetValue("AutoReloadScript", bAutoLoadScript);
                    key.SetValue("HideOnMinimize", bHideOnMinimize);
                    key.SetValue("AlwaysShowTrayIcon", bAlwaysShowTrayIcon);
                    if (!bUsingPortOverride)
                    {
                        key.SetValue("ListenPort", m_ListenPort);
                    }
                    key.SetValue("HotkeyMod", iHotkeyMod);
                    key.SetValue("Hotkey", iHotkey);
                    key.SetValue("CheckForISA", m_bCheckForISA);
                    Utilities.SetRegistryString(key, "ScriptReferences", m_sAdditionalScriptReferences);
                    Utilities.SetRegistryString(key, "JSEditor", m_JSEditor);
                }
            }
        }

        internal static void SaveSettings(frmViewer f)
        {
            if (!bIsViewOnly)
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(GetRegPath("UI"), RegistryKeyPermissionCheck.ReadWriteSubTree))
                {
                    key.SetValue("AutoScroll", bAutoScroll);
                    key.SetValue("SmartScroll", bSmartScroll);
                    key.SetValue("SearchUnmarkOldHits", bSearchUnmarkOldHits);
                    key.SetValue("ResetCounterOnClear", bResetCounterOnClear);
                    key.SetValue(f.Name + "_WState", (int) f.WindowState);
                    if (f.WindowState != FormWindowState.Normal)
                    {
                        Rectangle restoreBounds = f.RestoreBounds;
                        key.SetValue(f.Name + "_Top", restoreBounds.Top);
                        key.SetValue(f.Name + "_Left", restoreBounds.Left);
                        key.SetValue(f.Name + "_Height", restoreBounds.Height);
                        key.SetValue(f.Name + "_Width", restoreBounds.Width);
                    }
                    else
                    {
                        key.SetValue(f.Name + "_Top", f.Top);
                        key.SetValue(f.Name + "_Left", f.Left);
                        key.SetValue(f.Name + "_Height", f.Height);
                        key.SetValue(f.Name + "_Width", f.Width);
                    }
                    if (f.miViewDefault.Checked)
                    {
                        key.SetValue("pnlSessions_Width", f.pnlSessions.Width);
                    }
                    key.SetValue("tabsRequest_Height", f.tabsRequest.Height);
                    string[] strArray = new string[f.lvSessions.Columns.Count];
                    for (int i = 0; i < f.lvSessions.Columns.Count; i++)
                    {
                        strArray[f.lvSessions.Columns[i].DisplayIndex] = string.Format("{0}~{1}", f.lvSessions.Columns[i].Text, f.lvSessions.Columns[i].Width);
                    }
                    key.SetValue("lvSessions_Columns", string.Join("\x00a7", strArray));
                }
                SaveNonUISettings();
            }
        }

        internal static void SetNoDecryptList(string sNewList)
        {
            if (string.IsNullOrEmpty(sNewList))
            {
                oHLSkipDecryption = null;
            }
            else
            {
                oHLSkipDecryption = new HostList();
                oHLSkipDecryption.AssignFromString(sNewList);
            }
        }

        internal static void ShowISAFirewallWarning()
        {
            DialogResult no;
            if (bQuietMode)
            {
                no = DialogResult.No;
            }
            else
            {
                no = MessageBox.Show("Fiddler has detected that you may be running Microsoft Firewall client\nin Web Browser Automatic Configuration mode. This may cause\nFiddler to detach from Internet Explorer unexpectedly.\n\nWould you like to learn more?\n\nTo disable this warning, click 'Cancel'.", "Possible Conflict Detected", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
            }
            switch (no)
            {
                case DialogResult.Yes:
                    Utilities.LaunchHyperlink(GetRedirUrl("ISA"));
                    return;

                case DialogResult.Cancel:
                    m_bCheckForISA = false;
                    break;
            }
        }

        [CodeDescription("Returns true if Fiddler is configured to accept remote clients.")]
        public static bool bAllowRemoteConnections
        {
            get
            {
                return m_bAllowRemoteConnections;
            }
            internal set
            {
                m_bAllowRemoteConnections = value;
            }
        }

        internal static bool bEnableAnalytics
        {
            get
            {
                return _bEnableAnalytics;
            }
            set
            {
                _bEnableAnalytics = value;
            }
        }

        public static bool bRevertToDefaultLayout
        {
            [CompilerGenerated]
            get
            {
                return <bRevertToDefaultLayout>k__BackingField;
            }
            internal [CompilerGenerated]
            set
            {
                <bRevertToDefaultLayout>k__BackingField = value;
            }
        }

        public static ProcessFilterCategories DecryptWhichProcesses
        {
            get
            {
                return _pfcDecyptFilter;
            }
            set
            {
                _pfcDecyptFilter = value;
            }
        }

        public static bool ForceExclusivePort
        {
            get
            {
                return m_bForceExclusivePort;
            }
            internal set
            {
                m_bForceExclusivePort = value;
            }
        }

        public static bool IgnoreServerCertErrors
        {
            get
            {
                return bIgnoreServerCertErrors;
            }
            set
            {
                bIgnoreServerCertErrors = value;
            }
        }

        public static int iReverseProxyForPort
        {
            get
            {
                return _iReverseProxyForPort;
            }
            set
            {
                if (((value > -1) && (value <= 0xffff)) && (value != m_ListenPort))
                {
                    _iReverseProxyForPort = value;
                }
                else
                {
                    FiddlerApplication.Log.LogFormat("!Invalid configuration. ReverseProxyForPort may not be set to {0}", new object[] { value });
                }
            }
        }

        [CodeDescription("Return path to user's FiddlerScript editor.")]
        public static string JSEditor
        {
            get
            {
                if (string.IsNullOrEmpty(m_JSEditor))
                {
                    m_JSEditor = GetPath("TextEditor");
                }
                return m_JSEditor;
            }
            set
            {
                m_JSEditor = value;
            }
        }

        public static int ListenPort
        {
            get
            {
                return m_ListenPort;
            }
            internal set
            {
                if ((value >= 0) && (value < 0x10000))
                {
                    m_ListenPort = value;
                    sFiddlerListenHostPort = Utilities.TrimAfter(sFiddlerListenHostPort, ':') + ":" + m_ListenPort.ToString();
                }
            }
        }

        public static bool QuietMode
        {
            get
            {
                return bQuietMode;
            }
            set
            {
                bQuietMode = value;
            }
        }

        internal static PreferenceBag RawPrefs
        {
            get
            {
                return _Prefs;
            }
        }

        public static string sHostsThatBypassFiddler
        {
            get
            {
                return m_sHostsThatBypassFiddler;
            }
            set
            {
                string inStr = value;
                if (inStr == null)
                {
                    inStr = string.Empty;
                }
                if (!inStr.OICContains("<-loopback>") && !inStr.OICContains("<loopback>"))
                {
                    inStr = "<-loopback>;" + inStr;
                }
                m_sHostsThatBypassFiddler = inStr;
            }
        }

        public static string sScriptReferences
        {
            get
            {
                return ("mscorlib.dll;system.dll;system.windows.forms.dll;" + Assembly.GetExecutingAssembly().Location + ";" + m_sAdditionalScriptReferences);
            }
        }

        public static GatewayType UpstreamGateway
        {
            get
            {
                return _UpstreamGateway;
            }
            internal set
            {
                if ((value < GatewayType.None) || (value > GatewayType.WPAD))
                {
                    value = GatewayType.System;
                }
                _UpstreamGateway = value;
                bForwardToGateway = value != GatewayType.None;
            }
        }
    }
}

