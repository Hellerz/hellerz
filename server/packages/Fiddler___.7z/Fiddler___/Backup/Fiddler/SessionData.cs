﻿namespace Fiddler
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;

    [Serializable]
    public class SessionData : ISerializable
    {
        public byte[] arrMetadata;
        public byte[] arrRequest;
        public byte[] arrResponse;
        public byte[] arrWebSocketMessages;

        public SessionData(Session oS)
        {
            MemoryStream oFS = new MemoryStream();
            oS.WriteRequestToStream(false, true, oFS);
            this.arrRequest = oFS.ToArray();
            oFS = new MemoryStream();
            oS.WriteResponseToStream(oFS, false);
            this.arrResponse = oFS.ToArray();
            oFS = new MemoryStream();
            oS.WriteMetadataToStream(oFS);
            this.arrMetadata = oFS.ToArray();
            oFS = new MemoryStream();
            oS.WriteWebSocketMessagesToStream(oFS);
            this.arrWebSocketMessages = oFS.ToArray();
        }

        public SessionData(SerializationInfo info, StreamingContext ctxt)
        {
            this.arrRequest = (byte[]) info.GetValue("Request", typeof(byte[]));
            this.arrResponse = (byte[]) info.GetValue("Response", typeof(byte[]));
            this.arrMetadata = (byte[]) info.GetValue("Metadata", typeof(byte[]));
            this.arrWebSocketMessages = (byte[]) info.GetValue("WSMsgs", typeof(byte[]));
        }

        public virtual void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("Request", this.arrRequest);
            info.AddValue("Response", this.arrResponse);
            info.AddValue("Metadata", this.arrMetadata);
            info.AddValue("WSMsgs", this.arrWebSocketMessages);
        }
    }
}

