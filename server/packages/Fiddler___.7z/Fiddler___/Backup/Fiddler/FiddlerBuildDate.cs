﻿namespace Fiddler
{
    using System;
    using System.Globalization;

    [AttributeUsage(AttributeTargets.Assembly, Inherited=false, AllowMultiple=false)]
    internal sealed class FiddlerBuildDate : Attribute
    {
        private DateTime _dtBuildDate;

        internal FiddlerBuildDate(string sBuildDate)
        {
            try
            {
                this._dtBuildDate = DateTime.ParseExact(sBuildDate, "yyyy/M/d", CultureInfo.InvariantCulture);
            }
            catch
            {
                FiddlerApplication.Log.LogFormat("Unable to parse FiddlerBuildDate: {0}", new object[] { sBuildDate });
                this._dtBuildDate = DateTime.Now;
            }
        }

        public override string ToString()
        {
            return this._dtBuildDate.ToLongDateString();
        }

        internal bool IsOutdated
        {
            get
            {
                return (this._dtBuildDate < DateTime.Now.AddDays(-200.0));
            }
        }
    }
}

