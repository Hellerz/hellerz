﻿namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Globalization;
    using System.Text;
    using System.Windows.Forms;

    internal class SessionProperties : Form
    {
        private Container components;
        private Session mySession;
        private StatusBar sbStatus;
        private RichTextBox txtProperties;

        internal SessionProperties(Session oSession)
        {
            this.InitializeComponent();
            this.txtProperties.BackColor = CONFIG.colorDisabledEdit;
            this.txtProperties.Font = new Font(this.txtProperties.Font.FontFamily, CONFIG.flFontSize);
            this.mySession = oSession;
            this.RefreshInfo();
        }

        private void ChangeSession(int iAdjustment)
        {
            int num = this.mySession.ViewItem.Index + iAdjustment;
            if ((num >= 0) && (num < FiddlerApplication.UI.lvSessions.TotalItemCount()))
            {
                ListViewItem item = FiddlerApplication.UI.lvSessions.Items[num];
                Session tag = item.Tag as Session;
                if (tag != null)
                {
                    this.mySession = tag;
                    this.RefreshInfo();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public static string GetSessionProperties(Session oS)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("SESSION STATE: {0}.\n", oS.state.ToString("g"));
            switch (oS.state)
            {
                case SessionStates.ReadingRequest:
                    long num;
                    builder.AppendFormat("UPLOAD PROGRESS: {0:N0}", oS.oRequest._PeekUploadProgress);
                    if ((oS.oRequest["Content-Length"].Length > 0) && long.TryParse(oS.oRequest["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num))
                    {
                        builder.AppendFormat(string.Format(" of {0:N0}", num), new object[0]);
                    }
                    builder.Append(" bytes.\n\n");
                    break;

                case SessionStates.ReadingResponse:
                    long num2;
                    builder.AppendFormat("DOWNLOAD PROGRESS: {0:N0}", oS.oResponse._PeekDownloadProgress);
                    if ((oS.oResponse["Content-Length"].Length > 0) && long.TryParse(oS.oResponse["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num2))
                    {
                        builder.AppendFormat(string.Format(" of {0:N0}", num2), new object[0]);
                    }
                    builder.Append(" bytes.\n\n");
                    goto Label_013B;
            }
        Label_013B:
            if ((oS.state >= SessionStates.SendingRequest) && oS.isFlagSet(SessionFlags.SentToGateway))
            {
                builder.Append("The request was forwarded to the gateway.\n");
            }
            if ((oS.requestBodyBytes != null) && (oS.requestBodyBytes.Length > 0))
            {
                builder.AppendFormat("Request Entity Size: {0:N0} bytes.\n", oS.requestBodyBytes.LongLength.ToString());
            }
            if (oS.responseBodyBytes != null)
            {
                builder.AppendFormat("Response Entity Size: {0:N0} bytes.\n", oS.responseBodyBytes.LongLength.ToString());
            }
            builder.Append("\n== FLAGS ==================\n");
            builder.AppendFormat("BitFlags: [{0}] 0x{1}\n", oS.BitFlags, ((int) oS.BitFlags).ToString("x"));
            List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>(oS.oFlags.Count);
            foreach (DictionaryEntry entry in oS.oFlags)
            {
                list.Add(new KeyValuePair<string, string>((entry.Key as string).ToUpper(CultureInfo.InvariantCulture), entry.Value as string));
            }
            list.Sort(delegate (KeyValuePair<string, string> firstPair, KeyValuePair<string, string> nextPair) {
                return firstPair.Key.CompareTo(nextPair.Key);
            });
            foreach (KeyValuePair<string, string> pair in list)
            {
                builder.AppendFormat("{0}: {1}\n", pair.Key, pair.Value);
            }
            builder.Append("\n== TIMING INFO ============\n");
            DateTime clientBeginRequest = oS.Timers.ClientBeginRequest;
            if (((clientBeginRequest.Ticks > 0L) && (clientBeginRequest.Date != DateTime.Today)) && (clientBeginRequest < DateTime.Now.AddHours(-2.0)))
            {
                builder.AppendFormat("\r\nThis traffic was captured on {0}.\r\n\r\n", clientBeginRequest.Date.ToLongDateString());
            }
            builder.Append(oS.Timers.ToString(true));
            if (oS.state >= SessionStates.ReadingResponse)
            {
                builder.Append(oS.isFlagSet(SessionFlags.ResponseStreamed) ? "\nThe response was streamed to the client as it was received.\n" : "\nThe response was buffered before delivery to the client.\n");
            }
            builder.Append("\n== WININET CACHE INFO ============\n");
            builder.Append(WinINETCache.GetCacheItemInfo(oS.fullUrl));
            builder.Append("\n* Note: Data above shows WinINET's current cache state, not the state at the time of the request.\n");
            if (Environment.OSVersion.Version.Major > 5)
            {
                builder.Append("* Note: Data above shows WinINET's Medium Integrity (non-Protected Mode) cache only.\n");
            }
            builder.Append("\n");
            return builder.ToString();
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(SessionProperties));
            this.sbStatus = new StatusBar();
            this.txtProperties = new RichTextBox();
            base.SuspendLayout();
            this.sbStatus.Location = new Point(0, 0x214);
            this.sbStatus.Name = "sbStatus";
            this.sbStatus.Size = new Size(0x204, 20);
            this.sbStatus.TabIndex = 1;
            this.sbStatus.Text = "Hit ESC to close, F5 to refresh, ALT+Up/Down to switch Session.";
            this.txtProperties.BorderStyle = BorderStyle.None;
            this.txtProperties.DetectUrls = false;
            this.txtProperties.Dock = DockStyle.Fill;
            this.txtProperties.Font = new Font("Lucida Console", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtProperties.Location = new Point(0, 0);
            this.txtProperties.Name = "txtProperties";
            this.txtProperties.ReadOnly = true;
            this.txtProperties.Size = new Size(0x204, 0x214);
            this.txtProperties.TabIndex = 2;
            this.txtProperties.Text = "";
            this.txtProperties.WordWrap = false;
            this.AutoScaleBaseSize = new Size(5, 13);
            base.ClientSize = new Size(0x204, 0x228);
            base.Controls.Add(this.txtProperties);
            base.Controls.Add(this.sbStatus);
            base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.KeyPreview = true;
            base.Name = "SessionProperties";
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.Manual;
            this.Text = "Session Properties";
            base.KeyDown += new KeyEventHandler(this.SessionProperties_KeyDown);
            base.KeyUp += new KeyEventHandler(this.SessionProperties_KeyUp);
            base.ResumeLayout(false);
        }

        private void RefreshInfo()
        {
            try
            {
                this.Text = string.Concat(new object[] { "Session Properties (", this.mySession.id, ") ", this.mySession.url });
                this.txtProperties.Text = GetSessionProperties(this.mySession);
                this.txtProperties.Select(0, 0);
            }
            catch (Exception exception)
            {
                this.txtProperties.Clear();
                this.txtProperties.AppendText(exception.Message + "\r\n" + exception.StackTrace);
            }
        }

        private void SessionProperties_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                case (Keys.Control | Keys.Up):
                case (Keys.Alt | Keys.Up):
                    e.SuppressKeyPress = e.Handled = true;
                    this.ChangeSession(-1);
                    break;

                case (Keys.Control | Keys.Right):
                case (Keys.Alt | Keys.Right):
                    break;

                case (Keys.Control | Keys.Down):
                case (Keys.Alt | Keys.Down):
                    e.SuppressKeyPress = e.Handled = true;
                    this.ChangeSession(1);
                    return;

                case Keys.F5:
                    e.SuppressKeyPress = e.Handled = true;
                    this.RefreshInfo();
                    return;

                default:
                    return;
            }
        }

        private void SessionProperties_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                e.SuppressKeyPress = e.Handled = true;
                base.Close();
            }
        }
    }
}

