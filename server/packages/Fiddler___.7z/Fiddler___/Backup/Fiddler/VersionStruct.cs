﻿namespace Fiddler
{
    using System;

    internal class VersionStruct
    {
        public bool bMustCleanInstall;
        public int Build;
        public int Major;
        public int Minor;
        public int Private;
        public string sWelcomeMsg;
        public string sWhatIsNew;
    }
}

