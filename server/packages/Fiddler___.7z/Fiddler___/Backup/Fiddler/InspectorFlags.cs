﻿namespace Fiddler
{
    using System;

    [Flags]
    public enum InspectorFlags
    {
        None,
        AlwaysCommitEdits,
        HideInAutoResponder,
        HideInNewWindow
    }
}

