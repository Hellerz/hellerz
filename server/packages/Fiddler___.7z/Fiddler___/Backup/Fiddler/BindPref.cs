﻿namespace Fiddler
{
    using System;

    [AttributeUsage(AttributeTargets.Field, Inherited=false, AllowMultiple=false)]
    public sealed class BindPref : Attribute
    {
        private string _sPrefName;

        public BindPref(string sName)
        {
            this._sPrefName = sName;
        }

        public string PrefName
        {
            get
            {
                return this._sPrefName;
            }
        }
    }
}

