﻿namespace Fiddler
{
    using System;

    public interface ISAZWriter
    {
        void AddFile(string sFilename, SAZWriterDelegate oSWD);
        bool CompleteArchive();
        bool SetPassword(string sPassword);

        string Comment { set; }

        string EncryptionMethod { get; }

        string EncryptionStrength { get; }

        string Filename { get; }
    }
}

