﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class UINotifyList : Form
    {
        private static string[] arrIgnoredPrefixes = null;
        private CheckBox cbEnabled;
        private ComboBox cbxNotifyLevel;
        private IContainer components;
        private static UINotifyList frmProtocolViolationList = null;
        private LinkLabel lnkFilter;
        private ListBox lvItems;
        private static object oLock = new object();
        private static List<NotifyItem> qWarningsToAdd = new List<NotifyItem>();
        private static StringFormat sfIDColumn = new StringFormat();
        private static StringFormat sfTextColumn = new StringFormat();

        static UINotifyList()
        {
            SetIgnoredPrefixes();
        }

        public UINotifyList()
        {
            this.InitializeComponent();
            base.Icon = Utilities.GetIconFromImage(FiddlerApplication.UI.imglSessionIcons.Images[12]);
            base.Size = new Size(FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.httperror.Width", base.Width), FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.httperror.Height", base.Height));
            base.StartPosition = FormStartPosition.Manual;
            base.Location = new Point(FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.httperror.Left", 100), FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.httperror.Top", 100));
            Screen screen = Screen.FromRectangle(base.DesktopBounds);
            Rectangle rectangle = Rectangle.Intersect(base.DesktopBounds, screen.WorkingArea);
            if (rectangle.IsEmpty || ((rectangle.Width * rectangle.Height) < ((0.2 * base.Width) * base.Height)))
            {
                base.SetDesktopLocation(screen.WorkingArea.Left + 20, screen.WorkingArea.Top + 20);
            }
            sfIDColumn.Alignment = StringAlignment.Center;
            sfIDColumn.LineAlignment = StringAlignment.Center;
            sfTextColumn.Alignment = StringAlignment.Near;
            sfTextColumn.LineAlignment = StringAlignment.Near;
            this.lvItems.Font = new Font(this.lvItems.Font.FontFamily, CONFIG.flFontSize);
            this.lvItems.DrawItem += new DrawItemEventHandler(this.lvItems_DrawItem);
            this.lvItems.MeasureItem += new MeasureItemEventHandler(this.lvItems_MeasureItem);
            this.cbEnabled.Checked = CONFIG.bReportHTTPErrors;
            this.cbxNotifyLevel.SelectedIndex = CONFIG.bReportHTTPLintErrors ? 1 : 0;
            this.cbxNotifyLevel.SelectedIndexChanged += new EventHandler(this.cbxNotifyLevel_SelectedIndexChanged);
            this.lnkFilter.Visible = this.cbEnabled.Checked && (1 == this.cbxNotifyLevel.SelectedIndex);
        }

        private void _InternalRefresh()
        {
            try
            {
                typeof(ListBox).InvokeMember("RefreshItems", BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Instance, null, this.lvItems, new object[0]);
            }
            catch
            {
            }
        }

        private void actDoInspect()
        {
            try
            {
                if (this.lvItems.SelectedItem != null)
                {
                    int iID = ((NotifyItem) this.lvItems.SelectedItem).iSessionID;
                    FiddlerApplication.UI.actSelectSessionsMatchingCriteria(1, delegate (Session oS) {
                        return oS.id == iID;
                    });
                    if (1 == FiddlerApplication.UI.lvSessions.SelectedCount)
                    {
                        FiddlerApplication.UI.lvSessions.SelectedItems[0].EnsureVisible();
                        FiddlerApplication.UI.lvSessions.SelectedItems[0].Focused = true;
                        FiddlerApplication.UI.actInspectSession();
                        FiddlerApplication.UI.lvSessions.Focus();
                        if (FiddlerApplication.UI.WindowState == FormWindowState.Minimized)
                        {
                            FiddlerApplication.UI.actRestoreWindow();
                        }
                    }
                    else if (FiddlerApplication.UI.lvSessions.SelectedCount == 0)
                    {
                        FiddlerApplication.UI.SetStatusText("Sorry, the selected Session with a protocol violation was already removed from the Web Sessions list.");
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Unable to select Session");
            }
        }

        private void ApplyFiltersToList()
        {
            if (arrIgnoredPrefixes != null)
            {
                List<NotifyItem> list = new List<NotifyItem>();
                foreach (NotifyItem item in this.lvItems.Items)
                {
                    list.Add(item);
                }
                this.lvItems.Items.Clear();
                NotifyItem[] unfiltered = GetUnfiltered(list.ToArray());
                this.UpdateUIOnMainThread(unfiltered);
            }
        }

        private void cbEnabled_Click(object sender, EventArgs e)
        {
            CONFIG.bReportHTTPErrors = this.cbEnabled.Checked;
            this.cbxNotifyLevel.Visible = this.cbEnabled.Checked;
            this.lnkFilter.Visible = this.cbEnabled.Checked && (1 == this.cbxNotifyLevel.SelectedIndex);
        }

        private void cbxNotifyLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            CONFIG.bReportHTTPLintErrors = 1 == this.cbxNotifyLevel.SelectedIndex;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.Lint.HTTP", CONFIG.bReportHTTPLintErrors);
            this.lnkFilter.Visible = this.cbEnabled.Checked && (1 == this.cbxNotifyLevel.SelectedIndex);
        }

        public static void ClearAllErrors()
        {
            UINotifyList frmProtocolViolationList;
            object obj2;
            bool lockTaken = false;
            try
            {
                Monitor.Enter(obj2 = oLock, ref lockTaken);
                frmProtocolViolationList = UINotifyList.frmProtocolViolationList;
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(obj2);
                }
            }
            if (frmProtocolViolationList != null)
            {
                try
                {
                    FiddlerApplication.UIInvokeAsync(new MethodInvoker(frmProtocolViolationList.ClearUIOnMainThread), null);
                }
                catch
                {
                }
            }
        }

        private void ClearUIOnMainThread()
        {
            if (frmProtocolViolationList != null)
            {
                frmProtocolViolationList.lvItems.Items.Clear();
                frmProtocolViolationList.Text = "Protocol Violation Report";
            }
        }

        public static void CloseWindow()
        {
            UINotifyList frmProtocolViolationList;
            object obj2;
            bool lockTaken = false;
            try
            {
                Monitor.Enter(obj2 = oLock, ref lockTaken);
                frmProtocolViolationList = UINotifyList.frmProtocolViolationList;
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(obj2);
                }
            }
            if (frmProtocolViolationList != null)
            {
                try
                {
                    FiddlerApplication.UIInvokeAsync(new MethodInvoker(frmProtocolViolationList.Close), null);
                }
                catch
                {
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private static NotifyItem[] GetUnfiltered(NotifyItem[] arrItems)
        {
            if (arrItems.Length < 1)
            {
                return arrItems;
            }
            if (UINotifyList.arrIgnoredPrefixes == null)
            {
                return arrItems;
            }
            string[] arrIgnoredPrefixes = UINotifyList.arrIgnoredPrefixes;
            List<NotifyItem> list = new List<NotifyItem>();
            foreach (NotifyItem item in arrItems)
            {
                bool flag = false;
                foreach (string str in arrIgnoredPrefixes)
                {
                    if (item.sText.Contains(" #" + str))
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    list.Add(item);
                }
            }
            return list.ToArray();
        }

        [DllImport("user32.dll", SetLastError=true)]
        public static extern IntPtr GetWindow(IntPtr hWnd, uint uDirection);
        private void InitializeComponent()
        {
            this.cbEnabled = new CheckBox();
            this.cbxNotifyLevel = new ComboBox();
            this.lvItems = new ListBox();
            this.lnkFilter = new LinkLabel();
            base.SuspendLayout();
            this.cbEnabled.AutoSize = true;
            this.cbEnabled.Location = new Point(12, 12);
            this.cbEnabled.Margin = new Padding(0);
            this.cbEnabled.Name = "cbEnabled";
            this.cbEnabled.Size = new Size(0xb9, 0x11);
            this.cbEnabled.TabIndex = 1;
            this.cbEnabled.Text = "&Warn on HTTP Protocol Violations";
            this.cbEnabled.UseVisualStyleBackColor = true;
            this.cbEnabled.Click += new EventHandler(this.cbEnabled_Click);
            this.cbxNotifyLevel.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxNotifyLevel.FormattingEnabled = true;
            this.cbxNotifyLevel.Items.AddRange(new object[] { "Basic checks", "Extended checks" });
            this.cbxNotifyLevel.Location = new Point(0xd3, 8);
            this.cbxNotifyLevel.Name = "cbxNotifyLevel";
            this.cbxNotifyLevel.Size = new Size(0x79, 0x15);
            this.cbxNotifyLevel.TabIndex = 2;
            this.lvItems.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.lvItems.Cursor = Cursors.Hand;
            this.lvItems.DrawMode = DrawMode.OwnerDrawVariable;
            this.lvItems.FormattingEnabled = true;
            this.lvItems.Location = new Point(12, 0x23);
            this.lvItems.Name = "lvItems";
            this.lvItems.ScrollAlwaysVisible = true;
            this.lvItems.SelectionMode = SelectionMode.MultiExtended;
            this.lvItems.Size = new Size(0x1f6, 0x9c);
            this.lvItems.TabIndex = 0;
            this.lvItems.SizeChanged += new EventHandler(this.lvItems_SizeChanged);
            this.lvItems.KeyDown += new KeyEventHandler(this.lvItems_KeyDown);
            this.lvItems.MouseDoubleClick += new MouseEventHandler(this.lvItems_MouseDoubleClick);
            this.lnkFilter.AutoSize = true;
            this.lnkFilter.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkFilter.Location = new Point(0x152, 12);
            this.lnkFilter.Name = "lnkFilter";
            this.lnkFilter.Size = new Size(0x2b, 13);
            this.lnkFilter.TabIndex = 3;
            this.lnkFilter.TabStop = true;
            this.lnkFilter.Text = "Filter...";
            this.lnkFilter.Visible = false;
            this.lnkFilter.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkFilter_LinkClicked);
            base.AutoScaleMode = AutoScaleMode.Inherit;
            base.ClientSize = new Size(0x20f, 0xcf);
            base.Controls.Add(this.lnkFilter);
            base.Controls.Add(this.lvItems);
            base.Controls.Add(this.cbxNotifyLevel);
            base.Controls.Add(this.cbEnabled);
            this.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.KeyPreview = true;
            this.MinimumSize = new Size(400, 120);
            base.Name = "UINotifyList";
            this.Text = "Protocol Violation Report";
            base.FormClosing += new FormClosingEventHandler(this.UINotifyList_FormClosing);
            base.KeyDown += new KeyEventHandler(this.UINotifyList_KeyDown);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lnkFilter_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string sDefault = FiddlerApplication.Prefs.GetStringPref("fiddler.Lint.SuppressList", string.Empty).ToUpper();
            string sValue = frmPrompt.GetUserString(this, "Hide Warnings", "Enter a comma-delimited list of Warnings to hide. To specify an entire class of warnings, specify only the prefix, e.g.:\n   L, M016", sDefault, true, frmPrompt.PromptIcon.Default);
            if (sValue != null)
            {
                if (string.Empty == sValue)
                {
                    FiddlerApplication.Prefs.RemovePref("fiddler.Lint.SuppressList");
                }
                else
                {
                    FiddlerApplication.Prefs.SetStringPref("fiddler.Lint.SuppressList", sValue);
                }
                SetIgnoredPrefixes();
                this.ApplyFiltersToList();
            }
        }

        private void lvItems_DrawItem(object sender, DrawItemEventArgs e)
        {
            if ((e.Index >= 0) && (e.Index < this.lvItems.Items.Count))
            {
                if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                {
                    e.Graphics.FillRectangle(Brushes.LightYellow, e.Bounds);
                }
                else
                {
                    e.DrawBackground();
                }
                e.Graphics.DrawRectangle(Pens.AliceBlue, e.Bounds);
                NotifyItem item = (NotifyItem) this.lvItems.Items[e.Index];
                Rectangle layoutRectangle = new Rectangle(e.Bounds.X, e.Bounds.Y, 50, e.Bounds.Height);
                e.Graphics.DrawString("#" + item.iSessionID.ToString(), this.lvItems.Font, Brushes.Blue, layoutRectangle, sfIDColumn);
                Rectangle rectangle2 = new Rectangle(e.Bounds.X + 50, e.Bounds.Y + 3, e.Bounds.Width - 50, e.Bounds.Height);
                e.Graphics.DrawString(item.sText, this.lvItems.Font, Brushes.Black, rectangle2, sfTextColumn);
                e.DrawFocusRectangle();
            }
        }

        private void lvItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (!e.Control)
            {
                if (e.KeyCode == Keys.Return)
                {
                    e.Handled = e.SuppressKeyPress = true;
                    this.actDoInspect();
                }
                else if (e.KeyCode == Keys.Delete)
                {
                    e.Handled = e.SuppressKeyPress = true;
                    this.lvItems.BeginUpdate();
                    for (int i = this.lvItems.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        this.lvItems.Items.RemoveAt(this.lvItems.SelectedIndices[i]);
                    }
                    this.lvItems.EndUpdate();
                    this.Text = string.Format("Protocol Violation Report ({0})", this.lvItems.Items.Count);
                }
            }
            else
            {
                switch (e.KeyCode)
                {
                    case Keys.A:
                        e.Handled = e.SuppressKeyPress = true;
                        Utilities.SendMessage(this.lvItems.Handle, 0x185, (IntPtr) 1, (IntPtr) (-1));
                        return;

                    case Keys.B:
                        return;

                    case Keys.C:
                        e.Handled = e.SuppressKeyPress = true;
                        if (this.lvItems.SelectedItems.Count >= 1)
                        {
                            StringBuilder builder = new StringBuilder();
                            for (int j = 0; j < this.lvItems.SelectedItems.Count; j++)
                            {
                                NotifyItem item = (NotifyItem) this.lvItems.SelectedItems[j];
                                builder.AppendFormat("{0}\t{1}", item.iSessionID, item.sText);
                                if (j < (this.lvItems.SelectedItems.Count - 1))
                                {
                                    builder.AppendLine();
                                }
                            }
                            Utilities.CopyToClipboard(builder.ToString());
                            return;
                        }
                        return;

                    case Keys.X:
                        e.Handled = e.SuppressKeyPress = true;
                        this.lvItems.Items.Clear();
                        this.Text = string.Format("Protocol Violation Report ({0})", this.lvItems.Items.Count);
                        return;

                    default:
                        return;
                }
            }
        }

        private void lvItems_MeasureItem(object sender, MeasureItemEventArgs e)
        {
            e.ItemWidth = this.lvItems.ClientSize.Width;
            int width = (e.ItemWidth - 50) - SystemInformation.VerticalScrollBarWidth;
            SizeF ef = e.Graphics.MeasureString(((NotifyItem) this.lvItems.Items[e.Index]).sText, this.lvItems.Font, width, sfTextColumn);
            e.ItemHeight = Math.Min(0xff, ((int) Math.Ceiling((double) ef.Height)) + 6);
        }

        private void lvItems_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.actDoInspect();
        }

        private void lvItems_SizeChanged(object sender, EventArgs e)
        {
            this._InternalRefresh();
        }

        public static void ReportHTTPError(int iSessionID, string sErrorDetails)
        {
            List<NotifyItem> list;
            bool lockTaken = false;
            try
            {
                Monitor.Enter(list = qWarningsToAdd, ref lockTaken);
                qWarningsToAdd.Add(new NotifyItem(iSessionID, sErrorDetails));
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(list);
                }
            }
            ScheduledTasks.ScheduleWork("UpdateHTTPErrorList", 400, new SimpleEventHandler(UINotifyList.UpdateUI));
        }

        private static void SetIgnoredPrefixes()
        {
            string[] strArray = FiddlerApplication.Prefs.GetStringPref("fiddler.Lint.SuppressList", string.Empty).ToUpper().Split(new char[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (strArray.Length < 1)
            {
                arrIgnoredPrefixes = null;
            }
            arrIgnoredPrefixes = strArray;
        }

        [DllImport("user32.dll", SetLastError=true)]
        public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int W, int H, uint uFlags);
        private void UINotifyList_FormClosing(object sender, FormClosingEventArgs e)
        {
            object obj2;
            if (base.WindowState == FormWindowState.Normal)
            {
                FiddlerApplication.Prefs.SetInt32Pref("fiddler.ui.httperror.Top", base.Top);
                FiddlerApplication.Prefs.SetInt32Pref("fiddler.ui.httperror.Left", base.Left);
                FiddlerApplication.Prefs.SetInt32Pref("fiddler.ui.httperror.Width", base.Width);
                FiddlerApplication.Prefs.SetInt32Pref("fiddler.ui.httperror.Height", base.Height);
            }
            bool lockTaken = false;
            try
            {
                Monitor.Enter(obj2 = oLock, ref lockTaken);
                frmProtocolViolationList = null;
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(obj2);
                }
            }
        }

        private void UINotifyList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                e.SuppressKeyPress = e.Handled = true;
                base.Close();
            }
            else if (e.KeyCode == Keys.F5)
            {
                this._InternalRefresh();
            }
        }

        internal static void UpdateUI()
        {
            if (!FiddlerApplication.isClosing)
            {
                NotifyItem[] unfiltered;
                List<NotifyItem> list;
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(list = qWarningsToAdd, ref lockTaken);
                    unfiltered = qWarningsToAdd.ToArray();
                    qWarningsToAdd.Clear();
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(list);
                    }
                }
                unfiltered = GetUnfiltered(unfiltered);
                if (unfiltered.Length >= 1)
                {
                    if (frmProtocolViolationList == null)
                    {
                        object obj2;
                        bool flag = false;
                        try
                        {
                            Monitor.Enter(obj2 = oLock, ref flag);
                            if (frmProtocolViolationList == null)
                            {
                                FiddlerApplication.UIInvoke(delegate {
                                    frmProtocolViolationList = new UINotifyList();
                                    frmProtocolViolationList.Owner = FiddlerApplication.UI;
                                    frmProtocolViolationList.Show(FiddlerApplication.UI);
                                    IntPtr hWndInsertAfter = GetWindow(FiddlerApplication.UI.Handle, 3);
                                    SetWindowPos(frmProtocolViolationList.Handle, window, frmProtocolViolationList.Left, frmProtocolViolationList.Top, frmProtocolViolationList.Width, frmProtocolViolationList.Height, 0x10);
                                });
                            }
                        }
                        finally
                        {
                            if (flag)
                            {
                                Monitor.Exit(obj2);
                            }
                        }
                    }
                    FiddlerApplication.UI.BeginInvoke(new LogProtocolViolation(frmProtocolViolationList.UpdateUIOnMainThread), new object[] { unfiltered });
                }
            }
        }

        private void UpdateUIOnMainThread(NotifyItem[] oItems)
        {
            if (frmProtocolViolationList != null)
            {
                frmProtocolViolationList.lvItems.Items.AddRange(oItems);
                frmProtocolViolationList.Text = string.Format("Protocol Violation Report ({0})", this.lvItems.Items.Count);
            }
        }

        protected override bool ShowWithoutActivation
        {
            get
            {
                return true;
            }
        }

        private delegate void LogProtocolViolation(UINotifyList.NotifyItem[] oItems);

        private class NotifyItem
        {
            public int iSessionID;
            public string sText;

            public NotifyItem(int iID, string sWarning)
            {
                this.iSessionID = iID;
                this.sText = sWarning;
            }
        }
    }
}

