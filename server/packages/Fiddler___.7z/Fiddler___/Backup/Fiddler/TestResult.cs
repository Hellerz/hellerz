﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public class TestResult
    {
        [CompilerGenerated]
        private bool <IsPassing>k__BackingField;
        [CompilerGenerated]
        private Session <sessOriginal>k__BackingField;
        [CompilerGenerated]
        private Session <sessRerun>k__BackingField;

        internal TestResult(Session sessionOriginal, Session sessionRerun, bool passed)
        {
            this.sessOriginal = sessionOriginal;
            this.sessRerun = sessionRerun;
            this.IsPassing = passed;
        }

        public override string ToString()
        {
            return ((this.IsPassing ? "PASS - " : "FAIL - ") + this.sessOriginal.RequestMethod + " " + this.sessOriginal.fullUrl);
        }

        public bool IsPassing
        {
            [CompilerGenerated]
            get
            {
                return this.<IsPassing>k__BackingField;
            }
            internal [CompilerGenerated]
            set
            {
                this.<IsPassing>k__BackingField = value;
            }
        }

        public Session sessOriginal
        {
            [CompilerGenerated]
            get
            {
                return this.<sessOriginal>k__BackingField;
            }
            internal [CompilerGenerated]
            set
            {
                this.<sessOriginal>k__BackingField = value;
            }
        }

        public Session sessRerun
        {
            [CompilerGenerated]
            get
            {
                return this.<sessRerun>k__BackingField;
            }
            internal [CompilerGenerated]
            set
            {
                this.<sessRerun>k__BackingField = value;
            }
        }
    }
}

