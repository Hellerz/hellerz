﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Windows.Forms;

    internal class InspectorComparer : IComparer<TabPage>
    {
        public int Compare(TabPage x, TabPage y)
        {
            return ((x.Tag as Inspector2).GetOrder() - (y.Tag as Inspector2).GetOrder());
        }
    }
}

