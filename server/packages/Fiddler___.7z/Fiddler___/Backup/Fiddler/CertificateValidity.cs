﻿namespace Fiddler
{
    using System;

    public enum CertificateValidity
    {
        Default,
        ConfirmWithUser,
        ForceInvalid,
        ForceValid
    }
}

