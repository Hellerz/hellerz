﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    internal delegate void alerterDelegate(frmAlert oAlert);
}

