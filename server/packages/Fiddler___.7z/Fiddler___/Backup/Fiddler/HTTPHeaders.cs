﻿namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;

    public abstract class HTTPHeaders
    {
        protected Encoding _HeaderEncoding = CONFIG.oHeaderEncoding;
        [CodeDescription("HTTP version (e.g. HTTP/1.1).")]
        public string HTTPVersion = "HTTP/1.1";
        protected List<HTTPHeaderItem> storage = new List<HTTPHeaderItem>();

        protected HTTPHeaders()
        {
        }

        [CodeDescription("Add a new header containing the specified name and value.")]
        public HTTPHeaderItem Add(string sHeaderName, string sValue)
        {
            HTTPHeaderItem item = new HTTPHeaderItem(sHeaderName, sValue);
            try
            {
                this.GetWriterLock();
                this.storage.Add(item);
            }
            finally
            {
                this.FreeWriterLock();
            }
            return item;
        }

        public void AddRange(IEnumerable<HTTPHeaderItem> collHIs)
        {
            try
            {
                this.GetWriterLock();
                this.storage.AddRange(collHIs);
            }
            finally
            {
                this.FreeWriterLock();
            }
        }

        public string AllValues(string sHeaderName)
        {
            List<HTTPHeaderItem> list = this.FindAll(sHeaderName);
            if (list.Count == 0)
            {
                return string.Empty;
            }
            if (list.Count == 1)
            {
                return list[0].Value;
            }
            List<string> list2 = new List<string>();
            foreach (HTTPHeaderItem item in list)
            {
                list2.Add(item.Value);
            }
            return string.Join(", ", list2.ToArray());
        }

        public abstract bool AssignFromString(string sHeaders);
        public virtual int ByteCount()
        {
            return this.ToString().Length;
        }

        [CodeDescription("Returns an integer representing the number of headers.")]
        public int Count()
        {
            int count;
            try
            {
                this.GetReaderLock();
                count = this.storage.Count;
            }
            finally
            {
                this.FreeReaderLock();
            }
            return count;
        }

        public int CountOf(string sHeaderName)
        {
            Action<HTTPHeaderItem> action = null;
            int iResult = 0;
            try
            {
                this.GetReaderLock();
                if (action == null)
                {
                    action = delegate (HTTPHeaderItem oHI) {
                        if (string.Equals(sHeaderName, oHI.Name, StringComparison.OrdinalIgnoreCase))
                        {
                            iResult++;
                        }
                    };
                }
                this.storage.ForEach(action);
            }
            finally
            {
                this.FreeReaderLock();
            }
            return iResult;
        }

        [CodeDescription("Returns true if the Headers collection contains a header of the specified (case-insensitive) name.")]
        public bool Exists(string sHeaderName)
        {
            if (!string.IsNullOrEmpty(sHeaderName))
            {
                try
                {
                    this.GetReaderLock();
                    for (int i = 0; i < this.storage.Count; i++)
                    {
                        if (string.Equals(this.storage[i].Name, sHeaderName, StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                }
                finally
                {
                    this.FreeReaderLock();
                }
            }
            return false;
        }

        [CodeDescription("Returns true if the collection contains a header of the specified (case-insensitive) name, and sHeaderValue (case-insensitive) is part of the Header's value.")]
        public bool ExistsAndContains(string sHeaderName, string sHeaderValue)
        {
            if (!string.IsNullOrEmpty(sHeaderName))
            {
                try
                {
                    this.GetReaderLock();
                    for (int i = 0; i < this.storage.Count; i++)
                    {
                        if (this.storage[i].Name.OICEquals(sHeaderName) && this.storage[i].Value.OICContains(sHeaderValue))
                        {
                            return true;
                        }
                    }
                }
                finally
                {
                    this.FreeReaderLock();
                }
            }
            return false;
        }

        [CodeDescription("Returns true if the collection contains a header of the specified (case-insensitive) name, with value sHeaderValue (case-insensitive).")]
        public bool ExistsAndEquals(string sHeaderName, string sHeaderValue)
        {
            if (!string.IsNullOrEmpty(sHeaderName))
            {
                try
                {
                    this.GetReaderLock();
                    for (int i = 0; i < this.storage.Count; i++)
                    {
                        if (this.storage[i].Name.OICEquals(sHeaderName) && this.storage[i].Value.Trim().OICEquals(sHeaderValue))
                        {
                            return true;
                        }
                    }
                }
                finally
                {
                    this.FreeReaderLock();
                }
            }
            return false;
        }

        [CodeDescription("Returns true if the Headers collection contains a header of the specified (case-insensitive) name.")]
        public bool ExistsAny(IEnumerable<string> sHeaderNames)
        {
            if (sHeaderNames != null)
            {
                try
                {
                    this.GetReaderLock();
                    for (int i = 0; i < this.storage.Count; i++)
                    {
                        foreach (string str in sHeaderNames)
                        {
                            if (string.Equals(this.storage[i].Name, str, StringComparison.OrdinalIgnoreCase))
                            {
                                return true;
                            }
                        }
                    }
                }
                finally
                {
                    this.FreeReaderLock();
                }
            }
            return false;
        }

        public List<HTTPHeaderItem> FindAll(string sHeaderName)
        {
            Predicate<HTTPHeaderItem> match = null;
            List<HTTPHeaderItem> list;
            try
            {
                this.GetReaderLock();
                if (match == null)
                {
                    match = delegate (HTTPHeaderItem oHI) {
                        return string.Equals(sHeaderName, oHI.Name, StringComparison.OrdinalIgnoreCase);
                    };
                }
                list = this.storage.FindAll(match);
            }
            finally
            {
                this.FreeReaderLock();
            }
            return list;
        }

        protected internal void FreeReaderLock()
        {
            Monitor.Exit(this.storage);
        }

        protected void FreeWriterLock()
        {
            Monitor.Exit(this.storage);
        }

        public IEnumerator GetEnumerator()
        {
            return this.storage.GetEnumerator();
        }

        protected internal void GetReaderLock()
        {
            Monitor.Enter(this.storage);
        }

        [CodeDescription("Returns a string representing the value of the named token within the named header.")]
        public string GetTokenValue(string sHeaderName, string sTokenName)
        {
            string str = this[sHeaderName];
            if (string.IsNullOrEmpty(str))
            {
                return null;
            }
            return Utilities.ExtractAttributeValue(str, sTokenName);
        }

        protected void GetWriterLock()
        {
            Monitor.Enter(this.storage);
        }

        public void Remove(HTTPHeaderItem oRemove)
        {
            try
            {
                this.GetWriterLock();
                this.storage.Remove(oRemove);
            }
            finally
            {
                this.FreeWriterLock();
            }
        }

        [CodeDescription("Removes ALL headers from the header collection which have the specified (case-insensitive) name.")]
        public void Remove(string sHeaderName)
        {
            if (!string.IsNullOrEmpty(sHeaderName))
            {
                try
                {
                    this.GetWriterLock();
                    for (int i = this.storage.Count - 1; i >= 0; i--)
                    {
                        if (this.storage[i].Name.OICEquals(sHeaderName))
                        {
                            this.storage.RemoveAt(i);
                        }
                    }
                }
                finally
                {
                    this.FreeWriterLock();
                }
            }
        }

        public void RemoveAll()
        {
            try
            {
                this.GetWriterLock();
                this.storage.Clear();
            }
            finally
            {
                this.FreeWriterLock();
            }
        }

        [CodeDescription("Removes ALL headers from the header collection which have the specified (case-insensitive) names.")]
        public void RemoveRange(string[] arrToRemove)
        {
            if ((arrToRemove != null) && (arrToRemove.Length >= 1))
            {
                try
                {
                    this.GetWriterLock();
                    for (int i = this.storage.Count - 1; i >= 0; i--)
                    {
                        foreach (string str in arrToRemove)
                        {
                            if (this.storage[i].Name.OICEquals(str))
                            {
                                this.storage.RemoveAt(i);
                                break;
                            }
                        }
                    }
                }
                finally
                {
                    this.FreeWriterLock();
                }
            }
        }

        [CodeDescription("Renames ALL headers in the header collection which have the specified (case-insensitive) name.")]
        public bool RenameHeaderItems(string sOldHeaderName, string sNewHeaderName)
        {
            bool flag = false;
            try
            {
                this.GetReaderLock();
                for (int i = 0; i < this.storage.Count; i++)
                {
                    if (this.storage[i].Name.OICEquals(sOldHeaderName))
                    {
                        this.storage[i].Name = sNewHeaderName;
                        flag = true;
                    }
                }
            }
            finally
            {
                this.FreeReaderLock();
            }
            return flag;
        }

        public HTTPHeaderItem[] ToArray()
        {
            HTTPHeaderItem[] itemArray;
            try
            {
                this.GetReaderLock();
                itemArray = this.storage.ToArray();
            }
            finally
            {
                this.FreeReaderLock();
            }
            return itemArray;
        }

        internal bool TryGetEntitySize(out uint iSize)
        {
            iSize = 0;
            if (this.ExistsAndEquals("Transfer-Encoding", "chunked"))
            {
                return false;
            }
            return uint.TryParse(this["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out iSize);
        }

        [CodeDescription("Indexer property. Returns HTTPHeaderItem by index.")]
        public HTTPHeaderItem this[int iHeaderNumber]
        {
            get
            {
                HTTPHeaderItem item;
                try
                {
                    this.GetReaderLock();
                    item = this.storage[iHeaderNumber];
                }
                finally
                {
                    this.FreeReaderLock();
                }
                return item;
            }
            set
            {
                try
                {
                    this.GetWriterLock();
                    this.storage[iHeaderNumber] = value;
                }
                finally
                {
                    this.FreeWriterLock();
                }
            }
        }

        [CodeDescription("Indexer property. Gets or sets the value of a header. In the case of Gets, the value of the FIRST header of that name is returned.\nIf the header does not exist, returns null.\nIn the case of Sets, the value of the FIRST header of that name is updated.\nIf the header does not exist, it is added.")]
        public string this[string HeaderName]
        {
            get
            {
                string str;
                try
                {
                    this.GetReaderLock();
                    for (int i = 0; i < this.storage.Count; i++)
                    {
                        if (string.Equals(this.storage[i].Name, HeaderName, StringComparison.OrdinalIgnoreCase))
                        {
                            return this.storage[i].Value;
                        }
                    }
                    str = string.Empty;
                }
                finally
                {
                    this.FreeReaderLock();
                }
                return str;
            }
            set
            {
                for (int i = 0; i < this.storage.Count; i++)
                {
                    if (string.Equals(this.storage[i].Name, HeaderName, StringComparison.OrdinalIgnoreCase))
                    {
                        this.storage[i].Value = value;
                        return;
                    }
                }
                this.Add(HeaderName, value);
            }
        }
    }
}

