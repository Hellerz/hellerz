﻿namespace Fiddler
{
    using System;

    [Flags]
    public enum SessionFlags
    {
        ClientPipeReused = 8,
        Ignored = 4,
        ImportedFromOtherTool = 0x400,
        IsBlindTunnel = 0x1000,
        IsDecryptingTunnel = 0x2000,
        IsFTP = 2,
        IsHTTPS = 1,
        IsRPCTunnel = 0x200000,
        IsWebSocketTunnel = 0x40000,
        LoadedFromSAZ = 0x200,
        None = 0,
        ProtocolViolationInRequest = 0x8000,
        ProtocolViolationInResponse = 0x10000,
        RequestBodyDropped = 0x100000,
        RequestGeneratedByFiddler = 0x80,
        RequestStreamed = 0x20,
        ResponseBodyDropped = 0x20000,
        ResponseGeneratedByFiddler = 0x100,
        ResponseStreamed = 0x40,
        SentToGateway = 0x800,
        SentToSOCKSGateway = 0x80000,
        ServedFromCache = 0x4000,
        ServerPipeReused = 0x10
    }
}

