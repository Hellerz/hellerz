﻿namespace Fiddler
{
    using System;
    using System.IO;

    public interface ISAZReader
    {
        void Close();
        byte[] GetFileBytes(string sFilename);
        Stream GetFileStream(string sFilename);
        string[] GetRequestFileList();

        string Comment { get; }

        string EncryptionMethod { get; }

        string EncryptionStrength { get; }

        string Filename { get; }
    }
}

