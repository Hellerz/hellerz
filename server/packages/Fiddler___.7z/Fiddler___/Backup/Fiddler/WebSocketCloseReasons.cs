﻿namespace Fiddler
{
    using System;

    public enum WebSocketCloseReasons : short
    {
        GoingAway = 0x3e9,
        InternalServerError = 0x3f3,
        InvalidPayloadData = 0x3ef,
        MandatoryExtension = 0x3f2,
        MessageTooBig = 0x3f1,
        Normal = 0x3e8,
        PolicyViolation = 0x3f0,
        ProtocolError = 0x3ea,
        Reserved1005 = 0x3ed,
        Reserved1006 = 0x3ee,
        Reserved1015 = 0x3f7,
        Undefined1004 = 0x3ec,
        UnsupportedData = 0x3eb
    }
}

