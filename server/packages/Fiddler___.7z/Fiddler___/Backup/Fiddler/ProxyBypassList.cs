﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;

    internal class ProxyBypassList
    {
        private bool _BypassOnLocal;
        private List<Regex> _RegExBypassList;

        public ProxyBypassList(string sBypassList)
        {
            if (!string.IsNullOrEmpty(sBypassList))
            {
                this.AssignBypassList(sBypassList);
            }
        }

        private void AssignBypassList(string sBypassList)
        {
            this._BypassOnLocal = false;
            this._RegExBypassList = null;
            if (!string.IsNullOrEmpty(sBypassList))
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Build Bypass List from: {0}\n", new object[] { sBypassList });
                }
                string[] strArray = sBypassList.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                if (strArray.Length >= 1)
                {
                    List<string> list = null;
                    foreach (string str in strArray)
                    {
                        string inStr = str.Trim();
                        if (inStr.Length != 0)
                        {
                            if (inStr.OICEquals("<local>"))
                            {
                                this._BypassOnLocal = true;
                            }
                            else if (!inStr.OICEquals("<-loopback>"))
                            {
                                if (!inStr.Contains("://"))
                                {
                                    inStr = "*://" + inStr;
                                }
                                bool flag = inStr.IndexOf(':') == inStr.LastIndexOf(':');
                                inStr = Utilities.RegExEscape(inStr, true, !flag);
                                if (flag)
                                {
                                    inStr = inStr + @"(:\d+)?$";
                                }
                                if (list == null)
                                {
                                    list = new List<string>();
                                }
                                if (!list.Contains(inStr))
                                {
                                    list.Add(inStr);
                                }
                            }
                        }
                    }
                    if (list != null)
                    {
                        if (CONFIG.bDebugSpew)
                        {
                            FiddlerApplication.DebugSpew("Proxy Bypass List:\n{0}\n-----\n", new object[] { string.Join("  \n", list.ToArray()) });
                        }
                        this._RegExBypassList = new List<Regex>(list.Count);
                        foreach (string str3 in list)
                        {
                            try
                            {
                                Regex item = new Regex(str3, RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);
                                this._RegExBypassList.Add(item);
                                continue;
                            }
                            catch
                            {
                                FiddlerApplication.Log.LogFormat("Invalid rule in Proxy Bypass list. '{0}'", new object[] { str3 });
                                continue;
                            }
                        }
                        if (this._RegExBypassList.Count < 1)
                        {
                            this._RegExBypassList = null;
                        }
                    }
                }
            }
        }

        [Obsolete]
        public bool IsBypass(string sSchemeHostPort)
        {
            string sScheme = Utilities.TrimAfter(sSchemeHostPort, "://");
            string sHostAndPort = Utilities.TrimBefore(sSchemeHostPort, "://");
            return this.IsBypass(sScheme, sHostAndPort);
        }

        public bool IsBypass(string sScheme, string sHostAndPort)
        {
            if (this._BypassOnLocal && Utilities.isPlainHostName(sHostAndPort))
            {
                return true;
            }
            if (this._RegExBypassList != null)
            {
                string input = sScheme + "://" + sHostAndPort;
                for (int i = 0; i < this._RegExBypassList.Count; i++)
                {
                    if (this._RegExBypassList[i].IsMatch(input))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public bool HasEntries
        {
            get
            {
                if (!this._BypassOnLocal)
                {
                    return (null != this._RegExBypassList);
                }
                return true;
            }
        }
    }
}

