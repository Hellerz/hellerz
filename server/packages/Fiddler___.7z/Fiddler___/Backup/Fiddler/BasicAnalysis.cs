﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Runtime.InteropServices;
    using System.Text;

    public class BasicAnalysis
    {
        [CodeDescription("Get a multi-line string describing the provided sessions.")]
        public static string ComputeBasicStatistics(Session[] _arrSessions, bool bTimeEstimates)
        {
            Dictionary<string, long> dictionary;
            long num;
            return ComputeBasicStatistics(_arrSessions, bTimeEstimates, out dictionary, out num);
        }

        public static string ComputeBasicStatistics(Session[] _arrSessions, bool bEstimates, out Dictionary<string, long> dictResponseSizeByContentType, out long cBytesRecv)
        {
            long num = 0L;
            long num2 = 0L;
            long num3 = 0L;
            long num4 = 0L;
            int length = _arrSessions.Length;
            int num6 = 0;
            int num7 = 0;
            int num8 = 0;
            int num9 = 0;
            int num10 = 0;
            DateTime time = new DateTime();
            StringBuilder builder = new StringBuilder();
            Dictionary<int, int> collection = new Dictionary<int, int>();
            DateTime maxValue = DateTime.MaxValue;
            DateTime minValue = DateTime.MinValue;
            Dictionary<string, int> dictionary2 = new Dictionary<string, int>();
            cBytesRecv = 0L;
            dictResponseSizeByContentType = new Dictionary<string, long>();
            bool flag = false;
            if (_arrSessions.Length == 1)
            {
                flag = _arrSessions[0].isAnyFlagSet(SessionFlags.IsWebSocketTunnel | SessionFlags.IsBlindTunnel);
                if (flag)
                {
                    string str = string.Format(", Raw Bytes Out: {0:N0}; In: {1:N0}", _arrSessions[0].TunnelEgressByteCount, _arrSessions[0].TunnelIngressByteCount);
                    builder.AppendFormat("This is a Tunnel. Status: {0}{1}\n\n", _arrSessions[0].TunnelIsOpen ? "OPEN" : "CLOSED", str);
                }
                if (_arrSessions[0].HTTPMethodIs("CONNECT"))
                {
                    builder.AppendLine("The selected session is a HTTP CONNECT Tunnel. This tunnel enables a client to send raw traffic (e.g. HTTPS-encrypted streams or WebSocket messages) through a HTTP Proxy Server (like Fiddler).\r\n");
                    if (!CONFIG.bMITM_HTTPS)
                    {
                        builder.AppendLine("\r\nTo enable Fiddler's HTTPS-decryption feature and view decrypted traffic, click Tools > Fiddler Options > HTTPS.\r\n\r\n");
                    }
                    else if (_arrSessions[0].isAnyFlagSet(SessionFlags.IsBlindTunnel))
                    {
                        builder.AppendLine("This tunnel was exempt from HTTPS-decryption.\r\n\r\n");
                    }
                }
                else if ((_arrSessions[0].state < SessionStates.Done) && Utilities.HasHeaders(_arrSessions[0].oResponse))
                {
                    builder.AppendLine("This session is not yet complete. Press F5 to refresh with updated statistics.\n");
                    try
                    {
                        long num11 = _arrSessions[0].oResponse._PeekDownloadProgress;
                        num4 += num11;
                        DateTime fiddlerGotResponseHeaders = _arrSessions[0].Timers.FiddlerGotResponseHeaders;
                        double num12 = 0.0;
                        double num13 = 0.0;
                        DateTime time5 = DateTime.MinValue;
                        if (fiddlerGotResponseHeaders.Ticks > 0L)
                        {
                            long num14;
                            TimeSpan span = (TimeSpan) (DateTime.Now - fiddlerGotResponseHeaders);
                            num12 = ((double) num11) / span.TotalMilliseconds;
                            num13 = (num12 * 1024.0) / 1000.0;
                            if (long.TryParse(_arrSessions[0].oResponse.headers["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num14) && (num14 > num11))
                            {
                                time5 = DateTime.Now.AddMilliseconds(((double) (num14 - num11)) / num12);
                            }
                        }
                        if (time5 > DateTime.Now)
                        {
                            builder.AppendFormat("Downloading at {0:N0}KB/sec, this download should complete at {1:H:mm:ss}.\n\n", num13, time5);
                        }
                        else
                        {
                            builder.AppendFormat("Downloading at {0:N0}KB/sec.\n\n", num13);
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            }
            builder.AppendFormat("Request Count:   {0:N0}\r\n", _arrSessions.Length);
            foreach (Session session in _arrSessions)
            {
                num6 += session.Timers.DNSTime;
                num7 += session.Timers.TCPConnectTime;
                num8 += session.Timers.HTTPSHandshakeTime;
                if (!dictionary2.ContainsKey(session.hostname))
                {
                    dictionary2.Add(session.hostname, 1);
                    num10 = Math.Max(num10, session.hostname.Length);
                }
                else
                {
                    Dictionary<string, int> dictionary3;
                    string str3;
                    (dictionary3 = dictionary2)[str3 = session.hostname] = dictionary3[str3] + 1;
                }
                if ((session.Timers.ClientBeginRequest.Ticks > 0L) && (session.Timers.ClientBeginRequest < maxValue))
                {
                    maxValue = session.Timers.ClientBeginRequest;
                }
                if ((session.Timers.ClientDoneResponse.Ticks > 0L) && (session.Timers.ClientDoneResponse > minValue))
                {
                    minValue = session.Timers.ClientDoneResponse;
                }
                if ((session.Timers.ClientBeginRequest.Ticks > 0L) && (session.Timers.ClientDoneResponse.Ticks > 0L))
                {
                    time += session.Timers.ClientDoneResponse - session.Timers.ClientBeginRequest;
                }
                if ((!session.HTTPMethodIs("CONNECT") && (session.oResponse != null)) && ((session.oResponse.headers != null) && (session.responseBodyBytes != null)))
                {
                    string key = Utilities.TrimAfter(session.oResponse["Content-Type"], ';').ToLower();
                    if (key.Length < 1)
                    {
                        key = "~???????~";
                    }
                    num9 = Math.Max(num9, key.Length);
                    long longLength = session.responseBodyBytes.LongLength;
                    if (longLength > 0L)
                    {
                        if (!dictResponseSizeByContentType.ContainsKey(key))
                        {
                            dictResponseSizeByContentType.Add(key, longLength);
                        }
                        else
                        {
                            dictResponseSizeByContentType[key] += longLength;
                        }
                    }
                }
                if (!collection.ContainsKey(session.responseCode))
                {
                    collection.Add(session.responseCode, 1);
                }
                else
                {
                    collection[session.responseCode] += 1;
                }
                if (!session.HTTPMethodIs("CONNECT") && (session.requestBodyBytes != null))
                {
                    num2 += session.requestBodyBytes.LongLength;
                }
                if ((session.oRequest != null) && (session.oRequest.headers != null))
                {
                    num += session.oRequest.headers.ByteCount();
                }
                if (!session.HTTPMethodIs("CONNECT") && (session.responseBodyBytes != null))
                {
                    num4 += session.responseBodyBytes.Length;
                }
                if ((session.oResponse != null) && (session.oResponse.headers != null))
                {
                    num3 += session.oResponse.headers.ByteCount();
                }
            }
            if (dictionary2.Count > 1)
            {
                builder.AppendFormat("Unique Hosts:    {0}\r\n", dictionary2.Count);
            }
            long num16 = num + num2;
            builder.AppendFormat("Bytes Sent:      {0:N0}\t\t(headers:{1:N0}; body:{2:N0})\r\n", num16, num, num2);
            cBytesRecv = num3 + num4;
            builder.AppendFormat("Bytes Received:  {0:N0}\t\t(headers:{1:N0}; body:{2:N0})\r\n", (long) cBytesRecv, num3, num4);
            if (flag)
            {
                builder.AppendFormat("Tunnel Sent:     {0:N0}\r\n", _arrSessions[0].TunnelEgressByteCount);
                builder.AppendFormat("Tunnel Received: {0:N0}\r\n", _arrSessions[0].TunnelIngressByteCount);
            }
            builder.Append("\r\nACTUAL PERFORMANCE\r\n--------------\r\n");
            if (_arrSessions.Length == 1)
            {
                DateTime clientBeginRequest = _arrSessions[0].Timers.ClientBeginRequest;
                if (((clientBeginRequest.Ticks > 0L) && (clientBeginRequest.Date != DateTime.Today)) && (clientBeginRequest < DateTime.Now.AddHours(-2.0)))
                {
                    builder.AppendFormat("\r\nThis traffic was captured on {0}.\r\n\r\n", clientBeginRequest.Date.ToLongDateString());
                }
                if (_arrSessions[0].oFlags.ContainsKey("x-RetryOnFailedSend"))
                {
                    builder.Append("\nNOTE: This request was retried after a Send operation failed.\n\n");
                }
                if (_arrSessions[0].oFlags.ContainsKey("x-RetryOnFailedReceive"))
                {
                    builder.Append("\nNOTE: This request was retried after a Receive operation failed.\n\n");
                }
                builder.Append(_arrSessions[0].Timers.ToString(true));
            }
            else
            {
                TimeSpan span2 = (TimeSpan) (minValue - maxValue);
                if (span2.Ticks > 0L)
                {
                    builder.AppendFormat("Requests started at:\t\t{0:HH:mm:ss.fff}\r\nResponses completed at:\t{1:HH:mm:ss.fff}\r\nSequence (clock) duration:\t{2:hh\\:mm\\:ss\\.fff}\r\nAggregate Session duration:\t{3:HH:mm:ss.fff}\r\n", new object[] { maxValue, minValue, (TimeSpan) (minValue - maxValue), time });
                    if (num6 > 0)
                    {
                        builder.AppendFormat("DNS Lookup time:\t\t{0:N0}ms\r\n", num6);
                    }
                    if (num7 > 0)
                    {
                        builder.AppendFormat("TCP/IP Connect duration:\t{0:N0}ms\r\n", num7);
                    }
                    if (num8 > 0)
                    {
                        builder.AppendFormat("HTTPS Handshake duration:\t{0:N0}ms\r\n", num8);
                    }
                }
            }
            if (_arrSessions.Length > 1)
            {
                builder.Append("\r\nRESPONSE CODES\r\n--------------\r\n");
                List<KeyValuePair<int, int>> list = new List<KeyValuePair<int, int>>(collection);
                list.Sort(delegate (KeyValuePair<int, int> firstPair, KeyValuePair<int, int> nextPair) {
                    return -firstPair.Value.CompareTo(nextPair.Value);
                });
                foreach (KeyValuePair<int, int> pair in list)
                {
                    builder.AppendFormat("HTTP/{0,3:N0}: \t{1:N0}\r\n", pair.Key, pair.Value);
                }
            }
            dictResponseSizeByContentType.Add("~headers~", num3);
            builder.AppendFormat("\r\nRESPONSE BYTES (by Content-Type)\r\n--------------\r\n", new object[0]);
            List<KeyValuePair<string, long>> list2 = new List<KeyValuePair<string, long>>(dictResponseSizeByContentType);
            list2.Sort(delegate (KeyValuePair<string, long> firstPair, KeyValuePair<string, long> nextPair) {
                return -firstPair.Value.CompareTo(nextPair.Value);
            });
            foreach (KeyValuePair<string, long> pair2 in list2)
            {
                builder.AppendFormat("{0," + num9.ToString() + "}: {1:N0}\r\n", pair2.Key, pair2.Value);
            }
            if (dictionary2.Count > 1)
            {
                builder.Append("\r\nREQUESTS PER HOST\r\n--------------\r\n");
                List<KeyValuePair<string, int>> list3 = new List<KeyValuePair<string, int>>(dictionary2);
                list3.Sort(delegate (KeyValuePair<string, int> firstPair, KeyValuePair<string, int> nextPair) {
                    return -firstPair.Value.CompareTo(nextPair.Value);
                });
                foreach (KeyValuePair<string, int> pair3 in list3)
                {
                    builder.AppendFormat("{0," + num10.ToString() + "}: {1:N0}\r\n", pair3.Key, pair3.Value);
                }
            }
            if (bEstimates)
            {
                builder.Append("\r\n\r\nESTIMATED WORLDWIDE PERFORMANCE\r\n--------------\r\n");
                builder.Append("The following are VERY rough estimates of download times when hitting servers based in Seattle.\r\n");
                builder.Append("\r\nUS West Coast (Modem - 6KB/sec)\r\n");
                builder.AppendFormat("\tRTT:\t\t{0:N2}s\r\n", length * 0.1);
                builder.AppendFormat("\tElapsed:\t{0:N2}s\r\n", (length * 0.1) + ((num16 + cBytesRecv) / 0x1770L));
                builder.Append("\r\nJapan / Northern Europe (Modem)\r\n");
                builder.AppendFormat("\tRTT:\t\t{0:N2}s\r\n", length * 0.15);
                builder.AppendFormat("\tElapsed:\t{0:N2}s\r\n", (length * 0.15) + ((num16 + cBytesRecv) / 0x1770L));
                builder.Append("\r\nChina (Modem)\r\n");
                builder.AppendFormat("\tRTT:\t\t{0:N2}s\r\n", length * 0.45);
                builder.AppendFormat("\tElapsed:\t{0:N2}s\r\n", (length * 0.45) + ((num16 + cBytesRecv) / 0x1770L));
                builder.Append("\r\nUS West Coast (DSL - 30KB/sec)\r\n");
                builder.AppendFormat("\tRTT:\t\t{0:N2}s\r\n", length * 0.1);
                builder.AppendFormat("\tElapsed:\t{0:N2}s\r\n", (length * 0.1) + ((num16 + cBytesRecv) / 0x7530L));
                builder.Append("\r\nJapan / Northern Europe (DSL)\r\n");
                builder.AppendFormat("\tRTT:\t\t{0:N2}s\r\n", length * 0.15);
                builder.AppendFormat("\tElapsed:\t{0:N2}s\r\n", (length * 0.15) + ((num16 + cBytesRecv) / 0x7530L));
                builder.Append("\r\nChina (DSL)\r\n");
                builder.AppendFormat("\tRTT:\t\t{0:N2}s\r\n", length * 0.45);
                builder.AppendFormat("\tElapsed:\t{0:N2}s\r\n\r\n", (length * 0.45) + ((num16 + cBytesRecv) / 0x7530L));
            }
            return builder.ToString();
        }
    }
}

