﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool doesSessionMatchCriteriaDelegate(Session oSession);
}

