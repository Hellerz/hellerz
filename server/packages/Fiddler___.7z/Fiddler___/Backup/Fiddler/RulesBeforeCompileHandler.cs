﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void RulesBeforeCompileHandler(string sFilename);
}

