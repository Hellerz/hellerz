﻿namespace Fiddler
{
    using System;

    public class TranscoderTuple
    {
        private ProfferFormatAttribute _pfa;
        public string sFormatDescription;
        public Type typeFormatter;

        internal TranscoderTuple(ProfferFormatAttribute pFA, Type oFormatter)
        {
            this._pfa = pFA;
            this.sFormatDescription = pFA.FormatDescription;
            this.typeFormatter = oFormatter;
        }

        internal bool HandlesExtension(string sExt)
        {
            foreach (string str in this._pfa.getExtensions())
            {
                if (sExt.OICEquals(str))
                {
                    return true;
                }
            }
            return false;
        }

        public string sFormatName
        {
            get
            {
                return this._pfa.FormatName;
            }
        }
    }
}

