﻿namespace Fiddler
{
    using System;

    public enum ContinueTransactionReason : byte
    {
        Authenticate = 1,
        None = 0,
        Redirect = 2,
        Tunnel = 3
    }
}

