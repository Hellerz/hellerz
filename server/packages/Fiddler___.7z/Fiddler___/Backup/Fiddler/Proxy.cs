﻿namespace Fiddler
{
    using Microsoft.Win32;
    using System;
    using System.Collections;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.IO;
    using System.Net;
    using System.Net.NetworkInformation;
    using System.Net.Sockets;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class Proxy : IDisposable
    {
        private bool _bDetaching;
        private bool _bIsAttached;
        internal IPEndPoint _DefaultEgressEndPoint;
        private IPEndPoint _ipepFtpGateway;
        private IPEndPoint _ipepHttpGateway;
        private IPEndPoint _ipepHttpsGateway;
        private X509Certificate2 _oHTTPSCertificate;
        private string _sHTTPSHostname;
        private EventHandler DetachedUnexpectedly;
        internal static PipePool htServerPipePool = new PipePool();
        private Socket oAcceptor;
        internal WinINETConnectoids oAllConnectoids;
        private WinHTTPAutoProxy oAutoProxy;
        private ProxyBypassList oBypassList;
        internal RegistryWatcher oRegistryWatcher;
        private WinINETProxyInfo piSystemGateway;
        internal static string sUpstreamPACScript;
        private PreferenceBag.PrefWatcher? watcherPrefNotify = null;

        public event EventHandler DetachedUnexpectedly
        {
            add
            {
                EventHandler handler2;
                EventHandler detachedUnexpectedly = this.DetachedUnexpectedly;
                do
                {
                    handler2 = detachedUnexpectedly;
                    EventHandler handler3 = (EventHandler) Delegate.Combine(handler2, value);
                    detachedUnexpectedly = Interlocked.CompareExchange<EventHandler>(ref this.DetachedUnexpectedly, handler3, handler2);
                }
                while (detachedUnexpectedly != handler2);
            }
            remove
            {
                EventHandler handler2;
                EventHandler detachedUnexpectedly = this.DetachedUnexpectedly;
                do
                {
                    handler2 = detachedUnexpectedly;
                    EventHandler handler3 = (EventHandler) Delegate.Remove(handler2, value);
                    detachedUnexpectedly = Interlocked.CompareExchange<EventHandler>(ref this.DetachedUnexpectedly, handler3, handler2);
                }
                while (detachedUnexpectedly != handler2);
            }
        }

        internal Proxy(bool bIsPrimary)
        {
            if (bIsPrimary)
            {
                try
                {
                    NetworkChange.NetworkAvailabilityChanged += new NetworkAvailabilityChangedEventHandler(this.NetworkChange_NetworkAvailabilityChanged);
                    NetworkChange.NetworkAddressChanged += new NetworkAddressChangedEventHandler(this.NetworkChange_NetworkAddressChanged);
                }
                catch (Exception)
                {
                }
                try
                {
                    this.watcherPrefNotify = new PreferenceBag.PrefWatcher?(FiddlerApplication.Prefs.AddWatcher("fiddler.network", new EventHandler<PrefChangeEventArgs>(this.onNetworkPrefsChange)));
                    this.SetDefaultEgressEndPoint(FiddlerApplication.Prefs["fiddler.network.egress.ip"]);
                    CONFIG.SetNoDecryptList(FiddlerApplication.Prefs["fiddler.network.https.NoDecryptionHosts"]);
                    CONFIG.sFiddlerListenHostPort = string.Format("{0}:{1}", FiddlerApplication.Prefs.GetStringPref("fiddler.network.proxy.RegistrationHostName", "127.0.0.1").ToLower(), CONFIG.ListenPort);
                    ClientChatter.s_cbClientReadBuffer = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.ClientReadBufferSize", ClientChatter.s_cbClientReadBuffer);
                    ServerChatter.s_cbServerReadBuffer = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.ServerReadBufferSize", ServerChatter.s_cbServerReadBuffer);
                    ClientChatter.s_SO_SNDBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Client_SO_SNDBUF", ClientChatter.s_SO_SNDBUF_Option);
                    ClientChatter.s_SO_RCVBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Client_SO_RCVBUF", ClientChatter.s_SO_RCVBUF_Option);
                    ServerChatter.s_SO_SNDBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Server_SO_SNDBUF", ServerChatter.s_SO_SNDBUF_Option);
                    ServerChatter.s_SO_RCVBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Server_SO_RCVBUF", ServerChatter.s_SO_RCVBUF_Option);
                }
                catch (Exception)
                {
                }
            }
        }

        private void _DetermineGatewayIPEndPoints()
        {
            if (this.piSystemGateway != null)
            {
                this._ipepHttpGateway = GetFirstRespondingEndpoint(this.piSystemGateway.sHttpProxy);
                if (this.piSystemGateway.sHttpsProxy == this.piSystemGateway.sHttpProxy)
                {
                    this._ipepHttpsGateway = this._ipepHttpGateway;
                }
                else
                {
                    this._ipepHttpsGateway = GetFirstRespondingEndpoint(this.piSystemGateway.sHttpsProxy);
                }
                if (this.piSystemGateway.sFtpProxy == this.piSystemGateway.sHttpProxy)
                {
                    this._ipepFtpGateway = this._ipepHttpGateway;
                }
                else
                {
                    this._ipepFtpGateway = GetFirstRespondingEndpoint(this.piSystemGateway.sFtpProxy);
                }
            }
        }

        internal string _GetPACScriptText(bool bUseFiddler)
        {
            string stringPref;
            if (bUseFiddler)
            {
                stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.proxy.pacfile.text", "return 'PROXY " + CONFIG.sFiddlerListenHostPort + "';");
            }
            else
            {
                stringPref = "return 'DIRECT';";
            }
            return ("// Autogenerated file; do not edit. Rewritten on attach and detach of Fiddler.\r\n\r\n// Get the URL to this file from Fiddler by clicking Tools > Fiddler Options > Connections > Copy Browser Proxy Configuration URL.\r\n\r\nfunction FindProxyForURL(url, host){\r\n  " + stringPref + "\r\n}");
        }

        private static string _GetPACScriptURL()
        {
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.pacfile.usefileprotocol", true))
            {
                return ("file://" + CONFIG.GetPath("Pac"));
            }
            return ("http://" + CONFIG.sFiddlerListenHostPort + "/proxy.pac");
        }

        internal string _GetUpstreamPACScriptText()
        {
            return sUpstreamPACScript;
        }

        private static void _setDynamicRegistryKey(bool bAttached)
        {
            if (!CONFIG.bIsViewOnly)
            {
                try
                {
                    RegistryKey key = Registry.CurrentUser.CreateSubKey(CONFIG.GetRegPath("Dynamic"));
                    if (key != null)
                    {
                        key.SetValue("Attached", bAttached ? 1 : 0, RegistryValueKind.DWord);
                        key.Close();
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("fiddler.network.FiddlerHook> Unable to set Dynamic registry key; registry permissions likely corrupt. Exception: {0}", new object[] { exception.Message });
                }
            }
        }

        private void AcceptConnection(IAsyncResult ar)
        {
            try
            {
                ProxyExecuteParams state = new ProxyExecuteParams(this.oAcceptor.EndAccept(ar), this._oHTTPSCertificate);
                ThreadPool.UnsafeQueueUserWorkItem(new WaitCallback(Session.CreateAndExecute), state);
            }
            catch (ObjectDisposedException exception)
            {
                FiddlerApplication.Log.LogFormat("!ERROR - Fiddler Acceptor failed to AcceptConnection: {0}", new object[] { Utilities.DescribeException(exception) });
                return;
            }
            catch (Exception exception2)
            {
                FiddlerApplication.Log.LogFormat("!WARNING - Fiddler Acceptor failed to AcceptConnection: {0}", new object[] { Utilities.DescribeException(exception2) });
            }
            try
            {
                this.oAcceptor.BeginAccept(new AsyncCallback(this.AcceptConnection), null);
            }
            catch (Exception exception3)
            {
                FiddlerApplication.Log.LogFormat("!ERROR - Fiddler Acceptor failed to call BeginAccept: {0}", new object[] { Utilities.DescribeException(exception3) });
            }
        }

        internal bool ActAsHTTPSEndpointForHostname(string sHTTPSHostname)
        {
            try
            {
                if (string.IsNullOrEmpty(sHTTPSHostname))
                {
                    throw new ArgumentException();
                }
                this._oHTTPSCertificate = CertMaker.FindCert(sHTTPSHostname);
                this._sHTTPSHostname = this._oHTTPSCertificate.Subject;
                return true;
            }
            catch (Exception)
            {
                this._oHTTPSCertificate = null;
                this._sHTTPSHostname = null;
            }
            return false;
        }

        private void AssignGateway(WinINETProxyInfo oPI)
        {
            this.piSystemGateway = oPI;
            if (this.piSystemGateway.bAutoDetect || (this.piSystemGateway.sPACScriptLocation != null))
            {
                this.oAutoProxy = new WinHTTPAutoProxy(this.piSystemGateway.bAutoDetect, this.piSystemGateway.sPACScriptLocation);
            }
            if (this.piSystemGateway.bUseManualProxies)
            {
                this._DetermineGatewayIPEndPoints();
                if (!string.IsNullOrEmpty(this.piSystemGateway.sHostsThatBypass))
                {
                    this.oBypassList = new ProxyBypassList(this.piSystemGateway.sHostsThatBypass);
                    if (!this.oBypassList.HasEntries)
                    {
                        this.oBypassList = null;
                    }
                }
            }
        }

        public bool Attach()
        {
            return this.Attach(false);
        }

        internal bool Attach(bool bCollectGWInfo)
        {
            if (!this._bIsAttached)
            {
                if (CONFIG.bIsViewOnly)
                {
                    return false;
                }
                if (bCollectGWInfo)
                {
                    this.CollectConnectoidAndGatewayInfo();
                }
                WinINETProxyInfo oNewInfo = new WinINETProxyInfo();
                oNewInfo.bUseManualProxies = true;
                oNewInfo.bAllowDirect = true;
                oNewInfo.sHttpProxy = CONFIG.sFiddlerListenHostPort;
                if (CONFIG.bCaptureCONNECT)
                {
                    oNewInfo.sHttpsProxy = CONFIG.sFiddlerListenHostPort;
                }
                else if ((this.piSystemGateway != null) && this.piSystemGateway.bUseManualProxies)
                {
                    oNewInfo.sHttpsProxy = this.piSystemGateway.sHttpsProxy;
                }
                if (CONFIG.bCaptureFTP)
                {
                    oNewInfo.sFtpProxy = CONFIG.sFiddlerListenHostPort;
                }
                else if ((this.piSystemGateway != null) && this.piSystemGateway.bUseManualProxies)
                {
                    oNewInfo.sFtpProxy = this.piSystemGateway.sFtpProxy;
                }
                if ((this.piSystemGateway != null) && this.piSystemGateway.bUseManualProxies)
                {
                    oNewInfo.sSocksProxy = this.piSystemGateway.sSocksProxy;
                }
                oNewInfo.sHostsThatBypass = CONFIG.sHostsThatBypassFiddler;
                if (CONFIG.bHookWithPAC)
                {
                    oNewInfo.sPACScriptLocation = _GetPACScriptURL();
                }
                if (this.oAllConnectoids == null)
                {
                    this.CollectConnectoidAndGatewayInfo();
                }
                if (this.oAllConnectoids.HookConnections(oNewInfo))
                {
                    this._bIsAttached = true;
                    FiddlerApplication.OnFiddlerAttach();
                    this.WriteAutoProxyPACFile(true);
                    if ((this.oRegistryWatcher == null) && FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.WatchRegistry", true))
                    {
                        this.oRegistryWatcher = RegistryWatcher.WatchKey(RegistryHive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Internet Settings", new EventHandler(this.ProxyRegistryKeysChanged));
                    }
                }
                else
                {
                    FiddlerApplication.DoNotifyUser("Failed to register Fiddler as the system proxy.", "Error");
                    _setDynamicRegistryKey(false);
                    return false;
                }
                _setDynamicRegistryKey(true);
            }
            return true;
        }

        internal void CollectConnectoidAndGatewayInfo()
        {
            try
            {
                this.oAllConnectoids = new WinINETConnectoids();
                this.RefreshUpstreamGatewayInformation();
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "System Error");
            }
        }

        public bool Detach()
        {
            return this.Detach(false);
        }

        internal bool Detach(bool bSkipVerifyAttached)
        {
            if (bSkipVerifyAttached || this._bIsAttached)
            {
                if (CONFIG.bIsViewOnly)
                {
                    return true;
                }
                try
                {
                    this._bDetaching = true;
                    _setDynamicRegistryKey(false);
                    if (this.oAllConnectoids.UnhookAllConnections())
                    {
                        this._bIsAttached = false;
                        FiddlerApplication.OnFiddlerDetach();
                        this.WriteAutoProxyPACFile(false);
                    }
                    else
                    {
                        return false;
                    }
                }
                finally
                {
                    this._bDetaching = false;
                }
            }
            return true;
        }

        public void Dispose()
        {
            if (this.watcherPrefNotify.HasValue)
            {
                FiddlerApplication.Prefs.RemoveWatcher(this.watcherPrefNotify.Value);
            }
            if (this.oRegistryWatcher != null)
            {
                this.oRegistryWatcher.Dispose();
            }
            this.Stop();
            if (this.oAutoProxy != null)
            {
                this.oAutoProxy.Dispose();
                this.oAutoProxy = null;
            }
        }

        public IPEndPoint FindGatewayForOrigin(string sURIScheme, string sHostAndPort)
        {
            if (!string.IsNullOrEmpty(sURIScheme))
            {
                if (string.IsNullOrEmpty(sHostAndPort))
                {
                    return null;
                }
                if (CONFIG.UpstreamGateway == GatewayType.None)
                {
                    return null;
                }
                if (Utilities.isLocalhost(sHostAndPort))
                {
                    return null;
                }
                if (sURIScheme.OICEquals("http"))
                {
                    if (sHostAndPort.EndsWith(":80", StringComparison.Ordinal))
                    {
                        sHostAndPort = sHostAndPort.Substring(0, sHostAndPort.Length - 3);
                    }
                }
                else if (sURIScheme.OICEquals("https"))
                {
                    if (sHostAndPort.EndsWith(":443", StringComparison.Ordinal))
                    {
                        sHostAndPort = sHostAndPort.Substring(0, sHostAndPort.Length - 4);
                    }
                }
                else if (sURIScheme.OICEquals("ftp") && sHostAndPort.EndsWith(":21", StringComparison.Ordinal))
                {
                    sHostAndPort = sHostAndPort.Substring(0, sHostAndPort.Length - 3);
                }
                WinHTTPAutoProxy oAutoProxy = this.oAutoProxy;
                if ((oAutoProxy != null) && (oAutoProxy.iAutoProxySuccessCount > -1))
                {
                    IPEndPoint point;
                    if (oAutoProxy.GetAutoProxyForUrl(sURIScheme + "://" + sHostAndPort + "/", out point))
                    {
                        oAutoProxy.iAutoProxySuccessCount = 1;
                        return point;
                    }
                    if ((oAutoProxy.iAutoProxySuccessCount == 0) && !FiddlerApplication.Prefs.GetBoolPref("fiddler.network.gateway.UseFailedAutoProxy", false))
                    {
                        FiddlerApplication.Log.LogString("AutoProxy failed. Disabling for this network.");
                        oAutoProxy.iAutoProxySuccessCount = -1;
                    }
                }
                ProxyBypassList oBypassList = this.oBypassList;
                if ((oBypassList == null) || !oBypassList.IsBypass(sURIScheme, sHostAndPort))
                {
                    if (sURIScheme.OICEquals("http"))
                    {
                        return this._ipepHttpGateway;
                    }
                    if (sURIScheme.OICEquals("https"))
                    {
                        return this._ipepHttpsGateway;
                    }
                    if (sURIScheme.OICEquals("ftp"))
                    {
                        return this._ipepFtpGateway;
                    }
                }
            }
            return null;
        }

        private static IPEndPoint GetFirstRespondingEndpoint(string sHostPortList)
        {
            string str;
            IPAddress[] addressArray;
            if (Utilities.IsNullOrWhiteSpace(sHostPortList))
            {
                return null;
            }
            sHostPortList = Utilities.TrimAfter(sHostPortList, ';');
            IPEndPoint point = null;
            int iPort = 80;
            Utilities.CrackHostAndPort(sHostPortList, out str, ref iPort);
            try
            {
                addressArray = DNSResolver.GetIPAddressList(str, true, null);
            }
            catch
            {
                FiddlerApplication.Log.LogFormat("fiddler.network.gateway> Unable to resolve upstream proxy '{0}'... ignoring.", new object[] { str });
                return null;
            }
            try
            {
                foreach (IPAddress address in addressArray)
                {
                    try
                    {
                        using (Socket socket = new Socket(address.AddressFamily, SocketType.Stream, ProtocolType.Tcp))
                        {
                            socket.NoDelay = true;
                            if (FiddlerApplication.oProxy._DefaultEgressEndPoint != null)
                            {
                                socket.Bind(FiddlerApplication.oProxy._DefaultEgressEndPoint);
                            }
                            socket.Connect(address, iPort);
                            point = new IPEndPoint(address, iPort);
                        }
                        break;
                    }
                    catch (Exception exception)
                    {
                        if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.network.dns.fallback", true))
                        {
                            break;
                        }
                        FiddlerApplication.Log.LogFormat("fiddler.network.gateway.connect>Connection to {0} failed. {1}. Will try DNS Failover if available.", new object[] { address.ToString(), exception.Message });
                    }
                }
                return point;
            }
            catch (Exception)
            {
                return null;
            }
        }

        internal string GetGatewayInformation()
        {
            if (FiddlerApplication.oProxy.oAutoProxy != null)
            {
                return string.Format("Gateway: Auto-Config\n{0}", FiddlerApplication.oProxy.oAutoProxy.ToString());
            }
            IPEndPoint point = this.FindGatewayForOrigin("http", "fiddler2.com");
            if (point != null)
            {
                return string.Format("Gateway: {0}:{1}\n", point.Address.ToString(), point.Port.ToString());
            }
            return string.Format("Gateway: No Gateway\n", new object[0]);
        }

        public void InjectCustomRequest(string sRequest)
        {
            if (this.oAcceptor == null)
            {
                this.InjectCustomRequest(sRequest, null);
            }
            else
            {
                Socket socket = new Socket(IPAddress.Loopback.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                socket.Connect(new IPEndPoint(IPAddress.Loopback, CONFIG.ListenPort));
                socket.Send(Encoding.UTF8.GetBytes(sRequest));
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
        }

        public void InjectCustomRequest(string sRequest, StringDictionary oNewFlags)
        {
            this.SendRequest(sRequest, oNewFlags);
        }

        public void InjectCustomRequest(HTTPRequestHeaders oHeaders, byte[] arrRequestBodyBytes, StringDictionary oNewFlags)
        {
            this.SendRequest(oHeaders, arrRequestBodyBytes, oNewFlags);
        }

        [Obsolete("This overload of InjectCustomRequest is obsolete. Use a different version.", true)]
        public void InjectCustomRequest(HTTPRequestHeaders oHeaders, byte[] arrRequestBodyBytes, bool bRunRequestRules, bool bViewResult)
        {
            StringDictionary oNewFlags = new StringDictionary();
            oNewFlags["x-From-Builder"] = "true";
            if (bViewResult)
            {
                oNewFlags["x-Builder-Inspect"] = "1";
            }
            this.InjectCustomRequest(oHeaders, arrRequestBodyBytes, oNewFlags);
        }

        private void NetworkChange_NetworkAddressChanged(object sender, EventArgs e)
        {
            try
            {
                DNSResolver.ClearCache();
                FiddlerApplication.Log.LogString("NetworkAddressChanged.");
                if (this.oAutoProxy != null)
                {
                    this.oAutoProxy.iAutoProxySuccessCount = 0;
                }
                if ((this.piSystemGateway != null) && this.piSystemGateway.bUseManualProxies)
                {
                    this._DetermineGatewayIPEndPoints();
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void NetworkChange_NetworkAvailabilityChanged(object sender, NetworkAvailabilityEventArgs e)
        {
            try
            {
                this.PurgeServerPipePool();
                FiddlerApplication.Log.LogFormat("fiddler.network.availability.change> Network Available: {0}", new object[] { e.IsAvailable });
                FiddlerApplication.UI.sbpInfo.Text = e.IsAvailable ? "The system reports that Network Connectivity was restored." : "The system reports that Network Connectivity was lost.";
                if (FiddlerToolbar.IsShowing())
                {
                    FiddlerToolbar.UpdateNetworkStatus();
                }
            }
            catch (Exception)
            {
            }
        }

        protected virtual void OnDetachedUnexpectedly()
        {
            EventHandler detachedUnexpectedly = this.DetachedUnexpectedly;
            if (detachedUnexpectedly != null)
            {
                detachedUnexpectedly(this, null);
            }
        }

        private void onNetworkPrefsChange(object sender, PrefChangeEventArgs oPCE)
        {
            if (oPCE.PrefName.OICStartsWith("fiddler.network.timeouts."))
            {
                if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.serverpipe.send.initial"))
                {
                    ServerPipe._timeoutSendInitial = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.send.initial", -1);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.serverpipe.send.reuse"))
                {
                    ServerPipe._timeoutSendReused = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.send.reuse", -1);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.serverpipe.receive.initial"))
                {
                    ServerPipe._timeoutReceiveInitial = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.receive.initial", -1);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.serverpipe.receive.reuse"))
                {
                    ServerPipe._timeoutReceiveReused = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.receive.reuse", -1);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.serverpipe.reuse"))
                {
                    PipePool.MSEC_PIPE_POOLED_LIFETIME = (uint) FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.reuse", 0x1c138);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.clientpipe.receive.initial"))
                {
                    ClientPipe._timeoutFirstReceive = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.clientpipe.receive.initial", 0xafc8);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.clientpipe.receive.loop"))
                {
                    ClientPipe._timeoutReceiveLoop = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.clientpipe.receive.loop", 0xea60);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.clientpipe.idle"))
                {
                    ClientPipe._timeoutIdle = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.clientpipe.idle", 0x1c138);
                }
                else if (oPCE.PrefName.OICEquals("fiddler.network.timeouts.dnscache"))
                {
                    DNSResolver.MSEC_DNS_CACHE_LIFETIME = (ulong) FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.dnscache", 0x249f0);
                }
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.sockets.ClientReadBufferSize"))
            {
                ClientChatter.s_cbClientReadBuffer = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.ClientReadBufferSize", 0x2000);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.sockets.ServerReadBufferSize"))
            {
                ServerChatter.s_cbServerReadBuffer = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.ServerReadBufferSize", 0x8000);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.sockets.Server_SO_SNDBUF"))
            {
                ServerChatter.s_SO_SNDBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Server_SO_SNDBUF", -1);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.sockets.Server_SO_RCVBUF"))
            {
                ServerChatter.s_SO_RCVBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Server_SO_RCVBUF", -1);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.sockets.Client_SO_SNDBUF"))
            {
                ClientChatter.s_SO_SNDBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Client_SO_SNDBUF", -1);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.sockets.Client_SO_RCVBUF"))
            {
                ClientChatter.s_SO_RCVBUF_Option = FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.sockets.Client_SO_RCVBUF", -1);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.egress.ip"))
            {
                this.SetDefaultEgressEndPoint(oPCE.ValueString);
            }
            else if (oPCE.PrefName.OICEquals("fiddler.network.https.NoDecryptionHosts"))
            {
                CONFIG.SetNoDecryptList(oPCE.ValueString);
            }
            else
            {
                if (oPCE.PrefName.OICEquals("fiddler.network.https.DropSNIAlerts"))
                {
                    ServerPipe._bEatTLSAlerts = oPCE.ValueBool;
                }
                if (oPCE.PrefName.OICEquals("fiddler.network.proxy.RegistrationHostName"))
                {
                    CONFIG.sFiddlerListenHostPort = string.Format("{0}:{1}", FiddlerApplication.Prefs.GetStringPref("fiddler.network.proxy.RegistrationHostName", "127.0.0.1").ToLower(), CONFIG.ListenPort);
                }
            }
        }

        private void ProxyRegistryKeysChanged(object sender, EventArgs e)
        {
            if ((this._bIsAttached && !this._bDetaching) && FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.WatchRegistry", true))
            {
                ScheduledTasks.ScheduleWork("VerifyAttached", 50, new SimpleEventHandler(this.VerifyAttached));
            }
        }

        public void PurgeServerPipePool()
        {
            htServerPipePool.Clear();
        }

        internal void RefreshUpstreamGatewayInformation()
        {
            this._ipepFtpGateway = this._ipepHttpGateway = (IPEndPoint) (this._ipepHttpsGateway = null);
            this.piSystemGateway = null;
            this.oBypassList = null;
            if (this.oAutoProxy != null)
            {
                this.oAutoProxy.Dispose();
                this.oAutoProxy = null;
            }
            switch (CONFIG.UpstreamGateway)
            {
                case GatewayType.None:
                    FiddlerApplication.Log.LogString("Setting upstream gateway to none");
                    return;

                case GatewayType.Manual:
                {
                    WinINETProxyInfo oPI = WinINETProxyInfo.CreateFromStrings(FiddlerApplication.Prefs.GetStringPref("fiddler.network.gateway.proxies", string.Empty), FiddlerApplication.Prefs.GetStringPref("fiddler.network.gateway.exceptions", string.Empty));
                    this.AssignGateway(oPI);
                    return;
                }
                case GatewayType.System:
                    this.AssignGateway(this.oAllConnectoids.GetDefaultConnectionGatewayInfo());
                    return;

                case GatewayType.WPAD:
                    FiddlerApplication.Log.LogString("Setting upstream gateway to WPAD");
                    this.oAutoProxy = new WinHTTPAutoProxy(true, null);
                    return;
            }
        }

        public Session SendRequest(string sRequest, StringDictionary oNewFlags)
        {
            int num;
            int num2;
            HTTPHeaderParseWarnings warnings;
            byte[] emptyByteArray;
            byte[] bytes = CONFIG.oHeaderEncoding.GetBytes(sRequest);
            if (!Parser.FindEntityBodyOffsetFromArray(bytes, out num, out num2, out warnings))
            {
                throw new ArgumentException("sRequest did not represent a valid HTTP request", "sRequest");
            }
            string sHeaders = CONFIG.oHeaderEncoding.GetString(bytes, 0, num) + "\r\n\r\n";
            HTTPRequestHeaders oHeaders = new HTTPRequestHeaders();
            if (!oHeaders.AssignFromString(sHeaders))
            {
                throw new ArgumentException("sRequest did not contain valid HTTP headers", "sRequest");
            }
            if (1 > (bytes.Length - num2))
            {
                emptyByteArray = Utilities.emptyByteArray;
            }
            else
            {
                emptyByteArray = new byte[bytes.Length - num2];
                Buffer.BlockCopy(bytes, num2, emptyByteArray, 0, emptyByteArray.Length);
            }
            return this.SendRequest(oHeaders, emptyByteArray, oNewFlags, null);
        }

        [CodeDescription("Send a custom request through the proxy. Hook the OnStateChanged event of the returned Session to monitor progress")]
        public Session SendRequest(HTTPRequestHeaders oHeaders, byte[] arrRequestBodyBytes, StringDictionary oNewFlags)
        {
            return this.SendRequest(oHeaders, arrRequestBodyBytes, oNewFlags, null);
        }

        [CodeDescription("Send a custom request through the proxy. Hook the OnStateChanged event of the returned Session to monitor progress")]
        public Session SendRequest(HTTPRequestHeaders oHeaders, byte[] arrRequestBodyBytes, StringDictionary oNewFlags, EventHandler<StateChangeEventArgs> onStateChange)
        {
            if (oHeaders.ExistsAndContains("Fiddler-Encoding", "base64"))
            {
                oHeaders.Remove("Fiddler-Encoding");
                if (!Utilities.IsNullOrEmpty(arrRequestBodyBytes))
                {
                    arrRequestBodyBytes = Convert.FromBase64String(Encoding.ASCII.GetString(arrRequestBodyBytes));
                    if (oNewFlags == null)
                    {
                        oNewFlags = new StringDictionary();
                    }
                    oNewFlags["x-Builder-FixContentLength"] = "CFE-required";
                }
            }
            if (oHeaders.Exists("Fiddler-Host"))
            {
                if (oNewFlags == null)
                {
                    oNewFlags = new StringDictionary();
                }
                oNewFlags["x-OverrideHost"] = oHeaders["Fiddler-Host"];
                oNewFlags["X-IgnoreCertCNMismatch"] = "Overrode HOST";
                oHeaders.Remove("Fiddler-Host");
            }
            if ((oNewFlags != null) && oNewFlags.ContainsKey("x-Builder-FixContentLength"))
            {
                if ((arrRequestBodyBytes != null) && !oHeaders.ExistsAndContains("Transfer-Encoding", "chunked"))
                {
                    if (!Utilities.HTTPMethodAllowsBody(oHeaders.HTTPMethod) && (arrRequestBodyBytes.Length == 0))
                    {
                        oHeaders.Remove("Content-Length");
                    }
                    else
                    {
                        oHeaders["Content-Length"] = arrRequestBodyBytes.LongLength.ToString();
                    }
                }
                else
                {
                    oHeaders.Remove("Content-Length");
                }
            }
            Session session = new Session((HTTPRequestHeaders) oHeaders.Clone(), arrRequestBodyBytes);
            session.SetBitFlag(SessionFlags.RequestGeneratedByFiddler, true);
            if (onStateChange != null)
            {
                session.OnStateChanged += onStateChange;
            }
            if ((oNewFlags != null) && (oNewFlags.Count > 0))
            {
                foreach (DictionaryEntry entry in oNewFlags)
                {
                    session.oFlags[(string) entry.Key] = oNewFlags[(string) entry.Key];
                }
            }
            if (session.oFlags.ContainsKey("x-AutoAuth"))
            {
                string inStr = session.oRequest.headers["Authorization"];
                if ((inStr.OICContains("NTLM") || inStr.OICContains("Negotiate")) || inStr.OICContains("Digest"))
                {
                    session.oRequest.headers.Remove("Authorization");
                }
                inStr = session.oRequest.headers["Proxy-Authorization"];
                if ((inStr.OICContains("NTLM") || inStr.OICContains("Negotiate")) || inStr.OICContains("Digest"))
                {
                    session.oRequest.headers.Remove("Proxy-Authorization");
                }
            }
            session.ExecuteOnThreadPool();
            return session;
        }

        [CodeDescription("Send a custom request through the proxy, blocking until it completes (or aborts).")]
        public Session SendRequestAndWait(HTTPRequestHeaders oHeaders, byte[] arrRequestBodyBytes, StringDictionary oNewFlags, EventHandler<StateChangeEventArgs> onStateChange)
        {
            ManualResetEvent oMRE = new ManualResetEvent(false);
            EventHandler<StateChangeEventArgs> handler = delegate (object o, StateChangeEventArgs scea) {
                if (scea.newState >= SessionStates.Done)
                {
                    FiddlerApplication.DebugSpew("SendRequestAndWait Session #{0} reached state {1}", new object[] { (o as Session).id, scea.newState });
                    oMRE.Set();
                }
                if (onStateChange != null)
                {
                    onStateChange(o, scea);
                }
            };
            Session session = this.SendRequest(oHeaders, arrRequestBodyBytes, oNewFlags, handler);
            oMRE.WaitOne();
            return session;
        }

        private void SetDefaultEgressEndPoint(string sEgressIP)
        {
            if (string.IsNullOrEmpty(sEgressIP))
            {
                this._DefaultEgressEndPoint = null;
            }
            else
            {
                IPAddress address;
                if (IPAddress.TryParse(sEgressIP, out address))
                {
                    this._DefaultEgressEndPoint = new IPEndPoint(address, 0);
                }
                else
                {
                    this._DefaultEgressEndPoint = null;
                }
            }
        }

        internal void ShowGatewayInformation()
        {
            if ((this.piSystemGateway == null) && (this.oAutoProxy == null))
            {
                MessageBox.Show("No upstream gateway proxy is configured.", "No Upstream Gateway");
            }
            else if ((this.piSystemGateway != null) && this.piSystemGateway.bUseManualProxies)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(this.piSystemGateway.ToString());
                if (!string.IsNullOrEmpty(this.piSystemGateway.sHttpProxy) && (this._ipepHttpGateway == null))
                {
                    builder.AppendLine("\nWARNING: HTTP Gateway specified was unreachable and is being ignored.");
                }
                if (!string.IsNullOrEmpty(this.piSystemGateway.sHttpsProxy) && (this._ipepHttpsGateway == null))
                {
                    builder.AppendLine("\nWARNING: HTTPS Gateway specified was unreachable and is being ignored.");
                }
                if (!string.IsNullOrEmpty(this.piSystemGateway.sFtpProxy) && (this._ipepFtpGateway == null))
                {
                    builder.AppendLine("\nWARNING: FTP Gateway specified was unreachable and is being ignored.");
                }
                if (!string.IsNullOrEmpty(this.piSystemGateway.sSocksProxy))
                {
                    builder.AppendLine("\nWARNING: SOCKS Gateway was specified but is ignored.");
                }
                MessageBox.Show(builder.ToString(), "Manually-Configured Gateway");
            }
            else if (this.oAutoProxy != null)
            {
                MessageBox.Show(this.oAutoProxy.ToString().Trim(), "Auto-Configured Gateway");
            }
            else
            {
                MessageBox.Show("No upstream gateway proxy is configured.", "No Upstream Gateway");
            }
        }

        internal bool Start(int iPort, bool bAllowRemote)
        {
            if (CONFIG.bIsViewOnly && (DialogResult.No == MessageBox.Show("This instance is running in Fiddler's Viewer Mode. Do you want to start the listener anyway?", "Warning: Viewer Mode", MessageBoxButtons.YesNo)))
            {
                return false;
            }
            bool flag = false;
            try
            {
                flag = (bAllowRemote && CONFIG.bEnableIPv6) && Socket.OSSupportsIPv6;
            }
            catch (Exception exception)
            {
                if (exception is ConfigurationErrorsException)
                {
                    FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "A Microsoft .NET configuration file (listed below) is corrupt and contains invalid data. You can often correct this error by installing updates from WindowsUpdate and/or reinstalling the .NET Framework.\n\n", exception.Message, "\nSource: ", exception.Source, "\n", exception.StackTrace, "\n\n", exception.InnerException, "\nFiddler v", Application.ProductVersion, (8 == IntPtr.Size) ? " (x64) " : " (x86) ", " [.NET ", Environment.Version, " on ", Environment.OSVersion.VersionString, "] " }), ".NET Configuration Error", MessageBoxIcon.Hand);
                    this.oAcceptor = null;
                    return false;
                }
            }
            string listeningProcess = Winsock.GetListeningProcess(iPort);
            try
            {
                if (flag)
                {
                    this.oAcceptor = new Socket(AddressFamily.InterNetworkV6, SocketType.Stream, ProtocolType.Tcp);
                    if (Environment.OSVersion.Version.Major > 5)
                    {
                        this.oAcceptor.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.IPv6Only, 0);
                    }
                }
                else
                {
                    this.oAcceptor = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                }
                if (CONFIG.ForceExclusivePort)
                {
                    this.oAcceptor.ExclusiveAddressUse = true;
                }
                try
                {
                    if (!string.IsNullOrEmpty(listeningProcess))
                    {
                        FiddlerApplication.Log.LogFormat("! WARNING: Port {0} is already in use (for at least some IP addresses) by '{1}'", new object[] { iPort, listeningProcess });
                    }
                    this.oAcceptor.Bind(new IPEndPoint(bAllowRemote ? (flag ? IPAddress.IPv6Any : IPAddress.Any) : IPAddress.Loopback, iPort));
                }
                catch (SocketException exception2)
                {
                    if (!CONFIG.QuietMode && ((exception2.ErrorCode == 0x2740) || (exception2.ErrorCode == 0x271d)))
                    {
                        string str2 = Winsock.GetListeningProcess(iPort).ToString();
                        if (DialogResult.Yes != MessageBox.Show(string.Format("Port {0} is in use{1}. Would you like Fiddler to use a random port instead?", iPort, string.IsNullOrEmpty(str2) ? string.Empty : (" by process '" + str2 + "'")), "Port in Use", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation))
                        {
                            throw;
                        }
                        this.oAcceptor.Bind(new IPEndPoint(bAllowRemote ? (flag ? IPAddress.IPv6Any : IPAddress.Any) : IPAddress.Loopback, 0));
                        CONFIG.ListenPort = (this.oAcceptor.LocalEndPoint as IPEndPoint).Port;
                        CONFIG.bUsingPortOverride = true;
                    }
                }
                this.oAcceptor.Listen(50);
            }
            catch (SocketException exception3)
            {
                string str3 = string.Empty;
                string sTitle = "Fiddler Cannot Listen";
                switch (exception3.ErrorCode)
                {
                    case 0x273f:
                    case 0x2741:
                        if (flag)
                        {
                            str3 = "An unsupported option was used. This often means that you've enabled IPv6 support inside Tools > Fiddler Options, but your computer has IPv6 disabled.";
                        }
                        break;

                    case 0x2740:
                    case 0x271d:
                    {
                        string str5 = listeningProcess;
                        if (string.IsNullOrEmpty(str5))
                        {
                            str5 = "use NETSTAT -AB at a command prompt to identify it.";
                        }
                        else
                        {
                            str5 = "the process is '" + str5 + "'.";
                        }
                        str3 = string.Format("Another service is using port {0}; {1}\n\n{2}", iPort, str5, (iPort == CONFIG.ListenPort) ? "You can easily change the port used by Fiddler. Click Tools > Fiddler Options > Connections, select a new port, and restart Fiddler." : string.Empty);
                        sTitle = "Port in Use";
                        break;
                    }
                }
                this.oAcceptor = null;
                if (!string.IsNullOrEmpty(str3))
                {
                    str3 = str3 + "\n\n";
                }
                FiddlerApplication.DoNotifyUser(string.Format("{2}Unable to bind to port [{0}]. ErrorCode: {1}.\n{3}\n\n{4}", new object[] { iPort, exception3.ErrorCode, str3, exception3.ToString(), string.Concat(new object[] { "Fiddler v", Application.ProductVersion, " [.NET ", Environment.Version, " on ", Environment.OSVersion.VersionString, "]" }) }), sTitle, MessageBoxIcon.Hand);
                return false;
            }
            catch (Exception exception4)
            {
                this.oAcceptor = null;
                FiddlerApplication.ReportException(exception4);
                return false;
            }
            try
            {
                this.oAcceptor.BeginAccept(new AsyncCallback(this.AcceptConnection), null);
            }
            catch (Exception exception5)
            {
                this.oAcceptor = null;
                FiddlerApplication.Log.LogFormat("Fiddler BeginAccept() Exception: {0}", new object[] { exception5.Message });
                return false;
            }
            return true;
        }

        internal void Stop()
        {
            if (this.oAcceptor != null)
            {
                try
                {
                    this.oAcceptor.LingerState = new LingerOption(true, 0);
                    this.oAcceptor.Close();
                }
                catch (Exception exception)
                {
                    FiddlerApplication.DebugSpew("oProxy.Dispose threw an exception: " + exception.Message);
                }
            }
        }

        public override string ToString()
        {
            return string.Format("Proxy instance is listening for requests on Port #{0}. HTTPS SubjectCN: {1}\n\n{2}", this.ListenPort, this._sHTTPSHostname ?? "<None>", htServerPipePool.InspectPool());
        }

        internal void VerifyAttached()
        {
            if (!AppRecovery.IsRecovering)
            {
                FiddlerApplication.Log.LogString("WinINET Registry change detected. Verifying proxy keys are intact...");
                bool flag = true;
                try
                {
                    if (this.oAllConnectoids != null)
                    {
                        flag = !this.oAllConnectoids.MarkUnhookedConnections(CONFIG.sFiddlerListenHostPort);
                        if (!flag)
                        {
                            FiddlerApplication.Log.LogString("WinINET API indicates that Fiddler is no longer attached.");
                        }
                    }
                }
                catch (Exception)
                {
                }
                if (flag)
                {
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", false))
                    {
                        if (key != null)
                        {
                            if (1 != Utilities.GetRegistryInt(key, "ProxyEnable", 0))
                            {
                                flag = false;
                            }
                            string str = key.GetValue("ProxyServer") as string;
                            if (string.IsNullOrEmpty(str))
                            {
                                flag = false;
                            }
                            else
                            {
                                if (!str.OICEquals(CONFIG.sFiddlerListenHostPort) && !str.OICContains(("http=" + CONFIG.sFiddlerListenHostPort)))
                                {
                                    flag = false;
                                    FiddlerApplication.Log.LogFormat("WinINET Registry had config: '{0}'", new object[] { str });
                                }
                                if (flag)
                                {
                                    string str2 = key.GetValue("AutoConfigURL") as string;
                                    if (!string.IsNullOrEmpty(str2))
                                    {
                                        flag = str2.OICContains(_GetPACScriptURL());
                                        if (!flag)
                                        {
                                            FiddlerApplication.Log.LogFormat("WinINET Registry had config: 'URL={0}'", new object[] { str2 });
                                        }
                                    }
                                }
                            }
                            if (!flag && (this.oAllConnectoids != null))
                            {
                                this.oAllConnectoids.MarkDefaultLANAsUnhooked();
                            }
                        }
                    }
                }
                if (!flag)
                {
                    this.OnDetachedUnexpectedly();
                }
            }
        }

        private void WriteAutoProxyPACFile(bool bUseFiddler)
        {
            if (!CONFIG.bIsViewOnly)
            {
                try
                {
                    System.IO.File.WriteAllText(CONFIG.GetPath("Pac"), this._GetPACScriptText(bUseFiddler));
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("Failed to update PAC file to indicate Listening={0} due to {1}", new object[] { bUseFiddler, exception.Message });
                }
            }
        }

        public bool IsAttached
        {
            get
            {
                return this._bIsAttached;
            }
            set
            {
                if (value)
                {
                    this.Attach();
                }
                else
                {
                    this.Detach();
                }
            }
        }

        public int ListenPort
        {
            get
            {
                if (this.oAcceptor != null)
                {
                    IPEndPoint localEndPoint = this.oAcceptor.LocalEndPoint as IPEndPoint;
                    if (localEndPoint != null)
                    {
                        return localEndPoint.Port;
                    }
                }
                return 0;
            }
        }
    }
}

