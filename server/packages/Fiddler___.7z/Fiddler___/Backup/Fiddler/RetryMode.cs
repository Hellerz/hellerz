﻿namespace Fiddler
{
    using System;

    internal enum RetryMode : byte
    {
        Always = 0,
        IdempotentOnly = 2,
        Never = 1
    }
}

