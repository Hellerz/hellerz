﻿namespace Fiddler
{
    using System;

    public interface ICertificateProvider2 : ICertificateProvider
    {
        bool ClearCertificateCache(bool bClearRoot);
    }
}

