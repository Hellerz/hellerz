﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;

    internal delegate DialogResult getUpdateDecisionDelegate(frmUpdate oPrompt);
}

