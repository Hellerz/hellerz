﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    internal class PeriodicWorker
    {
        private const int CONST_MIN_RESOLUTION = 500;
        private List<taskItem> oTaskList = new List<taskItem>();
        private Timer timerInternal;

        internal PeriodicWorker()
        {
            this.timerInternal = new Timer(new TimerCallback(this.doWork), null, 500, 500);
        }

        internal taskItem assignWork(SimpleEventHandler workFunction, uint iMS)
        {
            List<taskItem> list;
            taskItem item = new taskItem(workFunction, iMS);
            bool lockTaken = false;
            try
            {
                Monitor.Enter(list = this.oTaskList, ref lockTaken);
                this.oTaskList.Add(item);
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(list);
                }
            }
            return item;
        }

        private void doWork(object objState)
        {
            if (FiddlerApplication.isClosing)
            {
                this.timerInternal.Dispose();
            }
            else
            {
                taskItem[] itemArray;
                List<taskItem> list;
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(list = this.oTaskList, ref lockTaken);
                    itemArray = new taskItem[this.oTaskList.Count];
                    this.oTaskList.CopyTo(itemArray);
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(list);
                    }
                }
                foreach (taskItem item in itemArray)
                {
                    if (Utilities.GetTickCount() > (item._ulLastRun + item._iPeriod))
                    {
                        item._oTask();
                        item._ulLastRun = Utilities.GetTickCount();
                    }
                }
            }
        }

        internal void revokeWork(taskItem oToRevoke)
        {
            if (oToRevoke != null)
            {
                List<taskItem> list;
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(list = this.oTaskList, ref lockTaken);
                    this.oTaskList.Remove(oToRevoke);
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(list);
                    }
                }
            }
        }

        internal class taskItem
        {
            public uint _iPeriod;
            public SimpleEventHandler _oTask;
            public ulong _ulLastRun = Utilities.GetTickCount();

            public taskItem(SimpleEventHandler oTask, uint iPeriod)
            {
                this._iPeriod = iPeriod;
                this._oTask = oTask;
            }
        }
    }
}

