﻿namespace Fiddler
{
    using System;

    public interface ISAZProvider
    {
        ISAZWriter CreateSAZ(string sFilename);
        ISAZReader LoadSAZ(string sFilename);

        bool BufferLocally { get; }

        bool SupportsEncryption { get; }
    }
}

