﻿namespace Fiddler
{
    using System;
    using System.IO;
    using System.Text;
    using Xceed.FileSystem;
    using Xceed.Zip;

    internal class XceedSAZWriter : ISAZWriter
    {
        private DiskFile _odfZip;
        private ZipArchive _oZip;
        private string _sFilename;

        internal XceedSAZWriter(string sFilename)
        {
            this._sFilename = sFilename;
            this._odfZip = new DiskFile(sFilename);
            this._oZip = new ZipArchive(this._odfZip);
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.SAZ.UseMemoryCache", true))
            {
                this._oZip.TempFolder = new MemoryFolder();
            }
            this._oZip.BeginUpdate();
            ZippedFolder folder1 = (ZippedFolder) this._oZip.CreateFolder("raw");
        }

        public void AddFile(string sFilename, SAZWriterDelegate oSWD)
        {
            ZippedFile file = new ZippedFile(this._odfZip, sFilename);
            using (Stream stream = file.CreateWrite(FileShare.None))
            {
                oSWD(stream);
            }
        }

        public bool CompleteArchive()
        {
            this.WriteODCXML();
            this._oZip.EndUpdate();
            this._oZip = null;
            this._odfZip = null;
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.ClearCaches", false))
            {
                ZipArchive.ClearCachedZipHandlers();
            }
            return true;
        }

        public bool SetPassword(string sPassword)
        {
            if (CONFIG.bUseAESForSAZ)
            {
                this._oZip.DefaultEncryptionMethod = Xceed.Zip.EncryptionMethod.WinZipAes;
                if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.AES.Use256Bit", false))
                {
                    this._oZip.DefaultEncryptionStrength = 0x80;
                }
            }
            this._oZip.DefaultEncryptionPassword = sPassword;
            return true;
        }

        private void WriteODCXML()
        {
            ZippedFile file = new ZippedFile(this._odfZip, "[Content_Types].xml");
            using (Stream stream = file.CreateWrite(FileShare.None))
            {
                byte[] bytes = Encoding.UTF8.GetBytes("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">\r\n<Default Extension=\"htm\" ContentType=\"text/html\" />\r\n<Default Extension=\"xml\" ContentType=\"application/xml\" />\r\n<Default Extension=\"txt\" ContentType=\"text/plain\" />\r\n</Types>");
                stream.Write(bytes, 0, bytes.Length);
            }
        }

        public string Comment
        {
            get
            {
                return string.Empty;
            }
            set
            {
                this._oZip.Comment = value;
            }
        }

        public string EncryptionMethod
        {
            get
            {
                return this._oZip.DefaultEncryptionMethod.ToString();
            }
        }

        public string EncryptionStrength
        {
            get
            {
                return this._oZip.DefaultEncryptionStrength.ToString();
            }
        }

        public string Filename
        {
            get
            {
                return this._sFilename;
            }
        }
    }
}

