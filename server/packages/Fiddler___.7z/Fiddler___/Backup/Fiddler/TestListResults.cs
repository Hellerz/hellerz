﻿namespace Fiddler
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;

    public class TestListResults : IEnumerable<TestResult>, IEnumerable
    {
        private List<TestResult> listResults = new List<TestResult>();

        public void Add(Session sessionOriginal, Session sessionRerun, bool passed)
        {
            TestResult item = new TestResult(sessionOriginal, sessionRerun, passed);
            this.listResults.Add(item);
        }

        public IEnumerator<TestResult> GetEnumerator()
        {
            return this.listResults.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.listResults.GetEnumerator();
        }

        public void WriteFailuresToSAZ(string sFilename)
        {
            if (this.listResults.Count >= 1)
            {
                List<Session> list = new List<Session>();
                foreach (TestResult result in this.listResults)
                {
                    if (!result.IsPassing)
                    {
                        Session item = new Session(result.sessOriginal);
                        item["ui-backcolor"] = "#ffffff";
                        item["ui-comments"] = item["API-VALIDATOR"] + " " + item["ui-comments"];
                        list.Add(item);
                        item = new Session(result.sessRerun);
                        item["ui-backcolor"] = "#FDA899";
                        item["ui-comments"] = item["API-LASTFAILREASON"];
                        list.Add(item);
                    }
                }
                if (list.Count > 0)
                {
                    Utilities.WriteSessionArchive(sFilename, list.ToArray(), null, true);
                }
                else
                {
                    File.Delete(sFilename);
                }
            }
        }
    }
}

