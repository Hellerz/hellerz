﻿namespace Fiddler
{
    using System;

    internal class XceedProvider : ISAZProvider
    {
        public ISAZWriter CreateSAZ(string sFilename)
        {
            return new XceedSAZWriter(sFilename);
        }

        public ISAZReader LoadSAZ(string sFilename)
        {
            return new XceedSAZReader(sFilename);
        }

        public bool BufferLocally
        {
            get
            {
                return true;
            }
        }

        public bool SupportsEncryption
        {
            get
            {
                return true;
            }
        }
    }
}

