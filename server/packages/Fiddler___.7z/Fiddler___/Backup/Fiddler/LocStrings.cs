﻿namespace Fiddler
{
    using System;

    internal class LocStrings
    {
        internal const string sCNBuyLink = "躲 Fiddler...";
        internal const string sCNHideMenu = "躲";
        internal const string sCNMnuTitle = "册 Fiddler";
        internal const string sJPNBuyLink = "購 本 Fiddler...";
        internal const string sJPNHideMenu = "隠す";
        internal const string sJPNMnuTitle = "本 Fiddler";
    }
}

