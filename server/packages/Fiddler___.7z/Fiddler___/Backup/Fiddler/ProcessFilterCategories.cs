﻿namespace Fiddler
{
    using System;

    public enum ProcessFilterCategories
    {
        All,
        Browsers,
        NonBrowsers,
        HideAll
    }
}

