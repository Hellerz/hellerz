﻿namespace Fiddler
{
    using System;
    using System.IO;
    using System.Runtime.CompilerServices;

    public delegate void SAZWriterDelegate(Stream oStreamToWrite);
}

