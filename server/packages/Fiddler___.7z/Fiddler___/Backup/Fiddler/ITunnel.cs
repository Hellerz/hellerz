﻿namespace Fiddler
{
    using System;

    public interface ITunnel
    {
        void CloseTunnel();

        long EgressByteCount { get; }

        long IngressByteCount { get; }

        bool IsOpen { get; }
    }
}

