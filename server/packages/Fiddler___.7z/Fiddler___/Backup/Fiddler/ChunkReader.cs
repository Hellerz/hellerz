﻿namespace Fiddler
{
    using System;
    using System.IO;

    internal class ChunkReader
    {
        private int _cbRemainingInBlock;
        private int _iEntityLength;
        private int _iOverage;
        private ChunkedTransferState _state = ChunkedTransferState.ReadStartOfSize;

        internal ChunkReader()
        {
        }

        internal int getEntityLength()
        {
            return this._iEntityLength;
        }

        internal int getOverage()
        {
            return this._iOverage;
        }

        private int HexValue(byte b)
        {
            if ((b >= 0x30) && (b <= 0x39))
            {
                return (b - 0x30);
            }
            if ((b >= 0x41) && (b <= 70))
            {
                return (10 + (b - 0x41));
            }
            if ((b >= 0x61) && (b <= 0x66))
            {
                return (10 + (b - 0x61));
            }
            return -1;
        }

        internal ChunkedTransferState pushBytes(byte[] arrData, int iOffset, int iLen)
        {
            while (iLen > 0)
            {
                int num;
                byte num2;
                switch (this._state)
                {
                    case ChunkedTransferState.ReadStartOfSize:
                        iLen--;
                        num = this.HexValue(arrData[iOffset++]);
                        if (num >= 0)
                        {
                            break;
                        }
                        return (this._state = ChunkedTransferState.Malformed);

                    case ChunkedTransferState.ReadingSize:
                    {
                        iLen--;
                        num2 = arrData[iOffset++];
                        int num3 = this.HexValue(num2);
                        if (num3 <= -1)
                        {
                            goto Label_00C5;
                        }
                        this._cbRemainingInBlock = (this._cbRemainingInBlock * 0x10) + num3;
                        continue;
                    }
                    case ChunkedTransferState.ReadingChunkExtToCR:
                    {
                        do
                        {
                            iLen--;
                            if (arrData[iOffset++] == 13)
                            {
                                this._state = ChunkedTransferState.ReadLFAfterChunkHeader;
                                break;
                            }
                        }
                        while (iLen > 0);
                        continue;
                    }
                    case ChunkedTransferState.ReadLFAfterChunkHeader:
                        iLen--;
                        if (arrData[iOffset++] == 10)
                        {
                            goto Label_016C;
                        }
                        return (this._state = ChunkedTransferState.Malformed);

                    case ChunkedTransferState.ReadingBlock:
                        if (this._cbRemainingInBlock <= iLen)
                        {
                            goto Label_01AA;
                        }
                        this._cbRemainingInBlock -= iLen;
                        this._iEntityLength += iLen;
                        return ChunkedTransferState.ReadingBlock;

                    case ChunkedTransferState.ReadCRAfterBlock:
                        iLen--;
                        if (arrData[iOffset++] == 13)
                        {
                            goto Label_022E;
                        }
                        return (this._state = ChunkedTransferState.Malformed);

                    case ChunkedTransferState.ReadLFAfterBlock:
                        iLen--;
                        if (arrData[iOffset++] == 10)
                        {
                            goto Label_0259;
                        }
                        return (this._state = ChunkedTransferState.Malformed);

                    case ChunkedTransferState.ReadStartOfTrailer:
                    {
                        iLen--;
                        this._state = (arrData[iOffset++] == 13) ? ChunkedTransferState.ReadFinalLF : ChunkedTransferState.ReadToTrailerCR;
                        continue;
                    }
                    case ChunkedTransferState.ReadToTrailerCR:
                    {
                        iLen--;
                        if (arrData[iOffset++] == 13)
                        {
                            this._state = ChunkedTransferState.ReadTrailerLF;
                        }
                        continue;
                    }
                    case ChunkedTransferState.ReadTrailerLF:
                    {
                        iLen--;
                        this._state = (arrData[iOffset++] == 10) ? ChunkedTransferState.ReadStartOfTrailer : ChunkedTransferState.Malformed;
                        continue;
                    }
                    case ChunkedTransferState.ReadFinalLF:
                    {
                        iLen--;
                        this._state = (arrData[iOffset++] == 10) ? ChunkedTransferState.Completed : ChunkedTransferState.Malformed;
                        continue;
                    }
                    case ChunkedTransferState.Completed:
                        this._iOverage = iLen;
                        return (this._state = ChunkedTransferState.Overread);

                    default:
                        throw new InvalidDataException("We should never get called in state: " + this._state.ToString());
                }
                if (this._cbRemainingInBlock != 0)
                {
                    throw new InvalidDataException("?");
                }
                this._cbRemainingInBlock = num;
                this._state = ChunkedTransferState.ReadingSize;
                continue;
            Label_00C5:;
                FiddlerApplication.DebugSpew("Reached Non-Size character '0x{0:X}'; block size is {1}", new object[] { num2, this._cbRemainingInBlock });
                byte num4 = num2;
                if (num4 != 13)
                {
                    if (num4 != 0x3b)
                    {
                        return (this._state = ChunkedTransferState.Malformed);
                    }
                    this._state = ChunkedTransferState.ReadingChunkExtToCR;
                }
                else
                {
                    this._state = ChunkedTransferState.ReadLFAfterChunkHeader;
                }
                continue;
            Label_016C:
                this._state = (this._cbRemainingInBlock == 0) ? ChunkedTransferState.ReadStartOfTrailer : ChunkedTransferState.ReadingBlock;
                continue;
            Label_01AA:
                if (this._cbRemainingInBlock == iLen)
                {
                    this._cbRemainingInBlock = 0;
                    this._iEntityLength += iLen;
                    return (this._state = ChunkedTransferState.ReadCRAfterBlock);
                }
                this._iEntityLength += this._cbRemainingInBlock;
                iLen -= this._cbRemainingInBlock;
                iOffset += this._cbRemainingInBlock;
                this._cbRemainingInBlock = 0;
                this._state = ChunkedTransferState.ReadCRAfterBlock;
                continue;
            Label_022E:
                this._state = ChunkedTransferState.ReadLFAfterBlock;
                continue;
            Label_0259:
                this._state = ChunkedTransferState.ReadStartOfSize;
                if (this._cbRemainingInBlock != 0)
                {
                    FiddlerApplication.Log.LogFormat("! BUG BUG BUG Expecting {0} more", new object[] { this._cbRemainingInBlock });
                }
            }
            return this._state;
        }

        internal ChunkedTransferState state
        {
            get
            {
                return this._state;
            }
        }
    }
}

