﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void RulesCompileFailedHandler(string sDescription, int iLine, int iStartColumn, int iEndColumn);
}

