﻿namespace Fiddler
{
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading;

    internal class MRU
    {
        private int _iMaxFileCount;
        private List<string> _slItems;
        private string _sMutexName;
        private string _sRegPath;

        public MRU(string sRegPath, int iMaxFileCount)
        {
            if (iMaxFileCount < 0)
            {
                throw new ArgumentException("Max file count must be >= 0");
            }
            this._iMaxFileCount = iMaxFileCount;
            this._sRegPath = sRegPath;
            this._sMutexName = string.Format(@"Global\MRU_{0}_{1}", Environment.UserName, sRegPath.Replace('\\', '_'));
        }

        private void _FilterNonExistentFiles()
        {
            List<string> list = new List<string>();
            if (this._slItems != null)
            {
                foreach (string str in this._slItems)
                {
                    try
                    {
                        if (File.Exists(str))
                        {
                            list.Add(str);
                        }
                        continue;
                    }
                    catch (Exception)
                    {
                        continue;
                    }
                }
            }
            this._slItems = list;
        }

        private void _PushOrRemoveFile(string sFilename, bool bInsertAtTop)
        {
            Predicate<string> match = null;
            if ((((this._iMaxFileCount != 0) && !string.IsNullOrEmpty(sFilename)) && (!sFilename.OICEndsWith(".dat") && !sFilename.OICEndsWith(".tmp"))) && (sFilename.LastIndexOf(Path.DirectorySeparatorChar + "_") != sFilename.LastIndexOf(Path.DirectorySeparatorChar)))
            {
                using (Mutex mutex = new Mutex(false, this._sMutexName))
                {
                    if (mutex.WaitOne(0x1388, false))
                    {
                        try
                        {
                            if (this.RefreshList())
                            {
                                if (match == null)
                                {
                                    match = delegate (string s) {
                                        return sFilename.OICEquals(s);
                                    };
                                }
                                this._slItems.RemoveAll(match);
                                if (bInsertAtTop)
                                {
                                    this._slItems.Insert(0, sFilename);
                                }
                                if (this._slItems.Count > this._iMaxFileCount)
                                {
                                    this._slItems.RemoveRange(this._iMaxFileCount, this._slItems.Count - this._iMaxFileCount);
                                }
                                string listAsString = this.GetListAsString();
                                RegistryKey key = Registry.CurrentUser.CreateSubKey(this._sRegPath);
                                if (key != null)
                                {
                                    key.SetValue("MRU", listAsString);
                                    key.Close();
                                }
                            }
                        }
                        finally
                        {
                            mutex.ReleaseMutex();
                        }
                    }
                }
            }
        }

        public string[] GetList()
        {
            if (this._slItems == null)
            {
                return new string[0];
            }
            return this._slItems.ToArray();
        }

        public string GetListAsString()
        {
            if (this._slItems == null)
            {
                return string.Empty;
            }
            return string.Join("*", this._slItems.ToArray());
        }

        public void PruneObsolete()
        {
            this._slItems = new List<string>();
            using (Mutex mutex = new Mutex(false, this._sMutexName))
            {
                if (mutex.WaitOne(0x3e8, false))
                {
                    try
                    {
                        RegistryKey key = Registry.CurrentUser.OpenSubKey(this._sRegPath, RegistryKeyPermissionCheck.ReadWriteSubTree);
                        if (key != null)
                        {
                            string listAsString = (string) key.GetValue("MRU");
                            if (!string.IsNullOrEmpty(listAsString))
                            {
                                this._slItems.AddRange(listAsString.Split(new char[] { '*' }, StringSplitOptions.RemoveEmptyEntries));
                                this._FilterNonExistentFiles();
                                listAsString = this.GetListAsString();
                                key.SetValue("MRU", listAsString);
                            }
                            key.Close();
                        }
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.ReportException(exception, "Unable to Prune", "Fiddler was unable to prune the registry entries.");
                    }
                    finally
                    {
                        mutex.ReleaseMutex();
                    }
                }
            }
        }

        public void PurgeAll()
        {
            this._slItems = null;
            using (Mutex mutex = new Mutex(false, this._sMutexName))
            {
                if (mutex.WaitOne(0x3e8, false))
                {
                    try
                    {
                        RegistryKey key = Registry.CurrentUser.OpenSubKey(this._sRegPath, RegistryKeyPermissionCheck.ReadWriteSubTree);
                        if (key != null)
                        {
                            key.DeleteValue("MRU", false);
                            key.Close();
                        }
                    }
                    finally
                    {
                        mutex.ReleaseMutex();
                    }
                }
            }
        }

        public void PushFile(string sFilename)
        {
            this._PushOrRemoveFile(sFilename, true);
        }

        public bool RefreshList()
        {
            if (this._iMaxFileCount == 0)
            {
                return true;
            }
            bool flag = false;
            this._slItems = new List<string>();
            string str = null;
            try
            {
                flag = true;
                RegistryKey key = Registry.CurrentUser.OpenSubKey(this._sRegPath, RegistryKeyPermissionCheck.ReadSubTree);
                if (key != null)
                {
                    str = (string) key.GetValue("MRU");
                    key.Close();
                }
            }
            catch
            {
                flag = false;
                str = null;
            }
            if (!string.IsNullOrEmpty(str))
            {
                this._slItems.AddRange(str.Split(new char[] { '*' }, this._iMaxFileCount, StringSplitOptions.RemoveEmptyEntries));
            }
            return flag;
        }

        public void RemoveFile(string sFilename)
        {
            this._PushOrRemoveFile(sFilename, false);
        }
    }
}

