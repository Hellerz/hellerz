﻿namespace Fiddler
{
    using System;

    internal enum ChunkedTransferState
    {
        Unknown,
        ReadStartOfSize,
        ReadingSize,
        ReadingChunkExtToCR,
        ReadLFAfterChunkHeader,
        ReadingBlock,
        ReadCRAfterBlock,
        ReadLFAfterBlock,
        ReadStartOfTrailer,
        ReadToTrailerCR,
        ReadTrailerLF,
        ReadFinalLF,
        Completed,
        Overread,
        Malformed
    }
}

