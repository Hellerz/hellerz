﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Configuration;
    using System.Diagnostics;
    using System.IO;
    using System.Net.Security;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;
    using Telerik.Analytics;
    using Xceed.Compression.Formats;
    using Xceed.Zip;

    public static class FiddlerApplication
    {
        internal static AutoResponder _AutoResponder;
        private static bool _bSuppressReportUpdates = false;
        internal static frmViewer _frmMain;
        internal static SplashScreen _frmSplash;
        internal static int _iShowOnlyPID;
        internal static readonly Logger _Log = new Logger(true);
        private static SessionStateHandler AfterSessionComplete;
        private static EventHandler<ConnectionEventArgs> AfterSocketAccept;
        private static EventHandler<ConnectionEventArgs> AfterSocketConnect;
        private static CancelEventHandler BeforeFiddlerShutdown;
        private static CancelEventHandler BeforeInspectSession;
        private static SessionStateHandler BeforeRequest;
        private static SessionStateHandler BeforeResponse;
        private static SessionStateHandler BeforeReturningError;
        private static CalculateReportHandler CalculateReport;
        public static LocalCertificateSelectionCallback ClientCertificateProvider;
        private static SimpleEventHandler FiddlerAttach;
        private static SimpleEventHandler FiddlerBoot;
        private static SimpleEventHandler FiddlerDetach;
        private static SimpleEventHandler FiddlerShutdown;
        internal static readonly int iPID;
        public static bool isClosing;
        internal static readonly PeriodicWorker Janitor = new PeriodicWorker();
        public static X509Certificate oDefaultClientCertificate;
        [CodeDescription("Fiddler's loaded extensions.")]
        public static FiddlerExtensions oExtensions;
        internal static Inspectors oInspectors;
        private static EventHandler<CacheClearEventArgs> OnClearCache;
        private static EventHandler<ReadSAZEventArgs> OnLoadSAZ;
        private static EventHandler<NotificationEventArgs> OnNotification;
        private static EventHandler<WriteSAZEventArgs> OnSaveSAZ;
        private static EventHandler<ValidateServerCertificateEventArgs> OnValidateServerCertificate;
        private static EventHandler<WebSocketMessageEventArgs> OnWebSocketMessage;
        [CodeDescription("Fiddler's core proxy engine.")]
        public static Proxy oProxy;
        internal static IMonitor oTelemetry = null;
        public static FiddlerTranscoders oTranscoders = new FiddlerTranscoders();
        internal static WebSocketTab oWSView;
        internal static Report Reporter;
        private static SessionStateHandler RequestHeadersAvailable;
        private static SessionStateHandler ResponseHeadersAvailable;
        public static FiddlerScript scriptRules;
        private static readonly List<string> slLeakedFiles = new List<string>();
        internal static readonly string sProcessInfo;

        public static  event SessionStateHandler AfterSessionComplete
        {
            add
            {
                SessionStateHandler handler2;
                SessionStateHandler afterSessionComplete = AfterSessionComplete;
                do
                {
                    handler2 = afterSessionComplete;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Combine(handler2, value);
                    afterSessionComplete = Interlocked.CompareExchange<SessionStateHandler>(ref AfterSessionComplete, handler3, handler2);
                }
                while (afterSessionComplete != handler2);
            }
            remove
            {
                SessionStateHandler handler2;
                SessionStateHandler afterSessionComplete = AfterSessionComplete;
                do
                {
                    handler2 = afterSessionComplete;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Remove(handler2, value);
                    afterSessionComplete = Interlocked.CompareExchange<SessionStateHandler>(ref AfterSessionComplete, handler3, handler2);
                }
                while (afterSessionComplete != handler2);
            }
        }

        public static  event EventHandler<ConnectionEventArgs> AfterSocketAccept
        {
            add
            {
                EventHandler<ConnectionEventArgs> handler2;
                EventHandler<ConnectionEventArgs> afterSocketAccept = AfterSocketAccept;
                do
                {
                    handler2 = afterSocketAccept;
                    EventHandler<ConnectionEventArgs> handler3 = (EventHandler<ConnectionEventArgs>) Delegate.Combine(handler2, value);
                    afterSocketAccept = Interlocked.CompareExchange<EventHandler<ConnectionEventArgs>>(ref AfterSocketAccept, handler3, handler2);
                }
                while (afterSocketAccept != handler2);
            }
            remove
            {
                EventHandler<ConnectionEventArgs> handler2;
                EventHandler<ConnectionEventArgs> afterSocketAccept = AfterSocketAccept;
                do
                {
                    handler2 = afterSocketAccept;
                    EventHandler<ConnectionEventArgs> handler3 = (EventHandler<ConnectionEventArgs>) Delegate.Remove(handler2, value);
                    afterSocketAccept = Interlocked.CompareExchange<EventHandler<ConnectionEventArgs>>(ref AfterSocketAccept, handler3, handler2);
                }
                while (afterSocketAccept != handler2);
            }
        }

        public static  event EventHandler<ConnectionEventArgs> AfterSocketConnect
        {
            add
            {
                EventHandler<ConnectionEventArgs> handler2;
                EventHandler<ConnectionEventArgs> afterSocketConnect = AfterSocketConnect;
                do
                {
                    handler2 = afterSocketConnect;
                    EventHandler<ConnectionEventArgs> handler3 = (EventHandler<ConnectionEventArgs>) Delegate.Combine(handler2, value);
                    afterSocketConnect = Interlocked.CompareExchange<EventHandler<ConnectionEventArgs>>(ref AfterSocketConnect, handler3, handler2);
                }
                while (afterSocketConnect != handler2);
            }
            remove
            {
                EventHandler<ConnectionEventArgs> handler2;
                EventHandler<ConnectionEventArgs> afterSocketConnect = AfterSocketConnect;
                do
                {
                    handler2 = afterSocketConnect;
                    EventHandler<ConnectionEventArgs> handler3 = (EventHandler<ConnectionEventArgs>) Delegate.Remove(handler2, value);
                    afterSocketConnect = Interlocked.CompareExchange<EventHandler<ConnectionEventArgs>>(ref AfterSocketConnect, handler3, handler2);
                }
                while (afterSocketConnect != handler2);
            }
        }

        [CodeDescription("Sync this event to prevent Fiddler from shutting down.")]
        public static  event CancelEventHandler BeforeFiddlerShutdown
        {
            add
            {
                CancelEventHandler handler2;
                CancelEventHandler beforeFiddlerShutdown = BeforeFiddlerShutdown;
                do
                {
                    handler2 = beforeFiddlerShutdown;
                    CancelEventHandler handler3 = (CancelEventHandler) Delegate.Combine(handler2, value);
                    beforeFiddlerShutdown = Interlocked.CompareExchange<CancelEventHandler>(ref BeforeFiddlerShutdown, handler3, handler2);
                }
                while (beforeFiddlerShutdown != handler2);
            }
            remove
            {
                CancelEventHandler handler2;
                CancelEventHandler beforeFiddlerShutdown = BeforeFiddlerShutdown;
                do
                {
                    handler2 = beforeFiddlerShutdown;
                    CancelEventHandler handler3 = (CancelEventHandler) Delegate.Remove(handler2, value);
                    beforeFiddlerShutdown = Interlocked.CompareExchange<CancelEventHandler>(ref BeforeFiddlerShutdown, handler3, handler2);
                }
                while (beforeFiddlerShutdown != handler2);
            }
        }

        [CodeDescription("This event fires before the user inspects a session.")]
        public static  event CancelEventHandler BeforeInspectSession
        {
            add
            {
                CancelEventHandler handler2;
                CancelEventHandler beforeInspectSession = BeforeInspectSession;
                do
                {
                    handler2 = beforeInspectSession;
                    CancelEventHandler handler3 = (CancelEventHandler) Delegate.Combine(handler2, value);
                    beforeInspectSession = Interlocked.CompareExchange<CancelEventHandler>(ref BeforeInspectSession, handler3, handler2);
                }
                while (beforeInspectSession != handler2);
            }
            remove
            {
                CancelEventHandler handler2;
                CancelEventHandler beforeInspectSession = BeforeInspectSession;
                do
                {
                    handler2 = beforeInspectSession;
                    CancelEventHandler handler3 = (CancelEventHandler) Delegate.Remove(handler2, value);
                    beforeInspectSession = Interlocked.CompareExchange<CancelEventHandler>(ref BeforeInspectSession, handler3, handler2);
                }
                while (beforeInspectSession != handler2);
            }
        }

        public static  event SessionStateHandler BeforeRequest
        {
            add
            {
                SessionStateHandler handler2;
                SessionStateHandler beforeRequest = BeforeRequest;
                do
                {
                    handler2 = beforeRequest;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Combine(handler2, value);
                    beforeRequest = Interlocked.CompareExchange<SessionStateHandler>(ref BeforeRequest, handler3, handler2);
                }
                while (beforeRequest != handler2);
            }
            remove
            {
                SessionStateHandler handler2;
                SessionStateHandler beforeRequest = BeforeRequest;
                do
                {
                    handler2 = beforeRequest;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Remove(handler2, value);
                    beforeRequest = Interlocked.CompareExchange<SessionStateHandler>(ref BeforeRequest, handler3, handler2);
                }
                while (beforeRequest != handler2);
            }
        }

        public static  event SessionStateHandler BeforeResponse
        {
            add
            {
                SessionStateHandler handler2;
                SessionStateHandler beforeResponse = BeforeResponse;
                do
                {
                    handler2 = beforeResponse;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Combine(handler2, value);
                    beforeResponse = Interlocked.CompareExchange<SessionStateHandler>(ref BeforeResponse, handler3, handler2);
                }
                while (beforeResponse != handler2);
            }
            remove
            {
                SessionStateHandler handler2;
                SessionStateHandler beforeResponse = BeforeResponse;
                do
                {
                    handler2 = beforeResponse;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Remove(handler2, value);
                    beforeResponse = Interlocked.CompareExchange<SessionStateHandler>(ref BeforeResponse, handler3, handler2);
                }
                while (beforeResponse != handler2);
            }
        }

        public static  event SessionStateHandler BeforeReturningError
        {
            add
            {
                SessionStateHandler handler2;
                SessionStateHandler beforeReturningError = BeforeReturningError;
                do
                {
                    handler2 = beforeReturningError;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Combine(handler2, value);
                    beforeReturningError = Interlocked.CompareExchange<SessionStateHandler>(ref BeforeReturningError, handler3, handler2);
                }
                while (beforeReturningError != handler2);
            }
            remove
            {
                SessionStateHandler handler2;
                SessionStateHandler beforeReturningError = BeforeReturningError;
                do
                {
                    handler2 = beforeReturningError;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Remove(handler2, value);
                    beforeReturningError = Interlocked.CompareExchange<SessionStateHandler>(ref BeforeReturningError, handler3, handler2);
                }
                while (beforeReturningError != handler2);
            }
        }

        [CodeDescription("Sync this event to capture the CalculateReport event, summarizing the selected sessions.")]
        public static  event CalculateReportHandler CalculateReport
        {
            add
            {
                CalculateReportHandler handler2;
                CalculateReportHandler calculateReport = CalculateReport;
                do
                {
                    handler2 = calculateReport;
                    CalculateReportHandler handler3 = (CalculateReportHandler) Delegate.Combine(handler2, value);
                    calculateReport = Interlocked.CompareExchange<CalculateReportHandler>(ref CalculateReport, handler3, handler2);
                }
                while (calculateReport != handler2);
            }
            remove
            {
                CalculateReportHandler handler2;
                CalculateReportHandler calculateReport = CalculateReport;
                do
                {
                    handler2 = calculateReport;
                    CalculateReportHandler handler3 = (CalculateReportHandler) Delegate.Remove(handler2, value);
                    calculateReport = Interlocked.CompareExchange<CalculateReportHandler>(ref CalculateReport, handler3, handler2);
                }
                while (calculateReport != handler2);
            }
        }

        [CodeDescription("Sync this event to be notified when FiddlerCore has attached as the system proxy.")]
        public static  event SimpleEventHandler FiddlerAttach
        {
            add
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerAttach = FiddlerAttach;
                do
                {
                    handler2 = fiddlerAttach;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Combine(handler2, value);
                    fiddlerAttach = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerAttach, handler3, handler2);
                }
                while (fiddlerAttach != handler2);
            }
            remove
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerAttach = FiddlerAttach;
                do
                {
                    handler2 = fiddlerAttach;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Remove(handler2, value);
                    fiddlerAttach = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerAttach, handler3, handler2);
                }
                while (fiddlerAttach != handler2);
            }
        }

        [CodeDescription("Sync this event to be notified when Fiddler has completed startup.")]
        public static  event SimpleEventHandler FiddlerBoot
        {
            add
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerBoot = FiddlerBoot;
                do
                {
                    handler2 = fiddlerBoot;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Combine(handler2, value);
                    fiddlerBoot = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerBoot, handler3, handler2);
                }
                while (fiddlerBoot != handler2);
            }
            remove
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerBoot = FiddlerBoot;
                do
                {
                    handler2 = fiddlerBoot;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Remove(handler2, value);
                    fiddlerBoot = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerBoot, handler3, handler2);
                }
                while (fiddlerBoot != handler2);
            }
        }

        [CodeDescription("Sync this event to be notified when FiddlerCore has detached as the system proxy.")]
        public static  event SimpleEventHandler FiddlerDetach
        {
            add
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerDetach = FiddlerDetach;
                do
                {
                    handler2 = fiddlerDetach;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Combine(handler2, value);
                    fiddlerDetach = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerDetach, handler3, handler2);
                }
                while (fiddlerDetach != handler2);
            }
            remove
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerDetach = FiddlerDetach;
                do
                {
                    handler2 = fiddlerDetach;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Remove(handler2, value);
                    fiddlerDetach = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerDetach, handler3, handler2);
                }
                while (fiddlerDetach != handler2);
            }
        }

        [CodeDescription("Sync this event to be notified when Fiddler shuts down.")]
        public static  event SimpleEventHandler FiddlerShutdown
        {
            add
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerShutdown = FiddlerShutdown;
                do
                {
                    handler2 = fiddlerShutdown;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Combine(handler2, value);
                    fiddlerShutdown = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerShutdown, handler3, handler2);
                }
                while (fiddlerShutdown != handler2);
            }
            remove
            {
                SimpleEventHandler handler2;
                SimpleEventHandler fiddlerShutdown = FiddlerShutdown;
                do
                {
                    handler2 = fiddlerShutdown;
                    SimpleEventHandler handler3 = (SimpleEventHandler) Delegate.Remove(handler2, value);
                    fiddlerShutdown = Interlocked.CompareExchange<SimpleEventHandler>(ref FiddlerShutdown, handler3, handler2);
                }
                while (fiddlerShutdown != handler2);
            }
        }

        [CodeDescription("This event fires when the user instructs Fiddler to clear the cache or cookies.")]
        public static  event EventHandler<CacheClearEventArgs> OnClearCache
        {
            add
            {
                EventHandler<CacheClearEventArgs> handler2;
                EventHandler<CacheClearEventArgs> onClearCache = OnClearCache;
                do
                {
                    handler2 = onClearCache;
                    EventHandler<CacheClearEventArgs> handler3 = (EventHandler<CacheClearEventArgs>) Delegate.Combine(handler2, value);
                    onClearCache = Interlocked.CompareExchange<EventHandler<CacheClearEventArgs>>(ref OnClearCache, handler3, handler2);
                }
                while (onClearCache != handler2);
            }
            remove
            {
                EventHandler<CacheClearEventArgs> handler2;
                EventHandler<CacheClearEventArgs> onClearCache = OnClearCache;
                do
                {
                    handler2 = onClearCache;
                    EventHandler<CacheClearEventArgs> handler3 = (EventHandler<CacheClearEventArgs>) Delegate.Remove(handler2, value);
                    onClearCache = Interlocked.CompareExchange<EventHandler<CacheClearEventArgs>>(ref OnClearCache, handler3, handler2);
                }
                while (onClearCache != handler2);
            }
        }

        public static  event EventHandler<ReadSAZEventArgs> OnLoadSAZ
        {
            add
            {
                EventHandler<ReadSAZEventArgs> handler2;
                EventHandler<ReadSAZEventArgs> onLoadSAZ = OnLoadSAZ;
                do
                {
                    handler2 = onLoadSAZ;
                    EventHandler<ReadSAZEventArgs> handler3 = (EventHandler<ReadSAZEventArgs>) Delegate.Combine(handler2, value);
                    onLoadSAZ = Interlocked.CompareExchange<EventHandler<ReadSAZEventArgs>>(ref OnLoadSAZ, handler3, handler2);
                }
                while (onLoadSAZ != handler2);
            }
            remove
            {
                EventHandler<ReadSAZEventArgs> handler2;
                EventHandler<ReadSAZEventArgs> onLoadSAZ = OnLoadSAZ;
                do
                {
                    handler2 = onLoadSAZ;
                    EventHandler<ReadSAZEventArgs> handler3 = (EventHandler<ReadSAZEventArgs>) Delegate.Remove(handler2, value);
                    onLoadSAZ = Interlocked.CompareExchange<EventHandler<ReadSAZEventArgs>>(ref OnLoadSAZ, handler3, handler2);
                }
                while (onLoadSAZ != handler2);
            }
        }

        [CodeDescription("This event fires when a user notification would be shown. See CONFIG.QuietMode property.")]
        public static  event EventHandler<NotificationEventArgs> OnNotification
        {
            add
            {
                EventHandler<NotificationEventArgs> handler2;
                EventHandler<NotificationEventArgs> onNotification = OnNotification;
                do
                {
                    handler2 = onNotification;
                    EventHandler<NotificationEventArgs> handler3 = (EventHandler<NotificationEventArgs>) Delegate.Combine(handler2, value);
                    onNotification = Interlocked.CompareExchange<EventHandler<NotificationEventArgs>>(ref OnNotification, handler3, handler2);
                }
                while (onNotification != handler2);
            }
            remove
            {
                EventHandler<NotificationEventArgs> handler2;
                EventHandler<NotificationEventArgs> onNotification = OnNotification;
                do
                {
                    handler2 = onNotification;
                    EventHandler<NotificationEventArgs> handler3 = (EventHandler<NotificationEventArgs>) Delegate.Remove(handler2, value);
                    onNotification = Interlocked.CompareExchange<EventHandler<NotificationEventArgs>>(ref OnNotification, handler3, handler2);
                }
                while (onNotification != handler2);
            }
        }

        public static  event EventHandler<WriteSAZEventArgs> OnSaveSAZ
        {
            add
            {
                EventHandler<WriteSAZEventArgs> handler2;
                EventHandler<WriteSAZEventArgs> onSaveSAZ = OnSaveSAZ;
                do
                {
                    handler2 = onSaveSAZ;
                    EventHandler<WriteSAZEventArgs> handler3 = (EventHandler<WriteSAZEventArgs>) Delegate.Combine(handler2, value);
                    onSaveSAZ = Interlocked.CompareExchange<EventHandler<WriteSAZEventArgs>>(ref OnSaveSAZ, handler3, handler2);
                }
                while (onSaveSAZ != handler2);
            }
            remove
            {
                EventHandler<WriteSAZEventArgs> handler2;
                EventHandler<WriteSAZEventArgs> onSaveSAZ = OnSaveSAZ;
                do
                {
                    handler2 = onSaveSAZ;
                    EventHandler<WriteSAZEventArgs> handler3 = (EventHandler<WriteSAZEventArgs>) Delegate.Remove(handler2, value);
                    onSaveSAZ = Interlocked.CompareExchange<EventHandler<WriteSAZEventArgs>>(ref OnSaveSAZ, handler3, handler2);
                }
                while (onSaveSAZ != handler2);
            }
        }

        [CodeDescription("This event fires a HTTPS certificate is validated.")]
        public static  event EventHandler<ValidateServerCertificateEventArgs> OnValidateServerCertificate
        {
            add
            {
                EventHandler<ValidateServerCertificateEventArgs> handler2;
                EventHandler<ValidateServerCertificateEventArgs> onValidateServerCertificate = OnValidateServerCertificate;
                do
                {
                    handler2 = onValidateServerCertificate;
                    EventHandler<ValidateServerCertificateEventArgs> handler3 = (EventHandler<ValidateServerCertificateEventArgs>) Delegate.Combine(handler2, value);
                    onValidateServerCertificate = Interlocked.CompareExchange<EventHandler<ValidateServerCertificateEventArgs>>(ref OnValidateServerCertificate, handler3, handler2);
                }
                while (onValidateServerCertificate != handler2);
            }
            remove
            {
                EventHandler<ValidateServerCertificateEventArgs> handler2;
                EventHandler<ValidateServerCertificateEventArgs> onValidateServerCertificate = OnValidateServerCertificate;
                do
                {
                    handler2 = onValidateServerCertificate;
                    EventHandler<ValidateServerCertificateEventArgs> handler3 = (EventHandler<ValidateServerCertificateEventArgs>) Delegate.Remove(handler2, value);
                    onValidateServerCertificate = Interlocked.CompareExchange<EventHandler<ValidateServerCertificateEventArgs>>(ref OnValidateServerCertificate, handler3, handler2);
                }
                while (onValidateServerCertificate != handler2);
            }
        }

        public static  event EventHandler<WebSocketMessageEventArgs> OnWebSocketMessage
        {
            add
            {
                EventHandler<WebSocketMessageEventArgs> handler2;
                EventHandler<WebSocketMessageEventArgs> onWebSocketMessage = OnWebSocketMessage;
                do
                {
                    handler2 = onWebSocketMessage;
                    EventHandler<WebSocketMessageEventArgs> handler3 = (EventHandler<WebSocketMessageEventArgs>) Delegate.Combine(handler2, value);
                    onWebSocketMessage = Interlocked.CompareExchange<EventHandler<WebSocketMessageEventArgs>>(ref OnWebSocketMessage, handler3, handler2);
                }
                while (onWebSocketMessage != handler2);
            }
            remove
            {
                EventHandler<WebSocketMessageEventArgs> handler2;
                EventHandler<WebSocketMessageEventArgs> onWebSocketMessage = OnWebSocketMessage;
                do
                {
                    handler2 = onWebSocketMessage;
                    EventHandler<WebSocketMessageEventArgs> handler3 = (EventHandler<WebSocketMessageEventArgs>) Delegate.Remove(handler2, value);
                    onWebSocketMessage = Interlocked.CompareExchange<EventHandler<WebSocketMessageEventArgs>>(ref OnWebSocketMessage, handler3, handler2);
                }
                while (onWebSocketMessage != handler2);
            }
        }

        public static  event SessionStateHandler RequestHeadersAvailable
        {
            add
            {
                SessionStateHandler handler2;
                SessionStateHandler requestHeadersAvailable = RequestHeadersAvailable;
                do
                {
                    handler2 = requestHeadersAvailable;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Combine(handler2, value);
                    requestHeadersAvailable = Interlocked.CompareExchange<SessionStateHandler>(ref RequestHeadersAvailable, handler3, handler2);
                }
                while (requestHeadersAvailable != handler2);
            }
            remove
            {
                SessionStateHandler handler2;
                SessionStateHandler requestHeadersAvailable = RequestHeadersAvailable;
                do
                {
                    handler2 = requestHeadersAvailable;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Remove(handler2, value);
                    requestHeadersAvailable = Interlocked.CompareExchange<SessionStateHandler>(ref RequestHeadersAvailable, handler3, handler2);
                }
                while (requestHeadersAvailable != handler2);
            }
        }

        public static  event SessionStateHandler ResponseHeadersAvailable
        {
            add
            {
                SessionStateHandler handler2;
                SessionStateHandler responseHeadersAvailable = ResponseHeadersAvailable;
                do
                {
                    handler2 = responseHeadersAvailable;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Combine(handler2, value);
                    responseHeadersAvailable = Interlocked.CompareExchange<SessionStateHandler>(ref ResponseHeadersAvailable, handler3, handler2);
                }
                while (responseHeadersAvailable != handler2);
            }
            remove
            {
                SessionStateHandler handler2;
                SessionStateHandler responseHeadersAvailable = ResponseHeadersAvailable;
                do
                {
                    handler2 = responseHeadersAvailable;
                    SessionStateHandler handler3 = (SessionStateHandler) Delegate.Remove(handler2, value);
                    responseHeadersAvailable = Interlocked.CompareExchange<SessionStateHandler>(ref ResponseHeadersAvailable, handler3, handler2);
                }
                while (responseHeadersAvailable != handler2);
            }
        }

        static FiddlerApplication()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                iPID = currentProcess.Id;
                sProcessInfo = string.Format("{0}:{1}", currentProcess.ProcessName.ToLower(), iPID);
                currentProcess.Dispose();
            }
            catch (Exception)
            {
            }
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        internal static void _SetXceedLicenseKeys()
        {
            try
            {
                Xceed.Zip.Licenser.LicenseKey = "ZIN54Y14HB8WUMDXBCA";
            }
            catch (Exception exception)
            {
                ReportException(exception, "Failed to set license key for Xceed.ZIP");
            }
            try
            {
                Xceed.Compression.Formats.Licenser.LicenseKey = "FTN54Y14HB8WUCK9U2A";
            }
            catch (Exception exception2)
            {
                ReportException(exception2, "Failed to set license key for Xceed.Compression");
            }
        }

        [CodeDescription("Notify the user of an event by showing a balloon tip if Fiddler is in the system tray.")]
        public static void AlertUser(string sTitle, string sMessage)
        {
            if ((!isClosing && (_frmMain != null)) && (_frmMain.notifyIcon != null))
            {
                _frmMain.notifyIcon.ShowBalloonTip(0x3e8, sTitle, sMessage, ToolTipIcon.Info);
            }
        }

        internal static void CheckOverrideCertificatePolicy(Session oS, string sExpectedCN, X509Certificate ServerCertificate, X509Chain ServerCertificateChain, SslPolicyErrors sslPolicyErrors, ref CertificateValidity oValidity)
        {
            EventHandler<ValidateServerCertificateEventArgs> onValidateServerCertificate = OnValidateServerCertificate;
            if (onValidateServerCertificate != null)
            {
                ValidateServerCertificateEventArgs e = new ValidateServerCertificateEventArgs(oS, sExpectedCN, ServerCertificate, ServerCertificateChain, sslPolicyErrors);
                onValidateServerCertificate(oS, e);
                oValidity = e.ValidityState;
            }
        }

        internal static void DebugSpew(string sMessage)
        {
            if (CONFIG.bDebugSpew)
            {
                Trace.WriteLine(sMessage);
            }
        }

        internal static void DebugSpew(string sMessage, params object[] args)
        {
            if (CONFIG.bDebugSpew)
            {
                Trace.WriteLine(string.Format(sMessage, args));
            }
        }

        internal static void DoAfterLoadSAZ(string sFilename, Session[] arrSessions, string sContext)
        {
            EventHandler<ReadSAZEventArgs> onLoadSAZ = OnLoadSAZ;
            if (onLoadSAZ != null)
            {
                ReadSAZEventArgs e = new ReadSAZEventArgs(sFilename, arrSessions, sContext);
                onLoadSAZ(UI, e);
            }
        }

        internal static void DoAfterSessionComplete(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                if (AfterSessionComplete != null)
                {
                    AfterSessionComplete(oSession);
                }
                if (scriptRules != null)
                {
                    scriptRules.DoSessionCompleted(oSession);
                }
            }
        }

        internal static void DoAfterSocketAccept(Session oSession, Socket sockClient)
        {
            EventHandler<ConnectionEventArgs> afterSocketAccept = AfterSocketAccept;
            if (afterSocketAccept != null)
            {
                ConnectionEventArgs e = new ConnectionEventArgs(oSession, sockClient);
                afterSocketAccept(oSession, e);
            }
        }

        internal static void DoAfterSocketConnect(Session oSession, Socket sockServer)
        {
            EventHandler<ConnectionEventArgs> afterSocketConnect = AfterSocketConnect;
            if (afterSocketConnect != null)
            {
                ConnectionEventArgs e = new ConnectionEventArgs(oSession, sockServer);
                afterSocketConnect(oSession, e);
            }
        }

        internal static bool DoBeforeInspect(Session oSession)
        {
            if (BeforeInspectSession == null)
            {
                return true;
            }
            CancelEventArgs e = new CancelEventArgs();
            try
            {
                BeforeInspectSession(oSession, e);
            }
            catch (Exception exception)
            {
                ReportException(exception, "BeforeInspect Error");
            }
            return !e.Cancel;
        }

        internal static void DoBeforeRequest(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored) && (BeforeRequest != null))
            {
                BeforeRequest(oSession);
            }
        }

        internal static void DoBeforeResponse(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored) && (BeforeResponse != null))
            {
                BeforeResponse(oSession);
            }
        }

        internal static void DoBeforeReturningError(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                if (BeforeReturningError != null)
                {
                    BeforeReturningError(oSession);
                }
                oExtensions.DoBeforeReturningError(oSession);
            }
        }

        internal static bool DoBeforeSaveSAZ(string sFilename, Session[] arrSessions)
        {
            EventHandler<WriteSAZEventArgs> onSaveSAZ = OnSaveSAZ;
            if (onSaveSAZ != null)
            {
                WriteSAZEventArgs e = new WriteSAZEventArgs(sFilename, arrSessions);
                onSaveSAZ(UI, e);
                return !e.Cancel;
            }
            return true;
        }

        internal static bool DoClearCache(bool bClearFiles, bool bClearCookies)
        {
            EventHandler<CacheClearEventArgs> onClearCache = OnClearCache;
            if (onClearCache == null)
            {
                return true;
            }
            CacheClearEventArgs e = new CacheClearEventArgs(bClearFiles, bClearCookies);
            onClearCache(null, e);
            return !e.Cancel;
        }

        [CodeDescription("Switch to, and fill the Request Composer tab with a copy of the request from the supplied Session.")]
        public static bool DoComposeByCloning(Session oSession)
        {
            if (UIComposer.FillUIFromSession(oSession))
            {
                UIComposer.EnsureShowing();
                return true;
            }
            return false;
        }

        [CodeDescription("Switch to, and fill the Request Composer tab with the Request information supplied.")]
        public static bool DoComposeFrom(HTTPRequestHeaders oRH, byte[] arrRequestBody)
        {
            Session oSession = new Session(oRH, arrRequestBody);
            return DoComposeByCloning(oSession);
        }

        public static bool DoExport(string sExportFormat, Session[] oSessions, Dictionary<string, object> dictOptions, EventHandler<ProgressCallbackEventArgs> ehPCEA)
        {
            if (string.IsNullOrEmpty(sExportFormat))
            {
                return false;
            }
            TranscoderTuple tuple = oTranscoders.GetExporter(sExportFormat);
            if (tuple == null)
            {
                Log.LogFormat("No exporter for the format '{0}' was available.", new object[] { sExportFormat });
                return false;
            }
            bool flag = false;
            try
            {
                oTelemetry.TrackEvent("Actions.DoExport");
                UI.UseWaitCursor = true;
                ISessionExporter exporter = (ISessionExporter) Activator.CreateInstance(tuple.typeFormatter);
                if (ehPCEA == null)
                {
                    ehPCEA = delegate (object sender, ProgressCallbackEventArgs oPCE) {
                        string str = (oPCE.PercentComplete > 0) ? ("Export is " + oPCE.PercentComplete + "% complete; ") : string.Empty;
                        Log.LogFormat("{0}{1}", new object[] { str, oPCE.ProgressText });
                        Application.DoEvents();
                    };
                }
                flag = exporter.ExportSessions(sExportFormat, oSessions, dictOptions, ehPCEA);
                exporter.Dispose();
            }
            catch (Exception exception)
            {
                LogAddonException(exception, "Exporter for " + sExportFormat + " failed.");
                flag = false;
            }
            UI.UseWaitCursor = false;
            return flag;
        }

        public static Session[] DoImport(string sImportFormat, bool bAddToSessionList, Dictionary<string, object> dictOptions, EventHandler<ProgressCallbackEventArgs> ehPCEA)
        {
            Session[] sessionArray;
            if (string.IsNullOrEmpty(sImportFormat))
            {
                return null;
            }
            TranscoderTuple tuple = oTranscoders.GetImporter(sImportFormat);
            if (tuple == null)
            {
                return null;
            }
            try
            {
                oTelemetry.TrackEvent("Actions.DoImport");
                UI.UseWaitCursor = true;
                ISessionImporter importer = (ISessionImporter) Activator.CreateInstance(tuple.typeFormatter);
                if (ehPCEA == null)
                {
                    ehPCEA = delegate (object sender, ProgressCallbackEventArgs oPCE) {
                        string str = (oPCE.PercentComplete > 0) ? ("Import is " + oPCE.PercentComplete + "% complete; ") : string.Empty;
                        Log.LogFormat("{0}{1}", new object[] { str, oPCE.ProgressText });
                        Application.DoEvents();
                    };
                }
                sessionArray = importer.ImportSessions(sImportFormat, dictOptions, ehPCEA);
                importer.Dispose();
                if (sessionArray == null)
                {
                    UI.UseWaitCursor = false;
                    return null;
                }
                if (bAddToSessionList)
                {
                    UI.AddImportedSessions(sessionArray);
                }
            }
            catch (Exception exception)
            {
                LogAddonException(exception, "Importer for " + sImportFormat + " failed.");
                sessionArray = null;
            }
            UI.UseWaitCursor = false;
            return sessionArray;
        }

        public static void DoNotifyUser(Exception eX, string sTitle)
        {
            DoNotifyUser(null, Utilities.DescribeException(eX), sTitle, MessageBoxIcon.Hand);
        }

        public static void DoNotifyUser(string sMessage, string sTitle)
        {
            DoNotifyUser(null, sMessage, sTitle, MessageBoxIcon.None);
        }

        public static void DoNotifyUser(string sMessage, string sTitle, MessageBoxIcon oIcon)
        {
            DoNotifyUser(null, sMessage, sTitle, oIcon);
        }

        public static void DoNotifyUser(IWin32Window ownerWnd, string sMessage, string sTitle, MessageBoxIcon oIcon)
        {
            if (OnNotification != null)
            {
                NotificationEventArgs e = new NotificationEventArgs(string.Format("{0} - {1}", sTitle, sMessage));
                OnNotification(null, e);
            }
            if (!CONFIG.QuietMode)
            {
                MessageBox.Show(ownerWnd, sMessage, sTitle, MessageBoxButtons.OK, oIcon);
            }
        }

        internal static void DoOnWebSocketMessage(Session oS, WebSocketMessage oWSM)
        {
            if (!oS.isFlagSet(SessionFlags.Ignored))
            {
                EventHandler<WebSocketMessageEventArgs> onWebSocketMessage = OnWebSocketMessage;
                if (onWebSocketMessage != null)
                {
                    onWebSocketMessage(oS, new WebSocketMessageEventArgs(oWSM));
                }
                if (scriptRules != null)
                {
                    scriptRules.DoWebSocketMessage(oWSM);
                }
            }
        }

        internal static void DoRequestHeadersAvailable(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                if (RequestHeadersAvailable != null)
                {
                    RequestHeadersAvailable(oSession);
                }
                oExtensions.DoPeekAtRequestHeaders(oSession);
            }
        }

        internal static void DoResponseHeadersAvailable(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                if (ResponseHeadersAvailable != null)
                {
                    ResponseHeadersAvailable(oSession);
                }
                oExtensions.DoPeekAtResponseHeaders(oSession);
            }
        }

        public static string GetDetailedInfo()
        {
            StringBuilder builder = new StringBuilder(0x200);
            builder.AppendFormat("You've run Fiddler: {0:N0} times.\n", CONFIG.iStartupCount);
            builder.AppendFormat("\nRunning {0}on: {1}:{2}\n", Utilities.IsUserAnAdmin() ? "ELEVATED " : string.Empty, CONFIG.sMachineName, oProxy.ListenPort.ToString());
            if (CONFIG.bHookAllConnections)
            {
                builder.AppendLine("Listening to: All Adapters");
            }
            else
            {
                builder.AppendFormat("Listening to: {0}\n", CONFIG.sHookConnectionNamed ?? "Default LAN");
            }
            if (CONFIG.iReverseProxyForPort > 0)
            {
                builder.AppendFormat("Acting as reverse proxy for port #{0}\n", CONFIG.iReverseProxyForPort);
            }
            builder.Append(oProxy.GetGatewayInformation());
            string str = string.Empty;
            try
            {
                str = string.Format("Built: {0}\n", ((FiddlerBuildDate) Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(FiddlerBuildDate), false)[0]).ToString());
            }
            catch
            {
            }
            return string.Format("Fiddler Web Debugger ({0})\n{8}\n{1}-bit {2}, VM: {3:N1}mb, WS: {4:N1}mb\n{5} {6}\n\n{7}\n", new object[] { CONFIG.bIsBeta ? string.Format("v{0} beta", Application.ProductVersion) : string.Format("v{0}", Application.ProductVersion), (8 == IntPtr.Size) ? "64" : "32", Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE"), Process.GetCurrentProcess().PagedMemorySize64 / 0x100000L, Process.GetCurrentProcess().WorkingSet64 / 0x100000L, ".NET " + Environment.Version, Utilities.GetOSVerString(), builder.ToString(), str });
        }

        public static string GetVersionString()
        {
            FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
            string str = " (+SAZ)";
            string str2 = "Fiddler";
            return string.Format("{0}/{1}.{2}.{3}.{4}{5}", new object[] { str2, versionInfo.FileMajorPart, versionInfo.FileMinorPart, versionInfo.FileBuildPart, versionInfo.FilePrivatePart, str });
        }

        internal static void HandleHTTPError(Session oSession, SessionFlags flagViolation, bool bPoisonClientConnection, bool bPoisonServerConnection, string sMessage)
        {
            oSession.EnsureID();
            if (bPoisonClientConnection)
            {
                oSession.PoisonClientPipe();
            }
            if (bPoisonServerConnection)
            {
                oSession.PoisonServerPipe();
            }
            oSession.SetBitFlag(flagViolation, true);
            oSession["ui-backcolor"] = "LightYellow";
            if (CONFIG.bReportHTTPErrors && !CONFIG.QuietMode)
            {
                oSession.oFlags.Remove("ui-hide");
                UINotifyList.ReportHTTPError(oSession.id, sMessage);
            }
            Log.LogFormat("{0} - [#{1}] {2}", new object[] { "Fiddler.Network.ProtocolViolation", oSession.id.ToString(), sMessage });
            sMessage = "[ProtocolViolation] " + sMessage;
            if ((oSession["x-HTTPProtocol-Violation"] == null) || !oSession["x-HTTPProtocol-Violation"].Contains(sMessage))
            {
                Session session;
                (session = oSession)["x-HTTPProtocol-Violation"] = session["x-HTTPProtocol-Violation"] + sMessage;
            }
        }

        internal static void LogAddonException(Exception eX, string sTitle)
        {
            if (Prefs.GetBoolPref("fiddler.debug.extensions.showerrors", false) || Prefs.GetBoolPref("fiddler.debug.extensions.verbose", false))
            {
                Log.LogFormat("!Exception from Extension: {0}", new object[] { Utilities.DescribeException(eX) });
                ReportException(eX, sTitle, "Fiddler has encountered an unexpected problem with an extension.");
            }
        }

        public static void LogLeakedFile(string sTempFile)
        {
            List<string> list;
            bool lockTaken = false;
            try
            {
                System.Threading.Monitor.Enter(list = slLeakedFiles, ref lockTaken);
                slLeakedFiles.Add(sTempFile);
            }
            finally
            {
                if (lockTaken)
                {
                    System.Threading.Monitor.Exit(list);
                }
            }
        }

        internal static bool OnBeforeFiddlerShutdown()
        {
            object obj2;
            if (((scriptRules != null) && scriptRules.DoMethod("OnBeforeShutdown", null, out obj2)) && !((bool) obj2))
            {
                return false;
            }
            CancelEventHandler beforeFiddlerShutdown = BeforeFiddlerShutdown;
            if (beforeFiddlerShutdown != null)
            {
                CancelEventArgs e = new CancelEventArgs(false);
                beforeFiddlerShutdown(null, e);
                if (e.Cancel)
                {
                    return false;
                }
            }
            return true;
        }

        internal static void OnCalculateReport(Session[] _arrSessions)
        {
            if ((!_bSuppressReportUpdates && !isClosing) && (CalculateReport != null))
            {
                CalculateReport(_arrSessions);
            }
        }

        internal static void OnFiddlerAttach()
        {
            _frmMain.miCaptureEnabled.Checked = true;
            _frmMain.miNotifyCapturing.Checked = true;
            if (scriptRules != null)
            {
                scriptRules.DoOnAttach();
            }
            if (FiddlerAttach != null)
            {
                FiddlerAttach();
            }
        }

        internal static void OnFiddlerBoot()
        {
            if (scriptRules != null)
            {
                scriptRules.DoOnBoot();
            }
            if (FiddlerBoot != null)
            {
                FiddlerBoot();
            }
            _Log.FlushStartupMessages();
        }

        internal static void OnFiddlerDetach()
        {
            _frmMain.miCaptureEnabled.Checked = false;
            _frmMain.miNotifyCapturing.Checked = false;
            if (scriptRules != null)
            {
                scriptRules.DoOnDetach();
            }
            if (FiddlerDetach != null)
            {
                FiddlerDetach();
            }
        }

        internal static void OnFiddlerShutdown()
        {
            if (scriptRules != null)
            {
                scriptRules.DoOnShutdown();
            }
            SimpleEventHandler fiddlerShutdown = FiddlerShutdown;
            if (fiddlerShutdown != null)
            {
                fiddlerShutdown();
            }
            WipeLeakedFiles();
        }

        internal static void ReportException(Exception eX)
        {
            string sTitle = "Awww, Fiddlesticks!";
            ReportException(eX, sTitle, null);
        }

        public static void ReportException(Exception eX, string sTitle)
        {
            ReportException(eX, sTitle, null);
        }

        public static void ReportException(Exception eX, string sTitle, string sCallerMessage)
        {
            Trace.WriteLine(string.Concat(new object[] { "******Fiddler ReportException()******\n", eX.Message, "\n", eX.StackTrace, "\n", eX.InnerException, "\nIsClosing: ", isClosing }));
            if (!(eX is ThreadAbortException) || !isClosing)
            {
                string str;
                if (eX is ConfigurationErrorsException)
                {
                    str = "Your Microsoft .NET Configuration file is corrupt and contains invalid data. You can often correct this error by installing updates from WindowsUpdate and/or reinstalling the .NET Framework.\r\n";
                }
                else if (eX is OutOfMemoryException)
                {
                    sTitle = "Insufficient Memory Address Space";
                    str = "An out-of-memory exception was encountered.\nGC Total Allocated: " + GC.GetTotalMemory(false).ToString("N0") + " bytes.\n\nTo help avoid this exception, please see: " + CONFIG.GetRedirUrl("FIDDLEROOM");
                }
                else if (string.IsNullOrEmpty(sCallerMessage))
                {
                    str = "Fiddler has encountered an unexpected problem. If you believe this is a bug in Fiddler, please copy this message by hitting CTRL+C, and submit a bug report using the Help | Send Feedback menu.";
                }
                else
                {
                    str = sCallerMessage;
                }
                DoNotifyUser(string.Concat(new object[] { 
                    str, "\n\n", eX.Message, "\n\nType: ", eX.GetType().ToString(), "\nSource: ", eX.Source, "\n", eX.StackTrace, "\n\n", eX.InnerException, "\nFiddler v", Application.ProductVersion, (8 == IntPtr.Size) ? " (x64 " : " (x86 ", Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE"), ") [.NET ", 
                    Environment.Version, " on ", Environment.OSVersion.VersionString, "] "
                 }), sTitle, MessageBoxIcon.Hand);
                oTelemetry.TrackException(eX);
            }
        }

        [CodeDescription("Reset the SessionID counter to 0. This method can lead to confusing UI, so call sparingly.")]
        public static void ResetSessionCounter()
        {
            Session.ResetSessionCounter();
        }

        public static bool Supports(string sFeatureName)
        {
            switch (sFeatureName)
            {
                case "bzip2":
                    return true;

                case "xpress":
                    return Utilities.IsWin8OrLater();

                case "br":
                {
                    try
                    {
                        return File.Exists(CONFIG.GetPath("Tools") + "brotli.exe");
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
            }
            return false;
        }

        internal static void UIInvoke(MethodInvoker target)
        {
            if (!isClosing)
            {
                if (_frmMain.InvokeRequired)
                {
                    _frmMain.Invoke(target);
                }
                else
                {
                    target();
                }
            }
        }

        internal static void UIInvokeAsync(Delegate oDel, object[] args)
        {
            if (!isClosing)
            {
                _frmMain.BeginInvoke(oDel, args);
            }
        }

        internal static void WipeLeakedFiles()
        {
            try
            {
                if (slLeakedFiles.Count >= 1)
                {
                    List<string> list;
                    bool lockTaken = false;
                    try
                    {
                        System.Threading.Monitor.Enter(list = slLeakedFiles, ref lockTaken);
                        foreach (string str in slLeakedFiles)
                        {
                            try
                            {
                                File.Delete(str);
                                continue;
                            }
                            catch (Exception)
                            {
                                continue;
                            }
                        }
                        slLeakedFiles.Clear();
                    }
                    finally
                    {
                        if (lockTaken)
                        {
                            System.Threading.Monitor.Exit(list);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Trace.WriteLine(string.Format("Fiddler.WipeLeakedFiles failed! {0}", exception.Message));
            }
        }

        public static bool IsViewerMode
        {
            get
            {
                return CONFIG.bIsViewOnly;
            }
        }

        [CodeDescription("Fiddler's logging subsystem; displayed on the LOG tab by default.")]
        public static Logger Log
        {
            get
            {
                return _Log;
            }
        }

        [CodeDescription("Fiddler's AutoResponder object.")]
        public static AutoResponder oAutoResponder
        {
            get
            {
                return _AutoResponder;
            }
        }

        public static ISAZProvider oSAZProvider
        {
            get
            {
                return new XceedProvider();
            }
        }

        [CodeDescription("Fiddler's Preferences collection. http://fiddler.wikidot.com/prefs")]
        public static IFiddlerPreferences Prefs
        {
            get
            {
                return CONFIG.RawPrefs;
            }
        }

        internal static bool SuppressReportUpdates
        {
            get
            {
                return _bSuppressReportUpdates;
            }
            set
            {
                _bSuppressReportUpdates = value;
                if (!_bSuppressReportUpdates)
                {
                    _frmMain.actReportStatistics(true);
                }
            }
        }

        [CodeDescription("Fiddler's main form.")]
        public static frmViewer UI
        {
            get
            {
                return _frmMain;
            }
        }

        public class ReadSAZEventArgs : EventArgs
        {
            [CompilerGenerated]
            private Session[] <arrSessions>k__BackingField;
            [CompilerGenerated]
            private string <sContext>k__BackingField;
            [CompilerGenerated]
            private string <sFilename>k__BackingField;

            public ReadSAZEventArgs(string _sFilename, Session[] _arrSessions, string _sContext)
            {
                this.sFilename = _sFilename;
                this.arrSessions = _arrSessions;
                this.sContext = _sContext;
            }

            public Session[] arrSessions
            {
                [CompilerGenerated]
                get
                {
                    return this.<arrSessions>k__BackingField;
                }
                private [CompilerGenerated]
                set
                {
                    this.<arrSessions>k__BackingField = value;
                }
            }

            public string sContext
            {
                [CompilerGenerated]
                get
                {
                    return this.<sContext>k__BackingField;
                }
                private [CompilerGenerated]
                set
                {
                    this.<sContext>k__BackingField = value;
                }
            }

            public string sFilename
            {
                [CompilerGenerated]
                get
                {
                    return this.<sFilename>k__BackingField;
                }
                private [CompilerGenerated]
                set
                {
                    this.<sFilename>k__BackingField = value;
                }
            }
        }

        public class WriteSAZEventArgs : EventArgs
        {
            [CompilerGenerated]
            private Session[] <arrSessions>k__BackingField;
            [CompilerGenerated]
            private bool <Cancel>k__BackingField;
            [CompilerGenerated]
            private string <sFilename>k__BackingField;

            public WriteSAZEventArgs(string _sFilename, Session[] _arrSessions)
            {
                this.sFilename = _sFilename;
                this.arrSessions = _arrSessions;
            }

            public Session[] arrSessions
            {
                [CompilerGenerated]
                get
                {
                    return this.<arrSessions>k__BackingField;
                }
                [CompilerGenerated]
                set
                {
                    this.<arrSessions>k__BackingField = value;
                }
            }

            public bool Cancel
            {
                [CompilerGenerated]
                get
                {
                    return this.<Cancel>k__BackingField;
                }
                [CompilerGenerated]
                set
                {
                    this.<Cancel>k__BackingField = value;
                }
            }

            public string sFilename
            {
                [CompilerGenerated]
                get
                {
                    return this.<sFilename>k__BackingField;
                }
                [CompilerGenerated]
                set
                {
                    this.<sFilename>k__BackingField = value;
                }
            }
        }
    }
}

