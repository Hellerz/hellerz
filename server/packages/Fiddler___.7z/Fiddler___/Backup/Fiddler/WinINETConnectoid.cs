﻿namespace Fiddler
{
    using System;

    internal class WinINETConnectoid
    {
        internal bool bIsHooked;
        internal WinINETProxyInfo oOriginalProxyInfo;
        internal string sConnectionName;
    }
}

