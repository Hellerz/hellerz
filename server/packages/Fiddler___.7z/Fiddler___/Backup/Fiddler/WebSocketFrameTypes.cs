﻿namespace Fiddler
{
    using System;

    public enum WebSocketFrameTypes : byte
    {
        Binary = 2,
        Close = 8,
        Continuation = 0,
        Ping = 9,
        Pong = 10,
        Reservedx3 = 3,
        Reservedx4 = 4,
        Reservedx5 = 5,
        Reservedx6 = 6,
        Reservedx7 = 7,
        ReservedxB = 11,
        ReservedxC = 12,
        ReservedxD = 13,
        ReservedxE = 14,
        ReservedxF = 15,
        Text = 1
    }
}

