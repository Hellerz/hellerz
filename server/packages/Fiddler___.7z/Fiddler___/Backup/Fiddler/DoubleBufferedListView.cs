﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    public class DoubleBufferedListView : ListView
    {
        [CompilerGenerated]
        private string <EmptyText>k__BackingField;

        public DoubleBufferedListView()
        {
            if (!base.DesignMode)
            {
                this.DoubleBuffered = true;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            LVNative.DontSelectBorderImage(this);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x204e)
            {
                LVNative.NMHDR lParam = (LVNative.NMHDR) m.GetLParam(typeof(LVNative.NMHDR));
                if ((-187 == lParam.code) && (base.Handle == lParam.hwndFrom))
                {
                    LVNative.NMLVEMPTYMARKUP structure = (LVNative.NMLVEMPTYMARKUP) m.GetLParam(typeof(LVNative.NMLVEMPTYMARKUP));
                    structure.szMarkup = this.EmptyText;
                    structure.dwFlags = 1;
                    Marshal.StructureToPtr(structure, m.LParam, true);
                    m.Result = (IntPtr) 1;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        public string EmptyText
        {
            [CompilerGenerated]
            get
            {
                return this.<EmptyText>k__BackingField;
            }
            [CompilerGenerated]
            set
            {
                this.<EmptyText>k__BackingField = value;
            }
        }
    }
}

