﻿namespace Fiddler
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Runtime.InteropServices;

    public class Parser
    {
        private static int _GetEntityLengthFromHeaders(HTTPHeaders oHeaders, MemoryStream strmData)
        {
            if (oHeaders.ExistsAndEquals("Transfer-Encoding", "chunked"))
            {
                long num;
                long num2;
                if (Utilities.IsChunkedBodyComplete(null, strmData, strmData.Position, out num, out num2))
                {
                    return (int) (num2 - strmData.Position);
                }
                return (int) (strmData.Length - strmData.Position);
            }
            string str = oHeaders["Content-Length"];
            if (!string.IsNullOrEmpty(str))
            {
                long result = 0L;
                if (long.TryParse(str, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out result) && (result >= 0L))
                {
                    return (int) result;
                }
                return (int) (strmData.Length - strmData.Position);
            }
            if (oHeaders.ExistsAndContains("Connection", "close"))
            {
                return (int) (strmData.Length - strmData.Position);
            }
            return 0;
        }

        private static string[] _GetHeaderLines(string sInput)
        {
            if (sInput.Length >= 2)
            {
                int index = sInput.IndexOf("\r\n\r\n", StringComparison.Ordinal);
                if (index < 1)
                {
                    index = sInput.Length;
                }
                string[] strArray = sInput.Substring(0, index).Replace("\r\n", "\n").Split(new char[] { '\n' });
                if ((strArray != null) && (strArray.Length >= 1))
                {
                    return strArray;
                }
            }
            return null;
        }

        internal static void CrackRequestLine(byte[] arrRequest, out int ixURIOffset, out int iURILen, out int ixHeaderNVPOffset, out string sMalformedURI)
        {
            int num2;
            ixHeaderNVPOffset = num2 = 0;
            ixURIOffset = iURILen = num2;
            int index = 0;
            sMalformedURI = null;
            do
            {
                if (0x20 == arrRequest[index])
                {
                    if (ixURIOffset == 0)
                    {
                        ixURIOffset = index + 1;
                    }
                    else if (iURILen == 0)
                    {
                        iURILen = index - ixURIOffset;
                    }
                    else
                    {
                        sMalformedURI = "Extra whitespace found in Request Line";
                    }
                }
                else if (arrRequest[index] == 10)
                {
                    ixHeaderNVPOffset = index + 1;
                }
                index++;
            }
            while (ixHeaderNVPOffset == 0);
        }

        internal static bool FindEndOfHeaders(byte[] arrData, ref int iBodySeekProgress, long lngDataLen, out HTTPHeaderParseWarnings oWarnings)
        {
            bool flag;
            oWarnings = HTTPHeaderParseWarnings.None;
        Label_0003:
            flag = false;
            while (((long) iBodySeekProgress) < (lngDataLen - 1L))
            {
                if (10 == arrData[iBodySeekProgress++])
                {
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                if (10 == arrData[iBodySeekProgress])
                {
                    oWarnings = HTTPHeaderParseWarnings.EndedWithLFLF;
                    return true;
                }
                if (13 != arrData[iBodySeekProgress])
                {
                    iBodySeekProgress++;
                    goto Label_0003;
                }
                iBodySeekProgress++;
                if (((long) iBodySeekProgress) < lngDataLen)
                {
                    if (10 == arrData[iBodySeekProgress])
                    {
                        if (13 != arrData[iBodySeekProgress - 3])
                        {
                            oWarnings = HTTPHeaderParseWarnings.EndedWithLFCRLF;
                        }
                        return true;
                    }
                    oWarnings = HTTPHeaderParseWarnings.Malformed;
                    return false;
                }
                if (iBodySeekProgress > 3)
                {
                    iBodySeekProgress -= 4;
                }
                else
                {
                    iBodySeekProgress = 0;
                }
            }
            return false;
        }

        public static bool FindEntityBodyOffsetFromArray(byte[] arrData, out int iHeadersLen, out int iEntityBodyOffset, out HTTPHeaderParseWarnings outWarnings)
        {
            if ((arrData != null) && (arrData.Length >= 2))
            {
                int iBodySeekProgress = 0;
                long length = arrData.Length;
                if (FindEndOfHeaders(arrData, ref iBodySeekProgress, length, out outWarnings))
                {
                    iEntityBodyOffset = iBodySeekProgress + 1;
                    switch (outWarnings)
                    {
                        case HTTPHeaderParseWarnings.None:
                            iHeadersLen = iBodySeekProgress - 3;
                            return true;

                        case HTTPHeaderParseWarnings.EndedWithLFLF:
                            iHeadersLen = iBodySeekProgress - 1;
                            return true;

                        case HTTPHeaderParseWarnings.EndedWithLFCRLF:
                            iHeadersLen = iBodySeekProgress - 2;
                            return true;
                    }
                }
            }
            iHeadersLen = iEntityBodyOffset = -1;
            outWarnings = HTTPHeaderParseWarnings.Malformed;
            return false;
        }

        private static bool IsPrefixedWithWhitespace(string s)
        {
            return ((s.Length > 0) && char.IsWhiteSpace(s[0]));
        }

        internal static bool ParseNVPHeaders(HTTPHeaders oHeaders, string[] sHeaderLines, int iStartAt, ref string sErrors)
        {
            bool flag = true;
            int index = iStartAt;
            HTTPHeaderItem item = null;
            while (index < sHeaderLines.Length)
            {
                int length = sHeaderLines[index].IndexOf(':');
                if (length > 0)
                {
                    item = oHeaders.Add(sHeaderLines[index].Substring(0, length), sHeaderLines[index].Substring(length + 1).TrimStart(new char[] { ' ', '\t' }));
                }
                else if (length == 0)
                {
                    item = null;
                    sErrors = sErrors + string.Format("Missing Header name #{0}, {1}\n", (1 + index) - iStartAt, sHeaderLines[index]);
                    flag = false;
                }
                else
                {
                    item = oHeaders.Add(sHeaderLines[index], string.Empty);
                    sErrors = sErrors + string.Format("Missing colon in header #{0}, {1}\n", (1 + index) - iStartAt, sHeaderLines[index]);
                    flag = false;
                }
                index++;
                for (bool flag2 = ((item != null) && (index < sHeaderLines.Length)) && IsPrefixedWithWhitespace(sHeaderLines[index]); flag2; flag2 = (index < sHeaderLines.Length) && IsPrefixedWithWhitespace(sHeaderLines[index]))
                {
                    FiddlerApplication.Log.LogString("[HTTPWarning] Header folding detected. Not all clients properly handle folded headers.");
                    item.Value = item.Value + " " + sHeaderLines[index].TrimStart(new char[] { ' ', '\t' });
                    index++;
                }
            }
            return flag;
        }

        public static HTTPRequestHeaders ParseRequest(string sRequest)
        {
            string[] sHeaderLines = _GetHeaderLines(sRequest);
            if (sHeaderLines != null)
            {
                HTTPRequestHeaders oHeaders = new HTTPRequestHeaders(CONFIG.oHeaderEncoding);
                int index = sHeaderLines[0].IndexOf(' ');
                if (index > 0)
                {
                    oHeaders.HTTPMethod = sHeaderLines[0].Substring(0, index).ToUpperInvariant();
                    sHeaderLines[0] = sHeaderLines[0].Substring(index).Trim();
                }
                index = sHeaderLines[0].LastIndexOf(' ');
                if (index > 0)
                {
                    string inStr = sHeaderLines[0].Substring(0, index);
                    oHeaders.HTTPVersion = sHeaderLines[0].Substring(index).Trim().ToUpperInvariant();
                    if (inStr.OICStartsWith("http://"))
                    {
                        oHeaders.UriScheme = "http";
                        index = inStr.IndexOfAny(new char[] { '/', '?' }, 7);
                        if (index == -1)
                        {
                            oHeaders.RequestPath = "/";
                        }
                        else
                        {
                            oHeaders.RequestPath = inStr.Substring(index);
                        }
                    }
                    else if (inStr.OICStartsWith("https://"))
                    {
                        oHeaders.UriScheme = "https";
                        index = inStr.IndexOfAny(new char[] { '/', '?' }, 8);
                        if (index == -1)
                        {
                            oHeaders.RequestPath = "/";
                        }
                        else
                        {
                            oHeaders.RequestPath = inStr.Substring(index);
                        }
                    }
                    else if (inStr.OICStartsWith("ftp://"))
                    {
                        oHeaders.UriScheme = "ftp";
                        index = inStr.IndexOf('/', 6);
                        if (index == -1)
                        {
                            oHeaders.RequestPath = "/";
                        }
                        else
                        {
                            string sString = inStr.Substring(6, index - 6);
                            if (sString.Contains("@"))
                            {
                                oHeaders.UriUserInfo = Utilities.TrimTo(sString, sString.IndexOf("@") + 1);
                            }
                            oHeaders.RequestPath = inStr.Substring(index);
                        }
                    }
                    else
                    {
                        oHeaders.RequestPath = inStr;
                    }
                    string sErrors = string.Empty;
                    ParseNVPHeaders(oHeaders, sHeaderLines, 1, ref sErrors);
                    return oHeaders;
                }
            }
            return null;
        }

        public static HTTPResponseHeaders ParseResponse(string sResponse)
        {
            string[] sHeaderLines = _GetHeaderLines(sResponse);
            if (sHeaderLines != null)
            {
                HTTPResponseHeaders oHeaders = new HTTPResponseHeaders(CONFIG.oHeaderEncoding);
                int index = sHeaderLines[0].IndexOf(' ');
                if (index > 0)
                {
                    oHeaders.HTTPVersion = sHeaderLines[0].Substring(0, index).ToUpperInvariant();
                    sHeaderLines[0] = sHeaderLines[0].Substring(index + 1).Trim();
                    if (!oHeaders.HTTPVersion.OICStartsWith("HTTP/"))
                    {
                        return null;
                    }
                    oHeaders.HTTPResponseStatus = sHeaderLines[0];
                    bool flag = false;
                    index = sHeaderLines[0].IndexOf(' ');
                    if (index > 0)
                    {
                        flag = int.TryParse(sHeaderLines[0].Substring(0, index).Trim(), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out oHeaders.HTTPResponseCode);
                    }
                    else
                    {
                        flag = int.TryParse(sHeaderLines[0].Trim(), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out oHeaders.HTTPResponseCode);
                    }
                    if (!flag)
                    {
                        return null;
                    }
                    string sErrors = string.Empty;
                    ParseNVPHeaders(oHeaders, sHeaderLines, 1, ref sErrors);
                    return oHeaders;
                }
            }
            return null;
        }

        public static bool TakeRequest(MemoryStream strmClient, out HTTPRequestHeaders headersRequest, out byte[] arrRequestBody)
        {
            headersRequest = null;
            arrRequestBody = Utilities.emptyByteArray;
            if ((strmClient.Length - strmClient.Position) >= 0x10L)
            {
                HTTPHeaderParseWarnings warnings;
                byte[] arrData = strmClient.GetBuffer();
                long length = strmClient.Length;
                int position = (int) strmClient.Position;
                if (!FindEndOfHeaders(arrData, ref position, length, out warnings))
                {
                    return false;
                }
                byte[] buffer = new byte[(1 + position) - strmClient.Position];
                strmClient.Read(buffer, 0, buffer.Length);
                string sRequest = CONFIG.oHeaderEncoding.GetString(buffer);
                headersRequest = ParseRequest(sRequest);
                if (headersRequest != null)
                {
                    int num3 = _GetEntityLengthFromHeaders(headersRequest, strmClient);
                    arrRequestBody = new byte[num3];
                    strmClient.Read(arrRequestBody, 0, arrRequestBody.Length);
                    return true;
                }
            }
            return false;
        }

        public static bool TakeResponse(MemoryStream strmServer, string sRequestMethod, out HTTPResponseHeaders headersResponse, out byte[] arrResponseBody)
        {
            HTTPHeaderParseWarnings warnings;
            headersResponse = null;
            arrResponseBody = Utilities.emptyByteArray;
            if ((strmServer.Length - strmServer.Position) < 0x10L)
            {
                return false;
            }
            byte[] arrData = strmServer.GetBuffer();
            long length = strmServer.Length;
            int position = (int) strmServer.Position;
            if (!FindEndOfHeaders(arrData, ref position, length, out warnings))
            {
                return false;
            }
            byte[] buffer = new byte[(1 + position) - strmServer.Position];
            strmServer.Read(buffer, 0, buffer.Length);
            string sResponse = CONFIG.oHeaderEncoding.GetString(buffer);
            headersResponse = ParseResponse(sResponse);
            if (headersResponse == null)
            {
                return false;
            }
            if (sRequestMethod != "HEAD")
            {
                int num3 = _GetEntityLengthFromHeaders(headersResponse, strmServer);
                if (sRequestMethod == "CONNECT")
                {
                    int hTTPResponseCode = headersResponse.HTTPResponseCode;
                }
                arrResponseBody = new byte[num3];
                strmServer.Read(arrResponseBody, 0, arrResponseBody.Length);
            }
            return true;
        }
    }
}

