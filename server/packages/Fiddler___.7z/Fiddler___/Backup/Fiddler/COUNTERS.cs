﻿namespace Fiddler
{
    using System;

    internal static class COUNTERS
    {
        internal static int ASYNC_DNS;
        internal static int ASYNC_WAIT_CLIENT_REUSE;
        internal static long CONNECTIONS_ACCEPTED;
        internal static int DNSCACHE_HITS;
        internal static long TOTAL_ASYNC_DNS;
        internal static long TOTAL_ASYNC_DNS_MS;
        internal static long TOTAL_ASYNC_WAIT_CLIENT_REUSE;
        internal static long TOTAL_DELAY_ACCEPT_CONNECTION;

        public static string Summarize()
        {
            return string.Format("-= Counters =-\nDNS Lookups underway:\t{0:N0}\nTotal DNS Async:\t{1:N0}\nAsync DNS saved(ms):\t{2:N0}\nDNS Cache Hits:\t\t{3:N0}\n\nAwaiting Client Reuse:\t{4:N0}\nTotal Client Reuse:\t{5:N0}\n\nConnections Accepted:\t{6:N0}\nAccept delay ms:\t{7:N0}\n", new object[] { ASYNC_DNS, TOTAL_ASYNC_DNS, TOTAL_ASYNC_DNS_MS, DNSCACHE_HITS, ASYNC_WAIT_CLIENT_REUSE, TOTAL_ASYNC_WAIT_CLIENT_REUSE, CONNECTIONS_ACCEPTED, TOTAL_DELAY_ACCEPT_CONNECTION });
        }
    }
}

