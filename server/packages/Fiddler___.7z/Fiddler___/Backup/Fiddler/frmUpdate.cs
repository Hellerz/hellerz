﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    internal class frmUpdate : Form
    {
        private Button btnImmediate;
        private Button btnNextTime;
        private Button btnNo;
        private Container components;
        private Label lblHint;
        private LinkLabelEx lnkDownloadOnly;
        private PictureBox pbImage;
        private RichTextBox txtMessage;

        internal frmUpdate()
        {
            this.InitializeComponent();
            this.Font = new Font(this.Font.FontFamily, CONFIG.flFontSize);
        }

        internal frmUpdate(string sTitle, string sMessage, bool bOfferAutoUpgrade, MessageBoxDefaultButton mbDefault) : this()
        {
            this.Text = sTitle;
            this.txtMessage.Text = sMessage;
            this.btnImmediate.Visible = this.btnNextTime.Visible = bOfferAutoUpgrade;
            if ((mbDefault == MessageBoxDefaultButton.Button1) || !bOfferAutoUpgrade)
            {
                base.ActiveControl = this.lnkDownloadOnly;
            }
            else
            {
                base.ActiveControl = this.btnNextTime;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void frmAlert_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                base.DialogResult = DialogResult.Cancel;
            }
            else if (e.KeyCode == Keys.Return)
            {
                e.SuppressKeyPress = e.Handled = true;
                if (this.btnImmediate.Visible)
                {
                    this.btnImmediate.PerformClick();
                }
                else if (this.btnNo.Visible)
                {
                    this.btnNo.PerformClick();
                }
            }
            else if (e.KeyData == (Keys.Control | Keys.C))
            {
                e.SuppressKeyPress = e.Handled = true;
                this.txtMessage.SelectAll();
                this.txtMessage.Copy();
            }
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmUpdate));
            this.pbImage = new PictureBox();
            this.btnNo = new Button();
            this.txtMessage = new RichTextBox();
            this.lblHint = new Label();
            this.btnImmediate = new Button();
            this.btnNextTime = new Button();
            this.lnkDownloadOnly = new LinkLabelEx();
            ((ISupportInitialize) this.pbImage).BeginInit();
            base.SuspendLayout();
            this.pbImage.Image = (Image) manager.GetObject("pbImage.Image");
            this.pbImage.Location = new Point(8, 8);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new Size(0x20, 0x20);
            this.pbImage.SizeMode = PictureBoxSizeMode.CenterImage;
            this.pbImage.TabIndex = 0;
            this.pbImage.TabStop = false;
            this.btnNo.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnNo.DialogResult = DialogResult.Cancel;
            this.btnNo.Location = new Point(0x152, 0xe0);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new Size(0x5c, 0x17);
            this.btnNo.TabIndex = 1;
            this.btnNo.Text = "&No";
            this.txtMessage.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtMessage.BackColor = SystemColors.Control;
            this.txtMessage.BorderStyle = BorderStyle.None;
            this.txtMessage.Location = new Point(0x30, 8);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ReadOnly = true;
            this.txtMessage.Size = new Size(0x180, 0xb8);
            this.txtMessage.TabIndex = 4;
            this.txtMessage.Text = manager.GetString("txtMessage.Text");
            this.txtMessage.LinkClicked += new LinkClickedEventHandler(this.txtMessage_LinkClicked);
            this.lblHint.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
            this.lblHint.BackColor = SystemColors.Highlight;
            this.lblHint.Font = new Font("Tahoma", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblHint.ForeColor = SystemColors.HighlightText;
            this.lblHint.Location = new Point(3, 0xc3);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new Size(0x1ab, 0x1a);
            this.lblHint.TabIndex = 5;
            this.lblHint.Text = "Would you like to install this update?";
            this.lblHint.TextAlign = ContentAlignment.MiddleCenter;
            this.btnImmediate.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnImmediate.DialogResult = DialogResult.Yes;
            this.btnImmediate.Location = new Point(90, 0xe0);
            this.btnImmediate.Name = "btnImmediate";
            this.btnImmediate.Size = new Size(0x88, 0x17);
            this.btnImmediate.TabIndex = 3;
            this.btnImmediate.Text = "Yes, &Restart Now";
            this.btnNextTime.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnNextTime.DialogResult = DialogResult.Retry;
            this.btnNextTime.Location = new Point(0xe8, 0xe0);
            this.btnNextTime.Name = "btnNextTime";
            this.btnNextTime.Size = new Size(100, 0x17);
            this.btnNextTime.TabIndex = 0;
            this.btnNextTime.Text = "Next &Time";
            this.lnkDownloadOnly.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.lnkDownloadOnly.AutoSize = true;
            this.lnkDownloadOnly.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkDownloadOnly.Location = new Point(5, 0xe5);
            this.lnkDownloadOnly.Name = "lnkDownloadOnly";
            this.lnkDownloadOnly.Size = new Size(0x4f, 13);
            this.lnkDownloadOnly.TabIndex = 2;
            this.lnkDownloadOnly.TabStop = true;
            this.lnkDownloadOnly.Text = "&Download Only";
            this.lnkDownloadOnly.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkDownloadOnly_LinkClicked);
            this.AutoScaleBaseSize = new Size(5, 14);
            base.CancelButton = this.btnNo;
            base.ClientSize = new Size(440, 250);
            base.Controls.Add(this.lnkDownloadOnly);
            base.Controls.Add(this.btnNextTime);
            base.Controls.Add(this.btnImmediate);
            base.Controls.Add(this.lblHint);
            base.Controls.Add(this.txtMessage);
            base.Controls.Add(this.btnNo);
            base.Controls.Add(this.pbImage);
            this.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.KeyPreview = true;
            this.MinimumSize = new Size(0x1c6, 150);
            base.Name = "frmUpdate";
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.Manual;
            this.Text = " Fiddler Update";
            base.KeyDown += new KeyEventHandler(this.frmAlert_KeyDown);
            ((ISupportInitialize) this.pbImage).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lnkDownloadOnly_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            base.DialogResult = DialogResult.OK;
        }

        private void txtMessage_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            Utilities.LaunchHyperlink(e.LinkText);
        }
    }
}

