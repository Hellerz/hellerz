﻿namespace Fiddler
{
    using System;

    internal enum ColumnDataSource
    {
        Unknown,
        Default,
        BoundByWizard,
        BoundToScript,
        BoundToExtension
    }
}

