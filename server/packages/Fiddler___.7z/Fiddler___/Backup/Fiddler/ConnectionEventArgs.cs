﻿namespace Fiddler
{
    using System;
    using System.Net.Sockets;

    public class ConnectionEventArgs : EventArgs
    {
        private readonly Session _oSession;
        private readonly Socket _oSocket;

        internal ConnectionEventArgs(Session oSession, Socket oSocket)
        {
            this._oSession = oSession;
            this._oSocket = oSocket;
        }

        public Socket Connection
        {
            get
            {
                return this._oSocket;
            }
        }

        public Session OwnerSession
        {
            get
            {
                return this._oSession;
            }
        }
    }
}

