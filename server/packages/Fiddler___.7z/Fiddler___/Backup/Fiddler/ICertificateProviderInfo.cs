﻿namespace Fiddler
{
    using System;

    public interface ICertificateProviderInfo
    {
        string GetConfigurationString();
        void ShowConfigurationUI(IntPtr hwndOwner);
    }
}

