﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    public class FiddlerExtensions : IDisposable
    {
        private List<IAutoTamper> m_AutoFiddlers = new List<IAutoTamper>();
        private Dictionary<Guid, IFiddlerExtension> m_Extensions = new Dictionary<Guid, IFiddlerExtension>();

        internal FiddlerExtensions()
        {
            if (CONFIG.bLoadExtensions)
            {
                this.ScanExtensions();
            }
        }

        public void Dispose()
        {
            foreach (IFiddlerExtension extension in this.m_Extensions.Values)
            {
                try
                {
                    extension.OnBeforeUnload();
                    continue;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.LogAddonException(exception, "Extension threw during OnBeforeUnload");
                    continue;
                }
            }
            this.m_AutoFiddlers.Clear();
            this.m_Extensions.Clear();
        }

        internal void DoAutoTamperRequestAfter(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                foreach (IAutoTamper tamper in this.m_AutoFiddlers)
                {
                    tamper.AutoTamperRequestAfter(oSession);
                }
            }
        }

        internal void DoAutoTamperRequestBefore(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                foreach (IAutoTamper tamper in this.m_AutoFiddlers)
                {
                    tamper.AutoTamperRequestBefore(oSession);
                }
                if (FiddlerApplication.scriptRules != null)
                {
                    FiddlerApplication.scriptRules.DoBeforeRequest(oSession);
                }
            }
        }

        internal void DoAutoTamperResponseAfter(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                foreach (IAutoTamper tamper in this.m_AutoFiddlers)
                {
                    tamper.AutoTamperResponseAfter(oSession);
                }
            }
        }

        internal void DoAutoTamperResponseBefore(Session oSession)
        {
            if (!oSession.isFlagSet(SessionFlags.Ignored))
            {
                foreach (IAutoTamper tamper in this.m_AutoFiddlers)
                {
                    tamper.AutoTamperResponseBefore(oSession);
                }
                if (FiddlerApplication.scriptRules != null)
                {
                    FiddlerApplication.scriptRules.DoBeforeResponse(oSession);
                }
            }
        }

        internal void DoBeforeReturningError(Session oSession)
        {
            foreach (IAutoTamper tamper in this.m_AutoFiddlers)
            {
                tamper.OnBeforeReturningError(oSession);
            }
            if (FiddlerApplication.scriptRules != null)
            {
                FiddlerApplication.scriptRules.DoReturningError(oSession);
            }
        }

        internal void DoOnLoad()
        {
            foreach (IFiddlerExtension extension in this.m_Extensions.Values)
            {
                try
                {
                    extension.OnLoad();
                    continue;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.LogAddonException(exception, "Extension threw during OnLoad");
                    continue;
                }
            }
        }

        internal bool DoOnQuickExec(string sCommand)
        {
            foreach (IFiddlerExtension extension in this.m_Extensions.Values)
            {
                IHandleExecAction action = extension as IHandleExecAction;
                if (action != null)
                {
                    try
                    {
                        if (!action.OnExecAction(sCommand))
                        {
                            continue;
                        }
                        return true;
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.LogAddonException(exception, "Extension threw during OnExecAction");
                        continue;
                    }
                }
            }
            if (FiddlerApplication.scriptRules == null)
            {
                return false;
            }
            return FiddlerApplication.scriptRules.DoExecAction(sCommand);
        }

        internal void DoPeekAtRequestHeaders(Session oSession)
        {
            foreach (IAutoTamper tamper in this.m_AutoFiddlers)
            {
                IAutoTamper3 tamper2 = tamper as IAutoTamper3;
                if (tamper2 != null)
                {
                    tamper2.OnPeekAtRequestHeaders(oSession);
                }
            }
            if (FiddlerApplication.scriptRules != null)
            {
                FiddlerApplication.scriptRules.DoPeekAtRequestHeaders(oSession);
            }
        }

        internal void DoPeekAtResponseHeaders(Session oSession)
        {
            foreach (IAutoTamper tamper in this.m_AutoFiddlers)
            {
                IAutoTamper2 tamper2 = tamper as IAutoTamper2;
                if (tamper2 != null)
                {
                    tamper2.OnPeekAtResponseHeaders(oSession);
                }
            }
            if (FiddlerApplication.scriptRules != null)
            {
                FiddlerApplication.scriptRules.DoPeekAtResponseHeaders(oSession);
            }
        }

        internal void ScanExtensions()
        {
            this.ScanPathForExtensions(CONFIG.GetPath("AutoFiddlers_User"));
            this.ScanPathForExtensions(CONFIG.GetPath("AutoFiddlers_Machine"));
            if (this.m_Extensions.Count > 0)
            {
                FiddlerApplication.FiddlerBoot += new SimpleEventHandler(this.DoOnLoad);
            }
        }

        private void ScanPathForExtensions(string sPath)
        {
            this.ScanPathForExtensions(sPath, false);
        }

        private void ScanPathForExtensions(string sPath, bool bIsSubfolder)
        {
            try
            {
                if (Directory.Exists(sPath))
                {
                    if (!bIsSubfolder)
                    {
                        foreach (DirectoryInfo info in new DirectoryInfo(sPath).GetDirectories("*.ext"))
                        {
                            this.ScanPathForExtensions(info.FullName, true);
                        }
                    }
                    FileInfo[] files = new DirectoryInfo(sPath).GetFiles(bIsSubfolder ? "Fiddler*.dll" : "*.dll");
                    bool boolPref = FiddlerApplication.Prefs.GetBoolPref("fiddler.debug.extensions.verbose", false);
                    if (boolPref)
                    {
                        FiddlerApplication.Log.LogFormat("Searching for FiddlerExtensions under {0}", new object[] { sPath });
                    }
                    foreach (FileInfo info2 in files)
                    {
                        if (bIsSubfolder || !Utilities.IsNotExtension(info2.Name))
                        {
                            Assembly assembly;
                            if (boolPref)
                            {
                                FiddlerApplication.Log.LogFormat("Looking for FiddlerExtensions inside {0}", new object[] { info2.FullName.ToString() });
                            }
                            try
                            {
                                if (!CONFIG.bRunningOnCLRv4)
                                {
                                    throw new Exception("Not reachable");
                                }
                                assembly = Assembly.UnsafeLoadFrom(info2.FullName);
                            }
                            catch (Exception exception)
                            {
                                FiddlerApplication.LogAddonException(exception, "Failed to load " + info2.FullName);
                                goto Label_02E5;
                            }
                            try
                            {
                                if (!Utilities.FiddlerMeetsVersionRequirement(assembly, "FiddlerExtensions"))
                                {
                                    if (boolPref)
                                    {
                                        FiddlerApplication.Log.LogString("    ! Assembly does not specify a valid Fiddler.RequiredVersionAttribute.");
                                    }
                                }
                                else
                                {
                                    foreach (Type type in assembly.GetExportedTypes())
                                    {
                                        if (((!type.IsAbstract && type.IsPublic) && (type.IsClass && typeof(IFiddlerExtension).IsAssignableFrom(type))) && !this.m_Extensions.ContainsKey(type.GUID))
                                        {
                                            try
                                            {
                                                IFiddlerExtension extension = (IFiddlerExtension) Activator.CreateInstance(type);
                                                this.m_Extensions.Add(type.GUID, extension);
                                                if (extension is IAutoTamper)
                                                {
                                                    this.m_AutoFiddlers.Add((IAutoTamper) extension);
                                                    if (boolPref)
                                                    {
                                                        FiddlerApplication.Log.LogFormat("    Class {0} is a IAutoTamper* extension.", new object[] { type.FullName });
                                                    }
                                                }
                                                else if (boolPref)
                                                {
                                                    FiddlerApplication.Log.LogFormat("    Class {0} is a basic IFiddlerExtension.", new object[] { type.FullName });
                                                }
                                            }
                                            catch (Exception exception2)
                                            {
                                                FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure loading {0} FiddlerExtensions from {1}: {2}\n\n{3}\n\n{4}", new object[] { type.Name, info2.FullName.ToString(), exception2.Message, exception2.StackTrace, exception2.InnerException }), "Extension Load Error");
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception exception3)
                            {
                                FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure loading FiddlerExtensions from {0}: {1}", info2.FullName.ToString(), exception3.Message), "Extension Load Error");
                            }
                        Label_02E5:;
                        }
                    }
                }
            }
            catch (Exception exception4)
            {
                FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure loading FiddlerExtensions: {0}", exception4.Message), "Extension Load Error");
            }
        }

        internal Dictionary<Guid, IFiddlerExtension> Extensions
        {
            get
            {
                return this.m_Extensions;
            }
        }
    }
}

