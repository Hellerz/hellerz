﻿namespace Fiddler
{
    using System;
    using System.Runtime.CompilerServices;

    public class WebSocketMessageEventArgs : EventArgs
    {
        [CompilerGenerated]
        private WebSocketMessage <oWSM>k__BackingField;

        public WebSocketMessageEventArgs(WebSocketMessage _inMsg)
        {
            this.oWSM = _inMsg;
        }

        public WebSocketMessage oWSM
        {
            [CompilerGenerated]
            get
            {
                return this.<oWSM>k__BackingField;
            }
            private [CompilerGenerated]
            set
            {
                this.<oWSM>k__BackingField = value;
            }
        }
    }
}

