﻿namespace Fiddler
{
    using System;

    internal class MockTunnel : ITunnel
    {
        private long _lngBytesEgress;
        private long _lngBytesIngress;

        public MockTunnel(long lngEgress, long lngIngress)
        {
            this._lngBytesEgress = lngEgress;
            this._lngBytesIngress = lngIngress;
        }

        public void CloseTunnel()
        {
        }

        public long EgressByteCount
        {
            get
            {
                return this._lngBytesEgress;
            }
        }

        public long IngressByteCount
        {
            get
            {
                return this._lngBytesIngress;
            }
        }

        public bool IsOpen
        {
            get
            {
                return false;
            }
        }
    }
}

