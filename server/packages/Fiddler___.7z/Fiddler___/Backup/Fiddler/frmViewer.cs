﻿namespace Fiddler
{
    using Fiddler.WebFormats;
    using Microsoft.Win32;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;
    using Telerik.Analytics;

    public class frmViewer : Form
    {
        private Form _frmFloatingInspectors;
        private int _iUnsquishedSessionListWidth;
        private Point _ptContextPopup;
        private string _sLastActiveRequestTab;
        private string _sLastActiveResponseTab;
        private string _sLastActiveViewTab;
        private PeriodicWorker.taskItem _taskUpdateMemoryPanel;
        private HiddenMessagingWindow _wndForMessages;
        private WeakReference _wrDeletedListViewItems;
        private Button btnDecodeRequest;
        private Button btnDecodeResponse;
        private Button btnPromptHTTPS;
        private Button btnResponseBodyDropped;
        private Button btnTamperSendClient;
        private Button btnTamperSendServer;
        private Button btnWarnDetached;
        private ComboBox cbxLoadFrom;
        private ColumnHeader colComments;
        private ColumnHeader colContentType;
        private ColumnHeader colCustom;
        private ColumnHeader colExpires;
        private ColumnHeader colHost;
        private ColumnHeader colID;
        private ColumnHeader colProcess;
        private ColumnHeader colProtocol;
        private ColumnHeader colRequest;
        private ColumnHeader colResponseSize;
        private ColumnHeader colStatus;
        private IContainer components;
        private Dictionary<int, string> dictUserHotkeys;
        private OpenFileDialog dlgLoadZip;
        private SaveFileDialog dlgSaveBinary;
        private SaveFileDialog dlgSaveZip;
        private FlowLayoutPanel flpFilterGutter;
        public ImageList imglSessionIcons;
        public ImageList imglToolbar;
        private Label lblBreakpoint;
        private Label lblInspectOne;
        public SessionListView lvSessions;
        private MenuItem menuItem1;
        private MenuItem menuItem16;
        private MenuItem menuItem18;
        private MenuItem menuItem19;
        private MenuItem menuItem2;
        private MenuItem menuItem20;
        private MenuItem menuItem21;
        private MenuItem menuItem26;
        private MenuItem menuItem28;
        private MenuItem menuItem32;
        private MenuItem menuItem7;
        public MenuItem miCaptureEnabled;
        private MenuItem miCaptureRules;
        private MenuItem miCaptureSplit;
        private MenuItem miContextMarkSplit;
        private MenuItem miContextSaveAndOpenBody;
        private MenuItem miContextSaveSplitter;
        private MenuItem miEditCopyFullSummary;
        private MenuItem miEditCopyHeaders;
        private MenuItem miEditCopySession;
        private MenuItem miEditCopyTerseSummary;
        private MenuItem miEditCopyUrl;
        private MenuItem miEditDivider;
        private MenuItem miEditFind;
        private MenuItem miEditMarkBlue;
        private MenuItem miEditMarkGold;
        private MenuItem miEditMarkGreen;
        private MenuItem miEditMarkOrange;
        private MenuItem miEditMarkPurple;
        private MenuItem miEditMarkRed;
        private MenuItem miEditMarkStrike;
        private MenuItem miEditMarkUnmark;
        private MenuItem miEditPaste;
        private MenuItem miEditRemoveAll;
        private MenuItem miEditRemoveSelected;
        private MenuItem miEditRemoveUnselected;
        private MenuItem miEditSelectAll;
        private MenuItem miEditSplit1;
        private MenuItem miEditUndelete;
        private MenuItem miEditUnlock;
        private MenuItem miFileExit;
        private MenuItem miFileLoad;
        private MenuItem miFileMRUClear;
        private MenuItem miFileMRUPrune;
        private MenuItem miFileMRUSplit;
        private MenuItem miFileNew;
        private MenuItem miFileSaveAllSessions;
        private MenuItem miFileSaveAndOpenBody;
        private MenuItem miFileSaveHeaders;
        private MenuItem miFileSaveRequest;
        private MenuItem miFileSaveRequestBody;
        private MenuItem miFileSaveResponse;
        private MenuItem miFileSaveResponseBody;
        private MenuItem miFileSaveSession;
        private MenuItem miFileSaveZip;
        private MenuItem miHelpAbout;
        private MenuItem miHelpBook;
        private MenuItem miHelpCommunity;
        private MenuItem miHelpContents;
        private MenuItem miHelpHTTP;
        private MenuItem miHelpPrioritySupport;
        private MenuItem miHelpReportBug;
        private MenuItem miHelpShowFiltered;
        private MenuItem miHelpSplit1;
        private MenuItem miHelpSplit2;
        private MenuItem miHelpSplit3;
        private MenuItem miHelpUpdates;
        private MenuItem miInspectorCopy;
        private MenuItem miInspectorHide;
        private MenuItem miInspectorProperties;
        public MenuItem miManipulateGZIP;
        public MenuItem miManipulateIgnoreImages;
        public MenuItem miManipulateRequireProxyAuth;
        public ToolStripMenuItem miNotifyCapturing;
        private ToolStripMenuItem miNotifyExit;
        private ToolStripMenuItem miNotifyRestore;
        private MenuItem miReissueSplit;
        private MenuItem miRulesBreakAt;
        private MenuItem miRulesBreakAtNothing;
        public MenuItem miRulesBreakAtRequest;
        public MenuItem miRulesBreakAtResponse;
        private MenuItem miRulesBreakpointsIgnoreImages;
        public MenuItem miRulesIgnoreConnects;
        public MenuItem miRulesRemoveEncoding;
        private MenuItem miRulesSplit1;
        private MenuItem miSessionAbort;
        private MenuItem miSessionAddComment;
        private MenuItem miSessionCOMETPeek;
        private MenuItem miSessionContextSplit;
        public MenuItem miSessionCopy;
        private MenuItem miSessionCopyColumn;
        private MenuItem miSessionCopyEntire;
        private MenuItem miSessionCopyHeaders;
        private MenuItem miSessionCopyHeadlines;
        private MenuItem miSessionCopyResponseAsDataURI;
        private MenuItem miSessionCopySummary;
        private MenuItem miSessionCopyURL;
        private MenuItem miSessionFilter;
        private MenuItem miSessionInspectNewWindow;
        internal MenuItem miSessionListScroll;
        private MenuItem miSessionMark;
        private MenuItem miSessionMarkBlue;
        private MenuItem miSessionMarkGold;
        private MenuItem miSessionMarkGreen;
        private MenuItem miSessionMarkOrange;
        private MenuItem miSessionMarkPurple;
        private MenuItem miSessionMarkRed;
        private MenuItem miSessionMarkStrike;
        private MenuItem miSessionMarkUnmark;
        private MenuItem miSessionMath;
        public MenuItem miSessionProperties;
        private MenuItem miSessionReissueAndVerify;
        private MenuItem miSessionReissueComposer;
        private MenuItem miSessionReissueEdited;
        private MenuItem miSessionReissueInIE;
        private MenuItem miSessionReissueRequests;
        private MenuItem miSessionReissueSequentially;
        private MenuItem miSessionReissueUnconditionally;
        private MenuItem miSessionRemove;
        private MenuItem miSessionRemoveAll;
        private MenuItem miSessionRemoveSelected;
        private MenuItem miSessionRemoveUnselected;
        public MenuItem miSessionReplay;
        private MenuItem miSessionReplayResponse;
        public MenuItem miSessionSave;
        private MenuItem miSessionSaveEntire;
        private MenuItem miSessionSaveFullRequest;
        private MenuItem miSessionSaveFullResponse;
        private MenuItem miSessionSaveHeaders;
        private MenuItem miSessionSaveRequestBody;
        private MenuItem miSessionSaveResponseBody;
        private MenuItem miSessionSaveToZip;
        public MenuItem miSessionSelect;
        private MenuItem miSessionSelectChildren;
        private MenuItem miSessionSelectDuplicates;
        private MenuItem miSessionSelectMatching;
        private MenuItem miSessionSelectParent;
        private MenuItem miSessionSplit;
        private MenuItem miSessionSplit2;
        private MenuItem miSessionSumAndAverage;
        private MenuItem miSessionUnlock;
        private MenuItem miSessionWinDiff;
        private MenuItem miToolsClearCache;
        private MenuItem miToolsClearCookies;
        private MenuItem miToolsCompare;
        private MenuItem miToolsEncodeDecode;
        private MenuItem miToolsInternetOptions;
        private MenuItem miToolsOptions;
        private MenuItem miToolsSplit1;
        private MenuItem miToolsSplit2;
        private MenuItem miToolsSplitCustom;
        internal MenuItem miViewAutoScroll;
        private MenuItem miViewBuilder;
        public MenuItem miViewDefault;
        private MenuItem miViewInspector;
        private MenuItem miViewMinimizeToTray;
        private MenuItem miViewRefresh;
        private MenuItem miViewSplit1;
        private MenuItem miViewSplit2;
        private MenuItem miViewSplit3;
        private MenuItem miViewSquish;
        public MenuItem miViewStacked;
        private MenuItem miViewStatistics;
        private MenuItem miViewStayOnTop;
        private MenuItem miViewToolbar;
        public MenuItem miViewWide;
        private MenuItem mnuContextSaveRequest;
        private MenuItem mnuContextSaveResponse;
        private MenuItem mnuContextSaveSessions;
        private MenuItem mnuEdit;
        private MenuItem mnuEditCopy;
        private MenuItem mnuEditMark;
        private MenuItem mnuEditRemove;
        private MenuItem mnuFile;
        private MenuItem mnuFileExport;
        private MenuItem mnuFileMRU;
        private MenuItem mnuFileSave;
        private MenuItem mnuFileSaveRequest;
        private MenuItem mnuFileSaveResponse;
        private MenuItem mnuFileSaveSessions;
        private MenuItem mnuHelp;
        private ContextMenu mnuInspectorsContext;
        public MainMenu mnuMain;
        public ContextMenuStrip mnuNotify;
        public MenuItem mnuRules;
        public ContextMenu mnuSessionContext;
        public MenuItem mnuTools;
        private MenuItem mnuView;
        internal MenuItem mnuViewTabs;
        internal NotifyIcon notifyIcon;
        private EventHandler<QuickExecEventArgs> OnQuickExec;
        private static System.Windows.Forms.Timer oReportingQueueTimer = new System.Windows.Forms.Timer();
        private MRU oSAZMRU;
        public TabPage pageBuilder;
        public TabPage pageInspector;
        public TabPage pageResponder;
        public TabPage pageStatistics;
        private Panel pnlInfoBar;
        internal Panel pnlInfoTip;
        internal Panel pnlInfoTipRequest;
        private Panel pnlInspector;
        private Panel pnlSessionControls;
        public Panel pnlSessions;
        private Panel pnlTopNotice;
        private StatusBarPanel sbpBreakpoints;
        private StatusBarPanel sbpCapture;
        public StatusBarPanel sbpInfo;
        private StatusBarPanel sbpMemory;
        private StatusBarPanel sbpProcessFilter;
        private StatusBarPanel sbpSelCount;
        public StatusBar sbStatus;
        internal Splitter splitterInspector;
        private Splitter splitterMain;
        internal TabControl tabsRequest;
        private TabControl tabsResponse;
        public TabControl tabsViews;
        private ToolStripSeparator toolStripMenuItem1;
        private QuickExec txtExec;

        public event EventHandler<QuickExecEventArgs> OnQuickExec
        {
            add
            {
                EventHandler<QuickExecEventArgs> handler2;
                EventHandler<QuickExecEventArgs> onQuickExec = this.OnQuickExec;
                do
                {
                    handler2 = onQuickExec;
                    EventHandler<QuickExecEventArgs> handler3 = (EventHandler<QuickExecEventArgs>) Delegate.Combine(handler2, value);
                    onQuickExec = Interlocked.CompareExchange<EventHandler<QuickExecEventArgs>>(ref this.OnQuickExec, handler3, handler2);
                }
                while (onQuickExec != handler2);
            }
            remove
            {
                EventHandler<QuickExecEventArgs> handler2;
                EventHandler<QuickExecEventArgs> onQuickExec = this.OnQuickExec;
                do
                {
                    handler2 = onQuickExec;
                    EventHandler<QuickExecEventArgs> handler3 = (EventHandler<QuickExecEventArgs>) Delegate.Remove(handler2, value);
                    onQuickExec = Interlocked.CompareExchange<EventHandler<QuickExecEventArgs>>(ref this.OnQuickExec, handler3, handler2);
                }
                while (onQuickExec != handler2);
            }
        }

        public frmViewer()
        {
            this.InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        private LinkLabel _AddFilterToGutter(string sText)
        {
            this._ShowFilterGutter();
            LinkLabel label = new LinkLabel();
            label.LinkBehavior = LinkBehavior.HoverUnderline;
            label.Text = sText;
            label.AutoSize = true;
            this.flpFilterGutter.Controls.Add(label);
            this.flpFilterGutter.Controls.SetChildIndex(label, 1);
            return label;
        }

        private void _addScreenshotNow()
        {
            HTTPRequestHeaders headers = new HTTPRequestHeaders();
            headers.HTTPMethod = "GET";
            headers.Add("Host", "localhost");
            headers.RequestPath = "/Screenshot_" + DateTime.Now.ToString("H-mm-ss") + ".jpg";
            byte[] arrRequest = headers.ToByteArray(true, true, false);
            byte[] bytes = Encoding.UTF8.GetBytes("HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nDate: " + DateTime.UtcNow.ToString("r") + "\r\nConnection: close\r\n\r\n");
            MemoryStream stream = new MemoryStream();
            stream.Write(bytes, 0, bytes.Length);
            if (true)
            {
                _GetDesktopScreenshot().Save(stream, ImageFormat.Jpeg);
            }
            Session oSession = new Session(arrRequest, stream.ToArray(), SessionFlags.ServedFromCache | SessionFlags.ImportedFromOtherTool | SessionFlags.ResponseGeneratedByFiddler | SessionFlags.RequestGeneratedByFiddler);
            oSession.Timers.ClientBeginRequest = oSession.Timers.ClientDoneResponse = DateTime.Now;
            if (FiddlerApplication.UI.InvokeRequired)
            {
                FiddlerApplication.UIInvokeAsync(new updateUIDelegate(this.finishSession), new object[] { oSession });
            }
            else
            {
                this.finishSession(oSession);
            }
        }

        private static void _AdjustThreadPool()
        {
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.threads.BumpBasePriority", false))
            {
                try
                {
                    Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.AboveNormal;
                }
                catch
                {
                }
            }
            int processorCount = Environment.ProcessorCount;
            int workerThreads = FiddlerApplication.Prefs.GetInt32Pref("fiddler.threads.minworker", Math.Max(0x10, 5 * processorCount));
            int completionPortThreads = FiddlerApplication.Prefs.GetInt32Pref("fiddler.threads.minIO", processorCount);
            if ((workerThreads > 0) && (completionPortThreads > 0))
            {
                ThreadPool.SetMinThreads(workerThreads, completionPortThreads);
            }
        }

        private void _AssignRequestInspector(Session oSession)
        {
            IRequestInspector2 activeRequestInspector = this.GetActiveRequestInspector();
            if (activeRequestInspector != null)
            {
                try
                {
                    if (oSession == null)
                    {
                        activeRequestInspector.Clear();
                    }
                    else
                    {
                        (activeRequestInspector as Inspector2).AssignSession(oSession);
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.LogAddonException(exception, "Request Inspector Failed");
                }
            }
        }

        private void _AssignResponseInspector(Session oSession)
        {
            IResponseInspector2 activeResponseInspector = this.GetActiveResponseInspector();
            if (activeResponseInspector != null)
            {
                try
                {
                    if (oSession == null)
                    {
                        activeResponseInspector.Clear();
                    }
                    else
                    {
                        (activeResponseInspector as Inspector2).AssignSession(oSession);
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.LogAddonException(exception, "Response Inspector Failed");
                }
            }
        }

        private void _CheckUpdatesOnStartup()
        {
            if ((CONFIG.bVersionCheck && !CONFIG.QuietMode) && (!CONFIG.bIsViewOnly && !Environment.CommandLine.OICContains("noversioncheck")))
            {
                Thread thread = new Thread(new ThreadStart(this.actCheckForUpdatesQuiet));
                thread.IsBackground = true;
                thread.Start();
            }
        }

        private static void _CompareAndTagResponses(Session oOriginal, Session oNew)
        {
            if (oNew.responseCode != oOriginal.responseCode)
            {
                oNew["ui-backcolor"] = "#FF4848";
                oNew["ui-comments"] = string.Format("Response Status Code differs from Session #{0}", oOriginal.id);
            }
            else
            {
                byte[] arrBody = Utilities.Dupe(oOriginal.responseBodyBytes);
                Utilities.utilDecodeHTTPBody(oOriginal.oResponse.headers, ref arrBody);
                byte[] buffer2 = Utilities.Dupe(oNew.responseBodyBytes);
                Utilities.utilDecodeHTTPBody(oNew.oResponse.headers, ref buffer2);
                if (arrBody.Length != buffer2.Length)
                {
                    oNew["ui-backcolor"] = "#FF4848";
                    oNew["ui-comments"] = string.Format("Response body size differs from Session #{0}", oOriginal.id);
                }
                else
                {
                    for (int i = 0; i < arrBody.Length; i++)
                    {
                        if (buffer2[i] != arrBody[i])
                        {
                            oNew["ui-backcolor"] = "#FF4848";
                            oNew["ui-comments"] = string.Format("Response body content differs from Session #{0}", oOriginal.id);
                            return;
                        }
                    }
                    oNew["ui-backcolor"] = "chartreuse";
                    oNew["ui-comments"] = string.Format("Matches Session #{0}", oOriginal.id);
                    oOriginal["ui-strikeout"] = "match";
                    oOriginal.RefreshUI();
                }
            }
        }

        private void _coreAddSession(Session oSession, bool bInsideFinishSession)
        {
            ListViewItem oLVI = new ListViewItem(oSession.id.ToString(), 0);
            oLVI.Tag = oSession;
            oSession.ViewItem = oLVI;
            oLVI.SubItems.AddRange(new string[] { " - ", _obtainScheme(oSession), oSession.host, oSession.PathAndQuery, "-1", string.Empty, string.Empty, oSession["SESSION", "x-ProcessInfo"], oSession["SESSION", "ui-comments"], oSession["SESSION", "ui-customcolumn"] });
            oLVI.SubItems.AddRange(this.lvSessions._emptyBoundColumns);
            if (!bInsideFinishSession)
            {
                if (oSession.state == SessionStates.Aborted)
                {
                    oLVI.ImageIndex = 14;
                }
                SessionListView.FillBoundColumns(oSession, oLVI);
                if (oSession.HTTPMethodIs("CONNECT"))
                {
                    oLVI.SubItems[3].Text = "Tunnel to";
                    oLVI.ForeColor = System.Drawing.Color.Gray;
                }
            }
            this.lvSessions.QueueItem(oLVI);
            if (oSession.oFlags.ContainsKey("x-Builder-Inspect"))
            {
                this.lvSessions.FlushUpdates();
                this.lvSessions.SelectedItems.Clear();
                oSession.ViewItem.Selected = true;
                oSession.ViewItem.Focused = true;
                oSession.ViewItem.EnsureVisible();
                this.tabsViews.SelectedTab = this.pageInspector;
            }
        }

        private static void _DeleteFileIfFound(string sFilename)
        {
            try
            {
                if ((sFilename != null) && System.IO.File.Exists(sFilename))
                {
                    System.IO.File.Delete(sFilename);
                }
            }
            catch (Exception)
            {
            }
        }

        private void _EnableBackButtonNavigationOfTabs()
        {
            this.tabsRequest.Deselecting += delegate (object o, TabControlCancelEventArgs ea) {
                try
                {
                    this._sLastActiveRequestTab = ea.TabPage.Text;
                }
                catch
                {
                }
            };
            this.tabsResponse.Deselecting += delegate (object o, TabControlCancelEventArgs ea) {
                try
                {
                    this._sLastActiveResponseTab = ea.TabPage.Text;
                }
                catch
                {
                }
            };
            this.tabsViews.Deselecting += delegate (object o, TabControlCancelEventArgs ea) {
                try
                {
                    this._sLastActiveViewTab = ea.TabPage.Text;
                }
                catch
                {
                }
            };
            this.tabsRequest.MouseDown += delegate (object o, MouseEventArgs mea) {
                if (((mea.Button == MouseButtons.XButton1) || (mea.Button == MouseButtons.XButton2)) && !string.IsNullOrEmpty(this._sLastActiveRequestTab))
                {
                    Utilities.activateTabByTitle(this._sLastActiveRequestTab, this.tabsRequest);
                }
            };
            this.tabsResponse.MouseDown += delegate (object o, MouseEventArgs mea) {
                if (((mea.Button == MouseButtons.XButton1) || (mea.Button == MouseButtons.XButton2)) && !string.IsNullOrEmpty(this._sLastActiveResponseTab))
                {
                    Utilities.activateTabByTitle(this._sLastActiveResponseTab, this.tabsResponse);
                }
            };
            this.tabsViews.MouseDown += delegate (object o, MouseEventArgs mea) {
                if (((mea.Button == MouseButtons.XButton1) || (mea.Button == MouseButtons.XButton2)) && !string.IsNullOrEmpty(this._sLastActiveViewTab))
                {
                    Utilities.activateTabByTitle(this._sLastActiveViewTab, this.tabsViews);
                }
            };
        }

        private void _GenerateMemoryUsageReport()
        {
            try
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendFormat("MEMORY ANALYSIS\n\n-= Fiddler Memory Usage =-\nProcess Bitness: {0}\n\n", (8 == IntPtr.Size) ? "64" : "32");
                builder.AppendFormat("OS Version:\t{0}\n", Environment.OSVersion.Version);
                builder.AppendFormat("CLR Version:\t{0}\n", Environment.Version);
                try
                {
                    PropertyInfo property = typeof(GCSettings).GetProperty("LargeObjectHeapCompactionMode", BindingFlags.Public | BindingFlags.Static);
                    builder.AppendFormat("LOH Compact:\t{0}\r\n", (null != property) ? "Supported" : "n/a");
                }
                catch
                {
                    builder.Append("LOH Compaction: No\r\n");
                }
                Session[] allSessions = this.GetAllSessions();
                long num = 0L;
                long num2 = 0L;
                long num3 = 0L;
                foreach (Session session in allSessions)
                {
                    num += Utilities.HasHeaders(session.oRequest) ? ((long) (2 * session.oRequest.headers.ByteCount())) : ((long) 0);
                    num += Utilities.HasHeaders(session.oResponse) ? ((long) (2 * session.oResponse.headers.ByteCount())) : ((long) 0);
                    num2 += (session.requestBodyBytes != null) ? ((long) session.requestBodyBytes.Length) : ((long) 0);
                    num2 += (session.responseBodyBytes != null) ? ((long) session.responseBodyBytes.Length) : ((long) 0);
                    WebSocket socket = session.__oTunnel as WebSocket;
                    if (socket != null)
                    {
                        num3 += socket.MemoryUsage();
                    }
                }
                builder.AppendFormat("\nThe Web Sessions list contains {0:N0} Sessions, accounting for:\n\t{1:N0} bytes of headers\n\t{2:N0} bytes of bodies\n\t{3:N0} bytes of WebSocket messages\n", new object[] { allSessions.Length, num, num2, num3 });
                builder.AppendFormat("\n-PRE-GC-\n\tGCAllocated:\t{0:N0}\n\tVirtualMemory:\t{1:N0}\n\tWorkingSet:\t{2:N0}\n", GC.GetTotalMemory(false), Process.GetCurrentProcess().PagedMemorySize64, Process.GetCurrentProcess().WorkingSet64);
                Utilities.RecoverMemory();
                builder.AppendFormat("\n-POST-GC-\n\tGCAllocated:\t{0:N0}\n\tVirtualMemory:\t{1:N0}\n\tWorkingSet:\t{2:N0}\n", GC.GetTotalMemory(false), Process.GetCurrentProcess().PagedMemorySize64, Process.GetCurrentProcess().WorkingSet64);
                MEMORYSTATUSEX lpBuffer = new MEMORYSTATUSEX();
                lpBuffer.Init();
                if (GlobalMemoryStatusEx(ref lpBuffer))
                {
                    builder.AppendFormat("\n-= System Memory Info=-\n\tTotal Physical:\t{0:N0}\n\tAvailable:\t{1:N0}\n\tTotal Virtual:\t{2:N0}\n\tAvailable:\t{3:N0}\n\tTotal PageFile:\t{4:N0}\n\tAvailable:\t{5:N0}\n", new object[] { lpBuffer.ullTotalPhys, lpBuffer.ullAvailPhys, lpBuffer.ullTotalVirtual, lpBuffer.ullAvailVirtual, lpBuffer.ullTotalPageFile, lpBuffer.ullAvailPageFile });
                }
                FiddlerApplication.Log.LogString(builder.ToString());
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private static Bitmap _GetDesktopScreenshot()
        {
            Screen screen = Screen.FromPoint(Cursor.Position);
            Bitmap image = new Bitmap(screen.Bounds.Width, screen.Bounds.Height, PixelFormat.Format32bppArgb);
            Graphics graphics = Graphics.FromImage(image);
            graphics.CopyFromScreen(screen.Bounds.X, screen.Bounds.Y, 0, 0, screen.Bounds.Size, CopyPixelOperation.SourceCopy);
            graphics.Dispose();
            return image;
        }

        private StringDictionary _GetFlagsForReissue()
        {
            StringDictionary dictionary = new StringDictionary();
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.reissue.autoauth", true))
            {
                dictionary.Add("x-AutoAuth", "(default)");
            }
            if (FiddlerApplication.Prefs.GetInt32Pref("fiddler.reissue.autoredircount", 0) > 0)
            {
                dictionary.Add("x-Builder-MaxRedir", FiddlerApplication.Prefs.GetInt32Pref("fiddler.reissue.autoredircount", 0).ToString());
            }
            return dictionary;
        }

        private TabPage _GetTabByTitle(TabControl oTC, string sTab)
        {
            foreach (TabPage page in oTC.TabPages)
            {
                if (page.Text.OICEquals(sTab))
                {
                    return page;
                }
            }
            return null;
        }

        private TabPage _GetTabPageFromPoint(Point pt)
        {
            for (int i = 0; i < this.tabsViews.TabPages.Count; i++)
            {
                if (this.tabsViews.GetTabRect(i).Contains(pt))
                {
                    return this.tabsViews.TabPages[i];
                }
            }
            return null;
        }

        private void _HideFilterGutterIfEmpty()
        {
            if ((this.flpFilterGutter != null) && (this.flpFilterGutter.Controls.Count < 2))
            {
                this.flpFilterGutter.Height = 0;
            }
        }

        private void _HideInspectorUI()
        {
            try
            {
                this.pageInspector.SuspendLayout();
                this.pnlSessionControls.Visible = this.pnlInfoBar.Visible = this.pnlInfoTip.Visible = this.pnlInfoTipRequest.Visible = this.tabsRequest.Visible = this.splitterInspector.Visible = this.tabsResponse.Visible = false;
                if (this.lblInspectOne == null)
                {
                    this.lblInspectOne = new Label();
                    this.lblInspectOne.TextAlign = ContentAlignment.MiddleCenter;
                    this.lblInspectOne.Font = new Font(this.lblInspectOne.Font, FontStyle.Italic);
                    this.lblInspectOne.Text = "Please select a single Web Session to inspect";
                    this.lblInspectOne.Parent = this.pageInspector;
                    this.lblInspectOne.ForeColor = System.Drawing.Color.FromKnownColor(KnownColor.ControlDarkDark);
                    this.lblInspectOne.Dock = DockStyle.Fill;
                }
                else
                {
                    this.lblInspectOne.Visible = true;
                }
            }
            finally
            {
                this.pageInspector.ResumeLayout();
            }
        }

        private void _initBookMenu()
        {
            try
            {
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.menus.book2.visible", true))
                {
                    MenuItem mnuBook = new MenuItem("GET /book");
                    string caption = "&Get the NEW Fiddler book...";
                    string str2 = "&Hide this menu";
                    if (0x411 == Thread.CurrentThread.CurrentUICulture.LCID)
                    {
                        mnuBook.Text = "本 Fiddler";
                        caption = "購 本 Fiddler...";
                        str2 = "隠す";
                    }
                    else if (0x804 == Thread.CurrentThread.CurrentUICulture.LCID)
                    {
                        mnuBook.Text = "册 Fiddler";
                        caption = "躲 Fiddler...";
                        str2 = "躲";
                    }
                    mnuBook.MenuItems.Add(caption).Click += delegate (object s, EventArgs obj) {
                        Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("FiddlerBook"));
                    };
                    mnuBook.MenuItems.Add(str2).Click += delegate (object s, EventArgs obj) {
                        FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.menus.book2.visible", false);
                        this.mnuMain.MenuItems.Remove(mnuBook);
                    };
                    this.mnuMain.MenuItems.Add(mnuBook);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        [Conditional("TELEMETRY2")]
        private static void _InitializeTelemetry()
        {
            try
            {
                FiddlerApplication.oTelemetry = Telerik.Analytics.Analytics.Monitor;
                if (!CONFIG.bEnableAnalytics)
                {
                    FiddlerApplication.DebugSpew("Telemetry is disabled.");
                    FiddlerApplication.oTelemetry.Disable();
                }
                else
                {
                    FiddlerApplication.DebugSpew("Telemetry is enabled.");
                    MonitorSettings settings = new MonitorSettings("27006a8622544e43b0da60db63bd66ba");
                    settings.UseHttps = true;
                    if (FiddlerApplication.Prefs.GetBoolPref("fiddler.telemetry.UseProxy", false))
                    {
                        settings.Proxy = new WebProxy("localhost", CONFIG.ListenPort);
                    }
                    if (FiddlerApplication.Prefs.GetBoolPref("fiddler.telemetry.NonPublic", false))
                    {
                        settings.IsInternalData = true;
                    }
                    FiddlerApplication.oTelemetry.Start(settings);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Telemetry Initialization Failed");
            }
        }

        private void _initImportExportMenu()
        {
            this.mnuFileExport = new MenuItem("&Export Sessions");
            this.mnuFile.MenuItems.Add(6, this.mnuFileExport);
            MenuItem miSub = new MenuItem("&All Sessions...");
            this.mnuFileExport.MenuItems.Add(miSub);
            miSub.Click += delegate (object s, EventArgs ea) {
                this.actDoExport(null);
            };
            miSub = new MenuItem("&Selected Sessions...");
            this.mnuFileExport.MenuItems.Add(miSub);
            miSub.Click += delegate (object s, EventArgs ea) {
                Session[] oSelectedSessions = FiddlerApplication.UI.GetSelectedSessions();
                if (selectedSessions.Length > 0)
                {
                    this.actDoExport(selectedSessions);
                }
            };
            this.mnuFileExport.Popup += delegate (object s, EventArgs ea) {
                miSub.Enabled = FiddlerApplication.UI.lvSessions.SelectedCount > 0;
            };
            MenuItem item = new MenuItem("&Import Sessions...");
            this.mnuFile.MenuItems.Add(6, item);
            item.Click += delegate (object s, EventArgs ea) {
                string[] array = FiddlerApplication.oTranscoders.getImportFormats();
                if (array.Length > 0)
                {
                    Array.Sort<string>(array);
                    string sImportFormat = actSelectImportExportFormat(true, array);
                    Session[] sessionArray = FiddlerApplication.DoImport(sImportFormat, true, null, null);
                    if (sessionArray != null)
                    {
                        this.sbpInfo.Text = string.Concat(new object[] { "Import from ", sImportFormat, " completed. Loaded ", sessionArray.Length, " sessions." });
                    }
                }
                else
                {
                    FiddlerApplication.DoNotifyUser(string.Format("You can install Importers from {0}", CONFIG.GetRedirUrl("FIDDLERTRANSCODERS")), "No Importers Installed");
                }
            };
            MenuItem item2 = new MenuItem("-");
            this.mnuFile.MenuItems.Add(6, item2);
        }

        internal void _internalTrimSessionList(int iTrimTo, bool bFlushUpdates)
        {
            if (bFlushUpdates)
            {
                this.lvSessions.FlushUpdates();
            }
            this.lvSessions.BeginUpdate();
            Session[] allSessions = this.GetAllSessions();
            int num = allSessions.Length - iTrimTo;
            for (uint i = 0; (i < allSessions.Length) && (num > 0); i++)
            {
                if (((allSessions[i] != null) && (allSessions[i].ViewItem != null)) && (allSessions[i].state >= SessionStates.Done))
                {
                    num--;
                    if (((!(allSessions[i].oFlags["ui-bold"] == "user-marked") && string.IsNullOrEmpty(allSessions[i].oFlags["ui-comments"])) && ((allSessions[i].__ViewForm == null) && (allSessions[i].state != SessionStates.HandTamperRequest))) && (allSessions[i].state != SessionStates.HandTamperResponse))
                    {
                        allSessions[i].ViewItem.Remove();
                    }
                }
            }
            this.lvSessions.EndUpdate();
            this.UpdateStatusBar(true);
        }

        private bool _IsSearchMatch(string sTextToSearch, Regex reSearchFor, string sSearchFor, bool bCaseSensitive)
        {
            if (reSearchFor != null)
            {
                return reSearchFor.Match(sTextToSearch).Success;
            }
            return (-1 < sTextToSearch.IndexOf(sSearchFor, bCaseSensitive ? StringComparison.CurrentCulture : StringComparison.CurrentCultureIgnoreCase));
        }

        private void _LoadAnyFileSpecifiedViaCommandLine()
        {
            string[] commandLineArgs = Environment.GetCommandLineArgs();
            for (int i = 1; i < commandLineArgs.Length; i++)
            {
                if (commandLineArgs[i].Contains("."))
                {
                    if (commandLineArgs[i].OICEndsWith(".saz"))
                    {
                        this.actLoadSessionArchive(commandLineArgs[i]);
                        return;
                    }
                    this.actImportFile(commandLineArgs[i]);
                }
            }
        }

        private static void _LogExceptionToEventLog(Exception unhandledException)
        {
            try
            {
                if (!EventLog.SourceExists("Fiddler"))
                {
                    EventLog.CreateEventSource("Fiddler", "Fiddler Error Log");
                }
                EventLog log = new EventLog();
                log.Source = "Fiddler";
                log.WriteEntry(unhandledException.Message + "\n" + unhandledException.StackTrace);
            }
            catch (Exception)
            {
            }
        }

        [Conditional("TELEMETRY2")]
        private static void _LogStartupTelemetry()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Fiddler.Boot");
            FiddlerApplication.oTelemetry.TrackValue("Fiddler.StartupCount", (long) CONFIG.iStartupCount);
            if (CONFIG.bIsBeta)
            {
                FiddlerApplication.oTelemetry.TrackEvent("Mode.IsBeta");
            }
            if (CONFIG.QuietMode)
            {
                FiddlerApplication.oTelemetry.TrackEvent("Mode.IsQuiet");
            }
            if (CONFIG.bIsViewOnly)
            {
                FiddlerApplication.oTelemetry.TrackEvent("Mode.IsViewer");
            }
            if (CONFIG.bCaptureCONNECT && CONFIG.bMITM_HTTPS)
            {
                FiddlerApplication.oTelemetry.TrackEvent("Mode.HTTPSDecryptionEnabled");
            }
        }

        private static string _obtainScheme(Session oSession)
        {
            if (!Utilities.HasHeaders(oSession.oRequest))
            {
                return "?";
            }
            return oSession.oRequest.headers.UriScheme.ToUpperInvariant();
        }

        private void _OverrideIcon()
        {
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.overrideIcon", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                try
                {
                    stringPref = Utilities.EnsurePathIsAbsolute(CONFIG.GetPath("App"), stringPref);
                    Icon icon = new Icon(stringPref);
                    base.Icon = icon;
                    this.notifyIcon.Icon = icon;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.Log.LogFormat("Failed to load 'fiddler.ui.overrideIcon' from '{0}'\n{1}", new object[] { stringPref, exception.Message });
                }
            }
        }

        [Conditional("TELEMETRY2")]
        private void _PromptForTelemetryOptin()
        {
            if ((!CONFIG.bEnableAnalytics && !CONFIG.bVersionCheckBlocked) && (FiddlerApplication.Prefs.GetBoolPref("fiddler.telemetry.AskPermission", true) && (new Random().Next(0, 10) < 2)))
            {
                if (DialogResult.Yes == MessageBox.Show(this, "You can help shape the development of Fiddler by allowing it to send anonymous usage and configuration information to Telerik.\n\nYou will not be contacted or personally identified.\n\nHelp us out?", "Help Improve Fiddler?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
                {
                    try
                    {
                        CONFIG.bEnableAnalytics = true;
                        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(CONFIG.sRootKey))
                        {
                            key.SetValue("SendTelemetry", true);
                        }
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.Log.LogFormat("Failed to record SendTelemetry value: {0}", new object[] { Utilities.DescribeException(exception) });
                    }
                }
                FiddlerApplication.Prefs.SetBoolPref("fiddler.telemetry.AskPermission", false);
            }
        }

        private bool _QuickExecAddColumns(string sCommand)
        {
            string[] strArray = Utilities.Parameterize(sCommand);
            if ((strArray.Length > 2) && strArray[1].OICEquals("add"))
            {
                FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.Cols.Add");
                bool flag = false;
                if (strArray.Length == 3)
                {
                    if (this.lvSessions.AddBoundColumn(strArray[2], 1, 80, strArray[2]))
                    {
                        this.sbpInfo.Text = "Added column bound to " + strArray[2];
                        flag = true;
                    }
                    else
                    {
                        this.sbpInfo.Text = "Failed to add column. Syntax: COLS ADD [TITLE] @COLLECTION.FLAGNAME";
                    }
                }
                else if (this.lvSessions.AddBoundColumn(strArray[2], 1, 80, strArray[3]))
                {
                    this.sbpInfo.Text = string.Format("Added column \"{0}\" bound to {1}.", strArray[2], strArray[3]);
                    flag = true;
                }
                else
                {
                    this.sbpInfo.Text = "Failed to add column. Syntax: COLS ADD [TITLE] @COLLECTION.FLAGNAME";
                }
                if (flag)
                {
                    this.WithinLimitRefreshBoundColumns();
                }
            }
            return true;
        }

        private static bool _QuickExecAddListener(string sCommand)
        {
            string[] strArray = Utilities.Parameterize(sCommand);
            if (strArray.Length > 1)
            {
                int result = 0;
                if (!int.TryParse(strArray[1], out result))
                {
                    FiddlerApplication.DoNotifyUser("The correct to start a new listener is:\n\n\t!listen port# [securehostname]", "Invalid Syntax");
                    return false;
                }
                Proxy proxy = new Proxy(false);
                if (strArray.Length > 2)
                {
                    if (!proxy.ActAsHTTPSEndpointForHostname(strArray[2]))
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("Failed to create secure listener on port #{0} for {1}", result, strArray[2]), "Failure");
                    }
                    else if (proxy.Start(result, true))
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("Started new Secure Listener on port #{0} with certificate SubjectCN={1}", result, strArray[2]), "Success");
                        FiddlerApplication.Log.LogFormat("Started new Secure Listener on port #{0} with certificate SubjectCN={1}", new object[] { result, strArray[2] });
                    }
                }
                else if (proxy.Start(result, true))
                {
                    FiddlerApplication.DoNotifyUser(string.Format("Started new Listener on port #{0}", result), "Success");
                    FiddlerApplication.Log.LogFormat("Started new Listener on port #{0}", new object[] { result });
                }
                else
                {
                    FiddlerApplication.DoNotifyUser(string.Format("Unable to start new Listener on port #{0}", result), "Failed");
                    FiddlerApplication.Log.LogFormat("Unable to start new Listener on port #{0}", new object[] { result });
                }
                return true;
            }
            FiddlerApplication.DoNotifyUser("The correct to start a new listener is:\n\n\t!listen port# [securehostname]", "Invalid Syntax");
            return false;
        }

        private static bool _QuickExecCerts(string sCommand)
        {
            string[] strArray = Utilities.Parameterize(sCommand);
            if (strArray.Length > 1)
            {
                if (strArray[1].OICEquals("flush"))
                {
                    if (CertMaker.flushCertCache())
                    {
                        FiddlerApplication.UI.SetStatusText("The Certificate Cache was flushed.");
                    }
                    else
                    {
                        FiddlerApplication.UI.SetStatusText("The Certificate Cache could not be flushed.");
                    }
                    return true;
                }
                if (strArray[1].OICEquals("find") && (strArray.Length > 2))
                {
                    X509Certificate2 certificate = CertMaker.FindCert(strArray[2]);
                    FiddlerApplication.UI.SetStatusText((certificate != null) ? certificate.Subject : string.Format("Certificate for '{0}' not found", strArray[2]));
                    return true;
                }
            }
            FiddlerApplication.DoNotifyUser("flush\r\nfind <hostname>\r\n", "Valid Actions", MessageBoxIcon.Asterisk);
            return false;
        }

        private bool _QuickExecConfigureThreadPool(string sCommand)
        {
            int result = 4;
            int num2 = 4;
            string[] strArray = Utilities.Parameterize(sCommand);
            if (strArray.Length < 2)
            {
                int num3;
                int num4;
                StringBuilder builder = new StringBuilder();
                builder.AppendLine("Output of !threads\n");
                builder.AppendLine(COUNTERS.Summarize());
                ThreadPool.GetMinThreads(out num3, out num4);
                Process currentProcess = Process.GetCurrentProcess();
                builder.AppendFormat("\n-= Fiddler CPU/Thread Usage =-\n\nProcess Priority: {0}-{1} Boost: {2}\nCurrent Thread Count: {3}\nCPU Time: {4}\n\n", new object[] { currentProcess.BasePriority, currentProcess.PriorityClass, currentProcess.PriorityBoostEnabled, currentProcess.Threads.Count, currentProcess.UserProcessorTime });
                builder.AppendLine("-ThreadPool Information-");
                builder.AppendFormat("Threads (MinIdle)\nWorker: \t\t{0}\nCompletion Port:\t{1}\n", num3, num4);
                ThreadPool.GetMaxThreads(out num3, out num4);
                builder.AppendFormat("Threads (Max)\nWorker: \t\t{0}\nCompletion Port:\t{1}\n", num3, num4);
                ThreadPool.GetAvailableThreads(out num3, out num4);
                builder.AppendFormat("Threads (Available)\nWorker: \t\t{0}\nCompletion Port:\t{1}\n", num3, num4);
                builder.AppendFormat("\nControl the threadpool using syntax: !threads <minPool#> <minCompletion#>", new object[0]);
                FiddlerApplication.Log.LogString(builder.ToString());
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
                return true;
            }
            string s = strArray[1];
            string str2 = (strArray.Length > 2) ? strArray[2] : strArray[1];
            if (!int.TryParse(s, out result))
            {
                result = 4;
            }
            if (!int.TryParse(str2, out num2))
            {
                num2 = 4;
            }
            ThreadPool.SetMinThreads(result, num2);
            this.sbpInfo.Text = string.Format("Setting threadpool min count to {0},{1}", result, num2);
            return true;
        }

        private void _QuickExecHandleFlags(string[] sParams)
        {
            FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.Flags");
            Session[] selectedSessions = FiddlerApplication.UI.GetSelectedSessions();
            if (selectedSessions.Length < 1)
            {
                FiddlerApplication.DoNotifyUser("Select one or more Sessions to adjust their flags.", "No Sessions Selected", MessageBoxIcon.Asterisk);
            }
            else if (sParams.Length < 2)
            {
                FiddlerApplication.DoNotifyUser("set <name> <value>\r\nremove <name>\r\n", "Valid Actions", MessageBoxIcon.Asterisk);
            }
            else
            {
                switch (sParams[1].ToLower())
                {
                    case "set":
                        if (sParams.Length != 4)
                        {
                            FiddlerApplication.DoNotifyUser("Correct Syntax is:\r\n\r\n\tflags SET flagName \"new value\"", "Invalid Parameters", MessageBoxIcon.Hand);
                            return;
                        }
                        try
                        {
                            foreach (Session session in selectedSessions)
                            {
                                session[sParams[2]] = sParams[3];
                            }
                            FiddlerApplication.UI.RefreshRange(selectedSessions);
                            this.sbpInfo.Text = string.Format("Set flag '{0}' to '{1}'", sParams[2], sParams[3]);
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.ReportException(exception, "Flag not set", "Unable to set the flag.");
                        }
                        return;

                    case "remove":
                        if (sParams.Length != 3)
                        {
                            FiddlerApplication.DoNotifyUser("Correct Syntax is:\r\n\r\n\tflags REMOVE flagName", "Invalid Parameters", MessageBoxIcon.Hand);
                            return;
                        }
                        foreach (Session session2 in selectedSessions)
                        {
                            session2.oFlags.Remove(sParams[2]);
                        }
                        FiddlerApplication.UI.RefreshRange(selectedSessions);
                        this.sbpInfo.Text = string.Format("Removed flag '{0}'", sParams[2]);
                        return;
                }
                FiddlerApplication.DoNotifyUser("set <name> <value>\r\nremove <name>\r\n", "Valid Actions", MessageBoxIcon.Asterisk);
            }
        }

        private void _QuickExecHandlePrefs(string[] sParams)
        {
            FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.Prefs");
            if (sParams.Length < 2)
            {
                FiddlerApplication.DoNotifyUser("set <name> <value>\r\nremove <name>\r\nshow {optional filter}\r\nlog\r\n", "Valid Actions", MessageBoxIcon.Asterisk);
            }
            else
            {
                switch (sParams[1].ToLower())
                {
                    case "log":
                        FiddlerApplication.Log.LogString(CONFIG.RawPrefs.ToString(true));
                        this.sbpInfo.Text = "Dumped preferences to log";
                        return;

                    case "show":
                        AboutConfig.ShowAboutConfigPage((sParams.Length < 3) ? string.Empty : sParams[2]);
                        return;

                    case "set":
                        if (sParams.Length != 4)
                        {
                            FiddlerApplication.DoNotifyUser("Correct Syntax is:\r\n\r\n\tprefs SET prefName \"new value\"", "Invalid Parameters", MessageBoxIcon.Hand);
                            return;
                        }
                        try
                        {
                            FiddlerApplication.Prefs.SetStringPref(sParams[2], sParams[3]);
                            this.sbpInfo.Text = string.Format("Set preference '{0}' to '{1}'", sParams[2], sParams[3]);
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.ReportException(exception, "Preference not set", "Unable to set the preference.");
                        }
                        return;

                    case "remove":
                        if (sParams.Length != 3)
                        {
                            FiddlerApplication.DoNotifyUser("Correct Syntax is:\r\n\r\n\tprefs REMOVE prefName", "Invalid Parameters", MessageBoxIcon.Hand);
                            return;
                        }
                        FiddlerApplication.Prefs.RemovePref(sParams[2]);
                        this.sbpInfo.Text = string.Format("Removed preference '{0}'", sParams[2]);
                        return;

                    case "flush":
                        try
                        {
                            if (CONFIG.bIsViewOnly)
                            {
                                this.SetStatusText("In Viewer Mode, preferences must not be stored.");
                            }
                            else
                            {
                                CONFIG.RawPrefs.WriteRegistry();
                                this.SetStatusText("Wrote Fiddler Preferences to the registry");
                            }
                        }
                        catch (Exception exception2)
                        {
                            FiddlerApplication.ReportException(exception2, "Could Not Write Preferences");
                        }
                        return;
                }
                FiddlerApplication.DoNotifyUser("set <name> <value>\r\nremove <name>\r\nshow {optional filter}\r\nlog\r\n", "Valid Actions", MessageBoxIcon.Asterisk);
            }
        }

        private static bool _QuickExecLogLoadedAssemblies(string sCommand)
        {
            StringBuilder builder = new StringBuilder();
            string str = null;
            if (sCommand.OICStartsWith("!lm "))
            {
                str = sCommand.Substring(3).Trim();
                builder.AppendFormat("== LOADED ASSEMBLIES MATCHING '{0}'==\n", str);
            }
            else
            {
                builder.Append(FiddlerApplication.GetDetailedInfo());
                builder.AppendLine("== LOADED ASSEMBLIES ==");
            }
            try
            {
                foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if ((str == null) || assembly.FullName.OICContains(str))
                    {
                        string location;
                        if (assembly.IsDynamic)
                        {
                            location = "DYNAMIC";
                        }
                        else
                        {
                            location = assembly.Location;
                        }
                        builder.AppendFormat("{0}\n\t{1}\n\tRuntime: {2} \tGAC: {3}\n", new object[] { assembly.FullName, location, assembly.ImageRuntimeVersion, assembly.GlobalAssemblyCache });
                    }
                }
                FiddlerApplication.Log.LogString(builder.ToString());
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Failed to gather information: {0}", new object[] { Utilities.DescribeException(exception) });
            }
            return true;
        }

        private static void _QuickExecLogLoadedAuthModules()
        {
            IEnumerator registeredModules = AuthenticationManager.RegisteredModules;
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("\nRegistered Authentication modules:");
            while (registeredModules.MoveNext())
            {
                builder.AppendFormat("\nModule:\t{0}\n", registeredModules.Current);
                IAuthenticationModule current = (IAuthenticationModule) registeredModules.Current;
                builder.AppendFormat("\tAuthType:\t{0}\n", current.AuthenticationType);
                builder.AppendFormat("\tCanPreAuth:\t{0}\n", current.CanPreAuthenticate);
            }
            FiddlerApplication.Log.LogString(builder.ToString());
        }

        private void _QuickExecQuickSearch()
        {
            if ((this.txtExec.TextLength > 1) && this.txtExec.Text.StartsWith("?", StringComparison.Ordinal))
            {
                List<ListViewItem> list = new List<ListViewItem>();
                string str = this.txtExec.Text.Substring(1).Trim();
                if (!string.IsNullOrEmpty(str))
                {
                    foreach (ListViewItem item in this.lvSessions.Items)
                    {
                        if ((item.SubItems[2].Text + "://" + item.SubItems[3].Text + item.SubItems[4].Text).OICContains(str))
                        {
                            list.Add(item);
                        }
                    }
                }
                Application.DoEvents();
                if ((this.txtExec.TextLength > 1) && (this.txtExec.Text.Substring(1).Trim() == str))
                {
                    FiddlerApplication.SuppressReportUpdates = true;
                    this.lvSessions.BeginUpdate();
                    this.lvSessions.SelectedItems.Clear();
                    foreach (ListViewItem item2 in list)
                    {
                        item2.Selected = true;
                    }
                    this.sbpInfo.Text = string.Format("Found {0:N0} instances of '{1}'", this.lvSessions.SelectedCount, str);
                    FiddlerApplication.SuppressReportUpdates = false;
                    this.lvSessions.EndUpdate();
                }
            }
        }

        private bool _QuickExecSelectFlagHeaderOrColumn(string sCommand)
        {
            string sCollection;
            string sHeaderOrFlag;
            string sMatch;
            string[] strArray = Utilities.Parameterize(sCommand);
            if (strArray.Length < 2)
            {
                return false;
            }
            if (strArray.Length == 2)
            {
                sCollection = "RESPONSE";
                sHeaderOrFlag = "Content-Type";
                sMatch = strArray[1];
            }
            else
            {
                sHeaderOrFlag = strArray[1];
                if (sHeaderOrFlag.OICStartsWith("@request."))
                {
                    sCollection = "REQUEST";
                    sHeaderOrFlag = sHeaderOrFlag.Substring(9);
                }
                else if (sHeaderOrFlag.OICStartsWith("@response."))
                {
                    sCollection = "RESPONSE";
                    sHeaderOrFlag = sHeaderOrFlag.Substring(10);
                }
                else if (sHeaderOrFlag.OICStartsWith("@col."))
                {
                    sCollection = "COLUMN";
                    sHeaderOrFlag = sHeaderOrFlag.Substring(5);
                }
                else
                {
                    sCollection = "SESSION";
                }
                sMatch = strArray[2];
            }
            if (sCollection == "COLUMN")
            {
                this.lvSessions.SearchColumn(sHeaderOrFlag, sMatch);
                return true;
            }
            if (sMatch == "*")
            {
                sMatch = string.Empty;
            }
            if (sMatch == @"\*")
            {
                sMatch = "*";
            }
            this.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                if (string.IsNullOrEmpty(sMatch))
                {
                    switch (sCollection)
                    {
                        case "SESSION":
                            return oS.oFlags.ContainsKey(sHeaderOrFlag);

                        case "REQUEST":
                            return Utilities.HasHeaders(oS.oRequest) && oS.oRequest.headers.Exists(sHeaderOrFlag);
                    }
                    return Utilities.HasHeaders(oS.oResponse) && oS.oResponse.headers.Exists(sHeaderOrFlag);
                }
                string inStr = oS[sCollection, sHeaderOrFlag];
                return (inStr != null) && inStr.OICContains(sMatch);
            });
            this.sbpInfo.Text = string.Format("Selected {0} sessions where {1}'s {2}.Contains({3})", new object[] { this.lvSessions.SelectedCount, sCollection, sHeaderOrFlag, sMatch });
            if (this.lvSessions.SelectedCount > 0)
            {
                this.lvSessions.Focus();
            }
            return true;
        }

        private bool _QuickExecToggleDebugSpew()
        {
            if (!CONFIG.bDebugSpew)
            {
                CONFIG.bDebugSpew = true;
                FiddlerApplication.Log.LogString("DebugSpew is now enabled; use DbgView.exe to examine output.");
                FiddlerApplication.DebugSpew(FiddlerApplication.GetDetailedInfo());
                if (CONFIG.bEnableAnalytics && (FiddlerApplication.oTelemetry != null))
                {
                    FiddlerApplication.DebugSpew("Telerik Analytics Enabled. ID: {0}\n", new object[] { FiddlerApplication.oTelemetry.DeviceId });
                }
                FiddlerApplication.DebugSpew("CONNECTIONS:\r\n");
                FiddlerApplication.DebugSpew(string.Join("\r\n", RASInfo.GetConnectionNames()));
                FiddlerApplication.DebugSpew("PREFERENCES:\r\n");
                FiddlerApplication.DebugSpew(CONFIG.RawPrefs.ToString(true));
                this.sbpInfo.Text = "DebugSpew is now enabled.";
            }
            else
            {
                FiddlerApplication.Log.LogString("DebugSpew is now disabled.");
                this.sbpInfo.Text = "DebugSpew is now disabled.";
                CONFIG.bDebugSpew = false;
            }
            return true;
        }

        private void _RefreshSessionListViewItem(Session oSession, ListViewItem lvi)
        {
            int num = 4;
            try
            {
                SessionListView.FillBoundColumns(oSession, lvi);
                lvi.SubItems[2].Text = _obtainScheme(oSession);
                lvi.SubItems[1].Text = ((oSession.oResponse == null) || (oSession.oResponse.headers == null)) ? " - " : oSession.responseCode.ToString();
                lvi.SubItems[3].Text = oSession.host;
                lvi.SubItems[4].Text = oSession.PathAndQuery;
                lvi.SubItems[10].Text = oSession.oFlags["ui-customcolumn"];
                lvi.SubItems[9].Text = oSession.oFlags["ui-comments"];
                if (oSession.responseBodyBytes != null)
                {
                    lvi.SubItems[5].Text = string.Format("{0:N0}", oSession.responseBodyBytes.LongLength);
                }
                else
                {
                    lvi.SubItems[5].Text = (oSession.state <= SessionStates.ReadingResponse) ? "-1" : "0";
                }
                string sString = string.Empty;
                if (Utilities.HasHeaders(oSession.oResponse))
                {
                    sString = oSession.oResponse.headers["Content-Type"];
                    lvi.SubItems[7].Text = sString;
                    sString = Utilities.TrimAfter(sString, ' ');
                    string str2 = oSession.oResponse.headers["Cache-Control"];
                    if (oSession.oResponse.headers.Exists("Expires"))
                    {
                        str2 = str2 + ((str2.Length > 0) ? "; " : string.Empty) + "Expires: " + oSession.oResponse.headers["Expires"];
                    }
                    lvi.SubItems[6].Text = str2;
                }
                if (oSession.isTunnel)
                {
                    if (SessionStates.Aborted != oSession.state)
                    {
                        num = oSession.isFlagSet(SessionFlags.IsWebSocketTunnel) ? 0x22 : 13;
                    }
                    else
                    {
                        num = 14;
                    }
                    if (oSession.HTTPMethodIs("CONNECT"))
                    {
                        lvi.SubItems[3].Text = "Tunnel to";
                        lvi.ForeColor = System.Drawing.Color.Gray;
                    }
                    else
                    {
                        lvi.ForeColor = System.Drawing.Color.Olive;
                    }
                }
                else if (oSession.isFlagSet(SessionFlags.IsRPCTunnel) || oSession.oResponse.MIMEType.Contains("text/event-stream"))
                {
                    num = 0x27;
                    lvi.ImageIndex = num;
                }
                else if (((oSession.responseCode == 0xcc) || oSession.HTTPMethodIs("HEAD")) || oSession.HTTPMethodIs("OPTIONS"))
                {
                    num = 0x10;
                }
                else if (((oSession.responseCode == 0x191) || (oSession.responseCode == 0x193)) || (oSession.responseCode == 0x197))
                {
                    lvi.ForeColor = CONFIG.colorIsAuth;
                    num = 15;
                }
                else if ((oSession.responseCode >= 400) || (oSession.responseCode < 100))
                {
                    num = 12;
                    lvi.ForeColor = System.Drawing.Color.Red;
                }
                else if (Utilities.IsRedirectStatus(oSession.responseCode))
                {
                    num = 10;
                }
                else if (oSession.responseCode == 0x130)
                {
                    lvi.ForeColor = System.Drawing.Color.Gray;
                    num = 11;
                }
                else if (oSession.responseCode == 0xce)
                {
                    num = 0x25;
                }
                else if (sString.OICStartsWith("image/"))
                {
                    lvi.ForeColor = System.Drawing.Color.Gray;
                    num = 5;
                }
                else if (sString.OICStartsWithAny(new string[] { "application/x-javascript", "application/javascript", "text/javascript" }))
                {
                    lvi.ForeColor = CONFIG.colorIsScript;
                    num = 6;
                }
                else if (sString.OICStartsWith("text/css"))
                {
                    lvi.ForeColor = System.Drawing.Color.Purple;
                    num = 9;
                }
                else if (sString.OICStartsWith("text/htm"))
                {
                    lvi.ForeColor = CONFIG.colorIsHTML;
                    num = 8;
                }
                else if (sString.OICStartsWith("application/x-shockwave-flash"))
                {
                    num = 30;
                }
                else if (sString.OICStartsWithAny(new string[] { "text/xml", "application/xml" }) || sString.OICEndsWith("+xml"))
                {
                    num = 7;
                }
                else if (sString.OICStartsWith("application/x-silverlight-app"))
                {
                    num = 0x1f;
                }
                else if (sString.OICStartsWith("audio/"))
                {
                    num = 0x1c;
                }
                else if (sString.OICStartsWith("video/"))
                {
                    num = 0x1b;
                }
                else if (sString.OICStartsWithAny(new string[] { "font/", "application/font-woff", "application/vnd.ms-fontobject", "application/x-woff" }))
                {
                    num = 0x1d;
                }
                else if (sString.OICStartsWith("application/json"))
                {
                    num = 0x21;
                }
                if (((num != 0x10) && (num != 15)) && (num != 12))
                {
                    if (oSession.isFlagSet(SessionFlags.IsWebSocketTunnel))
                    {
                        num = 0x22;
                    }
                    if (oSession.HTTPMethodIs("POST"))
                    {
                        num = 0x20;
                    }
                }
                string sColor = oSession.oFlags["ui-color"];
                if (sColor != null)
                {
                    lvi.ForeColor = Utilities.ParseColor(sColor);
                }
                sColor = oSession.oFlags["ui-backcolor"];
                if (sColor != null)
                {
                    lvi.BackColor = Utilities.ParseColor(sColor);
                }
                else if (oSession.isFlagSet(SessionFlags.ResponseBodyDropped))
                {
                    lvi.BackColor = CONFIG.colorBodyDropped;
                }
                else if (oSession.isAnyFlagSet(SessionFlags.ImportedFromOtherTool | SessionFlags.LoadedFromSAZ))
                {
                    lvi.BackColor = CONFIG.colorLoadedFromSAZ;
                }
                FontStyle regular = FontStyle.Regular;
                if (oSession.oFlags.ContainsKey("ui-bold"))
                {
                    regular |= FontStyle.Bold;
                }
                if (oSession.oFlags.ContainsKey("ui-italic"))
                {
                    regular |= FontStyle.Italic;
                }
                if (oSession.oFlags.ContainsKey("ui-strikeout"))
                {
                    regular |= FontStyle.Strikeout;
                }
                if (regular != FontStyle.Regular)
                {
                    lvi.Font = new Font(this.lvSessions.Font.FontFamily, lvi.Font.Size, lvi.Font.Style | regular);
                }
                if ((oSession.state == SessionStates.Aborted) && (oSession.oFlags.ContainsKey("X-Fiddler-Aborted") || !oSession.isAnyFlagSet(SessionFlags.RequestGeneratedByFiddler)))
                {
                    num = 14;
                }
                if (oSession.state >= SessionStates.Done)
                {
                    lvi.ImageIndex = num;
                }
                if (oSession.oFlags.ContainsKey("ui-indent"))
                {
                    lvi.IndentCount = 1;
                }
            }
            catch (Exception)
            {
            }
        }

        private void _ResumeSessions(Session[] oSessions)
        {
            this.pnlSessionControls.Visible = false;
            foreach (Session session in oSessions)
            {
                if (session == null)
                {
                    goto Label_0052;
                }
                if (session.ViewItem != null)
                {
                    switch (session.state)
                    {
                        case SessionStates.HandTamperRequest:
                            session.ViewItem.ImageIndex = 0;
                            break;

                        case SessionStates.HandTamperResponse:
                            goto Label_0040;
                    }
                }
                goto Label_004C;
            Label_0040:
                session.ViewItem.ImageIndex = 2;
            Label_004C:
                session.ThreadResume();
            Label_0052:;
            }
        }

        internal void _SaveQuickExecHistory()
        {
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.QuickExec.KeepHistory", true))
            {
                this.txtExec.SaveHistory(CONFIG.GetPath("QuickExecHistory"));
            }
        }

        internal void _SetProcessFilter(ProcessFilterCategories oCat)
        {
            FiddlerApplication.oTelemetry.TrackEvent("UI.SetProcessFilter");
            CONFIG.iShowProcessFilter = oCat;
            this.uihlpUpdateProcessFilterStatus();
        }

        private void _ShowFilterGutter()
        {
            if (this.flpFilterGutter != null)
            {
                if (this.flpFilterGutter.Height < 20)
                {
                    this.flpFilterGutter.Height = 20;
                }
            }
            else
            {
                Splitter splitter = new Splitter();
                splitter.Dock = DockStyle.Bottom;
                this.pnlSessions.Controls.Add(splitter);
                this.flpFilterGutter = new FlowLayoutPanel();
                this.flpFilterGutter.Dock = DockStyle.Bottom;
                this.flpFilterGutter.AutoScroll = true;
                this.flpFilterGutter.Height = 50;
                this.pnlSessions.Controls.Add(this.flpFilterGutter);
                Label label = new Label();
                label.AutoSize = true;
                label.MouseHover += new EventHandler(this.oTitle_MouseHover);
                label.Font = new Font(this.Font, FontStyle.Bold);
                label.Dock = DockStyle.Top;
                label.Text = "Fi&lters";
                this.flpFilterGutter.Controls.Add(label);
            }
        }

        private void _ShowViewerModeUI()
        {
            try
            {
                base.SuspendLayout();
                this.Text = "Fiddler Viewer";
                this.pnlSessions.BackColor = System.Drawing.Color.FromArgb(200, 220, 250);
                this.miCaptureEnabled.Enabled = false;
                this.miToolsOptions.Enabled = false;
                this.miNotifyCapturing.Visible = false;
                this.notifyIcon.Text = "Fiddler Viewer";
                this.notifyIcon.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[0x13]);
                base.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[0x13]);
                this.sbpCapture.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[0x13]);
                this.sbpCapture.Text = "Viewer Mode";
                this.sbpCapture.Style = StatusBarPanelStyle.Text;
                this.sbpProcessFilter.Text = string.Empty;
                this.lvSessions.EmptyText = "No Sessions are loaded";
            }
            finally
            {
                base.ResumeLayout();
            }
        }

        private void _storeMRUFolders(string sFilename)
        {
            try
            {
                string directoryName = Path.GetDirectoryName(sFilename);
                this.dlgSaveZip.InitialDirectory = directoryName;
                this.dlgSaveZip.FileName = string.Empty;
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.AddUIShortcuts", true))
                {
                    Utilities.AddPathToPlaces(this.dlgLoadZip, directoryName);
                    Utilities.AddPathToPlaces(this.dlgSaveZip, directoryName);
                }
            }
            catch
            {
            }
        }

        private void _UpdateBreakpointMenu()
        {
            if (this.miRulesBreakAtRequest.Checked)
            {
                this.sbpBreakpoints.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[1]);
                this.sbpBreakpoints.Style = StatusBarPanelStyle.Text;
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.breakonrequest", true);
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.breakonresponse", false);
            }
            else if (this.miRulesBreakAtResponse.Checked)
            {
                this.sbpBreakpoints.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[3]);
                this.sbpBreakpoints.Style = StatusBarPanelStyle.Text;
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.breakonrequest", false);
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.breakonresponse", true);
            }
            else
            {
                this.sbpBreakpoints.Style = StatusBarPanelStyle.OwnerDraw;
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.breakonrequest", false);
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.breakonresponse", false);
            }
        }

        private void _UpdateMemoryPanel()
        {
            double dblMemory = Math.Ceiling((double) (((double) GC.GetTotalMemory(false)) / 1000000.0));
            FiddlerApplication.UIInvokeAsync(delegate {
                this.sbpMemory.Text = string.Format("{0:####}mb", dblMemory);
            }, null);
        }

        private void _UpdateResponseInfoTipVisibility(Session oSession)
        {
            if ((oSession == null) || !Utilities.HasHeaders(oSession.oResponse))
            {
                this.pnlInfoTip.Visible = false;
            }
            else if (oSession.isAnyFlagSet(SessionFlags.ResponseBodyDropped))
            {
                this.btnDecodeResponse.Visible = false;
                if (oSession.isAnyFlagSet(SessionFlags.IsRPCTunnel))
                {
                    this.btnResponseBodyDropped.Text = "RPC Tunnel traffic is not available for inspection.";
                }
                else
                {
                    string str = oSession["X-RESPONSEBODYTRANSFERLENGTH"];
                    if (!string.IsNullOrEmpty(str))
                    {
                        this.btnResponseBodyDropped.Text = string.Format("The response body ({0} bytes) was dropped to conserve memory.", str);
                    }
                    else
                    {
                        this.btnResponseBodyDropped.Text = "The response body was dropped to conserve memory.";
                    }
                }
                this.btnResponseBodyDropped.Visible = true;
                this.pnlInfoTip.Visible = true;
            }
            else
            {
                this.btnResponseBodyDropped.Visible = false;
                bool flag = !Utilities.IsNullOrEmpty(oSession.responseBodyBytes) && (oSession.oResponse.headers.Exists("Transfer-Encoding") || oSession.oResponse.headers.Exists("Content-Encoding"));
                if (flag)
                {
                    if (!oSession.oResponse.headers.Exists("Transfer-Encoding"))
                    {
                        string str2 = oSession.oResponse.headers.AllValues("Content-Encoding").Trim();
                        if (string.IsNullOrEmpty(str2) || "identity".OICEquals(str2))
                        {
                            flag = false;
                        }
                    }
                    if (flag)
                    {
                        this.btnDecodeResponse.Visible = true;
                    }
                }
                this.pnlInfoTip.Visible = flag;
            }
        }

        private void _UpdateStatusBar()
        {
            int selectedCount = this.lvSessions.SelectedCount;
            if (selectedCount < 1)
            {
                this.sbpSelCount.Text = string.Format("{0:N0}", this.lvSessions.Items.Count);
            }
            else
            {
                this.sbpSelCount.Text = string.Format("{0:N0} / {1:N0}", selectedCount, this.lvSessions.Items.Count);
            }
        }

        private void _VerifyFiddlerIsFresh()
        {
            if ((!CONFIG.QuietMode && !CONFIG.bVersionCheckBlocked) && (!CONFIG.bVersionCheck && FiddlerApplication.Prefs.GetBoolPref("fiddler.updater.CheckFreshness", true)))
            {
                try
                {
                    FiddlerBuildDate date = (FiddlerBuildDate) Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(FiddlerBuildDate), false)[0];
                    if (date.IsOutdated && (FiddlerApplication.Prefs.GetStringPref("fiddler.updater.LastBegged", null) != DateTime.Now.ToShortDateString()))
                    {
                        FiddlerApplication.Prefs.SetStringPref("fiddler.updater.LastBegged", DateTime.Now.ToShortDateString());
                        if (DialogResult.Yes == MessageBox.Show("Sorry to bother you, but this version of Fiddler is now quite outdated.\n\nCan we check for a new version real quick?", "What's that smell?", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                        {
                            Thread thread = new Thread(delegate {
                                actCheckForUpdates(true);
                            });
                            thread.IsBackground = true;
                            thread.Start();
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        internal void actAddCommentSession()
        {
            DateTime now = DateTime.Now;
            string str = frmPrompt.GetUserString("Set Comment", "Enter a comment string to show in the Session List:", now.ToString("HH-mm-ss"), true);
            if (str != null)
            {
                HTTPRequestHeaders headersRequest = new HTTPRequestHeaders("/" + Utilities.UrlPathEncode(str.Replace(" ", "_")), new string[] { "Host: COMMENT", "Date: " + now.ToUniversalTime().ToString("r") });
                FiddlerApplication.UI.AddMockSession(headersRequest, null, null, Encoding.ASCII.GetBytes("This Session was generated by the Fiddler user hitting the Shift+M key to create a comment line in the Web Sessions list.\n" + now.ToLongTimeString())).oFlags["ui-backcolor"] = "OrangeRed";
            }
        }

        [CodeDescription("Attach Fiddler as the WinINET proxy.")]
        public void actAttachProxy()
        {
            this.actAttachProxy(true);
        }

        internal void actAttachProxy(bool bNeedGWInfo)
        {
            this.pnlTopNotice.Visible = false;
            if (FiddlerApplication.oProxy.Attach(bNeedGWInfo))
            {
                this.sbpCapture.Text = "Capturing";
                this.sbpCapture.Style = StatusBarPanelStyle.Text;
            }
        }

        public void actCaptureScreenshot(bool bDelay)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.CaptureScreenshot");
            if (bDelay)
            {
                this.actCaptureScreenshot(FiddlerApplication.Prefs.GetInt32Pref("fiddler.screenshot.DelayMS", 0x1388));
            }
            else
            {
                this.actCaptureScreenshot(0);
            }
        }

        [CodeDescription("Add a screenshot to the capture, delaying the specified number of milliseconds.")]
        public void actCaptureScreenshot(int iDelayMS)
        {
            DoWorkEventHandler handler = null;
            try
            {
                if (iDelayMS > 0)
                {
                    BackgroundWorker worker = new BackgroundWorker();
                    if (handler == null)
                    {
                        handler = delegate (object s, DoWorkEventArgs ea) {
                            if (iDelayMS > 0x3e8)
                            {
                                string str = FiddlerApplication.Prefs.GetStringPref("fiddler.sounds.Countdown", CONFIG.GetPath("App") + "Countdown.wav");
                                MethodInvoker oDel = null;
                                for (int iX = iDelayMS; iX > 0; iX -= 0x3e8)
                                {
                                    if (oDel == null)
                                    {
                                        oDel = delegate {
                                            FiddlerToolbar.SetScreenshotCounter(" ( " + ((iX / 0x3e8)).ToString() + "... )");
                                        };
                                    }
                                    FiddlerApplication.UIInvokeAsync(oDel, null);
                                    if ((iX <= 0xbb8) && !string.IsNullOrEmpty(str))
                                    {
                                        Utilities.PlaySoundFile(str);
                                    }
                                    Thread.Sleep(0x3e8);
                                }
                            }
                            else
                            {
                                Thread.Sleep(iDelayMS);
                            }
                            FiddlerApplication.UIInvokeAsync(delegate {
                                FiddlerToolbar.SetScreenshotCounter("(cheese!)");
                                Application.DoEvents();
                                this.actCaptureScreenshot(0);
                                string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.sounds.Screenshot", CONFIG.GetPath("App") + "Screenshot.wav");
                                if (!string.IsNullOrEmpty(stringPref))
                                {
                                    Utilities.PlaySoundFile(stringPref);
                                }
                                FiddlerToolbar.SetScreenshotCounter(string.Empty);
                            }, null);
                        };
                    }
                    worker.DoWork += handler;
                    worker.RunWorkerAsync();
                }
                else
                {
                    this._addScreenshotNow();
                    FiddlerApplication.UI.SetStatusText("A screenshot has been added to the capture.");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Screenshot failed");
            }
        }

        internal void actChangeToLayout(int iLayoutMode)
        {
            FiddlerApplication.Prefs.SetInt32Pref("fiddler.ui.layout.mode", iLayoutMode);
            base.SuspendLayout();
            switch (iLayoutMode)
            {
                case 0:
                    this.miViewDefault.Checked = true;
                    this.miViewStacked.Checked = false;
                    this.miViewWide.Checked = false;
                    break;

                case 1:
                    this.miViewDefault.Checked = false;
                    this.miViewStacked.Checked = true;
                    this.miViewWide.Checked = false;
                    break;

                case 2:
                    this.miViewDefault.Checked = false;
                    this.miViewStacked.Checked = false;
                    this.miViewWide.Checked = true;
                    break;
            }
            if (iLayoutMode > 0)
            {
                this.pnlSessions.Dock = DockStyle.Top;
                this.splitterMain.Dock = DockStyle.Top;
                this.pnlSessions.Height = base.Height / 2;
                if (iLayoutMode == 1)
                {
                    this.tabsRequest.Dock = DockStyle.Top;
                    this.splitterInspector.Dock = DockStyle.Top;
                }
                else
                {
                    this.tabsRequest.Dock = DockStyle.Left;
                    this.splitterInspector.Dock = DockStyle.Left;
                }
                this.miViewSquish.Enabled = false;
            }
            else
            {
                this.pnlSessions.Dock = DockStyle.Left;
                this.splitterMain.Dock = DockStyle.Left;
                this.pnlSessions.Width = base.Width / 2;
                this.tabsRequest.Dock = DockStyle.Top;
                this.splitterInspector.Dock = DockStyle.Top;
                this.miViewSquish.Enabled = true;
                this.miViewSquish.Checked = false;
            }
            base.ResumeLayout();
        }

        private static void actCheckForUpdates(bool verbose)
        {
            if (!CONFIG.bVersionCheckBlocked)
            {
                Updater.CheckForUpdates(verbose);
            }
            else if (verbose)
            {
                FiddlerApplication.DoNotifyUser("Sorry, an Adminstrator has disabled the update check.", "I can't do that, Dave");
            }
        }

        private void actCheckForUpdatesQuiet()
        {
            actCheckForUpdates(false);
        }

        private void actCheckForUpdatesVerbose()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.ManualUpdateCheck");
            actCheckForUpdates(true);
        }

        [CodeDescription("Delete all cached WinINET files.")]
        public void actClearWinINETCache()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.ClearWinINETCache");
            try
            {
                this.sbpInfo.Text = "Clearing WININET cache files...";
                FiddlerApplication.UI.UseWaitCursor = true;
                Application.DoEvents();
                WinINETCache.ClearFiles();
                this.sbpInfo.Text = "WinINET Temporary Internet Files cache cleared.";
            }
            finally
            {
                FiddlerApplication.UI.UseWaitCursor = false;
            }
        }

        [CodeDescription("Delete all stored WinINET cookies; won't clear memory-only session cookies")]
        public void actClearWinINETCookies()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.ClearWinINETCookies");
            this.sbpInfo.Text = "Clearing WININET cookies...";
            try
            {
                FiddlerApplication.UI.UseWaitCursor = true;
                Application.DoEvents();
                WinINETCache.ClearCookies();
                this.sbpInfo.Text = "WinINET cookies cleared.";
            }
            finally
            {
                FiddlerApplication.UI.UseWaitCursor = false;
            }
        }

        internal void actCommentSelectedSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.Comment");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                string sDefault = selectedSessions[0].oFlags["ui-comments"] ?? string.Empty;
                string str2 = frmPrompt.GetUserString("Set Comment", "Enter a comment to associate with the selected Sessions:", sDefault, true);
                if (str2 != null)
                {
                    this.lvSessions.BeginUpdate();
                    foreach (Session session in selectedSessions)
                    {
                        if (str2.Length > 0)
                        {
                            session.oFlags["ui-comments"] = str2;
                        }
                        else
                        {
                            session.oFlags.Remove("ui-comments");
                        }
                        if (session.ViewItem != null)
                        {
                            session.ViewItem.SubItems[9].Text = str2;
                        }
                    }
                    this.lvSessions.EndUpdate();
                }
            }
        }

        private void actCreateSessionFromCURLCommand(string sText)
        {
            HTTPRequestHeaders headers;
            byte[] buffer;
            if (GetRequestFromCURLString(sText, out headers, out buffer))
            {
                HTTPResponseHeaders headersResponse = new HTTPResponseHeaders(0xcc, "Never sent", new string[] { "X-Source: CURLPaste" });
                byte[] bytes = Encoding.UTF8.GetBytes("This request was pasted into Fiddler. Use one of the \"Reissue\" commands to actually send it.");
                this.AddMockSession(headers, buffer, headersResponse, bytes);
            }
        }

        private void actCreateSessionFromDataURI(string sText)
        {
            string sString = Utilities.TrimBefore(sText, "data:");
            string str2 = Utilities.TrimAfter(sString, ',');
            string str3 = Utilities.TrimBefore(sString, ',');
            string str4 = Utilities.TrimBefore(str2, ';');
            string str5 = Utilities.TrimAfter(str2, ';');
            bool flag = false;
            if (str4.Contains("base64"))
            {
                flag = true;
            }
            if (str3.Length < 1)
            {
                MessageBox.Show("The DataURI did not contain any data", "Malformed URI");
            }
            else
            {
                byte[] buffer3;
                HTTPRequestHeaders headers = new HTTPRequestHeaders();
                headers.HTTPMethod = "GET";
                headers.Add("Host", "localhost");
                headers.RequestPath = (str3.Length > 15) ? string.Format("/datauri/{0}~{1}", Utilities.UrlPathEncode(Utilities.TrimTo(str3, 10)), Utilities.UrlPathEncode(str3.Substring(str3.Length - 10))) : string.Format("/datauri/{0}", Utilities.UrlPathEncode(str3));
                byte[] arrRequest = headers.ToByteArray(true, true, false);
                byte[] bytes = Encoding.UTF8.GetBytes(string.Format("HTTP/1.1 200 OK\r\nContent-Type: {0}\r\nCache-Control: max-age=0, must-revalidate\r\nConnection: close\r\n\r\n", str5));
                if (flag)
                {
                    str3 = Utilities.TrimAfter(Utilities.TrimAfter(str3, '\''), '"').Trim();
                    if (str3.Contains("%"))
                    {
                        str3 = Utilities.UrlDecode(str3);
                    }
                    buffer3 = Convert.FromBase64String(str3);
                }
                else
                {
                    buffer3 = Encoding.UTF8.GetBytes(str3);
                }
                MemoryStream stream = new MemoryStream();
                stream.Write(bytes, 0, bytes.Length);
                stream.Write(buffer3, 0, buffer3.Length);
                Session oSession = new Session(arrRequest, stream.ToArray(), SessionFlags.ServedFromCache | SessionFlags.ImportedFromOtherTool | SessionFlags.ResponseGeneratedByFiddler | SessionFlags.RequestGeneratedByFiddler);
                oSession.state = SessionStates.Done;
                this.finishSession(oSession);
            }
        }

        private void actCreateSessionFromText(string sText)
        {
            HTTPResponseHeaders headers2;
            byte[] bytes;
            HTTPRequestHeaders headersRequest = new HTTPRequestHeaders(string.Format("/clipboard/{0}", DateTime.Now.ToString("H-mm-ss")), new string[] { "Host: localhost" });
            if (sText.StartsWith("HTTP/"))
            {
                headers2 = Parser.ParseResponse(sText);
                int index = sText.IndexOf("\r\n\r\n");
                int num2 = sText.IndexOf("\n\n");
                int length = sText.Length;
                if ((index > 0) && ((num2 < 0) || (index < num2)))
                {
                    bytes = Encoding.UTF8.GetBytes(sText.Substring(index + 4));
                }
                else if (num2 > 0)
                {
                    bytes = Encoding.UTF8.GetBytes(sText.Substring(num2 + 2));
                }
                else
                {
                    bytes = Utilities.emptyByteArray;
                }
            }
            else
            {
                headers2 = new HTTPResponseHeaders(200, "From Clipboard", new string[] { "Content-Type: text/plain; charset=utf-8" });
                bytes = Encoding.UTF8.GetBytes(sText);
            }
            this.AddMockSession(headersRequest, Utilities.emptyByteArray, headers2, bytes);
        }

        [CodeDescription("Detach Fiddler from WinINET.")]
        public void actDetachProxy()
        {
            if (FiddlerApplication.oProxy.Detach())
            {
                this.sbpCapture.Text = string.Empty;
                this.sbpCapture.Style = StatusBarPanelStyle.OwnerDraw;
            }
        }

        [CodeDescription("Compare two Web sessions using the default comparison tool.")]
        public void actDoCompareSessions(Session oSess1, Session oSess2)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.DoCompare");
            string path = CONFIG.GetPath("SafeTemp");
            string str2 = path + "S1_" + oSess1.id.ToString() + ".txt";
            string str3 = path + "S2_" + oSess2.id.ToString() + ".txt";
            try
            {
                SaveFilesForDiffer(str2, str3, oSess1, oSess2);
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser("Unable to save files for comparison.\n\n" + exception.Message, "Compare Failed", MessageBoxIcon.Hand);
                return;
            }
            try
            {
                string format = ((Control.ModifierKeys == Keys.Shift) || (Control.ModifierKeys == Keys.Alt)) ? FiddlerApplication.Prefs.GetStringPref("fiddler.differ.ParamsAlt", "\"{0}\" \"{1}\" -p") : FiddlerApplication.Prefs.GetStringPref("fiddler.differ.Params", " \"{0}\" \"{1}\"");
                using (Process.Start(CONFIG.GetPath("WINDIFF"), string.Format(format, str2, str3)))
                {
                }
            }
            catch (Exception exception2)
            {
                if (DialogResult.Yes == MessageBox.Show("Failed to launch comparison tool (" + exception2.Message + ").\n\nPlease ensure that " + CONFIG.GetPath("WINDIFF") + " is installed and in your Path.\n\nWould you like to download WinDiff or WinMerge?", "Compare Failed", MessageBoxButtons.YesNo, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2))
                {
                    Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("GETWINDIFF"));
                }
            }
        }

        private void actDoExport(Session[] oSelectedSessions)
        {
            string[] array = FiddlerApplication.oTranscoders.getExportFormats();
            if (array.Length > 0)
            {
                if (oSelectedSessions == null)
                {
                    oSelectedSessions = this.GetAllSessions();
                }
                Array.Sort<string>(array);
                string sExportFormat = actSelectImportExportFormat(false, array);
                if (sExportFormat != null)
                {
                    Application.DoEvents();
                    if (FiddlerApplication.DoExport(sExportFormat, oSelectedSessions, null, null))
                    {
                        this.sbpInfo.Text = "Export to " + sExportFormat + " completed.";
                    }
                    else
                    {
                        this.sbpInfo.Text = "Export failed or was cancelled.";
                    }
                }
            }
            else
            {
                FiddlerApplication.DoNotifyUser(string.Format("You can install Exporters from {0}", CONFIG.GetRedirUrl("FIDDLERTRANSCODERS")), "No Exporters Installed");
            }
        }

        [CodeDescription("Launch the Find Sessions user experience.")]
        public void actDoFind()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Dialogs.LaunchFind");
            using (frmSearch search = new frmSearch())
            {
                search.cbSearchSelectedSessions.Enabled = this.lvSessions.SelectedCount > 0;
                search.cbSearchSelectedSessions.Checked = this.lvSessions.SelectedCount > 1;
                if (DialogResult.OK == search.ShowDialog(this))
                {
                    IEnumerable selectedItems;
                    int num = 0;
                    if (search.cbSearchSelectedSessions.Checked)
                    {
                        selectedItems = this.lvSessions.SelectedItems;
                    }
                    else
                    {
                        selectedItems = this.lvSessions.Items;
                    }
                    System.Drawing.Color empty = System.Drawing.Color.Empty;
                    if (search.cbxSearchColor.SelectedIndex > 0)
                    {
                        empty = System.Drawing.Color.FromName(search.cbxSearchColor.Text);
                    }
                    if (search.cbSearchSelectMatches.Checked)
                    {
                        FiddlerApplication.SuppressReportUpdates = true;
                        this.lvSessions.SelectedItems.Clear();
                        FiddlerApplication.SuppressReportUpdates = false;
                    }
                    string text = search.txtSearchFor.Text;
                    Regex reSearchFor = null;
                    if (search.txtSearchFor.Text.OICStartsWith("REGEX:"))
                    {
                        try
                        {
                            RegexOptions options = RegexOptions.Singleline | RegexOptions.ExplicitCapture;
                            if (!search.cbSearchCaseSensitive.Checked)
                            {
                                options |= RegexOptions.IgnoreCase;
                            }
                            reSearchFor = new Regex(search.txtSearchFor.Text.Substring(6), options);
                        }
                        catch (Exception exception)
                        {
                            MessageBox.Show("The regular expression provided is not valid.\n" + exception.ToString(), "Invalid Expression");
                        }
                    }
                    bool flag = search.cbSearchDecodeFirst.Checked;
                    bool bCaseSensitive = search.cbSearchCaseSensitive.Checked;
                    frmSearch.SearchScope selectedIndex = (frmSearch.SearchScope) ((byte) search.cbxSearchIn.SelectedIndex);
                    foreach (ListViewItem item in selectedItems)
                    {
                        Session tag = item.Tag as Session;
                        if (tag != null)
                        {
                            bool flag3 = false;
                            if (frmSearch.SearchScope.URL == selectedIndex)
                            {
                                flag3 = this._IsSearchMatch(tag.fullUrl, reSearchFor, text, search.cbSearchCaseSensitive.Checked);
                            }
                            else
                            {
                                if ((selectedIndex < frmSearch.SearchScope.Response) && Utilities.HasHeaders(tag.oRequest))
                                {
                                    if (search.cbxExamine.SelectedIndex != 2)
                                    {
                                        flag3 = this._IsSearchMatch(tag.oRequest.headers.ToString(true, false, true), reSearchFor, text, bCaseSensitive);
                                    }
                                    if (((!flag3 && (search.cbxExamine.SelectedIndex != 1)) && !Utilities.IsNullOrEmpty(tag.requestBodyBytes)) && (search.cbSearchBinaries.Checked || !Utilities.IsBinaryMIME(tag.oRequest.headers["Content-Type"])))
                                    {
                                        if (flag)
                                        {
                                            tag.utilDecodeRequest();
                                        }
                                        flag3 = this._IsSearchMatch(Utilities.getEntityBodyEncoding(tag.oRequest.headers, tag.requestBodyBytes).GetString(tag.requestBodyBytes), reSearchFor, text, search.cbSearchCaseSensitive.Checked);
                                    }
                                }
                                if ((!flag3 && ((selectedIndex == frmSearch.SearchScope.RequestAndResponse) || (frmSearch.SearchScope.Response == selectedIndex))) && Utilities.HasHeaders(tag.oResponse))
                                {
                                    if (search.cbxExamine.SelectedIndex != 2)
                                    {
                                        flag3 = this._IsSearchMatch(tag.oResponse.headers.ToString(true, false), reSearchFor, text, search.cbSearchCaseSensitive.Checked);
                                    }
                                    if (((!flag3 && (search.cbxExamine.SelectedIndex != 1)) && !Utilities.IsNullOrEmpty(tag.responseBodyBytes)) && (search.cbSearchBinaries.Checked || !Utilities.IsBinaryMIME(tag.oResponse.headers["Content-Type"])))
                                    {
                                        if (flag)
                                        {
                                            tag.utilDecodeResponse();
                                        }
                                        flag3 = this._IsSearchMatch(Utilities.getResponseBodyEncoding(tag).GetString(tag.responseBodyBytes), reSearchFor, text, bCaseSensitive);
                                    }
                                }
                            }
                            if (flag3)
                            {
                                num++;
                                if (num == 1)
                                {
                                    item.EnsureVisible();
                                }
                                if (empty != System.Drawing.Color.Empty)
                                {
                                    if ((tag.oFlags["ui-bold"] != "user-marked") && (item.ForeColor != System.Drawing.Color.Black))
                                    {
                                        tag.oFlags["ui-oldcolor"] = Utilities.ColorToString(item.ForeColor);
                                    }
                                    item.BackColor = empty;
                                    tag.oFlags["ui-backcolor"] = search.cbxSearchColor.Text;
                                }
                                if (search.cbSearchSelectMatches.Checked)
                                {
                                    item.Selected = true;
                                }
                                continue;
                            }
                            if (search.cbUnmarkOld.Checked && (tag.oFlags["ui-backcolor"] == search.cbxSearchColor.Text))
                            {
                                item.BackColor = this.lvSessions.BackColor;
                                tag.oFlags.Remove("ui-backcolor");
                            }
                        }
                    }
                    string str2 = (reSearchFor == null) ? "contained" : "matched";
                    this.sbpInfo.Text = string.Format("{0} session{1} {2} '{3}'", new object[] { num, (num != 1) ? "s" : string.Empty, str2, (reSearchFor == null) ? text : text.Substring(6) });
                    this.lvSessions.Focus();
                }
            }
        }

        internal void actDoSelectNextFindResult(bool bForward)
        {
            if (this.lvSessions.TotalItemCount() >= 1)
            {
                Session firstSelectedSession = this.GetFirstSelectedSession();
                if (firstSelectedSession == null)
                {
                    firstSelectedSession = this.lvSessions.Items[0].Tag as Session;
                }
                if ((firstSelectedSession != null) && (firstSelectedSession.ViewItem != null))
                {
                    string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.find.ephemeral.lastsearchmarkcolor", null);
                    if (!string.IsNullOrEmpty(stringPref))
                    {
                        if (bForward)
                        {
                            for (int i = firstSelectedSession.ViewItem.Index + 1; i < this.lvSessions.Items.Count; i++)
                            {
                                Session tag = this.lvSessions.Items[i].Tag as Session;
                                if ((tag != null) && (tag.oFlags["ui-backcolor"] == stringPref))
                                {
                                    firstSelectedSession.ViewItem.Selected = false;
                                    tag.ViewItem.Selected = true;
                                    tag.ViewItem.Focused = true;
                                    tag.ViewItem.EnsureVisible();
                                    return;
                                }
                            }
                        }
                        else
                        {
                            for (int j = firstSelectedSession.ViewItem.Index - 1; j > -1; j--)
                            {
                                Session session3 = this.lvSessions.Items[j].Tag as Session;
                                if ((session3 != null) && (session3.oFlags["ui-backcolor"] == stringPref))
                                {
                                    firstSelectedSession.ViewItem.Selected = false;
                                    session3.ViewItem.Selected = true;
                                    session3.ViewItem.Focused = true;
                                    session3.ViewItem.EnsureVisible();
                                    return;
                                }
                            }
                        }
                        FiddlerApplication.UI.SetStatusText("No more matches were found");
                    }
                }
            }
        }

        public void actExit()
        {
            base.Close();
        }

        internal void actGetHelp()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.GetHelp");
            Utilities.LaunchHyperlink(CONFIG.GetUrl("HelpContents") + Application.ProductVersion);
        }

        private void actHandleWindowsShutdown()
        {
            bool flag = false;
            if ((FiddlerApplication.oProxy.IsAttached && (Environment.OSVersion.Version.Major > 5)) && FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.WorkaroundBuggyWinShutdown", true))
            {
                flag = true;
            }
            this.actDetachProxy();
            if (flag)
            {
                try
                {
                    WinINETProxyInfo defaultConnectionGatewayInfo = FiddlerApplication.oProxy.oAllConnectoids.GetDefaultConnectionGatewayInfo();
                    if (defaultConnectionGatewayInfo != null)
                    {
                        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true))
                        {
                            if (key != null)
                            {
                                key.SetValue("ProxyEnable", defaultConnectionGatewayInfo.bUseManualProxies ? 1 : 0);
                                key.SetValue("ProxyServer", defaultConnectionGatewayInfo.CalculateProxyString() ?? string.Empty);
                                key.SetValue("ProxyOverride", defaultConnectionGatewayInfo.sHostsThatBypass ?? string.Empty);
                                if (CONFIG.bHookWithPAC)
                                {
                                    key.DeleteValue("AutoConfigURL", false);
                                }
                                key.SetValue("_FiddlerDirectWrite", "BuggyWinShutdown at " + DateTime.Now.ToString("HH:mm:ss yyyy-MM-dd"));
                            }
                        }
                    }
                }
                catch (Exception exception)
                {
                    Trace.WriteLine("Failed last ditch attempt to overwrite proxy settings " + exception.Message);
                }
            }
        }

        [CodeDescription("Import Sessions from the specified file. Note: Only works for certain import types like .HAR, .pcap, .cap")]
        public void actImportFile(string sFilename)
        {
            try
            {
                if (System.IO.File.Exists(sFilename))
                {
                    string extension = Path.GetExtension(sFilename);
                    if (!string.IsNullOrEmpty(extension))
                    {
                        TranscoderTuple importerForExtension = FiddlerApplication.oTranscoders.GetImporterForExtension(extension);
                        if (importerForExtension == null)
                        {
                            FiddlerApplication.Log.LogFormat("!Unable to find an Importer to handle the specified file: '{0}'", new object[] { sFilename });
                        }
                        else
                        {
                            Dictionary<string, object> dictOptions = new Dictionary<string, object>();
                            dictOptions.Add("Filename", sFilename);
                            dictOptions.Add("Filename-Source", "CommandLine");
                            FiddlerApplication.DoImport(importerForExtension.sFormatName, true, dictOptions, null);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void actIndent(int iDelta)
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                foreach (Session session in selectedSessions)
                {
                    int num = session.ViewItem.IndentCount + iDelta;
                    session.ViewItem.IndentCount = Math.Min(5, Math.Max(num, 0));
                }
            }
        }

        private void actInspectInNewWindow()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.InspectInNewWindow");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                firstSelectedSession.actInspectInNewWindow();
            }
        }

        [CodeDescription("Show the most relevant Request and Response inspectors for this session")]
        public void actInspectSession()
        {
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if ((((firstSelectedSession != null) && (firstSelectedSession.ViewItem != null)) && (FiddlerApplication.oInspectors != null)) && FiddlerApplication.DoBeforeInspect(firstSelectedSession))
            {
                try
                {
                    TabPage bestRequestInspector = this.GetBestRequestInspector(firstSelectedSession);
                    TabPage bestResponseInspector = this.GetBestResponseInspector(firstSelectedSession);
                    if (bestRequestInspector != null)
                    {
                        this.tabsRequest.SelectedTab = bestRequestInspector;
                    }
                    if (bestResponseInspector != null)
                    {
                        this.tabsResponse.SelectedTab = bestResponseInspector;
                    }
                    this.tabsViews.SelectedTab = this.pageInspector;
                    if ((this._frmFloatingInspectors != null) && (this._frmFloatingInspectors.WindowState == FormWindowState.Minimized))
                    {
                        this._frmFloatingInspectors.WindowState = FormWindowState.Normal;
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception);
                }
            }
        }

        [CodeDescription("Unselects all selected sessions, Selects all unselected sessions")]
        public void actInvertSelectedSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.InvertSelection");
            this.lvSessions.BeginUpdate();
            FiddlerApplication.SuppressReportUpdates = true;
            foreach (ListViewItem item in this.lvSessions.Items)
            {
                item.Selected = !item.Selected;
            }
            this.lvSessions.EndUpdate();
            FiddlerApplication.SuppressReportUpdates = false;
            this.actUpdateInspector(true, true);
        }

        [CodeDescription("Display the named RequestInspector object")]
        public void ActivateRequestInspector(string sName)
        {
            this.tabsViews.SelectedTab = this.pageInspector;
            Utilities.activateTabByTitle(sName, this.tabsRequest);
        }

        [CodeDescription("Display the named ResponseInspector object")]
        public void ActivateResponseInspector(string sName)
        {
            this.tabsViews.SelectedTab = this.pageInspector;
            Utilities.activateTabByTitle(sName, this.tabsResponse);
        }

        [CodeDescription("Display the named tab (e.g. \"Log\") in the top-level View")]
        public void ActivateView(string sViewTabName)
        {
            Utilities.activateTabByTitle(sViewTabName, this.tabsViews);
        }

        [CodeDescription("Launch the Internet Explorer Control Panel Connections dialog.")]
        public void actLaunchIEProxy()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Tools.LaunchINETCPL");
            Utilities.RunExecutable("rundll32.exe", "shell32.dll,Control_RunDLL inetcpl.cpl,,4");
        }

        private void actLaunchTroubleshooter()
        {
            try
            {
                string sURL = "http://" + CONFIG.sFiddlerListenHostPort + "/troubleshooter.cgi";
                try
                {
                    Thread thread = new Thread(delegate {
                        try
                        {
                            HttpWebRequest request = (HttpWebRequest) WebRequest.Create("http://www.example.com/");
                            request.Headers.Add("X-ProxySetting", "Default");
                            request.KeepAlive = false;
                            request.GetResponse();
                        }
                        catch
                        {
                        }
                    });
                    thread.IsBackground = true;
                    thread.Start();
                    thread = new Thread(delegate {
                        try
                        {
                            HttpWebRequest request = (HttpWebRequest) WebRequest.Create("http://www.example.com/");
                            request.Proxy = new WebProxy("http://" + CONFIG.sFiddlerListenHostPort, false);
                            request.Headers.Add("X-ProxySetting", "Explicit");
                            request.KeepAlive = false;
                            request.GetResponse();
                        }
                        catch
                        {
                        }
                    });
                    thread.IsBackground = true;
                    thread.Start();
                }
                catch
                {
                }
                Utilities.LaunchHyperlink(sURL);
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        public void actLoadScripts()
        {
            this.UpdateLoadFromCbx();
            if (FiddlerApplication.scriptRules != null)
            {
                FiddlerApplication.scriptRules.LoadRulesScript();
            }
        }

        [CodeDescription("Load the specified .SAZ or .ZIP session archive")]
        public bool actLoadSessionArchive(string sFilename)
        {
            bool flag;
            FiddlerApplication.oTelemetry.TrackEvent("Actions.LoadSessionArchive");
            if (FiddlerApplication.oSAZProvider == null)
            {
                throw new NotSupportedException("This application was compiled without .SAZ support.");
            }
            sFilename = Utilities.EnsurePathIsAbsolute(CONFIG.GetPath("Captures"), sFilename);
            if (!System.IO.File.Exists(sFilename))
            {
                FiddlerApplication.Log.LogFormat("File Not Found attempting to load Session Archive {0}", new object[] { sFilename });
                return false;
            }
            string destFileName = null;
            string sourceFileName = null;
            if (FiddlerApplication.oSAZProvider.BufferLocally && sFilename.StartsWith(@"\\"))
            {
                try
                {
                    this.sbpInfo.Text = "Buffering .SAZ locally...";
                    Application.DoEvents();
                    sourceFileName = sFilename;
                    destFileName = Path.GetTempFileName();
                    System.IO.File.Copy(sourceFileName, destFileName, true);
                    sFilename = destFileName;
                }
                catch (Exception exception)
                {
                    FiddlerApplication.DoNotifyUser("Could not copy the SAZ File locally. " + Utilities.DescribeException(exception), "Operation Failed", MessageBoxIcon.Hand);
                    return false;
                }
            }
            try
            {
                this.sbpInfo.Text = "Reading archive...";
                Application.DoEvents();
                using (FileStream stream = System.IO.File.Open(sFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    if (((stream.Length < 0x40L) || (stream.ReadByte() != 80)) || (stream.ReadByte() != 0x4b))
                    {
                        string str3 = null;
                        if (!Path.GetExtension(sFilename).OICEndsWith(".saz"))
                        {
                            str3 = "\n\nIf you are attempting to import from another format, please choose File > Import Sessions...";
                        }
                        FiddlerApplication.DoNotifyUser(string.Format("The selected file is not a Fiddler-generated .SAZ archive of Web Sessions.{0}", str3), "Invalid Archive", MessageBoxIcon.Hand);
                        _DeleteFileIfFound(destFileName);
                        return false;
                    }
                }
                ISAZReader reader = FiddlerApplication.oSAZProvider.LoadSAZ(sFilename);
                string[] requestFileList = reader.GetRequestFileList();
                if (requestFileList.Length < 1)
                {
                    FiddlerApplication.DoNotifyUser("The selected file is not a Fiddler-generated .SAZ archive of Web Sessions.", "Invalid Archive", MessageBoxIcon.Hand);
                    reader.Close();
                    _DeleteFileIfFound(destFileName);
                    return false;
                }
                this.sbpInfo.Text = string.Format("Reading archive ({0} sessions)...", requestFileList.Length);
                this.lvSessions.BeginUpdate();
                Application.DoEvents();
                List<Session> list = new List<Session>();
                foreach (string str4 in requestFileList)
                {
                    try
                    {
                        byte[] buffer;
                        try
                        {
                            buffer = reader.GetFileBytes(str4);
                        }
                        catch (OperationCanceledException)
                        {
                            reader.Close();
                            _DeleteFileIfFound(destFileName);
                            this.sbpInfo.Text = "Aborted archive load.";
                            this.lvSessions.EndUpdate();
                            return false;
                        }
                        string str5 = str4.Replace("_c.txt", "_s.txt");
                        byte[] fileBytes = reader.GetFileBytes(str5);
                        string str6 = str4.Replace("_c.txt", "_m.xml");
                        Stream fileStream = reader.GetFileStream(str6);
                        Session item = this.AddReportedSession(buffer, fileBytes, fileStream, SessionFlags.LoadedFromSAZ);
                        list.Add(item);
                        if (item.isAnyFlagSet(SessionFlags.IsWebSocketTunnel) && !item.HTTPMethodIs("CONNECT"))
                        {
                            string str7 = str4.Replace("_c.txt", "_w.txt");
                            Stream strmWSMessages = reader.GetFileStream(str7);
                            if (strmWSMessages != null)
                            {
                                WebSocket.LoadWebSocketMessagesFromStream(item, strmWSMessages);
                            }
                            else
                            {
                                item.oFlags["X-WS-SAZ"] = "SAZ File did not contain any WebSocket messages.";
                            }
                        }
                    }
                    catch (Exception exception2)
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("Invalid data was present for session [{0}].\n\n{1}\n{2}", Utilities.TrimAfter(str4, "_"), Utilities.DescribeException(exception2), exception2.StackTrace), "Archive Incomplete", MessageBoxIcon.Hand);
                    }
                }
                string comment = reader.Comment;
                string str9 = null;
                if (!string.IsNullOrEmpty(reader.EncryptionMethod))
                {
                    str9 = string.Format("\tEncryption: {0} ({1}bit)\r\n", reader.EncryptionMethod, reader.EncryptionStrength);
                }
                reader.Close();
                string str10 = requestFileList.Length.ToString();
                if (sourceFileName != null)
                {
                    FiddlerApplication.Log.LogFormat("Loaded {0} Sessions from:\r\n\t{1}\r\n\tBuffered Locally as: {2}\r\n\t{3}\r\n{4}", new object[] { str10, sourceFileName, destFileName, comment, str9 });
                }
                else
                {
                    FiddlerApplication.Log.LogFormat("Loaded {0} Sessions from:\r\n\t{1}\r\n\t{2}\r\n{3}", new object[] { str10, sFilename, comment, str9 });
                }
                this.sbpInfo.Text = string.Format("Loaded {0} Sessions from {1}.", str10, sourceFileName ?? sFilename);
                FiddlerApplication.DoAfterLoadSAZ(sFilename, list.ToArray(), "WebSessionsList");
                flag = true;
            }
            catch (Exception exception3)
            {
                FiddlerApplication.DoNotifyUser(string.Concat(new object[] { "The Session Archive File could not be loaded. The file may be corrupt; try redownloading or recreating it.\n\n", exception3.Message, "\n", exception3.StackTrace, "\n\n", exception3.InnerException, "\n" }), "Corrupt Archive", MessageBoxIcon.Hand);
                this.sbpInfo.Text = "Failed to load archive.";
                flag = false;
            }
            this.lvSessions.EndUpdate();
            Application.DoEvents();
            _DeleteFileIfFound(destFileName);
            if (CONFIG.bIsViewOnly)
            {
                FiddlerToolbar.SetViewerTitle(Path.GetFileNameWithoutExtension(sourceFileName ?? sFilename), sourceFileName ?? sFilename);
            }
            if (flag)
            {
                string str12 = sourceFileName ?? sFilename;
                this.oSAZMRU.PushFile(str12);
                this._storeMRUFolders(str12);
            }
            return flag;
        }

        public void actMinimizeToTray()
        {
            this.notifyIcon.Visible = true;
            base.Visible = false;
        }

        public void actPasteAsSessions()
        {
            try
            {
                if (Clipboard.ContainsFileDropList())
                {
                    this.actPasteFilesFromClipboard();
                }
                else if (Clipboard.ContainsImage())
                {
                    this.actPasteImageFromClipboard();
                }
                else
                {
                    this.actPasteTextAsSessions();
                }
            }
            catch (Exception)
            {
            }
        }

        private void actPasteFilesFromClipboard()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Edit.PasteFilesAsSessions");
            string[] data = (string[]) Clipboard.GetData("FileDrop");
            if (data != null)
            {
                foreach (string str in data)
                {
                    if (Directory.Exists(str))
                    {
                        this.CreateSessionsForFolder(str);
                    }
                    else
                    {
                        this.CreateSessionsForFile(str, string.Empty);
                    }
                }
            }
        }

        private void actPasteImageFromClipboard()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Edit.PasteImageAsSession");
            try
            {
                Image image = Clipboard.GetImage();
                if (image == null)
                {
                    MessageBox.Show("The clipboard did not contain an image", "Nothing to do");
                }
                else
                {
                    HTTPRequestHeaders headers = new HTTPRequestHeaders();
                    headers.HTTPMethod = "GET";
                    headers.Add("Host", "localhost");
                    headers.RequestPath = string.Format("/clipboard/{0}.png", DateTime.Now.ToString("H-mm-ss"));
                    byte[] arrRequest = headers.ToByteArray(true, true, false);
                    byte[] bytes = Encoding.UTF8.GetBytes("HTTP/1.1 200 OK\r\nContent-Type: image/png\r\nCache-Control: max-age=0, must-revalidate\r\nConnection: close\r\n\r\n");
                    MemoryStream stream = new MemoryStream();
                    stream.Write(bytes, 0, bytes.Length);
                    image.Save(stream, ImageFormat.Png);
                    Session oSession = new Session(arrRequest, stream.ToArray(), SessionFlags.ServedFromCache | SessionFlags.ImportedFromOtherTool | SessionFlags.ResponseGeneratedByFiddler | SessionFlags.RequestGeneratedByFiddler);
                    oSession.state = SessionStates.Done;
                    this.finishSession(oSession);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Unable to store image.");
            }
        }

        private void actPasteTextAsSessions()
        {
            try
            {
                string text = Clipboard.GetText();
                if (string.IsNullOrEmpty(text))
                {
                    this.sbpInfo.Text = "The clipboard did not contain any data that could be converted to a Session.";
                }
                if (text.IndexOf("data:", 0, Math.Min(text.Length, 0x40)) > -1)
                {
                    FiddlerApplication.oTelemetry.TrackEvent("Menu.Edit.PasteDataUriAsSession");
                    this.actCreateSessionFromDataURI(text);
                }
                else if (text.IndexOf("curl", 0, Math.Min(text.Length, 0x40), StringComparison.OrdinalIgnoreCase) > -1)
                {
                    FiddlerApplication.oTelemetry.TrackEvent("Menu.Edit.PasteCurlCommandAsSession");
                    this.actCreateSessionFromCURLCommand(text);
                }
                else
                {
                    if (text.Trim().StartsWith("{"))
                    {
                        JSON.JSONParseErrors errors;
                        object obj2 = JSON.JsonDecode(text, out errors);
                        if (obj2 != null)
                        {
                            Hashtable hashtable = obj2 as Hashtable;
                            if ((null != hashtable) & hashtable.ContainsKey("log"))
                            {
                                FiddlerApplication.oTelemetry.TrackEvent("Menu.Edit.PasteHARAsSessions");
                                Dictionary<string, object> dictOptions = new Dictionary<string, object>();
                                dictOptions.Add("Content", text);
                                FiddlerApplication.DoImport("HTTPArchive", true, dictOptions, null);
                                return;
                            }
                        }
                    }
                    FiddlerApplication.oTelemetry.TrackEvent("Menu.Edit.PasteTextAsSessions");
                    this.actCreateSessionFromText(text);
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.DoNotifyUser(exception.Message, "Unable to interpret clipboard text as a Session");
            }
        }

        [CodeDescription("Passes sCommand into the QuickExec command-processing pipeline")]
        public bool actQuickExec(string sCommand)
        {
            if (string.IsNullOrEmpty(sCommand))
            {
                return false;
            }
            return this.txtExec_OnExecute(sCommand);
        }

        public void actRefreshInspectorsIfNeeded(Session oSession)
        {
            if (oSession == this.GetFirstSelectedSession())
            {
                this.actUpdateInspector(true, true);
            }
        }

        public void actRefreshUI()
        {
            this.actRefreshUI(false);
        }

        public void actRefreshUI(bool bBecauseItemIndexChanged)
        {
            if (!FiddlerApplication.isClosing)
            {
                int selectedCount = this.lvSessions.SelectedCount;
                this.actUpdateInspector(true, true);
                this.actReportStatistics();
                if (selectedCount == 1)
                {
                    Session firstSelectedSession = this.GetFirstSelectedSession();
                    if (firstSelectedSession == null)
                    {
                        this.sbpInfo.Text = string.Empty;
                    }
                    else if (SessionStates.ReadingResponse == firstSelectedSession.state)
                    {
                        if (firstSelectedSession.oResponse["Content-Length"].Length > 0)
                        {
                            long num2;
                            if (long.TryParse(firstSelectedSession.oResponse["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num2))
                            {
                                this.sbpInfo.Text = string.Format("Download Progress: {0:N0} of {1:N0} bytes. Hit F5 to refresh.", firstSelectedSession.oResponse._PeekDownloadProgress, num2);
                            }
                            else
                            {
                                this.sbpInfo.Text = "Reading server response...";
                            }
                        }
                        else
                        {
                            this.sbpInfo.Text = string.Format("Download Progress: {0:N0} bytes. Hit F5 to refresh.", firstSelectedSession.oResponse._PeekDownloadProgress);
                        }
                    }
                    else if (SessionStates.ReadingRequest == firstSelectedSession.state)
                    {
                        if (firstSelectedSession.oRequest["Content-Length"].Length > 0)
                        {
                            long num3;
                            if (long.TryParse(firstSelectedSession.oRequest["Content-Length"], NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out num3))
                            {
                                this.sbpInfo.Text = string.Format("Upload Progress: {0:N0} of {1:N0} bytes. Hit F5 to refresh.", firstSelectedSession.oRequest._PeekUploadProgress, num3);
                            }
                            else
                            {
                                this.sbpInfo.Text = "Reading client request...";
                            }
                        }
                        else
                        {
                            this.sbpInfo.Text = string.Format("Upload Progress: {0:N0} bytes. Hit F5 to refresh.", firstSelectedSession.oRequest._PeekUploadProgress);
                        }
                    }
                    else if (firstSelectedSession.isAnyFlagSet(SessionFlags.IsWebSocketTunnel | SessionFlags.IsBlindTunnel))
                    {
                        string str = string.Format(" Raw Bytes Out: {0:N0}; In: {1:N0}", firstSelectedSession.TunnelEgressByteCount, firstSelectedSession.TunnelIngressByteCount);
                        this.sbpInfo.Text = string.Format("This {0} a {1} tunnel to '{2}:{3}'.{4}", new object[] { firstSelectedSession.TunnelIsOpen ? "is" : "was", firstSelectedSession.isFlagSet(SessionFlags.IsWebSocketTunnel) ? "WebSocket" : "CONNECT", firstSelectedSession.hostname, firstSelectedSession.port, str });
                    }
                    else if (firstSelectedSession.isFlagSet(SessionFlags.IsDecryptingTunnel))
                    {
                        this.sbpInfo.Text = string.Format("This is a HTTPS Decrypting tunnel to '{0}:{1}'.", firstSelectedSession.hostname, firstSelectedSession.port);
                    }
                    else
                    {
                        this.sbpInfo.Text = firstSelectedSession.fullUrl;
                    }
                }
                else
                {
                    this.sbpInfo.Text = string.Empty;
                }
            }
        }

        private void actReissueAndVerify()
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                foreach (Session session in selectedSessions)
                {
                    if (session.state > SessionStates.ReadingResponse)
                    {
                        Session oOriginal = session;
                        Session oNew = FiddlerApplication.oProxy.SendRequest(oOriginal.oRequest.headers, oOriginal.requestBodyBytes, null);
                        oNew.OnStateChanged += delegate (object o, StateChangeEventArgs scEA) {
                            if (scEA.newState >= SessionStates.Done)
                            {
                                _CompareAndTagResponses(oOriginal, oNew);
                            }
                        };
                    }
                }
            }
        }

        [CodeDescription("Reissue the selected requests, optionally breaking on each request. If SHIFT key is held down, user will be prompted for repeat count")]
        public void actReissueSelected(bool bBreakOnRequest)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.ReissueSelected");
            this.actReissueSessions(this.GetSelectedSessions(), bBreakOnRequest);
        }

        private void actReissueSequentially()
        {
            ThreadStart start = null;
            Session[] oSessions = this.GetSelectedSessions();
            if (oSessions.Length >= 1)
            {
                Thread thread;
                if (oSessions.Length == 1)
                {
                    <>c__DisplayClass3d classd;
                    <>c__DisplayClass3d CS$<>8__locals3e = classd;
                    int iCount = 0;
                    string s = frmPrompt.GetUserString("Repeat Count", "Reissue this Request (sequentially) how many times?", "5", true, frmPrompt.PromptIcon.Numbers);
                    if (s == null)
                    {
                        return;
                    }
                    if (!int.TryParse(s, out iCount))
                    {
                        return;
                    }
                    thread = new Thread(delegate {
                        EventHandler<EventArgs> handler = null;
                        <>c__DisplayClass3d classd1 = CS$<>8__locals3e;
                        ManualResetEvent oMRE = new ManualResetEvent(false);
                        Session session = CS$<>8__locals3e.oSessions[0];
                        StringDictionary oNewFlags = CS$<>8__locals3e.<>4__this._GetFlagsForReissue();
                        for (int j = 0; i < iCount; i++)
                        {
                            oMRE.Reset();
                            if (handler == null)
                            {
                                handler = delegate (object o, EventArgs scEA) {
                                    oMRE.Set();
                                };
                            }
                            FiddlerApplication.oProxy.SendRequest(session.oRequest.headers, session.requestBodyBytes, oNewFlags).OnCompleteTransaction += handler;
                            oMRE.WaitOne();
                        }
                    });
                }
                else
                {
                    if (start == null)
                    {
                        start = delegate {
                            EventHandler<EventArgs> handler = null;
                            ManualResetEvent oMRE = new ManualResetEvent(false);
                            foreach (Session session in oSessions)
                            {
                                oMRE.Reset();
                                StringDictionary oNewFlags = this._GetFlagsForReissue();
                                if (handler == null)
                                {
                                    handler = delegate (object o, EventArgs scEA) {
                                        oMRE.Set();
                                    };
                                }
                                FiddlerApplication.oProxy.SendRequest(session.oRequest.headers, session.requestBodyBytes, oNewFlags).OnCompleteTransaction += handler;
                                oMRE.WaitOne();
                            }
                        };
                    }
                    thread = new Thread(start);
                }
                thread.IsBackground = true;
                thread.Start();
            }
        }

        public void actReissueSessions(Session[] oSessions, bool bBreakOnRequest)
        {
            if (oSessions.Length >= 1)
            {
                int result = 1;
                if (Keys.Shift == (Control.ModifierKeys & Keys.Shift))
                {
                    string s = frmPrompt.GetUserString("Repeat Count", "Repeat this request how many times?", "5", true, frmPrompt.PromptIcon.Numbers);
                    if (s == null)
                    {
                        return;
                    }
                    if (!int.TryParse(s, out result))
                    {
                        return;
                    }
                }
                StringDictionary oNewFlags = this._GetFlagsForReissue();
                if (bBreakOnRequest)
                {
                    oNewFlags.Add("x-breakrequest", "ReissueAndBreak");
                    oNewFlags.Add("x-Builder-Inspect", "1");
                }
                for (int i = 0; i < result; i++)
                {
                    for (int j = 0; j < oSessions.Length; j++)
                    {
                        if ((oSessions[j].oRequest != null) && (oSessions[j].oRequest.headers != null))
                        {
                            FiddlerApplication.oProxy.SendRequest(oSessions[j].oRequest.headers, oSessions[j].requestBodyBytes, oNewFlags);
                        }
                    }
                }
            }
        }

        public void actReloadInspectors()
        {
            FiddlerApplication.oInspectors.Dispose();
            FiddlerApplication.oInspectors = new Inspectors(this.tabsRequest, this.tabsResponse, this);
        }

        public void actRemoveAllSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.Clear");
            if (CONFIG.bResetCounterOnClear)
            {
                Session.ResetSessionCounter();
            }
            this.lvSessions.BeginUpdate();
            FiddlerApplication.SuppressReportUpdates = true;
            this.WeakStoreWebSessionsBeforeDelete(this.lvSessions.Items);
            this.lvSessions.Items.Clear();
            this.sbpInfo.Text = string.Empty;
            this.lvSessions.EndUpdate();
            FiddlerApplication.SuppressReportUpdates = false;
            this.actUpdateInspector(true, true);
            FiddlerApplication.oProxy.PurgeServerPipePool();
            UINotifyList.CloseWindow();
            Utilities.CompactLOHIfPossible();
        }

        public void actRemoveRange(IEnumerable<Session> listSessions)
        {
            this.lvSessions.BeginUpdate();
            FiddlerApplication.SuppressReportUpdates = true;
            List<int> listLVIs = new List<int>();
            foreach (Session session in listSessions)
            {
                ListViewItem viewItem = session.ViewItem;
                if (viewItem != null)
                {
                    listLVIs.Add(viewItem.Index);
                }
            }
            this.lvSessions.RemoveRange(listLVIs);
            this.sbpInfo.Text = string.Empty;
            this.lvSessions.EndUpdate();
            FiddlerApplication.SuppressReportUpdates = false;
        }

        [CodeDescription("Remove all selected sessions.")]
        public void actRemoveSelectedSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.ClearSelected");
            int selectedCount = this.lvSessions.SelectedCount;
            if (selectedCount >= 1)
            {
                if (selectedCount == this.lvSessions.Items.Count)
                {
                    this.actRemoveAllSessions();
                }
                else
                {
                    this.WeakStoreWebSessionsBeforeDelete(this.lvSessions.SelectedItems);
                    this.lvSessions.UnstoreActiveItem();
                    this.lvSessions.BeginUpdate();
                    FiddlerApplication.SuppressReportUpdates = true;
                    this.lvSessions.RemoveSelected();
                    if (this.lvSessions.FocusedItem != null)
                    {
                        this.lvSessions.FocusedItem.Selected = true;
                    }
                    else
                    {
                        this.sbpInfo.Text = string.Empty;
                    }
                    this.lvSessions.EndUpdate();
                    FiddlerApplication.SuppressReportUpdates = false;
                    this.actUpdateInspector(true, true);
                }
            }
        }

        internal int actRemoveSessionsMatchingCriteria(doesSessionMatchCriteriaDelegate oDel)
        {
            FiddlerApplication.SuppressReportUpdates = true;
            this.lvSessions.BeginUpdate();
            List<int> listLVIs = new List<int>();
            foreach (ListViewItem item in this.lvSessions.Items)
            {
                Session tag = (Session) item.Tag;
                if ((tag != null) && oDel(tag))
                {
                    listLVIs.Add(item.Index);
                }
            }
            this.lvSessions.RemoveRange(listLVIs);
            if (this.lvSessions.FocusedItem != null)
            {
                this.lvSessions.FocusedItem.Selected = true;
            }
            else
            {
                this.sbpInfo.Text = string.Empty;
            }
            this.lvSessions.EndUpdate();
            FiddlerApplication.SuppressReportUpdates = false;
            this.actUpdateInspector(true, true);
            return listLVIs.Count;
        }

        [CodeDescription("Remove Sessions which are not selected")]
        public void actRemoveUnselectedSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.ClearUnselected");
            this.lvSessions.BeginUpdate();
            FiddlerApplication.SuppressReportUpdates = true;
            this.WeakStoreWebSessionsBeforeDelete(this.lvSessions.UnselectedItems);
            this.lvSessions.RemoveUnselected();
            this.lvSessions.EndUpdate();
            FiddlerApplication.SuppressReportUpdates = false;
            this.actUpdateInspector(true, true);
        }

        public void actReportStatistics()
        {
            this.actReportStatistics(false);
        }

        public void actReportStatistics(bool bImmediate)
        {
            this.UpdateStatusBar(false);
            if (!FiddlerApplication.SuppressReportUpdates)
            {
                if (bImmediate)
                {
                    this.actUpdateReport();
                }
                else if (!oReportingQueueTimer.Enabled)
                {
                    oReportingQueueTimer.Start();
                }
            }
        }

        public void actRestoreWindow()
        {
            if (Utilities.IsIconic(base.Handle))
            {
                Utilities.ShowWindowAsync(base.Handle, 9);
            }
            if (!CONFIG.bAlwaysShowTrayIcon)
            {
                this.notifyIcon.Visible = false;
            }
            base.Visible = true;
            Utilities.SetForegroundWindow(base.Handle);
        }

        [CodeDescription("Immediately resume all paused sessions.")]
        public void actResumeAllSessions()
        {
            Session[] allSessions = this.GetAllSessions();
            this._ResumeSessions(allSessions);
        }

        [CodeDescription("Immediately resume all selected sessions.")]
        public void actResumeSelectedSessions()
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            this._ResumeSessions(selectedSessions);
        }

        internal void actSaveAllSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveAllSessions");
            this.actSaveSessionArchive(this, this.GetAllSessions(), null);
        }

        private void actSaveAndOpenResponseBodies()
        {
            bool flag = Control.ModifierKeys == Keys.Control;
            if (flag)
            {
                Application.DoEvents();
            }
            bool flag2 = false;
            foreach (Session session in this.GetSelectedSessions())
            {
                if (!Utilities.IsNullOrEmpty(session.responseBodyBytes))
                {
                    try
                    {
                        string sFilename = Utilities.EnsureUniqueFilename(string.Format(@"{0}\{1}", Environment.GetFolderPath(Environment.SpecialFolder.Desktop), session.SuggestedFilename));
                        session.utilDecodeResponse();
                        session.SaveResponseBody(sFilename);
                        flag2 = true;
                        if (flag)
                        {
                            Utilities.DoOpenFileWith(sFilename);
                        }
                        else
                        {
                            using (Process.Start(sFilename))
                            {
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.ReportException(exception, "Unable to open response", "Attempting to open the response body resulted in an error.");
                    }
                }
            }
            if (!flag2)
            {
                FiddlerApplication.DoNotifyUser("None of the selected sessions contained a response body.", "Nothing to do");
            }
        }

        [CodeDescription("Launch the Save Headers to Single File feature")]
        public void actSaveHeaders()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveHeaders");
            if (this.lvSessions.SelectedCount >= 1)
            {
                this.dlgSaveBinary.Title = "Save headers to one text file";
                this.dlgSaveBinary.FileName = this.GetFirstSelectedSession().id.ToString() + "_Headers.txt";
                if (DialogResult.OK == this.dlgSaveBinary.ShowDialog(this))
                {
                    this.actSaveSessions(this.dlgSaveBinary.FileName, true);
                }
            }
        }

        [CodeDescription("Launch the Save Selected Requests feature.")]
        public void actSaveRequests()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveRequests");
            this.dlgSaveBinary.Title = "Save requests to...";
            foreach (Session session in this.GetSelectedSessions())
            {
                this.dlgSaveBinary.FileName = session.id.ToString() + "_Request.txt";
                if (DialogResult.OK != this.dlgSaveBinary.ShowDialog(this))
                {
                    break;
                }
                session.SaveRequest(this.dlgSaveBinary.FileName, false, true);
            }
        }

        [CodeDescription("Launch the Save Selected Responses feature.")]
        public void actSaveResponses()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveResponses");
            this.dlgSaveBinary.Title = "Save responses to...";
            foreach (Session session in this.GetSelectedSessions())
            {
                this.dlgSaveBinary.FileName = session.id.ToString() + "_Response.txt";
                if (DialogResult.OK != this.dlgSaveBinary.ShowDialog(this))
                {
                    break;
                }
                session.SaveResponse(this.dlgSaveBinary.FileName, false);
            }
            this.UpdateLoadFromCbx();
        }

        private void actSaveSessionArchive(string sFilename, string sPassword, Session[] arrSessions)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveSessionArchive");
            if (FiddlerApplication.DoBeforeSaveSAZ(sFilename, arrSessions))
            {
                if (FiddlerApplication.oSAZProvider == null)
                {
                    throw new NotSupportedException("This application was compiled without .SAZ support.");
                }
                try
                {
                    if (System.IO.File.Exists(sFilename))
                    {
                        System.IO.File.Delete(sFilename);
                    }
                    this.sbpInfo.Text = "Archiving...";
                    Application.DoEvents();
                    ISAZWriter oISW = FiddlerApplication.oSAZProvider.CreateSAZ(sFilename);
                    string encryptionMethod = string.Empty;
                    string encryptionStrength = string.Empty;
                    if (!string.IsNullOrEmpty(sPassword))
                    {
                        FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveSessionEncrypted");
                        oISW.SetPassword(sPassword);
                        encryptionMethod = oISW.EncryptionMethod;
                        encryptionStrength = oISW.EncryptionStrength;
                    }
                    oISW.Comment = "Fiddler (v" + Application.ProductVersion + ") Session Archive. See http://fiddler2.com";
                    StringBuilder sbHTML = new StringBuilder(0x200);
                    sbHTML.Append("<html><head><style>body,thead,td,a,p{font-family:verdana,sans-serif;font-size: 10px;}</style></head><body><table cols=" + ((this.lvSessions.Columns.Count + 1)).ToString() + "><thead><tr>");
                    sbHTML.Append("<th>&nbsp;</th>");
                    foreach (ColumnHeader header in this.lvSessions.Columns)
                    {
                        sbHTML.AppendFormat("<th>{0}</th>", Utilities.HtmlEncode(header.Text));
                    }
                    sbHTML.Append("</tr></thead><tbody>");
                    int iFileNumber = 1;
                    int length = arrSessions.Length;
                    string sFileNumberFormat = "D" + length.ToString().Length;
                    int num2 = arrSessions.Length;
                    foreach (Session session in arrSessions)
                    {
                        this.sbpInfo.Text = string.Format("Collecting data... {0:f0}% (ID:{1})", Math.Floor((double) ((100f * iFileNumber) / ((float) num2))), session.id);
                        Application.DoEvents();
                        try
                        {
                            Utilities.WriteSessionToSAZ(session, oISW, iFileNumber, sFileNumberFormat, sbHTML, true);
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.ReportException(exception, "Warning: Failed to add Session");
                        }
                        iFileNumber++;
                    }
                    sbHTML.Append("</tbody></table></body></html>");
                    oISW.AddFile(@"\_index.htm", delegate (Stream oS) {
                        using (StreamWriter writer = new StreamWriter(oS, Encoding.UTF8))
                        {
                            writer.Write(sbHTML.ToString());
                        }
                    });
                    this.sbpInfo.Text = "Finalizing archive...";
                    Application.DoEvents();
                    try
                    {
                        oISW.CompleteArchive();
                    }
                    catch (Exception exception2)
                    {
                        FiddlerApplication.ReportException(exception2, "SAZ Creation Error");
                    }
                    this.sbpInfo.Text = string.Format("Saved {0} Session{1} to Archive: {2}", arrSessions.Length, (arrSessions.Length > 1) ? "s" : string.Empty, sFilename);
                    try
                    {
                        object[] args = new object[] { sFilename, (new FileInfo(sFilename).Length / 0x400L).ToString("N0"), (iFileNumber - 1).ToString("N0"), string.IsNullOrEmpty(sPassword) ? string.Empty : string.Format("\tEncryption: {0} ({1}bit)\n", encryptionMethod, encryptionStrength) };
                        string sMsg = string.Format("Sessions archived to:\n\tFilename: {0}\n\tFile size: {1}kb\n\tSession count: {2}\n{3}", args);
                        FiddlerApplication.Log.LogString(sMsg);
                        this.oSAZMRU.PushFile(sFilename);
                    }
                    catch (Exception exception3)
                    {
                        FiddlerApplication.ReportException(exception3);
                    }
                    Application.DoEvents();
                }
                catch (Exception exception4)
                {
                    FiddlerApplication.DoNotifyUser("Failed to save Session Archive.\n\n" + exception4.Message, "Save Failed");
                }
            }
        }

        public bool actSaveSessionArchive(IWin32Window wndOwner, Session[] arrSessions, string sSuggestedFilename)
        {
            if (FiddlerApplication.oSAZProvider == null)
            {
                throw new NotSupportedException("This application was compiled without .SAZ support.");
            }
            bool supportsEncryption = FiddlerApplication.oSAZProvider.SupportsEncryption;
            if (!supportsEncryption)
            {
                this.dlgSaveZip.Filter = this.dlgSaveZip.Filter.Replace("|Password-Protected SAZ (*.saz)|*.saz", string.Empty);
            }
            else if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.PrivacyNoticeShown", false))
            {
                FiddlerApplication.Prefs.SetBoolPref("fiddler.saz.PrivacyNoticeShown", true);
                FiddlerApplication.DoNotifyUser(FiddlerApplication.UI, "Session Archive files may contain passwords or other private information, and should only be shared with people you trust.\n\nTo encrypt the file before transfer or storage: On the next screen, set the Save As Type dropdown to 'Password-Protected SAZ'.", "Privacy Notice", MessageBoxIcon.Exclamation);
            }
            if (!string.IsNullOrEmpty(sSuggestedFilename))
            {
                this.dlgSaveZip.FileName = sSuggestedFilename;
            }
            if (DialogResult.OK != this.dlgSaveZip.ShowDialog(wndOwner))
            {
                return false;
            }
            string fileName = this.dlgSaveZip.FileName;
            try
            {
                this._storeMRUFolders(fileName);
                this.dlgSaveZip.FileName = Path.GetFileName(fileName);
            }
            catch
            {
            }
            if (supportsEncryption && ((this.dlgSaveZip.FilterIndex == 2) || (this.dlgSaveZip.FileName.StartsWith("_") && FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.UnderscoreMeansEncrypt", false))))
            {
                string sTitle = !CONFIG.bUseAESForSAZ ? "Password-Protect SAZ (Weak Encryption)" : (FiddlerApplication.Prefs.GetBoolPref("fiddler.saz.AES.Use256Bit", false) ? "Password-Protect SAZ (256-bit AES)" : "Password-Protect SAZ (128-bit AES)");
                string sPassword = frmPrompt.GetUserString(wndOwner, sTitle, "Enter a password to encrypt this Session Archive. Leave blank for no password.", string.Empty, true, frmPrompt.PromptIcon.Password);
                if (sPassword == null)
                {
                    return false;
                }
                if (sPassword.Length > 0)
                {
                    this.actSaveSessionArchive(fileName, sPassword, arrSessions);
                    return true;
                }
            }
            this.actSaveSessionArchive(fileName, null, arrSessions);
            return true;
        }

        [CodeDescription("Save Selected Request Bodies to Files feature.")]
        public void actSaveSessionRequestBody()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveRequestBody");
            this.dlgSaveBinary.Title = "Save request bodies to...";
            foreach (Session session in this.GetSelectedSessions())
            {
                if (!Utilities.IsNullOrEmpty(session.requestBodyBytes))
                {
                    if (DialogResult.OK != this.dlgSaveBinary.ShowDialog(this))
                    {
                        break;
                    }
                    session.SaveRequestBody(this.dlgSaveBinary.FileName);
                }
                else
                {
                    FiddlerApplication.DoNotifyUser("There is no request body to save.", "Error");
                }
            }
        }

        [CodeDescription("Save Selected Response Bodies to Files feature.")]
        public void actSaveSessionResponseBody()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveResponseBody");
            this.dlgSaveBinary.Title = "Save response bodies to...";
            foreach (Session session in this.GetSelectedSessions())
            {
                if (!Utilities.IsNullOrEmpty(session.responseBodyBytes))
                {
                    this.dlgSaveBinary.FileName = session.SuggestedFilename;
                    if (DialogResult.OK != this.dlgSaveBinary.ShowDialog(this))
                    {
                        break;
                    }
                    session.SaveResponseBody(this.dlgSaveBinary.FileName);
                }
                else
                {
                    FiddlerApplication.DoNotifyUser("There is no response body to save for Session #" + session.id.ToString() + ".", "No response body");
                }
            }
        }

        [CodeDescription("Launch the Save Selected Sessions to Single File feature.")]
        public void actSaveSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveSessions");
            if (this.lvSessions.SelectedCount >= 1)
            {
                this.dlgSaveBinary.Title = "Save sessions as one text file";
                this.dlgSaveBinary.FileName = this.GetFirstSelectedSession().id.ToString() + "_Full.txt";
                if (DialogResult.OK == this.dlgSaveBinary.ShowDialog(this))
                {
                    this.actSaveSessions(this.dlgSaveBinary.FileName, false);
                }
            }
        }

        [CodeDescription("Save Selected Sessions to single file")]
        public void actSaveSessions(string sFilename, bool bHeadersOnly)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.SaveSessions");
            byte[] bytes = Encoding.ASCII.GetBytes("\r\n\r\n------------------------------------------------------------------\r\n\r\n");
            using (FileStream stream = new FileStream(sFilename, FileMode.Create, FileAccess.Write))
            {
                Session[] selectedSessions = this.GetSelectedSessions();
                foreach (Session session in selectedSessions)
                {
                    session.WriteToStream(stream, bHeadersOnly);
                    if (selectedSessions.Length > 1)
                    {
                        stream.Write(bytes, 0, bytes.Length);
                    }
                }
            }
        }

        [CodeDescription("Launch the Save Selected Sessions to ZipArchive feature.")]
        public void actSaveSessionsToZip()
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length < 1)
            {
                FiddlerApplication.DoNotifyUser("Please select sessions in the Session List first", "Cannot Save SAZ");
            }
            else
            {
                this.actSaveSessionArchive(this, selectedSessions, null);
            }
        }

        [CodeDescription("Save Selected sessions to ZipArchive named by sFilename.")]
        public void actSaveSessionsToZip(string sFilename)
        {
            this.actSaveSessionsToZip(sFilename, null);
        }

        [CodeDescription("Save Selected sessions to ZipArchive named by sFilename, protected by password sPassword.")]
        public void actSaveSessionsToZip(string sFilename, string sPassword)
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length < 1)
            {
                FiddlerApplication.DoNotifyUser("Please select sessions in the Session List first", "Cannot Save SAZ");
            }
            else
            {
                this.actSaveSessionArchive(sFilename, sPassword, selectedSessions);
            }
        }

        [CodeDescription("Select all sessions in the Web Sessions List")]
        public void actSelectAll()
        {
            this.lvSessions.BeginUpdate();
            FiddlerApplication.SuppressReportUpdates = true;
            foreach (ListViewItem item in this.lvSessions.Items)
            {
                item.Selected = true;
            }
            FiddlerApplication.SuppressReportUpdates = false;
            this.lvSessions.EndUpdate();
        }

        private static string actSelectImportExportFormat(bool bIsImport, string[] arrFormats)
        {
            string sValue = null;
            Form frmPickType = new Form();
            Utilities.AdjustFontSize(frmPickType, CONFIG.flFontSize);
            frmPickType.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            frmPickType.Size = new Size(400, 0xa5);
            frmPickType.MinimumSize = new Size(0x109, 150);
            frmPickType.Text = bIsImport ? "Select Import Format" : "Select Export Format";
            ComboBox oCbx = new ComboBox();
            Utilities.AdjustFontSize(oCbx, CONFIG.flFontSize);
            oCbx.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            oCbx.DropDownStyle = ComboBoxStyle.DropDownList;
            oCbx.Items.AddRange(arrFormats);
            oCbx.Width = 0x177;
            frmPickType.Controls.Add(oCbx);
            oCbx.Location = new Point(5, 5);
            Button button = new Button();
            button.AutoSize = true;
            button.Text = "&Next";
            frmPickType.Controls.Add(button);
            button.Left = (frmPickType.ClientSize.Width - button.Width) - 10;
            button.Top = (frmPickType.ClientSize.Height - button.Height) - 10;
            button.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            frmPickType.AcceptButton = button;
            button.Click += delegate (object s2, EventArgs ea2) {
                frmPickType.DialogResult = DialogResult.OK;
            };
            Button button2 = new Button();
            button2.AutoSize = true;
            button2.Text = "Cancel";
            frmPickType.Controls.Add(button2);
            button2.Left = 10;
            button2.Top = (frmPickType.ClientSize.Height - button2.Height) - 10;
            button2.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            TextBox txtDescription = new TextBox();
            frmPickType.Controls.Add(txtDescription);
            txtDescription.BorderStyle = BorderStyle.None;
            txtDescription.ReadOnly = true;
            txtDescription.BackColor = frmPickType.BackColor;
            txtDescription.WordWrap = true;
            txtDescription.Multiline = true;
            txtDescription.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            txtDescription.Location = new Point(5, 0x23);
            txtDescription.Size = new Size(0x177, 50);
            oCbx.SelectedIndexChanged += delegate (object sender, EventArgs oEA) {
                TranscoderTuple tuple;
                if (bIsImport)
                {
                    if (FiddlerApplication.oTranscoders.m_Importers.TryGetValue(oCbx.SelectedItem.ToString(), out tuple))
                    {
                        txtDescription.Text = tuple.sFormatDescription;
                    }
                }
                else if (FiddlerApplication.oTranscoders.m_Exporters.TryGetValue(oCbx.SelectedItem.ToString(), out tuple))
                {
                    txtDescription.Text = tuple.sFormatDescription;
                }
            };
            string stringPref = FiddlerApplication.Prefs.GetStringPref(bIsImport ? "fiddler.importexport.LastImportFormat" : "fiddler.importexport.LastExportFormat", string.Empty);
            int num = 0;
            if (!string.IsNullOrEmpty(stringPref))
            {
                num = oCbx.FindStringExact(stringPref);
                if (num < 0)
                {
                    num = 0;
                }
            }
            oCbx.SelectedIndex = num;
            frmPickType.KeyPreview = true;
            frmPickType.KeyUp += delegate (object s, KeyEventArgs k) {
                if (k.KeyCode == Keys.Escape)
                {
                    k.Handled = true;
                    k.SuppressKeyPress = true;
                    frmPickType.DialogResult = DialogResult.Cancel;
                }
            };
            button2.Click += delegate (object s2, EventArgs ea2) {
                frmPickType.DialogResult = DialogResult.Cancel;
            };
            frmPickType.StartPosition = FormStartPosition.CenterParent;
            if (DialogResult.OK == frmPickType.ShowDialog(FiddlerApplication.UI))
            {
                sValue = oCbx.SelectedItem.ToString();
                FiddlerApplication.Prefs.SetStringPref(bIsImport ? "fiddler.importexport.LastImportFormat" : "fiddler.importexport.LastExportFormat", sValue);
            }
            frmPickType.Dispose();
            return sValue;
        }

        private void actSelectMarkedSessions(string sColor)
        {
            doesSessionMatchCriteriaDelegate delegate2;
            doesSessionMatchCriteriaDelegate delegate3 = null;
            if (sColor == null)
            {
                delegate2 = delegate (Session oS) {
                    return !oS.oFlags.ContainsKey("UI-BOLD") && !oS.oFlags.ContainsKey("UI-COLOR");
                };
            }
            else if (sColor == "Strikeout")
            {
                delegate2 = delegate (Session oS) {
                    return oS.oFlags.ContainsKey("ui-Strikeout");
                };
            }
            else
            {
                if (delegate3 == null)
                {
                    delegate3 = delegate (Session oS) {
                        return oS.oFlags.ContainsKey("UI-BOLD") && (oS.oFlags["UI-COLOR"] == sColor);
                    };
                }
                delegate2 = delegate3;
            }
            this.actSelectSessionsMatchingCriteria(delegate2);
            this.SetStatusText(string.Format("Selected sessions marked in {0}", sColor));
        }

        [CodeDescription("Select Sessions for which the provided matching function returns boolean True")]
        public void actSelectSessionsMatchingCriteria(doesSessionMatchCriteriaDelegate oDel)
        {
            this.actSelectSessionsMatchingCriteria(0, oDel);
        }

        [CodeDescription("Select up to iSelAtMost Sessions for which the provided matching function returns boolean True")]
        public void actSelectSessionsMatchingCriteria(int iSelAtMost, doesSessionMatchCriteriaDelegate oDel)
        {
            this.actSelectSessionsMatchingCriteria(true, iSelAtMost, oDel);
        }

        internal void actSelectSessionsMatchingCriteria(bool bClearFirst, int iSelAtMost, doesSessionMatchCriteriaDelegate oDel)
        {
            int num = 0;
            FiddlerApplication.SuppressReportUpdates = true;
            this.lvSessions.BeginUpdate();
            if (bClearFirst)
            {
                this.lvSessions.SelectedItems.Clear();
            }
            foreach (ListViewItem item in this.lvSessions.Items)
            {
                Session tag = (Session) item.Tag;
                if (tag != null)
                {
                    if (oDel(tag))
                    {
                        item.Selected = true;
                        if ((iSelAtMost <= 0) || (++num < iSelAtMost))
                        {
                            continue;
                        }
                        break;
                    }
                    if (!bClearFirst)
                    {
                        item.Selected = false;
                    }
                }
            }
            this.sbpInfo.Text = string.Empty;
            this.lvSessions.EndUpdate();
            FiddlerApplication.SuppressReportUpdates = false;
            this.actUpdateInspector(true, true);
        }

        [CodeDescription("Select Sessions with Request[sHeader] value of containing sPartialValue")]
        public void actSelectSessionsWithRequestHeaderValue(string sHeader, string sPartialValue)
        {
            this.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                return ((oS.oRequest != null) && (oS.oRequest.headers != null)) && oS.oRequest.headers.ExistsAndContains(sHeader, sPartialValue);
            });
        }

        [CodeDescription("Select Sessions with responseCode == iStatus")]
        public void actSelectSessionsWithResponseCode(uint iStatus)
        {
            this.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                return oS.responseCode == iStatus;
            });
        }

        [CodeDescription("Select Sessions with Response[sHeader] containing sPartialValue")]
        public void actSelectSessionsWithResponseHeaderValue(string sHeader, string sPartialValue)
        {
            this.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                return ((oS.oResponse != null) && (oS.oResponse.headers != null)) && oS.oResponse.headers.ExistsAndContains(sHeader, sPartialValue);
            });
        }

        [CodeDescription("Select Sessions with a response body of at (least/most) iSize bytes")]
        public void actSelectSessionsWithResponseSize(bool bGreater, long iSize)
        {
            this.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                if ((oS.responseBodyBytes == null) || ((!bGreater || (iSize >= oS.responseBodyBytes.LongLength)) && (bGreater || (iSize <= oS.responseBodyBytes.LongLength))))
                {
                    return false;
                }
                return true;
            });
        }

        public void actSessionCopy()
        {
            this.CopySessions(false);
        }

        public void actSessionCopyHeaders()
        {
            this.CopySessions(true);
        }

        [CodeDescription("Copies the terse summary of currently selected sessions to the clipboard.")]
        public void actSessionCopyHeadlines()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.Copy.TerseSummary");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                StringBuilder builder = new StringBuilder(0x200);
                foreach (Session session in selectedSessions)
                {
                    builder.AppendFormat("{0} {1}\r\n", session.RequestMethod, session.fullUrl);
                    if ((session.oResponse != null) && (session.oResponse.headers != null))
                    {
                        if (Utilities.IsRedirectStatus(session.responseCode))
                        {
                            builder.AppendFormat("{0} Redirect to {1}\r\n", session.oResponse.headers.HTTPResponseCode, session.oResponse["Location"]);
                        }
                        else
                        {
                            builder.AppendFormat("{0} ({1})\r\n", session.oResponse.headers.HTTPResponseStatus, session.oResponse.MIMEType);
                        }
                    }
                    else
                    {
                        builder.Append("No response\r\n");
                    }
                    if (selectedSessions.Length > 1)
                    {
                        builder.Append("\r\n");
                    }
                }
                Utilities.CopyToClipboard(builder.ToString());
            }
        }

        [CodeDescription("Copies summary of the currently selected sessions to the clipboard.")]
        public void actSessionCopySummary()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.Copy.AllColumns");
            ListView.SelectedListViewItemCollection selectedItems = this.lvSessions.SelectedItems;
            if (selectedItems.Count >= 1)
            {
                StringBuilder data = new StringBuilder(0x200);
                StringBuilder builder2 = new StringBuilder(0x200);
                builder2.Append("<table><tr>");
                foreach (ColumnHeader header in this.lvSessions.Columns)
                {
                    data.Append(header.Text);
                    data.Append("\t");
                    builder2.AppendFormat("<th>{0}</th>", Utilities.HtmlEncode(header.Text));
                }
                data.Append("\r\n");
                builder2.Append("</tr><tr>");
                foreach (ListViewItem item in selectedItems)
                {
                    foreach (ListViewItem.ListViewSubItem item2 in item.SubItems)
                    {
                        data.Append(item2.Text);
                        data.Append("\t");
                        builder2.AppendFormat("<td>{0}</td>", Utilities.HtmlEncode(item2.Text));
                    }
                    data.Append("\r\n");
                    builder2.Append("</tr>");
                }
                DataObject oData = new DataObject("HTML Format", Utilities.StringToCF_HTML(builder2.ToString()));
                oData.SetData(DataFormats.Text, data);
                Utilities.CopyToClipboard(oData);
            }
        }

        [CodeDescription("Copies the URLs of currently selected sessions to the clipboard.")]
        public void actSessionCopyURL()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.Copy.URLs");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                if (1 == selectedSessions.Length)
                {
                    Utilities.CopyToClipboard(selectedSessions[0].fullUrl);
                }
                else
                {
                    StringBuilder builder = new StringBuilder(0x200);
                    foreach (Session session in selectedSessions)
                    {
                        if (Utilities.HasHeaders(session.oRequest))
                        {
                            builder.AppendFormat("{0}\r\n", session.fullUrl);
                        }
                    }
                    Utilities.CopyToClipboard(builder.ToString());
                }
            }
        }

        public void actSessionMark(System.Drawing.Color c)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.Mark");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length > 0)
            {
                this.actSessionMark(c, selectedSessions);
            }
        }

        public void actSessionMark(System.Drawing.Color c, Session[] oSessions)
        {
            this.lvSessions.BeginUpdate();
            foreach (Session session in oSessions)
            {
                if (session.ViewItem != null)
                {
                    ListViewItem viewItem = session.ViewItem;
                    if (c != System.Drawing.Color.Empty)
                    {
                        viewItem.Font = new Font(viewItem.Font, FontStyle.Bold);
                        if ((session.oFlags["ui-bold"] != "user-marked") && (viewItem.ForeColor != System.Drawing.Color.Black))
                        {
                            session.oFlags["ui-oldcolor"] = Utilities.ColorToString(viewItem.ForeColor);
                        }
                        session.oFlags["ui-bold"] = "user-marked";
                        session.oFlags["ui-color"] = Utilities.ColorToString(c);
                        viewItem.ForeColor = c;
                    }
                    else
                    {
                        viewItem.Font = new Font(viewItem.Font, FontStyle.Regular);
                        viewItem.ForeColor = System.Drawing.Color.Black;
                        viewItem.BackColor = this.lvSessions.BackColor;
                        string sColor = session.oFlags["ui-oldcolor"];
                        if (sColor != null)
                        {
                            viewItem.ForeColor = Utilities.ParseColor(sColor);
                        }
                        session.oFlags.Remove("ui-bold");
                        session.oFlags.Remove("ui-strikeout");
                        session.oFlags.Remove("ui-oldcolor");
                        session.oFlags.Remove("ui-color");
                    }
                }
            }
            this.lvSessions.EndUpdate();
        }

        internal void actSessionsStrikeout()
        {
            foreach (Session session in FiddlerApplication.UI.GetSelectedSessions())
            {
                FontStyle newStyle = session.ViewItem.Font.Style ^ FontStyle.Strikeout;
                if (session.ViewItem != null)
                {
                    session.ViewItem.Font = new Font(session.ViewItem.Font, newStyle);
                    if ((newStyle & FontStyle.Strikeout) == FontStyle.Strikeout)
                    {
                        session.oFlags["ui-strikeout"] = "hotkey";
                    }
                    else
                    {
                        session.oFlags.Remove("ui-strikeout");
                    }
                }
            }
        }

        [CodeDescription("Set the font size for (some) Fiddler UI elements.")]
        public void actSetFontSize(float flFontSize)
        {
            try
            {
                flFontSize = Math.Min(flFontSize, 24f);
                flFontSize = Math.Max(flFontSize, 4f);
                base.SuspendLayout();
                FiddlerApplication.Reporter.FontSize = flFontSize;
                this.lvSessions.Font = new Font(this.lvSessions.Font.FontFamily, flFontSize);
                if (this.sbStatus.Font.Size != flFontSize)
                {
                    this.sbStatus.Font = new Font(this.sbStatus.Font.FontFamily, flFontSize);
                }
                if (this.txtExec.Font.Size != flFontSize)
                {
                    this.txtExec.Font = new Font(this.txtExec.Font.FontFamily, flFontSize);
                }
                if (this.tabsViews.Font.Size != flFontSize)
                {
                    this.tabsViews.Font = new Font(this.tabsViews.Font.FontFamily, flFontSize);
                }
                if (FiddlerApplication.oInspectors != null)
                {
                    FiddlerApplication.oInspectors.AnnounceFontSizeChange(flFontSize);
                }
                CONFIG.flFontSize = flFontSize;
                FiddlerApplication.Prefs.SetStringPref("fiddler.ui.font.size", flFontSize.ToString("##.##"));
                UIComposer.SetFontSize(flFontSize);
                if (FiddlerApplication.oAutoResponder != null)
                {
                    FiddlerApplication.oAutoResponder.SetFontSize(flFontSize);
                }
            }
            finally
            {
                base.ResumeLayout();
            }
        }

        [CodeDescription("Show the Fiddler Options dialog")]
        public void actShowOptions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Dialogs.ShowOptions");
            this.actShowOptions(null);
        }

        [CodeDescription("Show the Fiddler Options dialog, activating a particular tab")]
        public void actShowOptions(string sTabName)
        {
            if (CONFIG.bIsViewOnly)
            {
                this.SetStatusText("The Options dialog is not available in Viewer Mode instances");
            }
            else
            {
                using (frmOptions options = new frmOptions())
                {
                    if (!string.IsNullOrEmpty(sTabName))
                    {
                        options.SelectTab(sTabName);
                    }
                    options.ShowDialog(this);
                }
            }
        }

        public void actShowTextWizard(string sDefaultInput)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.LaunchTextWizard");
            frmTextWizard wizard = new frmTextWizard(sDefaultInput);
            wizard.Left = base.Left + 100;
            wizard.Top = base.Top + 100;
            wizard.Show(this);
        }

        internal bool actTearoffInspectors()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Inspectors.TearOff");
            if (this._frmFloatingInspectors != null)
            {
                return false;
            }
            base.SuspendLayout();
            this.miViewSquish.Enabled = false;
            this.miViewDefault.Enabled = this.miViewWide.Enabled = this.miViewStacked.Enabled = false;
            this._frmFloatingInspectors = new Form();
            this._frmFloatingInspectors.FormBorderStyle = FormBorderStyle.Sizable;
            this._frmFloatingInspectors.Width = 500;
            this._frmFloatingInspectors.Height = base.Height;
            this._frmFloatingInspectors.StartPosition = FormStartPosition.Manual;
            this._frmFloatingInspectors.Left = (base.Left + base.Width) - 500;
            this._frmFloatingInspectors.Top = base.Top + 0x19;
            this._frmFloatingInspectors.Text = "Fiddler - Details View";
            this._frmFloatingInspectors.Controls.Add(this.tabsViews);
            this._frmFloatingInspectors.Icon = base.Icon;
            this._frmFloatingInspectors.FormClosing += new FormClosingEventHandler(this.frmFloatingInspectors_FormClosing);
            this.splitterMain.Visible = false;
            this.pnlInspector.Dock = DockStyle.Right;
            this.pnlInspector.Width = 0;
            this.pnlSessions.Dock = DockStyle.Fill;
            base.ResumeLayout();
            this._frmFloatingInspectors.Show(this);
            return true;
        }

        public void actToggleCapture()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Actions.ToggleCapture");
            if (FiddlerApplication.oProxy.IsAttached)
            {
                this.actDetachProxy();
            }
            else
            {
                this.actAttachProxy();
            }
        }

        private void actToggleMark()
        {
            this.lvSessions.BeginUpdate();
            foreach (Session session in this.GetSelectedSessions())
            {
                if (session.oFlags["ui-bold"] == "user-marked")
                {
                    this.actSessionMark(System.Drawing.Color.Empty, new Session[] { session });
                }
                else
                {
                    this.actSessionMark(System.Drawing.Color.Red, new Session[] { session });
                }
            }
            this.lvSessions.EndUpdate();
        }

        private void actToggleSessionUnlock()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.Unlock");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                foreach (Session session in selectedSessions)
                {
                    if (!session.oFlags.ContainsKey("x-Unlocked"))
                    {
                        if (session.state >= SessionStates.Done)
                        {
                            session.oFlags["x-Unlocked"] = "User-Request";
                            if (session.ViewItem != null)
                            {
                                session.ViewItem.ImageIndex = 0x24;
                            }
                        }
                    }
                    else if (selectedSessions.Length <= 1)
                    {
                        this.actUpdateRequest(session);
                        this.actUpdateResponse(session);
                        session.oFlags.Remove("x-Unlocked");
                        this._RefreshSessionListViewItem(session, session.ViewItem);
                    }
                }
                this.actUpdateInspector(true, true);
            }
        }

        public void actToggleSquish()
        {
            FiddlerApplication.oTelemetry.TrackEvent("UI.ToggleSquished");
            if (this.pnlSessions.Width == 0x34)
            {
                this.miViewSquish.Checked = false;
                this.pnlSessions.Width = Math.Max(this._iUnsquishedSessionListWidth, 360);
            }
            else
            {
                this.miViewSquish.Checked = true;
                this._iUnsquishedSessionListWidth = this.pnlSessions.Width;
                this.pnlSessions.Width = 0x34;
            }
        }

        public void actToggleStackedLayout(bool bStacked)
        {
            FiddlerApplication.oTelemetry.TrackEvent("UI.ToggleStacked");
            this.actChangeToLayout(bStacked ? 1 : 0);
        }

        [CodeDescription("Reissue the selected requests unconditionally. If SHIFT key is held down, user will be prompted for repeat count")]
        public void actUnconditionallyReissueSelected()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.ReissueSelectedUnconditionally");
            int result = 1;
            if (Keys.Shift == (Control.ModifierKeys & Keys.Shift))
            {
                string s = frmPrompt.GetUserString("Repeat Count", "Reissue this Request (Unconditionally) how many times?", "5", true, frmPrompt.PromptIcon.Numbers);
                if (s == null)
                {
                    return;
                }
                if (!int.TryParse(s, out result))
                {
                    return;
                }
            }
            Session[] selectedSessions = this.GetSelectedSessions();
            StringDictionary oNewFlags = this._GetFlagsForReissue();
            for (int i = 0; i < result; i++)
            {
                for (int j = 0; j < selectedSessions.Length; j++)
                {
                    if (Utilities.HasHeaders(selectedSessions[j].oRequest))
                    {
                        HTTPRequestHeaders oHeaders = (HTTPRequestHeaders) selectedSessions[j].oRequest.headers.Clone();
                        oHeaders.RemoveRange(new string[] { "Range", "If-Modified-Since", "If-Unmodified-Since", "Unless-Modified-Since", "If-Range", "If-Match", "If-None-Match" });
                        FiddlerApplication.oProxy.SendRequest(oHeaders, selectedSessions[j].requestBodyBytes, oNewFlags);
                    }
                }
            }
        }

        private void actUndeleteSessions()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.UndeleteAttempted");
            if (this._wrDeletedListViewItems == null)
            {
                FiddlerApplication.UI.SetStatusText("No Web Sessions could be restored.");
            }
            else
            {
                ListViewItem[] target = this._wrDeletedListViewItems.Target as ListViewItem[];
                if (target == null)
                {
                    FiddlerApplication.UI.SetStatusText("No Web Sessions could be restored.");
                }
                else
                {
                    this._wrDeletedListViewItems = null;
                    try
                    {
                        foreach (ListViewItem item in target)
                        {
                            item.Selected = false;
                        }
                        this.lvSessions.Items.AddRange(target);
                        this._UpdateStatusBar();
                        FiddlerApplication.UI.SetStatusText(string.Format("Restored {0} removed Web Sessions", target.Length));
                        FiddlerApplication.oTelemetry.TrackEvent("Commands.List.UndeleteSucceeded");
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.ReportException(exception);
                    }
                }
            }
        }

        private void actUpdateBothInspectorsNow()
        {
            this.actUpdateInspector(true, true, true);
        }

        public void actUpdateInspector(bool bRequest, bool bResponse)
        {
            this.actUpdateInspector(bRequest, bResponse, false);
        }

        private void actUpdateInspector(bool bRequest, bool bResponse, bool bImmediate)
        {
            SimpleEventHandler workFunction = null;
            if (!FiddlerApplication.isClosing && (this.tabsViews.SelectedTab == this.pageInspector))
            {
                if (!bImmediate && (this.lvSessions.SelectedCount != 1))
                {
                    if (workFunction == null)
                    {
                        workFunction = delegate {
                            FiddlerApplication.UIInvokeAsync(new MethodInvoker(this.actUpdateBothInspectorsNow), null);
                        };
                    }
                    ScheduledTasks.ScheduleWork("UpdateInspectors", 100, workFunction);
                }
                else
                {
                    ScheduledTasks.CancelWork("UpdateInspectors");
                    if (this.lvSessions.SelectedCount != 1)
                    {
                        this._HideInspectorUI();
                    }
                    else
                    {
                        if (this.lblInspectOne != null)
                        {
                            this.lblInspectOne.Visible = false;
                        }
                        this.pageInspector.SuspendLayout();
                        this.tabsRequest.Visible = this.splitterInspector.Visible = this.tabsResponse.Visible = true;
                        Session firstSelectedSession = this.GetFirstSelectedSession();
                        this.btnTamperSendServer.Enabled = (firstSelectedSession != null) && (firstSelectedSession.state == SessionStates.HandTamperRequest);
                        this.btnTamperSendClient.Enabled = (firstSelectedSession != null) && ((firstSelectedSession.state == SessionStates.HandTamperRequest) || (firstSelectedSession.state == SessionStates.HandTamperResponse));
                        this.pnlSessionControls.Visible = this.btnTamperSendServer.Enabled || this.btnTamperSendClient.Enabled;
                        if (this.cbxLoadFrom.Items.Count > 0)
                        {
                            this.cbxLoadFrom.SelectedIndex = 0;
                        }
                        if ((firstSelectedSession != null) && Utilities.HasHeaders(firstSelectedSession.oRequest))
                        {
                            this.pnlInfoTipRequest.Visible = !Utilities.IsNullOrEmpty(firstSelectedSession.requestBodyBytes) && (firstSelectedSession.oRequest.headers.Exists("Transfer-Encoding") || firstSelectedSession.oRequest.headers.Exists("Content-Encoding"));
                        }
                        else
                        {
                            this.pnlInfoTipRequest.Visible = false;
                        }
                        this.pageInspector.ResumeLayout();
                        this.pnlInfoBar.Visible = (((firstSelectedSession != null) && !CONFIG.bMITM_HTTPS) && firstSelectedSession.HTTPMethodIs("CONNECT")) && !firstSelectedSession.isFlagSet(SessionFlags.LoadedFromSAZ);
                        this._UpdateResponseInfoTipVisibility(firstSelectedSession);
                        if (bRequest)
                        {
                            this._AssignRequestInspector(firstSelectedSession);
                        }
                        if (bResponse)
                        {
                            this._AssignResponseInspector(firstSelectedSession);
                        }
                    }
                }
            }
        }

        public void actUpdateReport()
        {
            FiddlerApplication.OnCalculateReport(this.GetSelectedSessions());
        }

        private void actUpdateRequest(Session oSession)
        {
            IRequestInspector2 activeRequestInspector = this.GetActiveRequestInspector();
            if ((activeRequestInspector != null) && (activeRequestInspector as Inspector2).CommitAnyChanges(oSession))
            {
                this.sbpInfo.Text = "Auto-saved changes to request from " + activeRequestInspector.GetType().ToString() + " at " + DateTime.Now.TimeOfDay.ToString();
            }
        }

        private void actUpdateResponse(Session oSession)
        {
            IResponseInspector2 activeResponseInspector = this.GetActiveResponseInspector();
            if ((activeResponseInspector != null) && (activeResponseInspector as Inspector2).CommitAnyChanges(oSession))
            {
                this.sbpInfo.Text = "Auto-saved changes to response from " + activeResponseInspector.GetType().ToString() + " at " + DateTime.Now.TimeOfDay.ToString();
            }
        }

        public void actValidateRequest(object sender, CancelEventArgs e)
        {
            if (!FiddlerApplication.isClosing && (this.lvSessions.SelectedCount >= 1))
            {
                Session firstSelectedSession = this.GetFirstSelectedSession();
                if (firstSelectedSession != null)
                {
                    this.actUpdateRequest(firstSelectedSession);
                }
            }
        }

        public void actValidateResponse(object sender, CancelEventArgs e)
        {
            if (!FiddlerApplication.isClosing && (this.lvSessions.SelectedCount >= 1))
            {
                Session firstSelectedSession = this.GetFirstSelectedSession();
                if (firstSelectedSession != null)
                {
                    this.actUpdateResponse(firstSelectedSession);
                }
            }
        }

        [CodeDescription("Display session properties dialog of the (1 or 2) currently selected Sessions.")]
        public void actViewSessionProperties()
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.ShowProperties");
            if ((this.lvSessions.SelectedCount == 1) || (this.lvSessions.SelectedCount == 2))
            {
                Session[] selectedSessions = this.GetSelectedSessions();
                if (selectedSessions[0] != null)
                {
                    SessionProperties properties = new SessionProperties(selectedSessions[0]);
                    properties.Left = base.Left + 250;
                    properties.Top = base.Top + 60;
                    properties.Show(this);
                }
                if (selectedSessions.Length == 2)
                {
                    SessionProperties properties2 = new SessionProperties(selectedSessions[1]);
                    properties2.Left = (base.Left + 250) + properties2.Width;
                    properties2.Top = base.Top + 60;
                    properties2.Show(this);
                }
            }
        }

        [CodeDescription("Add Imported Sessions to Fiddler's Web Sessions list. Assigns SessionID and flags as needed.")]
        public void AddImportedSessions(IEnumerable<Session> oSessions)
        {
            try
            {
                this.lvSessions.BeginUpdate();
                foreach (Session session in oSessions)
                {
                    session.SetBitFlag(SessionFlags.ImportedFromOtherTool, true);
                    if (session.HTTPMethodIs("CONNECT"))
                    {
                        session.isTunnel = true;
                    }
                    if (session.id == 0)
                    {
                        session._AssignID();
                    }
                    this.finishSession(session);
                }
            }
            finally
            {
                this.lvSessions.EndUpdate();
            }
        }

        [CodeDescription("Add a mock Session to the Web Sessions List containing any Request or Response data. All 4 parameters are optional. Returns the new Session.")]
        public Session AddMockSession(HTTPRequestHeaders headersRequest, byte[] arrRequestBody, HTTPResponseHeaders headersResponse, byte[] arrResponseBody)
        {
            return this.AddMockSession(headersRequest, arrRequestBody, headersResponse, arrResponseBody, true);
        }

        internal Session AddMockSession(HTTPRequestHeaders headersRequest, byte[] arrRequestBody, HTTPResponseHeaders headersResponse, byte[] arrResponseBody, bool bClone)
        {
            Session session = Session.BuildFromData(bClone, headersRequest, arrRequestBody, headersResponse, arrResponseBody, SessionFlags.ServedFromCache | SessionFlags.ImportedFromOtherTool | SessionFlags.ResponseGeneratedByFiddler | SessionFlags.RequestGeneratedByFiddler);
            session.Timers.ClientBeginRequest = session.Timers.ClientDoneResponse = DateTime.Now;
            session.FinishUISession();
            return session;
        }

        internal void AddReportedSession(Session oS)
        {
            ListViewItem oLVI = new ListViewItem(oS.id.ToString(), 0);
            oLVI.Font = this.lvSessions.Font;
            oLVI.Tag = oS;
            oS.ViewItem = oLVI;
            oLVI.SubItems.AddRange(new string[] { " - ", oS.oRequest.headers.UriScheme.ToUpperInvariant(), oS.host, oS.PathAndQuery, "-1", string.Empty, string.Empty, oS["SESSION", "x-ProcessInfo"], oS["SESSION", "ui-comments"], oS["SESSION", "ui-customcolumn"] });
            oLVI.SubItems.AddRange(this.lvSessions._emptyBoundColumns);
            SessionListView.FillBoundColumns(oS, oLVI);
            this.lvSessions.QueueItem(oLVI);
            this.finishSession(oS);
        }

        public Session AddReportedSession(byte[] arrRequest, byte[] arrResponse, Stream strmMetadata)
        {
            return this.AddReportedSession(arrRequest, arrResponse, strmMetadata, SessionFlags.None);
        }

        internal Session AddReportedSession(byte[] arrRequest, byte[] arrResponse, Stream strmMetadata, SessionFlags oAdditionalFlags)
        {
            Session oS = new Session(arrRequest, arrResponse);
            if (strmMetadata != null)
            {
                oS.LoadMetadata(strmMetadata);
            }
            if (oS.oFlags.ContainsKey("ui-hide") && ((oAdditionalFlags & SessionFlags.LoadedFromSAZ) == SessionFlags.LoadedFromSAZ))
            {
                oS.oFlags["ui-strikeout"] = string.Format("Was ui-hide='{0}'", oS.oFlags["ui-hide"]);
                oS.oFlags.Remove("ui-hide");
            }
            oS.BitFlags |= oAdditionalFlags;
            this.AddReportedSession(oS);
            return oS;
        }

        public void addSession(Session oSession)
        {
            if ((oSession.ViewItem == null) && !oSession.ShouldBeHidden())
            {
                this._coreAddSession(oSession, false);
            }
        }

        internal void ApplyOverrideFont()
        {
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.font.face", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                UpdateFont(this, stringPref);
            }
        }

        private void AssignStatusTextFromMenuItemTag(object sender, EventArgs e)
        {
            string tag = (sender as MenuItem).Tag as string;
            FiddlerApplication.UI.SetStatusText(tag);
        }

        private void btnDecodeRequest_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.DecodeRequest");
            this.actValidateRequest(sender, null);
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                if ((firstSelectedSession.state > SessionStates.ReadingRequest) && (firstSelectedSession.requestBodyBytes != null))
                {
                    firstSelectedSession.utilDecodeRequest();
                    this.actUpdateInspector(true, false);
                }
                else
                {
                    FiddlerApplication.DoNotifyUser("Full request data is not available for decoding.", "Decoding skipped", MessageBoxIcon.Asterisk);
                }
            }
        }

        private void btnDecodeResponse_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.DecodeResponse");
            this.actValidateResponse(sender, null);
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                if ((firstSelectedSession.state > SessionStates.ReadingResponse) && (firstSelectedSession.responseBodyBytes != null))
                {
                    firstSelectedSession.utilDecodeResponse(false);
                    if ((Control.ModifierKeys != Keys.None) && (FiddlerApplication.oInspectors != null))
                    {
                        int num;
                        DictionaryEntry entry = FiddlerApplication.oInspectors.FindBestResponseInspector(firstSelectedSession, out num);
                        if (entry.Key != null)
                        {
                            this.tabsResponse.SelectedTab = (TabPage) entry.Key;
                        }
                    }
                    this.actUpdateInspector(false, true);
                }
                else
                {
                    FiddlerApplication.DoNotifyUser("Full response data is not available for decoding.", "Decoding skipped", MessageBoxIcon.Asterisk);
                }
            }
        }

        private void btnPromptHTTPS_Click(object sender, EventArgs e)
        {
            this.pnlInfoBar.Hide();
            this.actShowOptions("HTTPS");
        }

        private void btnResponseBodyDropped_Click(object sender, EventArgs e)
        {
            this.actShowOptions("Performance");
        }

        private void btnTamperSend_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.Tamper.SendToServer");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                firstSelectedSession.oFlags["x-breakresponse"] = "USERREQUEST";
                firstSelectedSession.bBufferResponse = true;
                this.ResumeBreakpointedSession(firstSelectedSession);
            }
        }

        private void btnTamperSendClient_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.Tamper.SendToClient");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                firstSelectedSession.oFlags.Remove("x-breakresponse");
                this.ResumeBreakpointedSession(firstSelectedSession);
            }
        }

        private void btnWarnDetached_Click(object sender, EventArgs e)
        {
            this.actAttachProxy(true);
        }

        private void cbxLoadFrom_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string text;
            Session firstSelectedSession;
            FiddlerApplication.oTelemetry.TrackEvent("UI.Session.LoadResponseFromFile");
            if (this.cbxLoadFrom.SelectedIndex >= 1)
            {
                text = this.cbxLoadFrom.Text;
                if (this.lvSessions.SelectedCount != 1)
                {
                    return;
                }
                firstSelectedSession = this.GetFirstSelectedSession();
                if (firstSelectedSession == null)
                {
                    return;
                }
                if ((firstSelectedSession.state != SessionStates.HandTamperRequest) && (firstSelectedSession.state != SessionStates.HandTamperResponse))
                {
                    return;
                }
                if (!(text == AutoResponder.STR_FIND_FILE))
                {
                    goto Label_00CF;
                }
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.DefaultExt = "dat";
                dialog.Title = "Choose response file";
                dialog.Filter = "All Files (*.*)|*.*|Response Files (*.dat)|*.dat";
                if (DialogResult.OK == dialog.ShowDialog(this))
                {
                    this.cbxLoadFrom.Items.Insert(1, dialog.FileName);
                    this.cbxLoadFrom.SelectedIndex = 1;
                    text = dialog.FileName;
                    dialog.Dispose();
                    goto Label_00CF;
                }
                dialog.Dispose();
            }
            return;
        Label_00CF:
            if (firstSelectedSession.state != SessionStates.HandTamperResponse)
            {
                firstSelectedSession.state = SessionStates.HandTamperResponse;
            }
            firstSelectedSession.oResponse = new ServerChatter(firstSelectedSession, "HTTP/1.1 200 OK\r\nServer: Fiddler\r\n\r\n");
            firstSelectedSession.LoadResponseFromFile(text);
            this.actUpdateInspector(false, true);
        }

        [CodeDescription("Copies currently selected sessions to the clipboard.")]
        public void CopySessions(bool HeadersOnly)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.Copy.Sessions");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                StringBuilder data = new StringBuilder(0x400);
                StringBuilder builder2 = new StringBuilder(0x400);
                foreach (Session session in selectedSessions)
                {
                    builder2.Append(session.ToHTMLFragment(HeadersOnly));
                    data.Append(session.ToString(HeadersOnly));
                    if (selectedSessions.Length > 1)
                    {
                        builder2.Append("<hr />");
                        data.Append("\r\n------------------------------------------------------------------\r\n");
                    }
                }
                DataObject oData = new DataObject("HTML Format", Utilities.StringToCF_HTML(builder2.ToString()));
                oData.SetData(DataFormats.Text, data);
                Utilities.CopyToClipboard(oData);
            }
        }

        internal bool CreateSessionsForFile(string sFilename, string sRelativeTo)
        {
            try
            {
                if ((sFilename == null) || !System.IO.File.Exists(sFilename))
                {
                    return false;
                }
                if (sFilename.OICEndsWith(".saz"))
                {
                    return this.actLoadSessionArchive(sFilename);
                }
                if (((Control.ModifierKeys & (Keys.Control | Keys.Shift)) != Keys.None) && (FiddlerApplication.oTranscoders.GetImporterForExtension(Path.GetExtension(sFilename)) != null))
                {
                    this.actImportFile(sFilename);
                    return true;
                }
                string str = null;
                if (string.IsNullOrEmpty(sRelativeTo))
                {
                    str = string.Format("/{0}", Path.GetFileName(sFilename));
                }
                else
                {
                    str = sFilename.Substring(sRelativeTo.Length).Replace('\\', '/');
                }
                str = Utilities.UrlPathEncode(str);
                HTTPRequestHeaders headers = new HTTPRequestHeaders();
                headers.HTTPMethod = "GET";
                headers.Add("Host", "localhost");
                headers.RequestPath = str;
                byte[] arrRequest = headers.ToByteArray(true, true, false);
                byte[] bytes = Encoding.UTF8.GetBytes(string.Format("HTTP/1.1 200 OK\r\nContent-Type: {0}\r\nCache-Control: max-age=0, must-revalidate\r\nConnection: close\r\n\r\n", Utilities.ContentTypeForFilename(sFilename)));
                byte[] buffer = System.IO.File.ReadAllBytes(sFilename);
                MemoryStream stream = new MemoryStream();
                stream.Write(bytes, 0, bytes.Length);
                stream.Write(buffer, 0, buffer.Length);
                Session oSession = new Session(arrRequest, stream.ToArray(), SessionFlags.ServedFromCache | SessionFlags.ImportedFromOtherTool | SessionFlags.ResponseGeneratedByFiddler | SessionFlags.RequestGeneratedByFiddler);
                if (Clipboard.ContainsData("UniformResourceLocatorW"))
                {
                    try
                    {
                        MemoryStream data = (MemoryStream) Clipboard.GetData("UniformResourceLocatorW");
                        oSession["ui-comments"] = Encoding.Unicode.GetString(data.ToArray());
                        data.Dispose();
                    }
                    catch (Exception exception)
                    {
                        oSession["ui-comments"] = exception.Message;
                    }
                }
                else
                {
                    oSession["ui-comments"] = sFilename;
                }
                oSession.state = SessionStates.Done;
                this.finishSession(oSession);
                return true;
            }
            catch (Exception exception2)
            {
                FiddlerApplication.Log.LogFormat("Could not import data from '{0}' due to: {1}", new object[] { sFilename, Utilities.DescribeException(exception2) });
                return false;
            }
        }

        internal void CreateSessionsForFolder(string sFolderName)
        {
            DirectoryInfo info = new DirectoryInfo(sFolderName);
            foreach (FileInfo info2 in info.GetFiles("*", SearchOption.AllDirectories))
            {
                this.CreateSessionsForFile(info2.FullName, info.Parent.FullName);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void DoPostInitPreLoad()
        {
            try
            {
                CONFIG.ReadFormSettings();
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.filters.ResetOnRestart", false))
                {
                    FiddlerApplication.Prefs.RemovePref("fiddler.ui.rules.hideimages");
                    FiddlerApplication.Prefs.RemovePref("fiddler.ui.rules.hideconnects");
                }
                FiddlerToolbar.DisplayIfNeeded();
                this.miViewToolbar.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.toolbar.visible", true);
                FiddlerApplication.oAutoResponder.AddToUI();
                this.txtExec.OnExecute += new ExecuteHandler(this.txtExec_OnExecute);
                string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.Colors.QuickExec", null);
                if (!string.IsNullOrEmpty(stringPref))
                {
                    this.txtExec.BackColor = Utilities.ParseColor(stringPref);
                }
                stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.Colors.QuickExecText", null);
                if (!string.IsNullOrEmpty(stringPref))
                {
                    this.txtExec.ForeColor = Utilities.ParseColor(stringPref);
                }
                this.btnResponseBodyDropped.BackColor = CONFIG.colorBodyDropped;
                CONFIG.EnsureFoldersExist();
                this.dlgSaveZip.InitialDirectory = this.dlgLoadZip.InitialDirectory = CONFIG.GetPath("Captures");
                try
                {
                    Utilities.AddPathToPlaces(this.dlgSaveZip, CONFIG.GetPath("Captures"));
                    Utilities.AddPathToPlaces(this.dlgLoadZip, CONFIG.GetPath("Captures"));
                }
                catch (MissingMethodException exception)
                {
                    FiddlerApplication.ReportException(exception, "Outdated .NET Framework", "Fiddler requires .NET Framework 2.0 SP1 or later. Please install all updates from WindowsUpdate");
                }
                this._initBookMenu();
                this.oSAZMRU = new MRU(CONFIG.GetRegPath("MRU"), FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.mru.max", 0x10));
                this._initImportExportMenu();
                this.UNSTABLE_OfferTab("&Preferences", delegate (object s, EventArgs o) {
                    AboutConfig.ShowAboutConfigPage();
                });
                if (CONFIG.QuietMode)
                {
                    base.ShowInTaskbar = false;
                    base.WindowState = FormWindowState.Minimized;
                }
                UICustomizeColumns.DeserializeAndCreateWizardColumns();
                CONFIG._RestoreSessionListLayout();
                this._wndForMessages = new HiddenMessagingWindow(base.Handle);
                AppRecovery.RegisterForRecovery();
            }
            catch (Exception exception2)
            {
                FiddlerApplication.ReportException(exception2, "Error Starting Up");
            }
        }

        public void finishSession(Session oSession)
        {
            if (oSession != null)
            {
                ListViewItem viewItem = oSession.ViewItem;
                if (oSession.ShouldBeHidden())
                {
                    if (viewItem != null)
                    {
                        oSession.ViewItem = null;
                        this.lvSessions.RemoveOrDequeue(viewItem);
                    }
                }
                else
                {
                    if (viewItem == null)
                    {
                        this._coreAddSession(oSession, true);
                        viewItem = oSession.ViewItem;
                    }
                    this._RefreshSessionListViewItem(oSession, viewItem);
                    this.actRefreshInspectorsIfNeeded(oSession);
                }
            }
        }

        private void frmFloatingInspectors_FormClosing(object sender, FormClosingEventArgs e)
        {
            base.SuspendLayout();
            this.miViewDefault.Enabled = this.miViewWide.Enabled = this.miViewStacked.Enabled = true;
            this.splitterMain.Visible = true;
            this.pnlSessions.Width = 400;
            this.pnlInspector.Controls.Add(this.tabsViews);
            this.pnlInspector.Dock = DockStyle.Fill;
            this.miViewSquish.Enabled = true;
            this.actChangeToLayout(FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.layout.mode", 0));
            base.ResumeLayout();
            this._frmFloatingInspectors = null;
        }

        private void frmViewer_Closing(object sender, CancelEventArgs e)
        {
            if (FiddlerApplication._frmSplash != null)
            {
                e.Cancel = true;
            }
            else if (!FiddlerApplication.OnBeforeFiddlerShutdown())
            {
                e.Cancel = true;
            }
            else
            {
                FiddlerApplication.isClosing = true;
                this.actDetachProxy();
                if (this._wndForMessages != null)
                {
                    this._wndForMessages.DestroyHandle();
                }
                oReportingQueueTimer.Stop();
                TabPage selectedTab = FiddlerApplication.UI.tabsViews.SelectedTab;
                if (selectedTab != null)
                {
                    FiddlerApplication.Prefs.SetStringPref("fiddler.ui.lastview", selectedTab.Text);
                }
                FiddlerApplication.oTelemetry.TrackEvent("Fiddler.ExitedNormally");
                FiddlerApplication.OnFiddlerShutdown();
                this.UnregisterHotkey();
                this._SaveQuickExecHistory();
                CONFIG.SaveSettings(this);
                UIComposer.SavePrefs();
                FiddlerApplication._AutoResponder.SaveDefaultRules();
                base.Hide();
                if (FiddlerApplication.scriptRules != null)
                {
                    FiddlerApplication.scriptRules.Retire();
                }
                FiddlerApplication.oExtensions.Dispose();
                if (FiddlerApplication.oTelemetry != null)
                {
                    FiddlerApplication.oTelemetry.Stop();
                }
                CertMaker.DoDispose();
                CONFIG.RawPrefs.Close();
            }
        }

        private void frmViewer_KeyDown(object sender, KeyEventArgs e)
        {
            if (((e.KeyCode == Keys.Q) && ((e.Modifiers == Keys.Alt) || (e.Modifiers == Keys.Control))) || (e.KeyData == (Keys.Alt | Keys.OemSemicolon)))
            {
                e.SuppressKeyPress = e.Handled = true;
                this.txtExec.Focus();
                return;
            }
            if (e.KeyData == (Keys.Control | Keys.Shift | Keys.Delete))
            {
                e.SuppressKeyPress = e.Handled = true;
                this.actClearWinINETCache();
                return;
            }
            if (e.KeyData == (Keys.Alt | Keys.S))
            {
                e.SuppressKeyPress = e.Handled = true;
                this.lvSessions.Focus();
                return;
            }
            if (e.Modifiers != Keys.Control)
            {
                return;
            }
            Keys keyCode = e.KeyCode;
            if (keyCode <= Keys.H)
            {
                switch (keyCode)
                {
                    case Keys.Up:
                    {
                        int num2 = this.lvSessions.Items.Count - 1;
                        if (this.lvSessions.SelectedCount > 0)
                        {
                            num2 = this.lvSessions.SelectedIndices[0] - 1;
                        }
                        if (0 <= num2)
                        {
                            FiddlerApplication.SuppressReportUpdates = true;
                            this.lvSessions.SelectedItems.Clear();
                            FiddlerApplication.SuppressReportUpdates = false;
                            this.lvSessions.Items[num2].Selected = true;
                            this.lvSessions.Items[num2].Focused = true;
                            this.lvSessions.Items[num2].EnsureVisible();
                        }
                        e.Handled = true;
                        return;
                    }
                    case Keys.Right:
                        return;

                    case Keys.Down:
                    {
                        int num = 0;
                        if (this.lvSessions.SelectedCount > 0)
                        {
                            num = this.lvSessions.SelectedIndices[0] + 1;
                        }
                        if (this.lvSessions.Items.Count > num)
                        {
                            FiddlerApplication.SuppressReportUpdates = true;
                            this.lvSessions.SelectedItems.Clear();
                            FiddlerApplication.SuppressReportUpdates = false;
                            this.lvSessions.Items[num].Selected = true;
                            this.lvSessions.Items[num].Focused = true;
                            this.lvSessions.Items[num].EnsureVisible();
                        }
                        e.Handled = true;
                        return;
                    }
                    case Keys.D0:
                        goto Label_02AE;

                    case Keys.H:
                        this.ActivateRequestInspector("HEADERS");
                        this.ActivateResponseInspector("HEADERS");
                        e.Handled = true;
                        return;
                }
                return;
            }
            if (keyCode <= Keys.NumPad0)
            {
                if (keyCode == Keys.T)
                {
                    this.ActivateRequestInspector("TEXTVIEW");
                    this.ActivateResponseInspector("TEXTVIEW");
                    e.Handled = true;
                    return;
                }
                if (keyCode != Keys.NumPad0)
                {
                    return;
                }
            }
            else
            {
                switch (keyCode)
                {
                    case Keys.Add:
                    case Keys.Oemplus:
                    {
                        float flFontSize = Math.Min((float) 32f, (float) (CONFIG.flFontSize + ((float) 1.0)));
                        this.actSetFontSize(flFontSize);
                        e.Handled = true;
                        return;
                    }
                    case Keys.Separator:
                    case Keys.Oemcomma:
                        return;

                    case Keys.Subtract:
                    case Keys.OemMinus:
                    {
                        float num4 = Math.Max((float) 7f, (float) (CONFIG.flFontSize - ((float) 1.0)));
                        this.actSetFontSize(num4);
                        e.Handled = true;
                        return;
                    }
                    default:
                        return;
                }
            }
        Label_02AE:
            if (!this.lvSessions.Focused)
            {
                this.actSetFontSize(8.25f);
                e.Handled = true;
            }
        }

        private void frmViewer_Load(object sender, EventArgs e)
        {
            CONFIG.RetrieveFormSettings(this);
            _InitializeTelemetry();
            FiddlerApplication.Reporter = new Report();
            FiddlerApplication.Reporter.Parent = this.pageStatistics;
            FiddlerApplication.Reporter.Dock = DockStyle.Fill;
            this.actSetFontSize(CONFIG.flFontSize);
            FiddlerApplication.Reporter.Clear();
            FiddlerApplication._frmSplash.IndicateProgress("Loading Inspectors...");
            try
            {
                FiddlerApplication.oInspectors = new Inspectors(this.tabsRequest, this.tabsResponse, this);
                FiddlerApplication.oWSView = new WebSocketTab();
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Loading Inspectors failed");
            }
            FiddlerApplication._frmSplash.IndicateProgress("Loading Extensions...");
            try
            {
                FiddlerApplication.oExtensions = new FiddlerExtensions();
                if (CONFIG.bLoadScript)
                {
                    FiddlerApplication._frmSplash.IndicateProgress("Loading Scripting...");
                    FiddlerApplication.scriptRules = new FiddlerScript();
                    this.actLoadScripts();
                }
            }
            catch (Exception exception2)
            {
                FiddlerApplication.ReportException(exception2, "Loading Script/Extensions failed");
            }
            if (CONFIG.bIsViewOnly)
            {
                FiddlerApplication._frmSplash.IndicateProgress("Looking up gateway...");
                FiddlerApplication.oProxy.CollectConnectoidAndGatewayInfo();
            }
            else
            {
                FiddlerApplication.oProxy.DetachedUnexpectedly += new EventHandler(this.WhenDetachedUnexpectedly);
                FiddlerApplication._frmSplash.IndicateProgress("Starting Proxy...");
                if (FiddlerApplication.oProxy.Start(CONFIG.ListenPort, CONFIG.bAllowRemoteConnections))
                {
                    if (CONFIG.ListenPort == 0)
                    {
                        CONFIG.bUsingPortOverride = true;
                        CONFIG.ListenPort = FiddlerApplication.oProxy.ListenPort;
                    }
                    FiddlerApplication._frmSplash.IndicateProgress("Looking up gateway...");
                    FiddlerApplication.oProxy.CollectConnectoidAndGatewayInfo();
                    if (CONFIG.bAttachOnBoot && !Environment.CommandLine.OICContains("noattach"))
                    {
                        FiddlerApplication._frmSplash.IndicateProgress("Updating system's proxy settings...");
                        this.actAttachProxy(false);
                    }
                }
            }
            this.UpdateUIFromPrefs();
            FiddlerApplication.Prefs.AddWatcher("fiddler.ui.", new EventHandler<PrefChangeEventArgs>(this.OnPrefChange));
            this.miRulesBreakpointsIgnoreImages.Checked = !CONFIG.bBreakOnImages;
            this.uihlpUpdateProcessFilterStatus();
            if (CONFIG.bIsViewOnly)
            {
                this._ShowViewerModeUI();
            }
            FiddlerApplication._frmSplash.Close();
            FiddlerApplication._frmSplash = null;
            if (CONFIG.bAlwaysShowTrayIcon)
            {
                this.notifyIcon.Visible = true;
            }
            this._CheckUpdatesOnStartup();
            oReportingQueueTimer.Interval = CONFIG.iReporterUpdateInterval;
            oReportingQueueTimer.Tick += new EventHandler(this.oReportingQueueTimer_Tick);
            this.lvSessions.OnSessionsAdded = (SimpleEventHandler) Delegate.Combine(this.lvSessions.OnSessionsAdded, new SimpleEventHandler(this.lvSessions_OnSessionsAdded));
            this.RegisterHotkey();
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.QuickExec.KeepHistory", true))
            {
                this.txtExec.LoadHistory(CONFIG.GetPath("QuickExecHistory"));
            }
            try
            {
                FiddlerApplication.OnFiddlerBoot();
            }
            catch (Exception exception3)
            {
                FiddlerApplication.ReportException(exception3, "OnBoot Handler threw");
            }
            _AdjustThreadPool();
            if (!FiddlerApplication.isClosing)
            {
                if (!CONFIG.bRevertToDefaultLayout)
                {
                    this.ApplyOverrideFont();
                    Utilities.activateTabByTitle(FiddlerApplication.Prefs.GetStringPref("fiddler.ui.lastview", "Statistics"), FiddlerApplication.UI.tabsViews);
                    CONFIG._RestoreSessionListLayout();
                    CONFIG.MaximizeIfNeeded(this);
                    CONFIG.EnsurePanelSplittersAreVisible(this);
                }
                this._LoadAnyFileSpecifiedViaCommandLine();
                this.txtExec.Focus();
                if (!CONFIG.QuietMode)
                {
                    this._VerifyFiddlerIsFresh();
                    if (!CONFIG.bIsViewOnly)
                    {
                        CONFIG.PerformISAFirewallCheck();
                        CONFIG.PerformProxySettingsPerUserCheck();
                        CONFIG.PerformChromeGPOProxyCheck();
                        CONFIG.PerformAppContainerCheck();
                    }
                    this._PromptForTelemetryOptin();
                }
                this._EnableBackButtonNavigationOfTabs();
                this._OverrideIcon();
                _LogStartupTelemetry();
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ShowMemoryPanel", IntPtr.Size == 4))
                {
                    this._UpdateMemoryPanel();
                    FiddlerApplication.Janitor.assignWork(new SimpleEventHandler(this._UpdateMemoryPanel), 0x3a98);
                }
                else
                {
                    this.sbpMemory.Width = this.sbpMemory.MinWidth = 0;
                }
            }
        }

        private IRequestInspector2 GetActiveRequestInspector()
        {
            if (this.tabsRequest.TabCount > 0)
            {
                TabPage selectedTab = this.tabsRequest.SelectedTab;
                if ((selectedTab != null) && (selectedTab.Tag != null))
                {
                    return (IRequestInspector2) selectedTab.Tag;
                }
            }
            return null;
        }

        private IResponseInspector2 GetActiveResponseInspector()
        {
            if (this.tabsResponse.TabCount > 0)
            {
                TabPage selectedTab = this.tabsResponse.SelectedTab;
                if ((selectedTab != null) && (selectedTab.Tag != null))
                {
                    return (IResponseInspector2) selectedTab.Tag;
                }
            }
            return null;
        }

        [CodeDescription("Returns a Session[] array containing all sessions. Note: returns an empty non-null array if no sessions selected")]
        public Session[] GetAllSessions()
        {
            Session[] sessionArray = new Session[this.lvSessions.Items.Count];
            for (int i = 0; i < sessionArray.Length; i++)
            {
                sessionArray[i] = this.lvSessions.Items[i].Tag as Session;
            }
            return sessionArray;
        }

        private TabPage GetBestRequestInspector(Session oS)
        {
            TabPage key = null;
            string sTab = "HEADERS";
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.inspectors.request.alwaysuse", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                sTab = stringPref;
            }
            else if (Utilities.HasHeaders(oS.oRequest))
            {
                int num;
                DictionaryEntry entry = FiddlerApplication.oInspectors.FindBestRequestInspector(oS, out num);
                if (entry.Key != null)
                {
                    key = (TabPage) entry.Key;
                }
            }
            if (key == null)
            {
                key = this._GetTabByTitle(this.tabsRequest, sTab);
            }
            return key;
        }

        private TabPage GetBestResponseInspector(Session oS)
        {
            TabPage key = null;
            string sTab = "TEXTVIEW";
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.inspectors.response.alwaysuse", null);
            if (!string.IsNullOrEmpty(stringPref))
            {
                sTab = stringPref;
            }
            else if (Utilities.HasHeaders(oS.oResponse))
            {
                if (Utilities.IsNullOrEmpty(oS.responseBodyBytes) || ((oS.responseCode != 200) && (oS.responseCode != 0xcf)))
                {
                    sTab = "HEADERS";
                }
                else
                {
                    int num;
                    DictionaryEntry entry = FiddlerApplication.oInspectors.FindBestResponseInspector(oS, out num);
                    if (entry.Key != null)
                    {
                        key = (TabPage) entry.Key;
                    }
                }
            }
            else
            {
                sTab = "HEADERS";
            }
            if (key == null)
            {
                key = this._GetTabByTitle(this.tabsResponse, sTab);
            }
            return key;
        }

        public DialogResult GetDecision(frmAlert oAlert)
        {
            oAlert.StartPosition = FormStartPosition.CenterScreen;
            DialogResult result = oAlert.ShowDialog(this);
            oAlert.Dispose();
            return result;
        }

        private static void GetDiffFormattedHeaders(HTTPHeaders h1, HTTPHeaders h2, out string sHeaders1, out string sHeaders2)
        {
            StringBuilder builder = new StringBuilder();
            StringBuilder builder2 = new StringBuilder();
            List<HTTPHeaderItem> list = new List<HTTPHeaderItem>();
            List<HTTPHeaderItem> list2 = new List<HTTPHeaderItem>();
            foreach (HTTPHeaderItem item in h1)
            {
                list.Add((HTTPHeaderItem) item.Clone());
            }
            foreach (HTTPHeaderItem item2 in h2)
            {
                list2.Add((HTTPHeaderItem) item2.Clone());
            }
            foreach (HTTPHeaderItem item3 in list)
            {
                string name = item3.Name;
                string str2 = item3.Value;
                foreach (HTTPHeaderItem item4 in list2)
                {
                    if ((item4.Name == name) && (item4.Value == str2))
                    {
                        builder.AppendFormat("{0}: {1}\r\n", name, str2);
                        builder2.AppendFormat("{0}: {1}\r\n", name, str2);
                        item3.Name = string.Empty;
                        item3.Value = string.Empty;
                        list2.Remove(item4);
                        break;
                    }
                }
            }
            foreach (HTTPHeaderItem item5 in list)
            {
                string str3 = item5.Name;
                string str4 = item5.Value;
                if (!string.IsNullOrEmpty(str3) || !string.IsNullOrEmpty(str4))
                {
                    foreach (HTTPHeaderItem item6 in list2)
                    {
                        if (!(item6.Name == str3))
                        {
                            continue;
                        }
                        if (item6.Name.OICEquals("Cookie"))
                        {
                            builder.AppendFormat("{0}:\r\n\t\t{1}\r\n", str3, string.Join(";\r\n\t\t", str4.Split(new char[] { ';' })));
                            builder2.AppendFormat("{0}:\r\n\t\t{1}\r\n", str3, string.Join(";\r\n\t\t", item6.Value.Split(new char[] { ';' })));
                        }
                        else
                        {
                            int length = getFirstMismatchedCharacter(str4, item6.Value);
                            if (length > -1)
                            {
                                builder.AppendFormat("{0}: {1}\r\n>>\t{2}\r\n\r\n", str3, str4.Substring(0, length), str4.Substring(length, str4.Length - length));
                                builder2.AppendFormat("{0}: {1}\r\n>>\t{2}\r\n\r\n", str3, item6.Value.Substring(0, length), item6.Value.Substring(length, item6.Value.Length - length));
                            }
                            else
                            {
                                builder.AppendFormat("{0}: {1}\r\n", str3, str4);
                                builder2.AppendFormat("{0}: {1}\r\n", str3, item6.Value);
                            }
                        }
                        item5.Name = string.Empty;
                        item5.Value = string.Empty;
                        list2.Remove(item6);
                        break;
                    }
                    continue;
                }
            }
            foreach (HTTPHeaderItem item7 in list)
            {
                string str5 = item7.Name;
                string str6 = item7.Value;
                if (!string.IsNullOrEmpty(str5) || !string.IsNullOrEmpty(str6))
                {
                    builder.AppendFormat("{0}: {1}\r\n", str5, str6);
                    builder2.AppendLine();
                }
            }
            foreach (HTTPHeaderItem item8 in list2)
            {
                string str7 = item8.Name;
                string str8 = item8.Value;
                builder2.AppendFormat("{0}: {1}\r\n", str7, str8);
                builder.AppendLine();
            }
            sHeaders1 = builder.ToString();
            sHeaders2 = builder2.ToString();
        }

        private static int getFirstMismatchedCharacter(string s1, string s2)
        {
            if (s1 == s2)
            {
                return -1;
            }
            int num = 0;
            int length = s1.Length;
            int num3 = s2.Length;
            while ((num < length) && (num < num3))
            {
                if (s1[num] != s2[num])
                {
                    return num;
                }
                num++;
            }
            return num;
        }

        [CodeDescription("Returns the first of the selected sessions, or null if no selected sessions")]
        public Session GetFirstSelectedSession()
        {
            if (this.lvSessions.SelectedCount <= 0)
            {
                return null;
            }
            return (this.lvSessions.SelectedItems[0].Tag as Session);
        }

        internal static bool GetRequestFromCURLString(string sIn, out HTTPRequestHeaders oRH, out byte[] arrRequestBody)
        {
            oRH = new HTTPRequestHeaders();
            arrRequestBody = Utilities.emptyByteArray;
            sIn = sIn.Replace("\\\r\n", " ");
            sIn = Utilities.TrimBefore(sIn.Trim(), ' ').Replace("\r\n", " ");
            oRH.HTTPMethod = "GET";
            string str = null;
            string str2 = null;
            bool flag = false;
            string[] strArray = Utilities.Parameterize(sIn, true);
            int length = strArray.Length;
            for (int i = 0; i < length; i++)
            {
                string str4;
                string str8;
                switch (strArray[i])
                {
                    case "-I":
                    case "--head":
                    {
                        oRH.HTTPMethod = "HEAD";
                        continue;
                    }
                    case "-0":
                    case "--http1.0":
                    {
                        oRH.HTTPVersion = "HTTP/1.0";
                        continue;
                    }
                    case "-X":
                    case "--request":
                    {
                        if (++i < length)
                        {
                            string str3 = strArray[i];
                            oRH.HTTPMethod = str3;
                        }
                        continue;
                    }
                    case "--compressed":
                    {
                        if (!oRH.Exists("Accept-Encoding"))
                        {
                            oRH["Accept-Encoding"] = "gzip, deflate";
                        }
                        continue;
                    }
                    case "-b":
                    case "--cookie":
                    {
                        if (++i < length)
                        {
                            oRH["Cookie"] = (oRH.Exists("Cookie") ? (oRH["Cookie"] + ", ") : string.Empty) + strArray[i];
                        }
                        continue;
                    }
                    case "-A":
                    case "--user-agent":
                    {
                        if (++i < length)
                        {
                            oRH["User-Agent"] = strArray[i];
                        }
                        continue;
                    }
                    case "-e":
                    case "--referer":
                    {
                        if (++i < length)
                        {
                            oRH["Referer"] = strArray[i];
                        }
                        continue;
                    }
                    case "-u":
                    case "--user":
                    {
                        if (++i < length)
                        {
                        }
                        continue;
                    }
                    case "-U":
                    case "--proxy-user":
                    {
                        if (++i < length)
                        {
                        }
                        continue;
                    }
                    case "-r":
                    case "--range":
                    {
                        if (++i < length)
                        {
                            oRH["Range"] = "bytes=" + strArray[i];
                        }
                        continue;
                    }
                    case "-G":
                    case "--get":
                    {
                        flag = true;
                        continue;
                    }
                    case "-d":
                    case "--data":
                    case "--data-ascii":
                    {
                        if (++i < length)
                        {
                            if (!flag)
                            {
                                break;
                            }
                            str2 = str2 + "&" + strArray[i];
                        }
                        continue;
                    }
                    case "--data-urlencode":
                    {
                        if (++i >= length)
                        {
                            continue;
                        }
                        str4 = strArray[i];
                        if (!str4.Contains("="))
                        {
                            goto Label_0497;
                        }
                        string str5 = Utilities.TrimAfter(str4, '=');
                        string sInput = Utilities.TrimBefore(str4, '=');
                        str4 = str5 + '=' + Utilities.UrlEncode(sInput);
                        goto Label_04A0;
                    }
                    case "-H":
                    case "--header":
                    {
                        if (++i < length)
                        {
                            string sString = strArray[i];
                            if (!sString.Contains(":"))
                            {
                                if (!sString.EndsWith(";"))
                                {
                                    continue;
                                }
                                sString = sString.Remove(sString.Length - 1) + ":";
                            }
                            oRH.Add(Utilities.TrimAfter(sString, ':'), Utilities.TrimBefore(sString, ':').TrimStart(new char[0]));
                        }
                        continue;
                    }
                    default:
                        goto Label_0573;
                }
                oRH.HTTPMethod = "POST";
                if (!oRH.Exists("Content-Type"))
                {
                    oRH["Content-Type"] = "application/x-www-form-urlencoded";
                }
                str = (!string.IsNullOrEmpty(str) ? (str + "&") : string.Empty) + strArray[i];
                continue;
            Label_0497:
                str4 = Utilities.UrlEncode(str4);
            Label_04A0:
                if (flag)
                {
                    str2 = str2 + "&" + str4;
                }
                else
                {
                    oRH.HTTPMethod = "POST";
                    oRH["Content-Type"] = "application/x-www-form-urlencoded";
                    str = (!string.IsNullOrEmpty(str) ? (str + "&") : string.Empty) + str4;
                }
                continue;
            Label_0573:
                str8 = strArray[i];
                if (!str8.StartsWith("-"))
                {
                    if (str8.Contains("://"))
                    {
                        string str9 = Utilities.TrimAfter(str8, "://").ToLowerInvariant();
                        oRH.UriScheme = str9;
                        str8 = Utilities.TrimBefore(str8, "://");
                    }
                    if (str8.Contains("/"))
                    {
                        string str10 = Utilities.TrimAfter(str8, "/");
                        oRH["Host"] = str10;
                        str8 = str8.Substring(str10.Length);
                    }
                    oRH.RequestPath = str8;
                }
                else
                {
                    if (!str8.StartsWith("--") && (str8.Length > 2))
                    {
                        FiddlerApplication.Log.LogFormat("Fiddler doesn't yet support unexploded short-arguments: '{0}'", new object[] { strArray[i] });
                    }
                    FiddlerApplication.Log.LogFormat("CURL Execution skipping unrecognized argument: '{0}'", new object[] { strArray[i] });
                }
            }
            if (!oRH.Exists("User-Agent"))
            {
                oRH["User-Agent"] = "curl+Fiddler/7.33.0";
            }
            if (!oRH.Exists("Accept"))
            {
                oRH["Accept"] = "*/*";
            }
            if (!string.IsNullOrEmpty(str))
            {
                arrRequestBody = Encoding.UTF8.GetBytes(str);
            }
            if ((!oRH.Exists("Content-Length") && !oRH.Exists("Transfer-Encoding")) && (Utilities.HTTPMethodAllowsBody(oRH.HTTPMethod) || (arrRequestBody.Length > 0)))
            {
                oRH.Add("Content-Length", arrRequestBody.Length.ToString());
            }
            if (!string.IsNullOrEmpty(str2))
            {
                oRH.RequestPath = oRH.RequestPath + (oRH.RequestPath.Contains("?") ? "&" : "?") + str2.Substring(1);
            }
            return true;
        }

        [CodeDescription("Returns a Session[] array containing all of the selected sessions. Note: returns a non-null empty array if no sessions selected")]
        public Session[] GetSelectedSessions()
        {
            ListView.SelectedListViewItemCollection selectedItems = this.lvSessions.SelectedItems;
            Session[] sessionArray = new Session[selectedItems.Count];
            int index = 0;
            foreach (ListViewItem item in selectedItems)
            {
                sessionArray[index] = item.Tag as Session;
                index++;
            }
            return sessionArray;
        }

        [CodeDescription("Returns a Session[] array containing all (up to specified maximum #) of selected sessions. Note: returns a non-null empty array if no sessions selected")]
        public Session[] GetSelectedSessions(int iMax)
        {
            if (iMax < 0)
            {
                return new Session[0];
            }
            ListView.SelectedListViewItemCollection selectedItems = this.lvSessions.SelectedItems;
            Session[] sessionArray = new Session[Math.Min(iMax, selectedItems.Count)];
            int index = 0;
            foreach (ListViewItem item in selectedItems)
            {
                sessionArray[index] = item.Tag as Session;
                index++;
                if (index >= iMax)
                {
                    return sessionArray;
                }
            }
            return sessionArray;
        }

        internal DialogResult GetUpdateDecision(frmUpdate oUpdatePrompt)
        {
            if (base.InvokeRequired)
            {
                return (DialogResult) base.Invoke(new getUpdateDecisionDelegate(this.GetUpdateDecision), new object[] { oUpdatePrompt });
            }
            DialogResult result = oUpdatePrompt.ShowDialog(this);
            oUpdatePrompt.Dispose();
            return result;
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("kernel32", SetLastError=true)]
        private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);
        internal void HandleWMCopyData(Message m)
        {
            MethodInvoker oDel = null;
            MethodInvoker invoker2 = null;
            MethodInvoker invoker3 = null;
            MethodInvoker invoker4 = null;
            if (!FiddlerApplication.isClosing)
            {
                Utilities.COPYDATASTRUCT lParam = (Utilities.COPYDATASTRUCT) m.GetLParam(typeof(Utilities.COPYDATASTRUCT));
                if (((((long) lParam.dwData) >= 0xeefaL) && (((long) lParam.dwData) <= 0xeefdL)) && (lParam.cbData >= 1))
                {
                    byte[] destination = new byte[lParam.cbData];
                    Marshal.Copy(lParam.lpData, destination, 0, lParam.cbData);
                    long dwData = (long) lParam.dwData;
                    if ((dwData <= 0xeefdL) && (dwData >= 0xeefaL))
                    {
                        string strData;
                        switch (((int) (dwData - 0xeefaL)))
                        {
                            case 0:
                                strData = Encoding.Unicode.GetString(destination);
                                if (!strData.OICEndsWith(".saz"))
                                {
                                    if (invoker2 == null)
                                    {
                                        invoker2 = delegate {
                                            this.actImportFile(strData);
                                        };
                                    }
                                    FiddlerApplication.UIInvokeAsync(invoker2, null);
                                    return;
                                }
                                if (oDel == null)
                                {
                                    oDel = delegate {
                                        this.actLoadSessionArchive(strData);
                                    };
                                }
                                FiddlerApplication.UIInvokeAsync(oDel, null);
                                return;

                            case 1:
                                return;

                            case 2:
                                FiddlerApplication.oTelemetry.TrackEvent("Actions.WndProcExecActionANSI");
                                strData = Encoding.Default.GetString(destination);
                                if (invoker3 == null)
                                {
                                    invoker3 = delegate {
                                        this.actQuickExec(strData);
                                    };
                                }
                                FiddlerApplication.UIInvokeAsync(invoker3, null);
                                return;

                            case 3:
                                FiddlerApplication.oTelemetry.TrackEvent("Actions.WndProcExecActionUnicode");
                                strData = Encoding.Unicode.GetString(destination);
                                if (invoker4 == null)
                                {
                                    invoker4 = delegate {
                                        this.actQuickExec(strData);
                                    };
                                }
                                FiddlerApplication.UIInvokeAsync(invoker4, null);
                                return;
                        }
                    }
                }
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmViewer));
            this.mnuMain = new MainMenu(this.components);
            this.mnuFile = new MenuItem();
            this.miCaptureEnabled = new MenuItem();
            this.menuItem16 = new MenuItem();
            this.miFileNew = new MenuItem();
            this.miFileLoad = new MenuItem();
            this.mnuFileMRU = new MenuItem();
            this.miFileMRUSplit = new MenuItem();
            this.miFileMRUClear = new MenuItem();
            this.miFileMRUPrune = new MenuItem();
            this.mnuFileSave = new MenuItem();
            this.miFileSaveAllSessions = new MenuItem();
            this.menuItem32 = new MenuItem();
            this.mnuFileSaveSessions = new MenuItem();
            this.miFileSaveZip = new MenuItem();
            this.miFileSaveSession = new MenuItem();
            this.menuItem26 = new MenuItem();
            this.miFileSaveHeaders = new MenuItem();
            this.mnuFileSaveRequest = new MenuItem();
            this.miFileSaveRequest = new MenuItem();
            this.miFileSaveRequestBody = new MenuItem();
            this.mnuFileSaveResponse = new MenuItem();
            this.miFileSaveResponse = new MenuItem();
            this.miFileSaveResponseBody = new MenuItem();
            this.miFileSaveAndOpenBody = new MenuItem();
            this.menuItem7 = new MenuItem();
            this.miFileExit = new MenuItem();
            this.mnuEdit = new MenuItem();
            this.mnuEditCopy = new MenuItem();
            this.miEditCopySession = new MenuItem();
            this.miEditCopyUrl = new MenuItem();
            this.miEditCopyHeaders = new MenuItem();
            this.miEditCopyFullSummary = new MenuItem();
            this.miEditCopyTerseSummary = new MenuItem();
            this.mnuEditRemove = new MenuItem();
            this.miEditRemoveSelected = new MenuItem();
            this.miEditRemoveUnselected = new MenuItem();
            this.miEditRemoveAll = new MenuItem();
            this.miEditSelectAll = new MenuItem();
            this.miEditUndelete = new MenuItem();
            this.miEditPaste = new MenuItem();
            this.miEditSplit1 = new MenuItem();
            this.mnuEditMark = new MenuItem();
            this.miEditMarkStrike = new MenuItem();
            this.miEditMarkRed = new MenuItem();
            this.miEditMarkBlue = new MenuItem();
            this.miEditMarkGold = new MenuItem();
            this.miEditMarkGreen = new MenuItem();
            this.miEditMarkOrange = new MenuItem();
            this.miEditMarkPurple = new MenuItem();
            this.menuItem21 = new MenuItem();
            this.miEditMarkUnmark = new MenuItem();
            this.miEditUnlock = new MenuItem();
            this.miEditDivider = new MenuItem();
            this.miEditFind = new MenuItem();
            this.mnuRules = new MenuItem();
            this.miManipulateIgnoreImages = new MenuItem();
            this.miRulesIgnoreConnects = new MenuItem();
            this.miRulesSplit1 = new MenuItem();
            this.miRulesBreakAt = new MenuItem();
            this.miRulesBreakAtRequest = new MenuItem();
            this.miRulesBreakAtResponse = new MenuItem();
            this.miRulesBreakAtNothing = new MenuItem();
            this.menuItem18 = new MenuItem();
            this.miRulesBreakpointsIgnoreImages = new MenuItem();
            this.miCaptureRules = new MenuItem();
            this.miCaptureSplit = new MenuItem();
            this.miManipulateRequireProxyAuth = new MenuItem();
            this.miManipulateGZIP = new MenuItem();
            this.miRulesRemoveEncoding = new MenuItem();
            this.mnuTools = new MenuItem();
            this.miToolsOptions = new MenuItem();
            this.miToolsInternetOptions = new MenuItem();
            this.miToolsSplit1 = new MenuItem();
            this.miToolsClearCache = new MenuItem();
            this.miToolsClearCookies = new MenuItem();
            this.miToolsSplit2 = new MenuItem();
            this.miToolsEncodeDecode = new MenuItem();
            this.miToolsCompare = new MenuItem();
            this.miToolsSplitCustom = new MenuItem();
            this.mnuView = new MenuItem();
            this.miViewToolbar = new MenuItem();
            this.miViewSplit1 = new MenuItem();
            this.miViewDefault = new MenuItem();
            this.miViewStacked = new MenuItem();
            this.miViewWide = new MenuItem();
            this.menuItem1 = new MenuItem();
            this.mnuViewTabs = new MenuItem();
            this.miViewStatistics = new MenuItem();
            this.miViewInspector = new MenuItem();
            this.miViewBuilder = new MenuItem();
            this.miViewSplit2 = new MenuItem();
            this.miViewMinimizeToTray = new MenuItem();
            this.miViewStayOnTop = new MenuItem();
            this.miViewSplit3 = new MenuItem();
            this.miViewSquish = new MenuItem();
            this.miViewAutoScroll = new MenuItem();
            this.miViewRefresh = new MenuItem();
            this.mnuHelp = new MenuItem();
            this.miHelpContents = new MenuItem();
            this.miHelpBook = new MenuItem();
            this.miHelpCommunity = new MenuItem();
            this.miHelpSplit1 = new MenuItem();
            this.miHelpHTTP = new MenuItem();
            this.miHelpSplit2 = new MenuItem();
            this.miHelpShowFiltered = new MenuItem();
            this.miHelpPrioritySupport = new MenuItem();
            this.miHelpUpdates = new MenuItem();
            this.miHelpReportBug = new MenuItem();
            this.miHelpSplit3 = new MenuItem();
            this.miHelpAbout = new MenuItem();
            this.mnuSessionContext = new ContextMenu();
            this.miSessionListScroll = new MenuItem();
            this.miSessionContextSplit = new MenuItem();
            this.miSessionCopy = new MenuItem();
            this.miSessionCopyURL = new MenuItem();
            this.miSessionCopyColumn = new MenuItem();
            this.miSessionCopyHeadlines = new MenuItem();
            this.menuItem19 = new MenuItem();
            this.miSessionCopyHeaders = new MenuItem();
            this.menuItem20 = new MenuItem();
            this.miSessionCopyEntire = new MenuItem();
            this.miSessionCopyResponseAsDataURI = new MenuItem();
            this.miSessionCopySummary = new MenuItem();
            this.miSessionSave = new MenuItem();
            this.mnuContextSaveSessions = new MenuItem();
            this.miSessionSaveToZip = new MenuItem();
            this.miSessionSaveEntire = new MenuItem();
            this.menuItem28 = new MenuItem();
            this.miSessionSaveHeaders = new MenuItem();
            this.miContextSaveSplitter = new MenuItem();
            this.mnuContextSaveRequest = new MenuItem();
            this.miSessionSaveFullRequest = new MenuItem();
            this.miSessionSaveRequestBody = new MenuItem();
            this.mnuContextSaveResponse = new MenuItem();
            this.miSessionSaveFullResponse = new MenuItem();
            this.miSessionSaveResponseBody = new MenuItem();
            this.miContextSaveAndOpenBody = new MenuItem();
            this.miSessionRemove = new MenuItem();
            this.miSessionRemoveSelected = new MenuItem();
            this.miSessionRemoveUnselected = new MenuItem();
            this.miSessionRemoveAll = new MenuItem();
            this.miSessionFilter = new MenuItem();
            this.miSessionSplit2 = new MenuItem();
            this.miSessionAddComment = new MenuItem();
            this.miSessionMath = new MenuItem();
            this.miSessionSumAndAverage = new MenuItem();
            this.miSessionMark = new MenuItem();
            this.miSessionMarkStrike = new MenuItem();
            this.miSessionMarkRed = new MenuItem();
            this.miSessionMarkBlue = new MenuItem();
            this.miSessionMarkGold = new MenuItem();
            this.miSessionMarkGreen = new MenuItem();
            this.miSessionMarkOrange = new MenuItem();
            this.miSessionMarkPurple = new MenuItem();
            this.miContextMarkSplit = new MenuItem();
            this.miSessionMarkUnmark = new MenuItem();
            this.miSessionReplay = new MenuItem();
            this.miSessionReissueRequests = new MenuItem();
            this.miSessionReissueUnconditionally = new MenuItem();
            this.miSessionReissueEdited = new MenuItem();
            this.miSessionReissueAndVerify = new MenuItem();
            this.miSessionReissueSequentially = new MenuItem();
            this.miSessionReissueComposer = new MenuItem();
            this.miReissueSplit = new MenuItem();
            this.miSessionReissueInIE = new MenuItem();
            this.miSessionSelect = new MenuItem();
            this.miSessionSelectParent = new MenuItem();
            this.miSessionSelectChildren = new MenuItem();
            this.miSessionSelectDuplicates = new MenuItem();
            this.miSessionSelectMatching = new MenuItem();
            this.miSessionWinDiff = new MenuItem();
            this.miSessionCOMETPeek = new MenuItem();
            this.miSessionAbort = new MenuItem();
            this.miSessionReplayResponse = new MenuItem();
            this.miSessionUnlock = new MenuItem();
            this.miSessionSplit = new MenuItem();
            this.miSessionInspectNewWindow = new MenuItem();
            this.miSessionProperties = new MenuItem();
            this.imglSessionIcons = new ImageList(this.components);
            this.sbStatus = new StatusBar();
            this.sbpCapture = new StatusBarPanel();
            this.sbpProcessFilter = new StatusBarPanel();
            this.sbpBreakpoints = new StatusBarPanel();
            this.sbpSelCount = new StatusBarPanel();
            this.sbpMemory = new StatusBarPanel();
            this.sbpInfo = new StatusBarPanel();
            this.pnlSessions = new Panel();
            this.lvSessions = new SessionListView();
            this.colID = new ColumnHeader();
            this.colStatus = new ColumnHeader();
            this.colProtocol = new ColumnHeader();
            this.colHost = new ColumnHeader();
            this.colRequest = new ColumnHeader();
            this.colResponseSize = new ColumnHeader();
            this.colExpires = new ColumnHeader();
            this.colContentType = new ColumnHeader();
            this.colProcess = new ColumnHeader();
            this.colComments = new ColumnHeader();
            this.colCustom = new ColumnHeader();
            this.txtExec = new QuickExec();
            this.splitterMain = new Splitter();
            this.pnlInspector = new Panel();
            this.tabsViews = new TabControl();
            this.pageStatistics = new TabPage();
            this.pageInspector = new TabPage();
            this.tabsResponse = new TabControl();
            this.mnuInspectorsContext = new ContextMenu();
            this.miInspectorProperties = new MenuItem();
            this.miInspectorCopy = new MenuItem();
            this.menuItem2 = new MenuItem();
            this.miInspectorHide = new MenuItem();
            this.pnlInfoTip = new Panel();
            this.btnResponseBodyDropped = new Button();
            this.btnDecodeResponse = new Button();
            this.pnlSessionControls = new Panel();
            this.cbxLoadFrom = new ComboBox();
            this.lblBreakpoint = new Label();
            this.btnTamperSendClient = new Button();
            this.btnTamperSendServer = new Button();
            this.splitterInspector = new Splitter();
            this.tabsRequest = new TabControl();
            this.pnlInfoTipRequest = new Panel();
            this.btnDecodeRequest = new Button();
            this.pnlInfoBar = new Panel();
            this.btnPromptHTTPS = new Button();
            this.pageResponder = new TabPage();
            this.pageBuilder = new TabPage();
            this.dlgSaveBinary = new SaveFileDialog();
            this.notifyIcon = new NotifyIcon(this.components);
            this.mnuNotify = new ContextMenuStrip(this.components);
            this.miNotifyRestore = new ToolStripMenuItem();
            this.miNotifyCapturing = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.miNotifyExit = new ToolStripMenuItem();
            this.dlgSaveZip = new SaveFileDialog();
            this.dlgLoadZip = new OpenFileDialog();
            this.imglToolbar = new ImageList(this.components);
            this.pnlTopNotice = new Panel();
            this.btnWarnDetached = new Button();
            this.sbpCapture.BeginInit();
            this.sbpProcessFilter.BeginInit();
            this.sbpBreakpoints.BeginInit();
            this.sbpSelCount.BeginInit();
            this.sbpMemory.BeginInit();
            this.sbpInfo.BeginInit();
            this.pnlSessions.SuspendLayout();
            this.pnlInspector.SuspendLayout();
            this.tabsViews.SuspendLayout();
            this.pageInspector.SuspendLayout();
            this.pnlInfoTip.SuspendLayout();
            this.pnlSessionControls.SuspendLayout();
            this.pnlInfoTipRequest.SuspendLayout();
            this.pnlInfoBar.SuspendLayout();
            this.mnuNotify.SuspendLayout();
            this.pnlTopNotice.SuspendLayout();
            base.SuspendLayout();
            this.mnuMain.MenuItems.AddRange(new MenuItem[] { this.mnuFile, this.mnuEdit, this.mnuRules, this.mnuTools, this.mnuView, this.mnuHelp });
            this.mnuFile.Index = 0;
            this.mnuFile.MenuItems.AddRange(new MenuItem[] { this.miCaptureEnabled, this.menuItem16, this.miFileNew, this.miFileLoad, this.mnuFileMRU, this.mnuFileSave, this.menuItem7, this.miFileExit });
            this.mnuFile.Text = "&File";
            this.mnuFile.Popup += new EventHandler(this.mnuFile_Popup);
            this.miCaptureEnabled.Index = 0;
            this.miCaptureEnabled.Shortcut = Shortcut.F12;
            this.miCaptureEnabled.Text = "&Capture Traffic";
            this.miCaptureEnabled.Click += new EventHandler(this.miCaptureEnabled_Click);
            this.menuItem16.Index = 1;
            this.menuItem16.Text = "-";
            this.miFileNew.Index = 2;
            this.miFileNew.Text = "&New Viewer";
            this.miFileNew.Click += new EventHandler(this.miFileNew_Click);
            this.miFileLoad.Index = 3;
            this.miFileLoad.Text = "L&oad Archive...";
            this.miFileLoad.Click += new EventHandler(this.miFileLoad_Click);
            this.mnuFileMRU.Index = 4;
            this.mnuFileMRU.MenuItems.AddRange(new MenuItem[] { this.miFileMRUSplit, this.miFileMRUClear, this.miFileMRUPrune });
            this.mnuFileMRU.Text = "&Recent Archives";
            this.mnuFileMRU.Popup += new EventHandler(this.mnuFileMRU_Popup);
            this.miFileMRUSplit.Index = 0;
            this.miFileMRUSplit.Text = "-";
            this.miFileMRUClear.Index = 1;
            this.miFileMRUClear.Text = "Clear this &List";
            this.miFileMRUClear.Click += new EventHandler(this.miFileMRUClear_Click);
            this.miFileMRUPrune.Index = 2;
            this.miFileMRUPrune.Text = "&Prune Obsolete";
            this.miFileMRUPrune.Click += new EventHandler(this.miFileMRUPrune_Click);
            this.mnuFileSave.Index = 5;
            this.mnuFileSave.MenuItems.AddRange(new MenuItem[] { this.miFileSaveAllSessions, this.menuItem32, this.mnuFileSaveSessions, this.mnuFileSaveRequest, this.mnuFileSaveResponse });
            this.mnuFileSave.Text = "&Save";
            this.mnuFileSave.Popup += new EventHandler(this.mnuFileSave_Popup);
            this.miFileSaveAllSessions.Index = 0;
            this.miFileSaveAllSessions.Text = "&All Sessions...";
            this.miFileSaveAllSessions.Click += new EventHandler(this.miFileSaveAllSessions_Click);
            this.menuItem32.Index = 1;
            this.menuItem32.Text = "-";
            this.mnuFileSaveSessions.Index = 2;
            this.mnuFileSaveSessions.MenuItems.AddRange(new MenuItem[] { this.miFileSaveZip, this.miFileSaveSession, this.menuItem26, this.miFileSaveHeaders });
            this.mnuFileSaveSessions.Text = "Selected &Sessions";
            this.miFileSaveZip.DefaultItem = true;
            this.miFileSaveZip.Index = 0;
            this.miFileSaveZip.Text = "in Archive&Zip...";
            this.miFileSaveZip.Click += new EventHandler(this.miSessionSaveToZip_Click);
            this.miFileSaveSession.Index = 1;
            this.miFileSaveSession.Text = "as &Text...";
            this.miFileSaveSession.Click += new EventHandler(this.miSessionSaveEntire_Click);
            this.menuItem26.Index = 2;
            this.menuItem26.Text = "-";
            this.miFileSaveHeaders.Index = 3;
            this.miFileSaveHeaders.Text = "as Text (&Headers only)...";
            this.miFileSaveHeaders.Click += new EventHandler(this.miSessionSaveHeaders_Click);
            this.mnuFileSaveRequest.Index = 3;
            this.mnuFileSaveRequest.MenuItems.AddRange(new MenuItem[] { this.miFileSaveRequest, this.miFileSaveRequestBody });
            this.mnuFileSaveRequest.Text = "&Request";
            this.miFileSaveRequest.Index = 0;
            this.miFileSaveRequest.Text = "&Entire Request...";
            this.miFileSaveRequest.Click += new EventHandler(this.miSessionSaveFullRequest_Click);
            this.miFileSaveRequestBody.Index = 1;
            this.miFileSaveRequestBody.Text = "Request &Body...";
            this.miFileSaveRequestBody.Click += new EventHandler(this.miSessionSaveRequestBody_Click);
            this.mnuFileSaveResponse.Index = 4;
            this.mnuFileSaveResponse.MenuItems.AddRange(new MenuItem[] { this.miFileSaveResponse, this.miFileSaveResponseBody, this.miFileSaveAndOpenBody });
            this.mnuFileSaveResponse.Text = "R&esponse";
            this.miFileSaveResponse.Index = 0;
            this.miFileSaveResponse.Text = "&Entire Response...";
            this.miFileSaveResponse.Click += new EventHandler(this.miSessionSaveFullResponse_Click);
            this.miFileSaveResponseBody.Index = 1;
            this.miFileSaveResponseBody.Text = "&Response Body...";
            this.miFileSaveResponseBody.Click += new EventHandler(this.miSessionSaveResponseBody_Click);
            this.miFileSaveAndOpenBody.Index = 2;
            this.miFileSaveAndOpenBody.Text = "... and Open as Local &File";
            this.miFileSaveAndOpenBody.Click += new EventHandler(this.miFileSaveAndOpenBody_Click);
            this.menuItem7.Index = 6;
            this.menuItem7.Text = "-";
            this.miFileExit.Index = 7;
            this.miFileExit.Text = "E&xit";
            this.miFileExit.Click += new EventHandler(this.miExit_Click);
            this.mnuEdit.Index = 1;
            this.mnuEdit.MenuItems.AddRange(new MenuItem[] { this.mnuEditCopy, this.mnuEditRemove, this.miEditSelectAll, this.miEditUndelete, this.miEditPaste, this.miEditSplit1, this.mnuEditMark, this.miEditUnlock, this.miEditDivider, this.miEditFind });
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Popup += new EventHandler(this.mnuEdit_Popup);
            this.mnuEditCopy.Index = 0;
            this.mnuEditCopy.MenuItems.AddRange(new MenuItem[] { this.miEditCopySession, this.miEditCopyUrl, this.miEditCopyHeaders, this.miEditCopyFullSummary, this.miEditCopyTerseSummary });
            this.mnuEditCopy.Text = "&Copy";
            this.miEditCopySession.Index = 0;
            this.miEditCopySession.Text = "&Session\tCtrl+Shift+S";
            this.miEditCopySession.Click += new EventHandler(this.miSessionCopyEntire_Click);
            this.miEditCopyUrl.Index = 1;
            this.miEditCopyUrl.Text = "Just &Url\tCtrl+U";
            this.miEditCopyUrl.Click += new EventHandler(this.miSessionCopyURL_Click);
            this.miEditCopyHeaders.Index = 2;
            this.miEditCopyHeaders.Text = "&Headers only\tCtrl+Shift+C";
            this.miEditCopyHeaders.Click += new EventHandler(this.miSessionCopyHeaders_Click);
            this.miEditCopyFullSummary.Index = 3;
            this.miEditCopyFullSummary.Text = "&Full Summary\tCtrl+C";
            this.miEditCopyFullSummary.Click += new EventHandler(this.miSessionCopySummary_Click);
            this.miEditCopyTerseSummary.Index = 4;
            this.miEditCopyTerseSummary.Text = "&Terse Summary\tCtrl+Shift+T";
            this.miEditCopyTerseSummary.Click += new EventHandler(this.miSessionCopyHeadlines_Click);
            this.mnuEditRemove.Index = 1;
            this.mnuEditRemove.MenuItems.AddRange(new MenuItem[] { this.miEditRemoveSelected, this.miEditRemoveUnselected, this.miEditRemoveAll });
            this.mnuEditRemove.Text = "&Remove";
            this.mnuEditRemove.Popup += new EventHandler(this.mnuEditRemove_Popup);
            this.miEditRemoveSelected.Index = 0;
            this.miEditRemoveSelected.Text = "&Selected Sessions\tDel";
            this.miEditRemoveSelected.Click += new EventHandler(this.miSessionRemoveSelected_Click);
            this.miEditRemoveUnselected.Index = 1;
            this.miEditRemoveUnselected.Text = "&Unselected Sessions\tShift+Del";
            this.miEditRemoveUnselected.Click += new EventHandler(this.miSessionRemoveUnselected_Click);
            this.miEditRemoveAll.Index = 2;
            this.miEditRemoveAll.Text = "&All Sessions\tCtrl+X";
            this.miEditRemoveAll.Click += new EventHandler(this.miSessionRemoveAll_Click);
            this.miEditSelectAll.Index = 2;
            this.miEditSelectAll.Text = "Select &All\tCtrl+A";
            this.miEditSelectAll.Click += new EventHandler(this.miEditSelectAll_Click);
            this.miEditUndelete.Index = 3;
            this.miEditUndelete.Text = "&Undelete";
            this.miEditUndelete.Click += new EventHandler(this.miEditUndelete_Click);
            this.miEditPaste.Index = 4;
            this.miEditPaste.Text = "&Paste as Sessions";
            this.miEditPaste.Click += new EventHandler(this.miEditPaste_Click);
            this.miEditSplit1.Index = 5;
            this.miEditSplit1.Text = "-";
            this.mnuEditMark.Index = 6;
            this.mnuEditMark.MenuItems.AddRange(new MenuItem[] { this.miEditMarkStrike, this.miEditMarkRed, this.miEditMarkBlue, this.miEditMarkGold, this.miEditMarkGreen, this.miEditMarkOrange, this.miEditMarkPurple, this.menuItem21, this.miEditMarkUnmark });
            this.mnuEditMark.Text = "&Mark";
            this.miEditMarkStrike.Index = 0;
            this.miEditMarkStrike.Text = "Strikeout\tMinus";
            this.miEditMarkStrike.Click += new EventHandler(this.miEditMarkStrike_Click);
            this.miEditMarkRed.Index = 1;
            this.miEditMarkRed.Text = "&Red\tCtrl+1";
            this.miEditMarkRed.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miEditMarkBlue.Index = 2;
            this.miEditMarkBlue.Text = "&Blue\tCtrl+2";
            this.miEditMarkBlue.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miEditMarkGold.Index = 3;
            this.miEditMarkGold.Text = "Gol&d\tCtrl+3";
            this.miEditMarkGold.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miEditMarkGreen.Index = 4;
            this.miEditMarkGreen.Text = "&Green\tCtrl+4";
            this.miEditMarkGreen.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miEditMarkOrange.Index = 5;
            this.miEditMarkOrange.Text = "&Orange\tCtrl+5";
            this.miEditMarkOrange.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miEditMarkPurple.Index = 6;
            this.miEditMarkPurple.Text = "&Purple\tCtrl+6";
            this.miEditMarkPurple.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.menuItem21.Index = 7;
            this.menuItem21.Text = "-";
            this.miEditMarkUnmark.Index = 8;
            this.miEditMarkUnmark.Text = "&Unmark\tCtrl+0";
            this.miEditMarkUnmark.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miEditUnlock.Index = 7;
            this.miEditUnlock.Text = "Unlock for &Editing\tF2";
            this.miEditUnlock.Click += new EventHandler(this.miEditUnlock_Click);
            this.miEditDivider.Index = 8;
            this.miEditDivider.Text = "-";
            this.miEditFind.Index = 9;
            this.miEditFind.Shortcut = Shortcut.CtrlF;
            this.miEditFind.Text = "&Find Sessions...";
            this.miEditFind.Click += new EventHandler(this.miToolsFind_Click);
            this.mnuRules.Index = 2;
            this.mnuRules.MenuItems.AddRange(new MenuItem[] { this.miManipulateIgnoreImages, this.miRulesIgnoreConnects, this.miRulesSplit1, this.miRulesBreakAt, this.miCaptureRules, this.miCaptureSplit, this.miManipulateRequireProxyAuth, this.miManipulateGZIP, this.miRulesRemoveEncoding });
            this.mnuRules.Text = "&Rules";
            this.miManipulateIgnoreImages.Index = 0;
            this.miManipulateIgnoreImages.Text = "Hide &Image Requests";
            this.miManipulateIgnoreImages.Click += new EventHandler(this.miManipulateIgnoreImages_Click);
            this.miRulesIgnoreConnects.Index = 1;
            this.miRulesIgnoreConnects.Text = "Hide &CONNECTs";
            this.miRulesIgnoreConnects.Click += new EventHandler(this.miRulesIgnoreConnects_Click);
            this.miRulesSplit1.Index = 2;
            this.miRulesSplit1.Text = "-";
            this.miRulesBreakAt.Index = 3;
            this.miRulesBreakAt.MenuItems.AddRange(new MenuItem[] { this.miRulesBreakAtRequest, this.miRulesBreakAtResponse, this.miRulesBreakAtNothing, this.menuItem18, this.miRulesBreakpointsIgnoreImages });
            this.miRulesBreakAt.Text = "Automatic Breakpoint&s";
            this.miRulesBreakAtRequest.Index = 0;
            this.miRulesBreakAtRequest.RadioCheck = true;
            this.miRulesBreakAtRequest.Shortcut = Shortcut.F11;
            this.miRulesBreakAtRequest.Text = "&Before Requests";
            this.miRulesBreakAtRequest.Click += new EventHandler(this.miBreakAtChoice_Check);
            this.miRulesBreakAtResponse.Index = 1;
            this.miRulesBreakAtResponse.RadioCheck = true;
            this.miRulesBreakAtResponse.Shortcut = Shortcut.AltF11;
            this.miRulesBreakAtResponse.Text = "&After Responses";
            this.miRulesBreakAtResponse.Click += new EventHandler(this.miBreakAtChoice_Check);
            this.miRulesBreakAtNothing.Checked = true;
            this.miRulesBreakAtNothing.Index = 2;
            this.miRulesBreakAtNothing.RadioCheck = true;
            this.miRulesBreakAtNothing.Shortcut = Shortcut.ShiftF11;
            this.miRulesBreakAtNothing.Text = "&Disabled";
            this.miRulesBreakAtNothing.Click += new EventHandler(this.miBreakAtChoice_Check);
            this.menuItem18.Index = 3;
            this.menuItem18.Text = "-";
            this.miRulesBreakpointsIgnoreImages.Checked = true;
            this.miRulesBreakpointsIgnoreImages.Index = 4;
            this.miRulesBreakpointsIgnoreImages.Text = "&Ignore Images";
            this.miRulesBreakpointsIgnoreImages.Click += new EventHandler(this.miRulesBreakpointsIgnoreImages_Click);
            this.miCaptureRules.Index = 4;
            this.miCaptureRules.Shortcut = Shortcut.CtrlR;
            this.miCaptureRules.Text = "Customize &Rules...";
            this.miCaptureRules.Click += new EventHandler(this.miCaptureRules_Click);
            this.miCaptureSplit.Index = 5;
            this.miCaptureSplit.Text = "-";
            this.miManipulateRequireProxyAuth.Index = 6;
            this.miManipulateRequireProxyAuth.Text = "Require &Proxy Authentication";
            this.miManipulateRequireProxyAuth.Click += new EventHandler(this.miManipulateRequireProxyAuth_Click);
            this.miManipulateGZIP.Index = 7;
            this.miManipulateGZIP.Text = "Apply G&ZIP Encoding";
            this.miManipulateGZIP.Click += new EventHandler(this.miManipulateGZIP_Click);
            this.miRulesRemoveEncoding.Index = 8;
            this.miRulesRemoveEncoding.Text = "Remove All &Encodings";
            this.miRulesRemoveEncoding.Click += new EventHandler(this.miRulesRemoveEncoding_Click);
            this.mnuTools.Index = 3;
            this.mnuTools.MenuItems.AddRange(new MenuItem[] { this.miToolsOptions, this.miToolsInternetOptions, this.miToolsSplit1, this.miToolsClearCache, this.miToolsClearCookies, this.miToolsSplit2, this.miToolsEncodeDecode, this.miToolsCompare, this.miToolsSplitCustom });
            this.mnuTools.Text = "&Tools";
            this.mnuTools.Popup += new EventHandler(this.mnuTools_Popup);
            this.miToolsOptions.Index = 0;
            this.miToolsOptions.Text = "&Fiddler Options...";
            this.miToolsOptions.Click += new EventHandler(this.miToolsOptions_Click);
            this.miToolsInternetOptions.Index = 1;
            this.miToolsInternetOptions.Text = "WinINET &Options...";
            this.miToolsInternetOptions.Click += new EventHandler(this.miToolsInternetOptions_Click);
            this.miToolsSplit1.Index = 2;
            this.miToolsSplit1.Text = "-";
            this.miToolsClearCache.Index = 3;
            this.miToolsClearCache.Shortcut = Shortcut.CtrlShiftX;
            this.miToolsClearCache.Text = "&Clear WinINET Cache";
            this.miToolsClearCache.Click += new EventHandler(this.miToolsClearCache_Click);
            this.miToolsClearCookies.Index = 4;
            this.miToolsClearCookies.Text = "Clear WinINET Coo&kies";
            this.miToolsClearCookies.Click += new EventHandler(this.miToolsClearCookies_Click);
            this.miToolsSplit2.Index = 5;
            this.miToolsSplit2.Text = "-";
            this.miToolsEncodeDecode.Index = 6;
            this.miToolsEncodeDecode.Shortcut = Shortcut.CtrlE;
            this.miToolsEncodeDecode.Text = "T&extWizard...";
            this.miToolsEncodeDecode.Click += new EventHandler(this.miToolsBase64_Click);
            this.miToolsCompare.Index = 7;
            this.miToolsCompare.Text = "Co&mpare Sessions\tCtrl+W";
            this.miToolsCompare.Click += new EventHandler(this.miSessionWinDiff_Click);
            this.miToolsSplitCustom.Index = 8;
            this.miToolsSplitCustom.Text = "-";
            this.mnuView.Index = 4;
            this.mnuView.MenuItems.AddRange(new MenuItem[] { 
                this.miViewToolbar, this.miViewSplit1, this.miViewDefault, this.miViewStacked, this.miViewWide, this.menuItem1, this.mnuViewTabs, this.miViewStatistics, this.miViewInspector, this.miViewBuilder, this.miViewSplit2, this.miViewMinimizeToTray, this.miViewStayOnTop, this.miViewSplit3, this.miViewSquish, this.miViewAutoScroll, 
                this.miViewRefresh
             });
            this.mnuView.Text = "&View";
            this.miViewToolbar.Checked = true;
            this.miViewToolbar.Index = 0;
            this.miViewToolbar.Text = "Sho&w Toolbar";
            this.miViewToolbar.Click += new EventHandler(this.miViewToolbar_Click);
            this.miViewSplit1.Index = 1;
            this.miViewSplit1.Text = "-";
            this.miViewDefault.Checked = true;
            this.miViewDefault.Index = 2;
            this.miViewDefault.RadioCheck = true;
            this.miViewDefault.Text = "&Default Layout";
            this.miViewDefault.Click += new EventHandler(this.miViewLayout_Click);
            this.miViewStacked.Index = 3;
            this.miViewStacked.RadioCheck = true;
            this.miViewStacked.Text = "Stac&ked Layout";
            this.miViewStacked.Click += new EventHandler(this.miViewLayout_Click);
            this.miViewWide.Index = 4;
            this.miViewWide.RadioCheck = true;
            this.miViewWide.Text = "Wid&e Layout";
            this.miViewWide.Click += new EventHandler(this.miViewLayout_Click);
            this.menuItem1.Index = 5;
            this.menuItem1.Text = "-";
            this.mnuViewTabs.Index = 6;
            this.mnuViewTabs.Text = "Ta&bs";
            this.miViewStatistics.Index = 7;
            this.miViewStatistics.Shortcut = Shortcut.F7;
            this.miViewStatistics.Text = "&Statistics";
            this.miViewStatistics.Click += new EventHandler(this.miViewStatistics_Click);
            this.miViewInspector.Index = 8;
            this.miViewInspector.Shortcut = Shortcut.F8;
            this.miViewInspector.Text = "&Inspectors";
            this.miViewInspector.Click += new EventHandler(this.miViewInspector_Click);
            this.miViewBuilder.Index = 9;
            this.miViewBuilder.Shortcut = Shortcut.F9;
            this.miViewBuilder.Text = "&Composer";
            this.miViewBuilder.Click += new EventHandler(this.miViewBuilder_Click);
            this.miViewSplit2.Index = 10;
            this.miViewSplit2.Text = "-";
            this.miViewMinimizeToTray.Index = 11;
            this.miViewMinimizeToTray.Shortcut = Shortcut.CtrlM;
            this.miViewMinimizeToTray.Text = "&Minimize to Tray";
            this.miViewMinimizeToTray.Click += new EventHandler(this.miFileMinimizeToTray_Click);
            this.miViewStayOnTop.Index = 12;
            this.miViewStayOnTop.Text = "Stay on &Top";
            this.miViewStayOnTop.Click += new EventHandler(this.miViewStayOnTop_Click);
            this.miViewSplit3.Index = 13;
            this.miViewSplit3.Text = "-";
            this.miViewSquish.Index = 14;
            this.miViewSquish.Shortcut = Shortcut.F6;
            this.miViewSquish.Text = "Squish Session &List";
            this.miViewSquish.Click += new EventHandler(this.miSquish_Click);
            this.miViewAutoScroll.Checked = true;
            this.miViewAutoScroll.Index = 15;
            this.miViewAutoScroll.Text = "&AutoScroll Session List";
            this.miViewAutoScroll.Click += new EventHandler(this.miViewAutoScroll_Click);
            this.miViewRefresh.Index = 0x10;
            this.miViewRefresh.Shortcut = Shortcut.F5;
            this.miViewRefresh.Text = "&Refresh";
            this.miViewRefresh.Click += new EventHandler(this.miViewRefresh_Click);
            this.mnuHelp.Index = 5;
            this.mnuHelp.MenuItems.AddRange(new MenuItem[] { this.miHelpContents, this.miHelpBook, this.miHelpCommunity, this.miHelpSplit1, this.miHelpHTTP, this.miHelpSplit2, this.miHelpShowFiltered, this.miHelpPrioritySupport, this.miHelpUpdates, this.miHelpReportBug, this.miHelpSplit3, this.miHelpAbout });
            this.mnuHelp.Text = "&Help";
            this.miHelpContents.Index = 0;
            this.miHelpContents.Shortcut = Shortcut.F1;
            this.miHelpContents.Text = "Fiddler &Help";
            this.miHelpContents.Click += new EventHandler(this.miHelpContents_Click);
            this.miHelpBook.Index = 1;
            this.miHelpBook.Text = "Fiddler &Book";
            this.miHelpBook.Click += new EventHandler(this.miHelpBook_Click);
            this.miHelpCommunity.Index = 2;
            this.miHelpCommunity.Text = "Fiddler Dis&cussions";
            this.miHelpCommunity.Click += new EventHandler(this.miHelpCommunity_Click);
            this.miHelpSplit1.Index = 3;
            this.miHelpSplit1.Text = "-";
            this.miHelpHTTP.Index = 4;
            this.miHelpHTTP.Text = "HTTP &References";
            this.miHelpHTTP.Click += new EventHandler(this.miHelpHTTP_Click);
            this.miHelpSplit2.Index = 5;
            this.miHelpSplit2.Text = "-";
            this.miHelpShowFiltered.Index = 6;
            this.miHelpShowFiltered.Text = "&Troubleshoot...";
            this.miHelpShowFiltered.Click += new EventHandler(this.miHelpShowFiltered_Click);
            this.miHelpPrioritySupport.Index = 7;
            this.miHelpPrioritySupport.Text = "&Get Priority Support...";
            this.miHelpPrioritySupport.Click += new EventHandler(this.miHelpPrioritySupport_Click);
            this.miHelpUpdates.Index = 8;
            this.miHelpUpdates.Text = "Check for &Updates...";
            this.miHelpUpdates.Click += new EventHandler(this.miHelpUpdates_Click);
            this.miHelpReportBug.Index = 9;
            this.miHelpReportBug.Text = "&Send Feedback...";
            this.miHelpReportBug.Click += new EventHandler(this.miReportBug_Click);
            this.miHelpSplit3.Index = 10;
            this.miHelpSplit3.Text = "-";
            this.miHelpAbout.Index = 11;
            this.miHelpAbout.Text = "&About Fiddler";
            this.miHelpAbout.Click += new EventHandler(this.miHelpAbout_Click);
            this.mnuSessionContext.MenuItems.AddRange(new MenuItem[] { 
                this.miSessionListScroll, this.miSessionContextSplit, this.miSessionCopy, this.miSessionSave, this.miSessionRemove, this.miSessionFilter, this.miSessionSplit2, this.miSessionAddComment, this.miSessionMath, this.miSessionMark, this.miSessionReplay, this.miSessionSelect, this.miSessionWinDiff, this.miSessionCOMETPeek, this.miSessionAbort, this.miSessionReplayResponse, 
                this.miSessionUnlock, this.miSessionSplit, this.miSessionInspectNewWindow, this.miSessionProperties
             });
            this.mnuSessionContext.Popup += new EventHandler(this.mnuSessionContext_Popup);
            this.miSessionListScroll.Checked = true;
            this.miSessionListScroll.Index = 0;
            this.miSessionListScroll.Text = "AutoScroll Session List";
            this.miSessionListScroll.Click += new EventHandler(this.miSessionListScroll_Click);
            this.miSessionContextSplit.Index = 1;
            this.miSessionContextSplit.Text = "-";
            this.miSessionCopy.Index = 2;
            this.miSessionCopy.MenuItems.AddRange(new MenuItem[] { this.miSessionCopyURL, this.miSessionCopyColumn, this.miSessionCopyHeadlines, this.menuItem19, this.miSessionCopyHeaders, this.menuItem20, this.miSessionCopyEntire, this.miSessionCopyResponseAsDataURI, this.miSessionCopySummary });
            this.miSessionCopy.Text = "&Copy";
            this.miSessionCopyURL.Index = 0;
            this.miSessionCopyURL.Text = "Just &Url\tCtrl+U";
            this.miSessionCopyURL.Click += new EventHandler(this.miSessionCopyURL_Click);
            this.miSessionCopyColumn.Index = 1;
            this.miSessionCopyColumn.Text = "This &Column";
            this.miSessionCopyColumn.Click += new EventHandler(this.miSessionCopyColumn_Click);
            this.miSessionCopyHeadlines.Index = 2;
            this.miSessionCopyHeadlines.Text = "&Terse Summary\tCtrl+Shift+T";
            this.miSessionCopyHeadlines.Click += new EventHandler(this.miSessionCopyHeadlines_Click);
            this.menuItem19.Index = 3;
            this.menuItem19.Text = "-";
            this.miSessionCopyHeaders.DefaultItem = true;
            this.miSessionCopyHeaders.Index = 4;
            this.miSessionCopyHeaders.Text = "&Headers only\tCtrl+Shift+C";
            this.miSessionCopyHeaders.Click += new EventHandler(this.miSessionCopyHeaders_Click);
            this.menuItem20.Index = 5;
            this.menuItem20.Text = "-";
            this.miSessionCopyEntire.Index = 6;
            this.miSessionCopyEntire.Text = "&Session\tCtrl+Shift+S";
            this.miSessionCopyEntire.Click += new EventHandler(this.miSessionCopyEntire_Click);
            this.miSessionCopyResponseAsDataURI.Index = 7;
            this.miSessionCopyResponseAsDataURI.Text = "Response &DataURI";
            this.miSessionCopyResponseAsDataURI.Click += new EventHandler(this.miSessionCopyResponseAsDataURI_Click);
            this.miSessionCopySummary.Index = 8;
            this.miSessionCopySummary.Text = "&Full Summary\tCtrl+C";
            this.miSessionCopySummary.Click += new EventHandler(this.miSessionCopySummary_Click);
            this.miSessionSave.Index = 3;
            this.miSessionSave.MenuItems.AddRange(new MenuItem[] { this.mnuContextSaveSessions, this.miContextSaveSplitter, this.mnuContextSaveRequest, this.mnuContextSaveResponse, this.miContextSaveAndOpenBody });
            this.miSessionSave.Text = "&Save";
            this.mnuContextSaveSessions.Index = 0;
            this.mnuContextSaveSessions.MenuItems.AddRange(new MenuItem[] { this.miSessionSaveToZip, this.miSessionSaveEntire, this.menuItem28, this.miSessionSaveHeaders });
            this.mnuContextSaveSessions.Text = "Selected &Sessions";
            this.miSessionSaveToZip.DefaultItem = true;
            this.miSessionSaveToZip.Index = 0;
            this.miSessionSaveToZip.Text = "in Archive&ZIP...";
            this.miSessionSaveToZip.Click += new EventHandler(this.miSessionSaveToZip_Click);
            this.miSessionSaveEntire.Index = 1;
            this.miSessionSaveEntire.Text = "as Text...";
            this.miSessionSaveEntire.Click += new EventHandler(this.miSessionSaveEntire_Click);
            this.menuItem28.Index = 2;
            this.menuItem28.Text = "-";
            this.miSessionSaveHeaders.Index = 3;
            this.miSessionSaveHeaders.Text = "as Text (&Headers only)...";
            this.miSessionSaveHeaders.Click += new EventHandler(this.miSessionSaveHeaders_Click);
            this.miContextSaveSplitter.Index = 1;
            this.miContextSaveSplitter.Text = "-";
            this.mnuContextSaveRequest.Index = 2;
            this.mnuContextSaveRequest.MenuItems.AddRange(new MenuItem[] { this.miSessionSaveFullRequest, this.miSessionSaveRequestBody });
            this.mnuContextSaveRequest.Text = "&Request";
            this.miSessionSaveFullRequest.DefaultItem = true;
            this.miSessionSaveFullRequest.Index = 0;
            this.miSessionSaveFullRequest.Text = "&Entire Request...";
            this.miSessionSaveFullRequest.Click += new EventHandler(this.miSessionSaveFullRequest_Click);
            this.miSessionSaveRequestBody.Index = 1;
            this.miSessionSaveRequestBody.Text = "Request &Body...";
            this.miSessionSaveRequestBody.Click += new EventHandler(this.miSessionSaveRequestBody_Click);
            this.mnuContextSaveResponse.Index = 3;
            this.mnuContextSaveResponse.MenuItems.AddRange(new MenuItem[] { this.miSessionSaveFullResponse, this.miSessionSaveResponseBody });
            this.mnuContextSaveResponse.Text = "R&esponse";
            this.miSessionSaveFullResponse.Index = 0;
            this.miSessionSaveFullResponse.Text = "&Entire Response...";
            this.miSessionSaveFullResponse.Click += new EventHandler(this.miSessionSaveFullResponse_Click);
            this.miSessionSaveResponseBody.DefaultItem = true;
            this.miSessionSaveResponseBody.Index = 1;
            this.miSessionSaveResponseBody.Text = "&Response Body...";
            this.miSessionSaveResponseBody.Click += new EventHandler(this.miSessionSaveResponseBody_Click);
            this.miContextSaveAndOpenBody.Index = 4;
            this.miContextSaveAndOpenBody.Text = "...and Open as Local &File";
            this.miContextSaveAndOpenBody.Click += new EventHandler(this.miContextSaveAndOpenBody_Click);
            this.miSessionRemove.Index = 4;
            this.miSessionRemove.MenuItems.AddRange(new MenuItem[] { this.miSessionRemoveSelected, this.miSessionRemoveUnselected, this.miSessionRemoveAll });
            this.miSessionRemove.Text = "&Remove";
            this.miSessionRemoveSelected.Index = 0;
            this.miSessionRemoveSelected.Text = "&Selected Sessions\tDel";
            this.miSessionRemoveSelected.Click += new EventHandler(this.miSessionRemoveSelected_Click);
            this.miSessionRemoveUnselected.Index = 1;
            this.miSessionRemoveUnselected.Text = "&Unselected Sessions\tShift+Del";
            this.miSessionRemoveUnselected.Click += new EventHandler(this.miSessionRemoveUnselected_Click);
            this.miSessionRemoveAll.Index = 2;
            this.miSessionRemoveAll.Text = "&All Sessions\tCtrl+X";
            this.miSessionRemoveAll.Click += new EventHandler(this.miSessionRemoveAll_Click);
            this.miSessionFilter.Index = 5;
            this.miSessionFilter.Text = "&Filter Now";
            this.miSessionFilter.Popup += new EventHandler(this.miSessionFilter_Popup);
            this.miSessionSplit2.Index = 6;
            this.miSessionSplit2.Text = "-";
            this.miSessionAddComment.Index = 7;
            this.miSessionAddComment.Text = "Commen&t...\tM";
            this.miSessionAddComment.Click += new EventHandler(this.miSessionAddComment_Click);
            this.miSessionMath.Index = 8;
            this.miSessionMath.MenuItems.AddRange(new MenuItem[] { this.miSessionSumAndAverage });
            this.miSessionMath.Text = "Mat&h";
            this.miSessionMath.Visible = false;
            this.miSessionSumAndAverage.Index = 0;
            this.miSessionSumAndAverage.Text = "&Sum and Average";
            this.miSessionSumAndAverage.Click += new EventHandler(this.miSessionSumAndAverage_Click);
            this.miSessionMark.Index = 9;
            this.miSessionMark.MenuItems.AddRange(new MenuItem[] { this.miSessionMarkStrike, this.miSessionMarkRed, this.miSessionMarkBlue, this.miSessionMarkGold, this.miSessionMarkGreen, this.miSessionMarkOrange, this.miSessionMarkPurple, this.miContextMarkSplit, this.miSessionMarkUnmark });
            this.miSessionMark.Text = "&Mark";
            this.miSessionMarkStrike.Index = 0;
            this.miSessionMarkStrike.Text = "Strikeout\tMinus";
            this.miSessionMarkStrike.Click += new EventHandler(this.miEditMarkStrike_Click);
            this.miSessionMarkRed.Index = 1;
            this.miSessionMarkRed.Text = "&Red\tCtrl+1";
            this.miSessionMarkRed.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miSessionMarkBlue.Index = 2;
            this.miSessionMarkBlue.Text = "&Blue\tCtrl+2";
            this.miSessionMarkBlue.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miSessionMarkGold.Index = 3;
            this.miSessionMarkGold.Text = "Gol&d\tCtrl+3";
            this.miSessionMarkGold.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miSessionMarkGreen.Index = 4;
            this.miSessionMarkGreen.Text = "&Green\tCtrl+4";
            this.miSessionMarkGreen.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miSessionMarkOrange.Index = 5;
            this.miSessionMarkOrange.Text = "&Orange\tCtrl+5";
            this.miSessionMarkOrange.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miSessionMarkPurple.Index = 6;
            this.miSessionMarkPurple.Text = "&Purple\tCtrl+6";
            this.miSessionMarkPurple.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miContextMarkSplit.Index = 7;
            this.miContextMarkSplit.Text = "-";
            this.miSessionMarkUnmark.Index = 8;
            this.miSessionMarkUnmark.Text = "&Unmark\tCtrl+0";
            this.miSessionMarkUnmark.Click += new EventHandler(this.miSessionMarkColor_Click);
            this.miSessionReplay.Index = 10;
            this.miSessionReplay.MenuItems.AddRange(new MenuItem[] { this.miSessionReissueRequests, this.miSessionReissueUnconditionally, this.miSessionReissueEdited, this.miSessionReissueAndVerify, this.miSessionReissueSequentially, this.miSessionReissueComposer, this.miReissueSplit, this.miSessionReissueInIE });
            this.miSessionReplay.Text = "R&eplay";
            this.miSessionReissueRequests.Index = 0;
            this.miSessionReissueRequests.Text = "Reissue &Requests\tR";
            this.miSessionReissueRequests.Click += new EventHandler(this.miSessionReissueRequests_Click);
            this.miSessionReissueUnconditionally.Index = 1;
            this.miSessionReissueUnconditionally.Text = "Reissue &Unconditionally\tU";
            this.miSessionReissueUnconditionally.Click += new EventHandler(this.miSessionReissueUnconditionally_Click);
            this.miSessionReissueEdited.Index = 2;
            this.miSessionReissueEdited.Text = "Reissue and &Edit\tE";
            this.miSessionReissueEdited.Click += new EventHandler(this.miSessionReissueEdited_Click);
            this.miSessionReissueAndVerify.Index = 3;
            this.miSessionReissueAndVerify.Text = "Reissue and &Verify\tV";
            this.miSessionReissueAndVerify.Click += new EventHandler(this.miSessionReissueAndVerify_Click);
            this.miSessionReissueSequentially.Index = 4;
            this.miSessionReissueSequentially.Text = "Reissue Sequentially\tS";
            this.miSessionReissueSequentially.Click += new EventHandler(this.miSessionReissueSequentially_Click);
            this.miSessionReissueComposer.Index = 5;
            this.miSessionReissueComposer.Text = "Reissue from &Composer";
            this.miSessionReissueComposer.Click += new EventHandler(this.miSessionReissueComposer_Click);
            this.miReissueSplit.Index = 6;
            this.miReissueSplit.Text = "-";
            this.miSessionReissueInIE.Index = 7;
            this.miSessionReissueInIE.Text = "Revisit in &IE";
            this.miSessionReissueInIE.Click += new EventHandler(this.miSessionReissueInIE_Click);
            this.miSessionSelect.Index = 11;
            this.miSessionSelect.MenuItems.AddRange(new MenuItem[] { this.miSessionSelectParent, this.miSessionSelectChildren, this.miSessionSelectDuplicates, this.miSessionSelectMatching });
            this.miSessionSelect.Text = "Se&lect";
            this.miSessionSelectParent.Index = 0;
            this.miSessionSelectParent.Text = "&Parent Request\tP";
            this.miSessionSelectParent.Click += new EventHandler(this.miSessionSelectParent_Click);
            this.miSessionSelectChildren.Index = 1;
            this.miSessionSelectChildren.Text = "&Child Requests\tC";
            this.miSessionSelectChildren.Click += new EventHandler(this.miSessionSelectChildren_Click);
            this.miSessionSelectDuplicates.Index = 2;
            this.miSessionSelectDuplicates.Text = "&Duplicate Requests\tD";
            this.miSessionSelectDuplicates.Click += new EventHandler(this.miSessionSelectDuplicates_Click);
            this.miSessionSelectMatching.Index = 3;
            this.miSessionSelectMatching.Text = "Matching Values\tAlt+Click";
            this.miSessionSelectMatching.Click += new EventHandler(this.miSessionSelectMatching_Click);
            this.miSessionWinDiff.Index = 12;
            this.miSessionWinDiff.Text = "C&ompare\tCtrl+W";
            this.miSessionWinDiff.Click += new EventHandler(this.miSessionWinDiff_Click);
            this.miSessionCOMETPeek.Index = 13;
            this.miSessionCOMETPeek.Text = "COMETPeek";
            this.miSessionCOMETPeek.Click += new EventHandler(this.miSessionCOMETPeek_Click);
            this.miSessionAbort.Index = 14;
            this.miSessionAbort.Text = "Abort Session";
            this.miSessionAbort.Click += new EventHandler(this.miSessionAbort_Click);
            this.miSessionReplayResponse.Index = 15;
            this.miSessionReplayResponse.Text = "C&lone Response";
            this.miSessionReplayResponse.Click += new EventHandler(this.miSessionReplayResponse_Click);
            this.miSessionUnlock.Index = 0x10;
            this.miSessionUnlock.Text = "Unloc&k For Editing\tF2";
            this.miSessionUnlock.Click += new EventHandler(this.miSessionUnlock_Click);
            this.miSessionSplit.Index = 0x11;
            this.miSessionSplit.Text = "-";
            this.miSessionInspectNewWindow.Index = 0x12;
            this.miSessionInspectNewWindow.Text = "Inspect in &New Window...\tShift+Enter";
            this.miSessionInspectNewWindow.Click += new EventHandler(this.miSessionInspectNewWindow_Click);
            this.miSessionProperties.Index = 0x13;
            this.miSessionProperties.Text = "&Properties...\tAlt+Enter";
            this.miSessionProperties.Click += new EventHandler(this.miSessionProperties_Click);
            this.imglSessionIcons.ImageStream = (ImageListStreamer) manager.GetObject("imglSessionIcons.ImageStream");
            this.imglSessionIcons.TransparentColor = System.Drawing.Color.Magenta;
            this.imglSessionIcons.Images.SetKeyName(0, "Send");
            this.imglSessionIcons.Images.SetKeyName(1, "SendBP");
            this.imglSessionIcons.Images.SetKeyName(2, "Receive");
            this.imglSessionIcons.Images.SetKeyName(3, "ReceiveBP");
            this.imglSessionIcons.Images.SetKeyName(4, "Doc");
            this.imglSessionIcons.Images.SetKeyName(5, "Image");
            this.imglSessionIcons.Images.SetKeyName(6, "Script");
            this.imglSessionIcons.Images.SetKeyName(7, "XML");
            this.imglSessionIcons.Images.SetKeyName(8, "HTML");
            this.imglSessionIcons.Images.SetKeyName(9, "CSS");
            this.imglSessionIcons.Images.SetKeyName(10, "Redir");
            this.imglSessionIcons.Images.SetKeyName(11, "Cache");
            this.imglSessionIcons.Images.SetKeyName(12, "Error");
            this.imglSessionIcons.Images.SetKeyName(13, "Secure");
            this.imglSessionIcons.Images.SetKeyName(14, "abort");
            this.imglSessionIcons.Images.SetKeyName(15, "Auth");
            this.imglSessionIcons.Images.SetKeyName(0x10, "HEAD");
            this.imglSessionIcons.Images.SetKeyName(0x11, "unchecked");
            this.imglSessionIcons.Images.SetKeyName(0x12, "checked");
            this.imglSessionIcons.Images.SetKeyName(0x13, "inspect");
            this.imglSessionIcons.Images.SetKeyName(20, "builder");
            this.imglSessionIcons.Images.SetKeyName(0x15, "timer");
            this.imglSessionIcons.Images.SetKeyName(0x16, "timeline");
            this.imglSessionIcons.Images.SetKeyName(0x17, "unlitbolt");
            this.imglSessionIcons.Images.SetKeyName(0x18, "bolt");
            this.imglSessionIcons.Images.SetKeyName(0x19, "filter");
            this.imglSessionIcons.Images.SetKeyName(0x1a, "browser");
            this.imglSessionIcons.Images.SetKeyName(0x1b, "movie");
            this.imglSessionIcons.Images.SetKeyName(0x1c, "audio");
            this.imglSessionIcons.Images.SetKeyName(0x1d, "font");
            this.imglSessionIcons.Images.SetKeyName(30, "flash");
            this.imglSessionIcons.Images.SetKeyName(0x1f, "silverlight");
            this.imglSessionIcons.Images.SetKeyName(0x20, "post");
            this.imglSessionIcons.Images.SetKeyName(0x21, "json");
            this.imglSessionIcons.Images.SetKeyName(0x22, "socket");
            this.imglSessionIcons.Images.SetKeyName(0x23, "compose");
            this.imglSessionIcons.Images.SetKeyName(0x24, "editunlocked");
            this.imglSessionIcons.Images.SetKeyName(0x25, "http206");
            this.imglSessionIcons.Images.SetKeyName(0x26, "SPDY");
            this.imglSessionIcons.Images.SetKeyName(0x27, "RPC");
            this.imglSessionIcons.Images.SetKeyName(40, "HTTP2");
            this.sbStatus.Location = new Point(0, 0x18b);
            this.sbStatus.Name = "sbStatus";
            this.sbStatus.Panels.AddRange(new StatusBarPanel[] { this.sbpCapture, this.sbpProcessFilter, this.sbpBreakpoints, this.sbpSelCount, this.sbpMemory, this.sbpInfo });
            this.sbStatus.ShowPanels = true;
            this.sbStatus.Size = new Size(0x3d8, 0x16);
            this.sbStatus.TabIndex = 0;
            this.sbStatus.PanelClick += new StatusBarPanelClickEventHandler(this.sbStatus_PanelClick);
            this.sbStatus.MouseMove += new MouseEventHandler(this.sbStatus_MouseMove);
            this.sbpCapture.AutoSize = StatusBarPanelAutoSize.Contents;
            this.sbpCapture.Icon = (Icon) manager.GetObject("sbpCapture.Icon");
            this.sbpCapture.MinWidth = 0x55;
            this.sbpCapture.Name = "sbpCapture";
            this.sbpCapture.Style = StatusBarPanelStyle.OwnerDraw;
            this.sbpCapture.Width = 0x55;
            this.sbpProcessFilter.AutoSize = StatusBarPanelAutoSize.Contents;
            this.sbpProcessFilter.MinWidth = 110;
            this.sbpProcessFilter.Name = "sbpProcessFilter";
            this.sbpProcessFilter.Text = "All Processes";
            this.sbpProcessFilter.Width = 110;
            this.sbpBreakpoints.Icon = (Icon) manager.GetObject("sbpBreakpoints.Icon");
            this.sbpBreakpoints.MinWidth = 0x16;
            this.sbpBreakpoints.Name = "sbpBreakpoints";
            this.sbpBreakpoints.Style = StatusBarPanelStyle.OwnerDraw;
            this.sbpBreakpoints.Width = 0x16;
            this.sbpSelCount.Alignment = HorizontalAlignment.Center;
            this.sbpSelCount.MinWidth = 50;
            this.sbpSelCount.Name = "sbpSelCount";
            this.sbpSelCount.ToolTipText = "Number of sessions";
            this.sbpSelCount.Width = 80;
            this.sbpMemory.Alignment = HorizontalAlignment.Center;
            this.sbpMemory.Name = "sbpMemory";
            this.sbpMemory.Text = "0mb";
            this.sbpMemory.Width = 60;
            this.sbpInfo.BorderStyle = StatusBarPanelBorderStyle.None;
            this.sbpInfo.Name = "sbpInfo";
            this.sbpInfo.Width = 0x3e8;
            this.pnlSessions.BackColor = SystemColors.Control;
            this.pnlSessions.Controls.Add(this.lvSessions);
            this.pnlSessions.Controls.Add(this.txtExec);
            this.pnlSessions.Dock = DockStyle.Left;
            this.pnlSessions.Location = new Point(0, 0x1a);
            this.pnlSessions.Name = "pnlSessions";
            this.pnlSessions.Size = new Size(400, 0x171);
            this.pnlSessions.TabIndex = 1;
            this.lvSessions.Activation = ItemActivation.OneClick;
            this.lvSessions.AllowColumnReorder = true;
            this.lvSessions.AllowDrop = true;
            this.lvSessions.AutoArrange = false;
            this.lvSessions.BackColor = SystemColors.Window;
            this.lvSessions.BorderStyle = BorderStyle.FixedSingle;
            this.lvSessions.CausesValidation = false;
            this.lvSessions.Columns.AddRange(new ColumnHeader[] { this.colID, this.colStatus, this.colProtocol, this.colHost, this.colRequest, this.colResponseSize, this.colExpires, this.colContentType, this.colProcess, this.colComments, this.colCustom });
            this.lvSessions.ContextMenu = this.mnuSessionContext;
            this.lvSessions.Dock = DockStyle.Fill;
            this.lvSessions.EmptyText = "No Sessions captured\n(or all were hidden by filters)";
            this.lvSessions.Font = new Font("Tahoma", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lvSessions.FullRowSelect = true;
            this.lvSessions.HideSelection = false;
            this.lvSessions.LabelWrap = false;
            this.lvSessions.Location = new Point(0, 0);
            this.lvSessions.Name = "lvSessions";
            this.lvSessions.Size = new Size(400, 0x15c);
            this.lvSessions.SmallImageList = this.imglSessionIcons;
            this.lvSessions.TabIndex = 1;
            this.lvSessions.UseCompatibleStateImageBehavior = false;
            this.lvSessions.View = View.Details;
            this.lvSessions.ItemShowProperties += new EventHandler(this.lvSessions_ItemShowProperties);
            this.lvSessions.ItemDrag += new ItemDragEventHandler(this.lvSessions_ItemDrag);
            this.lvSessions.SelectedIndexChanged += new EventHandler(this.lvSessions_SelectedIndexChanged);
            this.lvSessions.DragDrop += new DragEventHandler(this.lvSessions_DragDrop);
            this.lvSessions.DragEnter += new DragEventHandler(this.lvSessions_DragEnter);
            this.lvSessions.DoubleClick += new EventHandler(this.lvSessions_DoubleClick);
            this.lvSessions.KeyDown += new KeyEventHandler(this.lvSessions_KeyDown);
            this.lvSessions.KeyUp += new KeyEventHandler(this.lvSessions_KeyUp);
            this.colID.Text = "#";
            this.colID.Width = 0x2d;
            this.colStatus.Text = "Result";
            this.colStatus.TextAlign = HorizontalAlignment.Center;
            this.colStatus.Width = 50;
            this.colProtocol.Text = "Protocol";
            this.colProtocol.Width = 0x37;
            this.colHost.Text = "Host";
            this.colHost.TextAlign = HorizontalAlignment.Right;
            this.colHost.Width = 120;
            this.colRequest.Text = "URL";
            this.colRequest.Width = 150;
            this.colResponseSize.Text = "Body";
            this.colResponseSize.TextAlign = HorizontalAlignment.Right;
            this.colResponseSize.Width = 0x34;
            this.colExpires.Text = "Caching";
            this.colContentType.Text = "Content-Type";
            this.colContentType.Width = 80;
            this.colProcess.Text = "Process";
            this.colComments.Text = "Comments";
            this.colComments.Width = 80;
            this.colCustom.Text = "Custom";
            this.txtExec.AllowDrop = true;
            this.txtExec.BackColor = System.Drawing.Color.Black;
            this.txtExec.CueText = "[QuickExec] ALT+Q > type HELP to learn more";
            this.txtExec.Dock = DockStyle.Bottom;
            this.txtExec.Font = new Font("Tahoma", 8.25f);
            this.txtExec.ForeColor = System.Drawing.Color.Lime;
            this.txtExec.Location = new Point(0, 0x15c);
            this.txtExec.Name = "txtExec";
            this.txtExec.Size = new Size(400, 0x15);
            this.txtExec.TabIndex = 2;
            this.txtExec.TextChanged += new EventHandler(this.txtExec_TextChanged);
            this.txtExec.DragDrop += new DragEventHandler(this.txtExec_DragDrop);
            this.txtExec.DragOver += new DragEventHandler(this.txtExec_DragOver);
            this.txtExec.KeyUp += new KeyEventHandler(this.txtExec_KeyUp);
            this.splitterMain.BackColor = System.Drawing.Color.LightSlateGray;
            this.splitterMain.Location = new Point(400, 0x1a);
            this.splitterMain.Name = "splitterMain";
            this.splitterMain.Size = new Size(3, 0x171);
            this.splitterMain.TabIndex = 2;
            this.splitterMain.TabStop = false;
            this.splitterMain.DoubleClick += new EventHandler(this.splitterMain_DoubleClick);
            this.pnlInspector.BackColor = SystemColors.Control;
            this.pnlInspector.Controls.Add(this.tabsViews);
            this.pnlInspector.Dock = DockStyle.Fill;
            this.pnlInspector.Location = new Point(0x193, 0x1a);
            this.pnlInspector.Name = "pnlInspector";
            this.pnlInspector.Size = new Size(0x245, 0x171);
            this.pnlInspector.TabIndex = 3;
            this.tabsViews.AllowDrop = true;
            this.tabsViews.Controls.Add(this.pageStatistics);
            this.tabsViews.Controls.Add(this.pageInspector);
            this.tabsViews.Controls.Add(this.pageResponder);
            this.tabsViews.Controls.Add(this.pageBuilder);
            this.tabsViews.Dock = DockStyle.Fill;
            this.tabsViews.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.tabsViews.HotTrack = true;
            this.tabsViews.ImageList = this.imglSessionIcons;
            this.tabsViews.Location = new Point(0, 0);
            this.tabsViews.Margin = new Padding(0);
            this.tabsViews.Multiline = true;
            this.tabsViews.Name = "tabsViews";
            this.tabsViews.SelectedIndex = 0;
            this.tabsViews.Size = new Size(0x245, 0x171);
            this.tabsViews.SizeMode = TabSizeMode.FillToRight;
            this.tabsViews.TabIndex = 0;
            this.tabsViews.SelectedIndexChanged += new EventHandler(this.tabsViews_SelectedIndexChanged);
            this.tabsViews.DragOver += new DragEventHandler(this.tabsViews_DragOver);
            this.tabsViews.MouseClick += new MouseEventHandler(this.tabsViews_MouseClick);
            this.pageStatistics.BackColor = System.Drawing.Color.Transparent;
            this.pageStatistics.ImageIndex = 0x15;
            this.pageStatistics.Location = new Point(4, 0x17);
            this.pageStatistics.Name = "pageStatistics";
            this.pageStatistics.Size = new Size(0x23d, 0x156);
            this.pageStatistics.TabIndex = 1;
            this.pageStatistics.Text = "Statistics";
            this.pageStatistics.UseVisualStyleBackColor = true;
            this.pageInspector.Controls.Add(this.tabsResponse);
            this.pageInspector.Controls.Add(this.pnlInfoTip);
            this.pageInspector.Controls.Add(this.pnlSessionControls);
            this.pageInspector.Controls.Add(this.splitterInspector);
            this.pageInspector.Controls.Add(this.tabsRequest);
            this.pageInspector.Controls.Add(this.pnlInfoTipRequest);
            this.pageInspector.Controls.Add(this.pnlInfoBar);
            this.pageInspector.ImageIndex = 0x13;
            this.pageInspector.Location = new Point(4, 0x17);
            this.pageInspector.Name = "pageInspector";
            this.pageInspector.Size = new Size(0x23d, 0x156);
            this.pageInspector.TabIndex = 0;
            this.pageInspector.Text = "Inspectors";
            this.pageInspector.UseVisualStyleBackColor = true;
            this.tabsResponse.AllowDrop = true;
            this.tabsResponse.Appearance = TabAppearance.FlatButtons;
            this.tabsResponse.ContextMenu = this.mnuInspectorsContext;
            this.tabsResponse.Dock = DockStyle.Fill;
            this.tabsResponse.HotTrack = true;
            this.tabsResponse.ImageList = this.imglSessionIcons;
            this.tabsResponse.ItemSize = new Size(0x2a, 0x12);
            this.tabsResponse.Location = new Point(0, 0x15b);
            this.tabsResponse.Margin = new Padding(0);
            this.tabsResponse.Multiline = true;
            this.tabsResponse.Name = "tabsResponse";
            this.tabsResponse.SelectedIndex = 0;
            this.tabsResponse.Size = new Size(0x23d, 0);
            this.tabsResponse.TabIndex = 5;
            this.tabsResponse.SelectedIndexChanged += new EventHandler(this.tabsResponse_SelectedIndexChanged);
            this.mnuInspectorsContext.MenuItems.AddRange(new MenuItem[] { this.miInspectorProperties, this.miInspectorCopy, this.menuItem2, this.miInspectorHide });
            this.miInspectorProperties.Index = 0;
            this.miInspectorProperties.Text = "Inspector &Properties";
            this.miInspectorProperties.Click += new EventHandler(this.miInspectorProperties_Click);
            this.miInspectorCopy.Index = 1;
            this.miInspectorCopy.Text = "&Copy as Image";
            this.miInspectorCopy.Click += new EventHandler(this.miInspectorCopy_Click);
            this.menuItem2.Index = 2;
            this.menuItem2.Text = "-";
            this.miInspectorHide.Index = 3;
            this.miInspectorHide.Text = "&Hide Inspector";
            this.miInspectorHide.Click += new EventHandler(this.miInspectorHide_Click);
            this.pnlInfoTip.BackColor = SystemColors.Info;
            this.pnlInfoTip.Controls.Add(this.btnResponseBodyDropped);
            this.pnlInfoTip.Controls.Add(this.btnDecodeResponse);
            this.pnlInfoTip.Dock = DockStyle.Top;
            this.pnlInfoTip.ForeColor = SystemColors.InfoText;
            this.pnlInfoTip.Location = new Point(0, 0x143);
            this.pnlInfoTip.Name = "pnlInfoTip";
            this.pnlInfoTip.Size = new Size(0x23d, 0x18);
            this.pnlInfoTip.TabIndex = 7;
            this.pnlInfoTip.Visible = false;
            this.btnResponseBodyDropped.Cursor = Cursors.Hand;
            this.btnResponseBodyDropped.Dock = DockStyle.Fill;
            this.btnResponseBodyDropped.FlatStyle = FlatStyle.Flat;
            this.btnResponseBodyDropped.Location = new Point(0, 0);
            this.btnResponseBodyDropped.Name = "btnResponseBodyDropped";
            this.btnResponseBodyDropped.Size = new Size(0x23d, 0x18);
            this.btnResponseBodyDropped.TabIndex = 2;
            this.btnResponseBodyDropped.Text = " The response body was dropped to conserve memory.";
            this.btnResponseBodyDropped.UseVisualStyleBackColor = true;
            this.btnResponseBodyDropped.Visible = false;
            this.btnResponseBodyDropped.Click += new EventHandler(this.btnResponseBodyDropped_Click);
            this.btnDecodeResponse.Cursor = Cursors.Hand;
            this.btnDecodeResponse.Dock = DockStyle.Fill;
            this.btnDecodeResponse.FlatStyle = FlatStyle.Flat;
            this.btnDecodeResponse.Location = new Point(0, 0);
            this.btnDecodeResponse.Name = "btnDecodeResponse";
            this.btnDecodeResponse.Size = new Size(0x23d, 0x18);
            this.btnDecodeResponse.TabIndex = 1;
            this.btnDecodeResponse.Text = "Response is encoded and may require decoding before inspection. Click here to transform.";
            this.btnDecodeResponse.UseVisualStyleBackColor = true;
            this.btnDecodeResponse.Click += new EventHandler(this.btnDecodeResponse_Click);
            this.pnlSessionControls.BackColor = System.Drawing.Color.Red;
            this.pnlSessionControls.Controls.Add(this.cbxLoadFrom);
            this.pnlSessionControls.Controls.Add(this.lblBreakpoint);
            this.pnlSessionControls.Controls.Add(this.btnTamperSendClient);
            this.pnlSessionControls.Controls.Add(this.btnTamperSendServer);
            this.pnlSessionControls.Dock = DockStyle.Top;
            this.pnlSessionControls.ForeColor = SystemColors.WindowText;
            this.pnlSessionControls.Location = new Point(0, 0x12a);
            this.pnlSessionControls.Name = "pnlSessionControls";
            this.pnlSessionControls.Size = new Size(0x23d, 0x19);
            this.pnlSessionControls.TabIndex = 3;
            this.pnlSessionControls.Visible = false;
            this.cbxLoadFrom.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.cbxLoadFrom.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxLoadFrom.Location = new Point(410, 1);
            this.cbxLoadFrom.MaxDropDownItems = 20;
            this.cbxLoadFrom.Name = "cbxLoadFrom";
            this.cbxLoadFrom.Size = new Size(0x9e, 0x15);
            this.cbxLoadFrom.TabIndex = 5;
            this.cbxLoadFrom.SelectionChangeCommitted += new EventHandler(this.cbxLoadFrom_SelectionChangeCommitted);
            this.lblBreakpoint.Location = new Point(6, 5);
            this.lblBreakpoint.Name = "lblBreakpoint";
            this.lblBreakpoint.Size = new Size(0xa2, 14);
            this.lblBreakpoint.TabIndex = 4;
            this.lblBreakpoint.Text = "Breakpoint hit. Tamper, then:";
            this.btnTamperSendClient.BackColor = System.Drawing.Color.FromArgb(0x55, 0xd9, 6);
            this.btnTamperSendClient.ForeColor = System.Drawing.Color.Black;
            this.btnTamperSendClient.Location = new Point(0x128, 1);
            this.btnTamperSendClient.Name = "btnTamperSendClient";
            this.btnTamperSendClient.Size = new Size(0x70, 0x17);
            this.btnTamperSendClient.TabIndex = 2;
            this.btnTamperSendClient.Text = "Run to &Completion";
            this.btnTamperSendClient.UseVisualStyleBackColor = false;
            this.btnTamperSendClient.Click += new EventHandler(this.btnTamperSendClient_Click);
            this.btnTamperSendServer.BackColor = System.Drawing.Color.FromArgb(0xff, 0xff, 0x80);
            this.btnTamperSendServer.ForeColor = System.Drawing.Color.Black;
            this.btnTamperSendServer.Location = new Point(0xae, 1);
            this.btnTamperSendServer.Name = "btnTamperSendServer";
            this.btnTamperSendServer.Size = new Size(120, 0x17);
            this.btnTamperSendServer.TabIndex = 0;
            this.btnTamperSendServer.Text = "&Break on Response";
            this.btnTamperSendServer.UseVisualStyleBackColor = false;
            this.btnTamperSendServer.Click += new EventHandler(this.btnTamperSend_Click);
            this.splitterInspector.BackColor = System.Drawing.Color.LightSlateGray;
            this.splitterInspector.Dock = DockStyle.Top;
            this.splitterInspector.Location = new Point(0, 0x127);
            this.splitterInspector.Name = "splitterInspector";
            this.splitterInspector.Size = new Size(0x23d, 3);
            this.splitterInspector.TabIndex = 6;
            this.splitterInspector.TabStop = false;
            this.splitterInspector.DoubleClick += new EventHandler(this.splitterInspector_DoubleClick);
            this.tabsRequest.Appearance = TabAppearance.FlatButtons;
            this.tabsRequest.ContextMenu = this.mnuInspectorsContext;
            this.tabsRequest.Dock = DockStyle.Top;
            this.tabsRequest.HotTrack = true;
            this.tabsRequest.ImageList = this.imglSessionIcons;
            this.tabsRequest.ItemSize = new Size(0x2a, 0x12);
            this.tabsRequest.Location = new Point(0, 50);
            this.tabsRequest.Margin = new Padding(0);
            this.tabsRequest.Multiline = true;
            this.tabsRequest.Name = "tabsRequest";
            this.tabsRequest.SelectedIndex = 0;
            this.tabsRequest.Size = new Size(0x23d, 0xf5);
            this.tabsRequest.TabIndex = 4;
            this.tabsRequest.SelectedIndexChanged += new EventHandler(this.tabsRequest_SelectedIndexChanged);
            this.pnlInfoTipRequest.BackColor = SystemColors.Info;
            this.pnlInfoTipRequest.Controls.Add(this.btnDecodeRequest);
            this.pnlInfoTipRequest.Dock = DockStyle.Top;
            this.pnlInfoTipRequest.ForeColor = SystemColors.InfoText;
            this.pnlInfoTipRequest.Location = new Point(0, 0x1a);
            this.pnlInfoTipRequest.Name = "pnlInfoTipRequest";
            this.pnlInfoTipRequest.Size = new Size(0x23d, 0x18);
            this.pnlInfoTipRequest.TabIndex = 9;
            this.pnlInfoTipRequest.Visible = false;
            this.btnDecodeRequest.Cursor = Cursors.Hand;
            this.btnDecodeRequest.Dock = DockStyle.Fill;
            this.btnDecodeRequest.FlatStyle = FlatStyle.Flat;
            this.btnDecodeRequest.Location = new Point(0, 0);
            this.btnDecodeRequest.Name = "btnDecodeRequest";
            this.btnDecodeRequest.Size = new Size(0x23d, 0x18);
            this.btnDecodeRequest.TabIndex = 1;
            this.btnDecodeRequest.Text = "Request is encoded and may need to be decoded before inspection. Click here to transform.";
            this.btnDecodeRequest.UseVisualStyleBackColor = true;
            this.btnDecodeRequest.Click += new EventHandler(this.btnDecodeRequest_Click);
            this.pnlInfoBar.BackColor = System.Drawing.Color.Yellow;
            this.pnlInfoBar.Controls.Add(this.btnPromptHTTPS);
            this.pnlInfoBar.Dock = DockStyle.Top;
            this.pnlInfoBar.ForeColor = System.Drawing.Color.Black;
            this.pnlInfoBar.Location = new Point(0, 0);
            this.pnlInfoBar.Name = "pnlInfoBar";
            this.pnlInfoBar.Size = new Size(0x23d, 0x1a);
            this.pnlInfoBar.TabIndex = 10;
            this.pnlInfoBar.Visible = false;
            this.btnPromptHTTPS.Cursor = Cursors.Hand;
            this.btnPromptHTTPS.Dock = DockStyle.Fill;
            this.btnPromptHTTPS.FlatStyle = FlatStyle.Flat;
            this.btnPromptHTTPS.ImageAlign = ContentAlignment.BottomRight;
            this.btnPromptHTTPS.ImageIndex = 12;
            this.btnPromptHTTPS.ImageList = this.imglSessionIcons;
            this.btnPromptHTTPS.Location = new Point(0, 0);
            this.btnPromptHTTPS.Name = "btnPromptHTTPS";
            this.btnPromptHTTPS.Size = new Size(0x23d, 0x1a);
            this.btnPromptHTTPS.TabIndex = 4;
            this.btnPromptHTTPS.Text = " HTTPS decryption is disabled. Click to configure...";
            this.btnPromptHTTPS.TextAlign = ContentAlignment.BottomCenter;
            this.btnPromptHTTPS.TextImageRelation = TextImageRelation.ImageBeforeText;
            this.btnPromptHTTPS.UseVisualStyleBackColor = true;
            this.btnPromptHTTPS.Click += new EventHandler(this.btnPromptHTTPS_Click);
            this.pageResponder.ImageIndex = 0x17;
            this.pageResponder.Location = new Point(4, 0x17);
            this.pageResponder.Name = "pageResponder";
            this.pageResponder.Size = new Size(0x23d, 0x156);
            this.pageResponder.TabIndex = 5;
            this.pageResponder.Text = "AutoResponder";
            this.pageResponder.UseVisualStyleBackColor = true;
            this.pageBuilder.AllowDrop = true;
            this.pageBuilder.ImageIndex = 0x23;
            this.pageBuilder.Location = new Point(4, 0x17);
            this.pageBuilder.Name = "pageBuilder";
            this.pageBuilder.Size = new Size(0x23d, 0x156);
            this.pageBuilder.TabIndex = 4;
            this.pageBuilder.Text = "Composer";
            this.pageBuilder.UseVisualStyleBackColor = true;
            this.dlgSaveBinary.AddExtension = false;
            this.dlgSaveBinary.Filter = "All files (*.*)|*.*";
            this.dlgSaveBinary.Title = "Save as...";
            this.notifyIcon.ContextMenuStrip = this.mnuNotify;
            this.notifyIcon.Icon = (Icon) manager.GetObject("notifyIcon.Icon");
            this.notifyIcon.Text = "Fiddler";
            this.notifyIcon.MouseClick += new MouseEventHandler(this.notifyIcon_MouseClick);
            this.mnuNotify.Items.AddRange(new ToolStripItem[] { this.miNotifyRestore, this.miNotifyCapturing, this.toolStripMenuItem1, this.miNotifyExit });
            this.mnuNotify.Name = "mnuNotify";
            this.mnuNotify.Size = new Size(0x9a, 0x4c);
            this.miNotifyRestore.Name = "miNotifyRestore";
            this.miNotifyRestore.Size = new Size(0x99, 0x16);
            this.miNotifyRestore.Text = "&Restore Fiddler";
            this.miNotifyRestore.Click += new EventHandler(this.miNotifyRestore_Click);
            this.miNotifyCapturing.CheckOnClick = true;
            this.miNotifyCapturing.Name = "miNotifyCapturing";
            this.miNotifyCapturing.Size = new Size(0x99, 0x16);
            this.miNotifyCapturing.Text = "&Capture Traffic";
            this.miNotifyCapturing.Click += new EventHandler(this.miNotifyCapture_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(150, 6);
            this.miNotifyExit.Name = "miNotifyExit";
            this.miNotifyExit.Size = new Size(0x99, 0x16);
            this.miNotifyExit.Text = "E&xit";
            this.miNotifyExit.Click += new EventHandler(this.miNotifyExit_Click);
            this.dlgSaveZip.DefaultExt = "saz";
            this.dlgSaveZip.Filter = "Session Archive (*.saz)|*.saz|Password-Protected SAZ (*.saz)|*.saz";
            this.dlgSaveZip.Title = "Save Session Archive";
            this.dlgLoadZip.DefaultExt = "saz";
            this.dlgLoadZip.Filter = "Session Archive (*.saz)|*.saz|All files|*.*";
            this.dlgLoadZip.Multiselect = true;
            this.dlgLoadZip.Title = "Load Session Archives";
            this.imglToolbar.ImageStream = (ImageListStreamer) manager.GetObject("imglToolbar.ImageStream");
            this.imglToolbar.TransparentColor = System.Drawing.Color.Magenta;
            this.imglToolbar.Images.SetKeyName(0, "textplain");
            this.imglToolbar.Images.SetKeyName(1, "image");
            this.imglToolbar.Images.SetKeyName(2, "script");
            this.imglToolbar.Images.SetKeyName(3, "xml");
            this.imglToolbar.Images.SetKeyName(4, "html");
            this.imglToolbar.Images.SetKeyName(5, "css");
            this.imglToolbar.Images.SetKeyName(6, "redirect");
            this.imglToolbar.Images.SetKeyName(7, "cached");
            this.imglToolbar.Images.SetKeyName(8, "redbang");
            this.imglToolbar.Images.SetKeyName(9, "lock");
            this.imglToolbar.Images.SetKeyName(10, "noentry");
            this.imglToolbar.Images.SetKeyName(11, "key");
            this.imglToolbar.Images.SetKeyName(12, "info");
            this.imglToolbar.Images.SetKeyName(13, "unchecked");
            this.imglToolbar.Images.SetKeyName(14, "checked");
            this.imglToolbar.Images.SetKeyName(15, "inspect");
            this.imglToolbar.Images.SetKeyName(0x10, "builder");
            this.imglToolbar.Images.SetKeyName(0x11, "timer");
            this.imglToolbar.Images.SetKeyName(0x12, "timeline");
            this.imglToolbar.Images.SetKeyName(0x13, "darkbolt");
            this.imglToolbar.Images.SetKeyName(20, "litbolt");
            this.imglToolbar.Images.SetKeyName(0x15, "filter");
            this.imglToolbar.Images.SetKeyName(0x16, "ie");
            this.imglToolbar.Images.SetKeyName(0x17, "back");
            this.imglToolbar.Images.SetKeyName(0x18, "copy");
            this.imglToolbar.Images.SetKeyName(0x19, "find");
            this.imglToolbar.Images.SetKeyName(0x1a, "help");
            this.imglToolbar.Images.SetKeyName(0x1b, "comment");
            this.imglToolbar.Images.SetKeyName(0x1c, "refresh");
            this.imglToolbar.Images.SetKeyName(0x1d, "remove");
            this.imglToolbar.Images.SetKeyName(30, "tools");
            this.imglToolbar.Images.SetKeyName(0x1f, "resume");
            this.imglToolbar.Images.SetKeyName(0x20, "save");
            this.imglToolbar.Images.SetKeyName(0x21, "mark");
            this.imglToolbar.Images.SetKeyName(0x22, "close");
            this.imglToolbar.Images.SetKeyName(0x23, "tearoff");
            this.imglToolbar.Images.SetKeyName(0x24, "streaming");
            this.imglToolbar.Images.SetKeyName(0x25, "clearcache");
            this.imglToolbar.Images.SetKeyName(0x26, "connected");
            this.imglToolbar.Images.SetKeyName(0x27, "notconnected");
            this.imglToolbar.Images.SetKeyName(40, "decoder");
            this.imglToolbar.Images.SetKeyName(0x29, "crosshair");
            this.imglToolbar.Images.SetKeyName(0x2a, "camera");
            this.imglToolbar.Images.SetKeyName(0x2b, "Win8");
            this.imglToolbar.Images.SetKeyName(0x2c, "textwizard");
            this.imglToolbar.Images.SetKeyName(0x2d, "RemoveDupes");
            this.pnlTopNotice.BackColor = System.Drawing.Color.Yellow;
            this.pnlTopNotice.Controls.Add(this.btnWarnDetached);
            this.pnlTopNotice.Dock = DockStyle.Top;
            this.pnlTopNotice.ForeColor = System.Drawing.Color.Black;
            this.pnlTopNotice.Location = new Point(0, 0);
            this.pnlTopNotice.Name = "pnlTopNotice";
            this.pnlTopNotice.Size = new Size(0x3d8, 0x1a);
            this.pnlTopNotice.TabIndex = 11;
            this.pnlTopNotice.Visible = false;
            this.btnWarnDetached.Cursor = Cursors.Hand;
            this.btnWarnDetached.Dock = DockStyle.Fill;
            this.btnWarnDetached.FlatStyle = FlatStyle.Flat;
            this.btnWarnDetached.ImageAlign = ContentAlignment.BottomRight;
            this.btnWarnDetached.ImageIndex = 12;
            this.btnWarnDetached.ImageList = this.imglSessionIcons;
            this.btnWarnDetached.Location = new Point(0, 0);
            this.btnWarnDetached.Name = "btnWarnDetached";
            this.btnWarnDetached.Size = new Size(0x3d8, 0x1a);
            this.btnWarnDetached.TabIndex = 4;
            this.btnWarnDetached.Text = "The system proxy was changed. Click to reenable Fiddler capture.";
            this.btnWarnDetached.TextAlign = ContentAlignment.BottomCenter;
            this.btnWarnDetached.TextImageRelation = TextImageRelation.ImageBeforeText;
            this.btnWarnDetached.UseVisualStyleBackColor = true;
            this.btnWarnDetached.Click += new EventHandler(this.btnWarnDetached_Click);
            this.AutoScaleBaseSize = new Size(5, 14);
            this.BackColor = SystemColors.AppWorkspace;
            base.ClientSize = new Size(0x3d8, 0x1a1);
            base.Controls.Add(this.pnlInspector);
            base.Controls.Add(this.splitterMain);
            base.Controls.Add(this.pnlSessions);
            base.Controls.Add(this.sbStatus);
            base.Controls.Add(this.pnlTopNotice);
            this.Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.KeyPreview = true;
            base.Menu = this.mnuMain;
            base.Name = "frmViewer";
            this.Text = "Fiddler Web Debugger";
            base.Closing += new CancelEventHandler(this.frmViewer_Closing);
            base.Load += new EventHandler(this.frmViewer_Load);
            base.KeyDown += new KeyEventHandler(this.frmViewer_KeyDown);
            this.sbpCapture.EndInit();
            this.sbpProcessFilter.EndInit();
            this.sbpBreakpoints.EndInit();
            this.sbpSelCount.EndInit();
            this.sbpMemory.EndInit();
            this.sbpInfo.EndInit();
            this.pnlSessions.ResumeLayout(false);
            this.pnlSessions.PerformLayout();
            this.pnlInspector.ResumeLayout(false);
            this.tabsViews.ResumeLayout(false);
            this.pageInspector.ResumeLayout(false);
            this.pnlInfoTip.ResumeLayout(false);
            this.pnlSessionControls.ResumeLayout(false);
            this.pnlInfoTipRequest.ResumeLayout(false);
            this.pnlInfoBar.ResumeLayout(false);
            this.mnuNotify.ResumeLayout(false);
            this.pnlTopNotice.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void lvSessions_DoubleClick(object sender, EventArgs e)
        {
            this.actInspectSession();
        }

        private void lvSessions_DragDrop(object sender, DragEventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.OnDrop");
            try
            {
                if (!e.Data.GetDataPresent(typeof(ToolStripItem)))
                {
                    if (e.Data.GetDataPresent(DataFormats.FileDrop))
                    {
                        string[] strArray = (string[]) e.Data.GetData("FileDrop", false);
                        if (strArray != null)
                        {
                            foreach (string str in strArray)
                            {
                                if (Directory.Exists(str))
                                {
                                    this.CreateSessionsForFolder(str);
                                }
                                else
                                {
                                    this.CreateSessionsForFile(str, string.Empty);
                                }
                            }
                            e.Effect = DragDropEffects.Copy;
                            return;
                        }
                    }
                    if (e.Data.GetDataPresent("FileContents"))
                    {
                        try
                        {
                            MemoryStream stream = (MemoryStream) e.Data.GetData("FileContents");
                            if (stream != null)
                            {
                                string tempFileName = Path.GetTempFileName();
                                FiddlerApplication.LogLeakedFile(tempFileName);
                                System.IO.File.WriteAllBytes(tempFileName, stream.ToArray());
                                this.actLoadSessionArchive(tempFileName);
                                e.Effect = DragDropEffects.Copy;
                            }
                            else
                            {
                                e.Effect = DragDropEffects.None;
                            }
                            return;
                        }
                        catch (Exception exception)
                        {
                            FiddlerApplication.ReportException(exception, "Drag/Drop Failure");
                        }
                    }
                    if (e.Data.GetDataPresent("Fiddler.Session[]"))
                    {
                        Session[] sessionArray;
                        try
                        {
                            sessionArray = (Session[]) e.Data.GetData("Fiddler.Session[]");
                        }
                        catch (InvalidCastException exception2)
                        {
                            if (e.Data.GetDataPresent("Fiddler.SessionData[]"))
                            {
                                try
                                {
                                    object[] objArray = (object[]) e.Data.GetData("Fiddler.SessionData[]");
                                    sessionArray = new Session[objArray.Length];
                                    for (int i = 0; i < objArray.Length; i++)
                                    {
                                        SessionData oSD = (SessionData) objArray[i];
                                        sessionArray[i] = new Session(oSD);
                                        this.AddReportedSession(sessionArray[i]);
                                    }
                                }
                                catch (Exception exception3)
                                {
                                    FiddlerApplication.ReportException(exception3, "Drag/Drop Failure");
                                }
                            }
                            else
                            {
                                FiddlerApplication.DoNotifyUser("Fiddler is unable to accept drops from other processes.\n\n" + exception2.Message, "Operation failed");
                            }
                            return;
                        }
                        catch
                        {
                            return;
                        }
                        foreach (Session session in sessionArray)
                        {
                            try
                            {
                                MemoryStream oFS = new MemoryStream();
                                MemoryStream stream3 = new MemoryStream();
                                MemoryStream strmMetadata = new MemoryStream();
                                MemoryStream stream5 = new MemoryStream();
                                session.WriteRequestToStream(false, true, oFS);
                                session.WriteResponseToStream(stream3, false);
                                session.WriteMetadataToStream(strmMetadata);
                                if (strmMetadata.Length < 1L)
                                {
                                    strmMetadata = null;
                                }
                                else
                                {
                                    strmMetadata.Position = 0L;
                                }
                                session.WriteWebSocketMessagesToStream(stream5);
                                if (stream5.Length < 1L)
                                {
                                    stream5 = null;
                                }
                                else
                                {
                                    stream5.Position = 0L;
                                }
                                Session oS = this.AddReportedSession(oFS.ToArray(), stream3.ToArray(), strmMetadata);
                                if (stream5 != null)
                                {
                                    WebSocket.LoadWebSocketMessagesFromStream(oS, stream5);
                                }
                            }
                            catch (Exception exception4)
                            {
                                FiddlerApplication.ReportException(exception4);
                            }
                        }
                    }
                    else
                    {
                        e.Effect = DragDropEffects.None;
                    }
                }
                else
                {
                    e.Effect = DragDropEffects.Move;
                    ToolStripItem data = e.Data.GetData(typeof(ToolStripItem)) as ToolStripItem;
                    if (data != null)
                    {
                        FiddlerToolbar.RemoveItem(data);
                    }
                }
            }
            catch (InvalidCastException)
            {
            }
        }

        private void lvSessions_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Link | DragDropEffects.Copy;
            }
            else if (e.Data.GetDataPresent("Fiddler.Session[]") || e.Data.GetDataPresent("FileContents"))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else if (e.Data.GetDataPresent(typeof(ToolStripItem)))
            {
                e.Effect = DragDropEffects.Move;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void lvSessions_ItemDrag(object sender, ItemDragEventArgs e)
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                try
                {
                    SessionData[] data = new SessionData[selectedSessions.Length];
                    for (int i = 0; i < selectedSessions.Length; i++)
                    {
                        data[i] = new SessionData(selectedSessions[i]);
                    }
                    DataObject obj2 = new DataObject();
                    obj2.SetData(selectedSessions);
                    obj2.SetData(data);
                    this.lvSessions.AllowDrop = false;
                    this.lvSessions.DoDragDrop(obj2, DragDropEffects.Copy);
                    this.lvSessions.AllowDrop = true;
                }
                catch (Exception)
                {
                }
            }
        }

        private void lvSessions_ItemShowProperties(object sender, EventArgs e)
        {
            this.actViewSessionProperties();
        }

        private void lvSessions_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Return)
            {
                e.Handled = e.SuppressKeyPress = true;
                if (this.lvSessions.SelectedCount > 1)
                {
                    Utilities.activateTabByTitle("Statistics", this.tabsViews);
                }
                else
                {
                    this.actInspectSession();
                }
            }
            if (e.Modifiers == (Keys.Control | Keys.Shift))
            {
                switch (e.KeyCode)
                {
                    case Keys.S:
                        e.Handled = e.SuppressKeyPress = true;
                        this.miSessionCopyEntire_Click(null, null);
                        break;

                    case Keys.T:
                        e.Handled = e.SuppressKeyPress = true;
                        this.miSessionCopyHeadlines_Click(null, null);
                        break;

                    case Keys.C:
                        e.Handled = e.SuppressKeyPress = true;
                        this.miSessionCopyHeaders_Click(null, null);
                        break;
                }
            }
            if (e.Modifiers != Keys.Control)
            {
                if ((e.KeyData == (Keys.Alt | Keys.Control | Keys.D0)) || (e.KeyData == (Keys.Alt | Keys.Control | Keys.NumPad0)))
                {
                    this.actSetFontSize(8.25f);
                    e.SuppressKeyPress = e.Handled = true;
                    return;
                }
                if (e.Modifiers == Keys.Shift)
                {
                    Keys keyCode = e.KeyCode;
                    if (keyCode != Keys.Return)
                    {
                        if (keyCode == Keys.Delete)
                        {
                            e.Handled = e.SuppressKeyPress = true;
                            this.miSessionRemoveUnselected_Click(null, null);
                            return;
                        }
                        if (keyCode != Keys.F3)
                        {
                            goto Label_02FD;
                        }
                    }
                    else
                    {
                        e.Handled = e.SuppressKeyPress = true;
                        this.actInspectInNewWindow();
                        return;
                    }
                    e.Handled = e.SuppressKeyPress = true;
                    this.actDoSelectNextFindResult(false);
                    return;
                }
            }
            else
            {
                bool flag = true;
                switch (e.KeyCode)
                {
                    case Keys.U:
                        this.miSessionCopyURL_Click(null, null);
                        break;

                    case Keys.W:
                        this.miSessionWinDiff_Click(null, null);
                        break;

                    case Keys.X:
                        this.miSessionRemoveAll_Click(null, null);
                        break;

                    case Keys.Z:
                        this.actUndeleteSessions();
                        break;

                    case Keys.NumPad0:
                    case Keys.D0:
                        this.miSessionMarkColor_Click(this.miSessionMarkUnmark, null);
                        break;

                    case Keys.NumPad1:
                    case Keys.D1:
                        this.miSessionMarkColor_Click(this.miSessionMarkRed, null);
                        break;

                    case Keys.NumPad2:
                    case Keys.D2:
                        this.miSessionMarkColor_Click(this.miSessionMarkBlue, null);
                        break;

                    case Keys.NumPad3:
                    case Keys.D3:
                        this.miSessionMarkColor_Click(this.miSessionMarkGold, null);
                        break;

                    case Keys.NumPad4:
                    case Keys.D4:
                        this.miSessionMarkColor_Click(this.miSessionMarkGreen, null);
                        break;

                    case Keys.NumPad5:
                    case Keys.D5:
                        this.miSessionMarkColor_Click(this.miSessionMarkOrange, null);
                        break;

                    case Keys.NumPad6:
                    case Keys.D6:
                        this.miSessionMarkColor_Click(this.miSessionMarkPurple, null);
                        break;

                    case Keys.I:
                        this.actInvertSelectedSessions();
                        break;

                    case Keys.A:
                        this.actSelectAll();
                        break;

                    case Keys.C:
                        this.miSessionCopySummary_Click(null, null);
                        break;

                    default:
                        flag = false;
                        break;
                }
                if (flag)
                {
                    e.SuppressKeyPress = e.Handled = true;
                }
                return;
            }
        Label_02FD:
            if (e.Modifiers == Keys.Alt)
            {
                switch (e.KeyCode)
                {
                    case Keys.D0:
                    case Keys.NumPad0:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions(null);
                        return;

                    case Keys.D1:
                    case Keys.NumPad1:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Red");
                        return;

                    case Keys.D2:
                    case Keys.NumPad2:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Blue");
                        return;

                    case Keys.D3:
                    case Keys.NumPad3:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Gold");
                        return;

                    case Keys.D4:
                    case Keys.NumPad4:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Green");
                        return;

                    case Keys.D5:
                    case Keys.NumPad5:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Orange");
                        return;

                    case Keys.D6:
                    case Keys.NumPad6:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Purple");
                        return;

                    case Keys.Subtract:
                    case Keys.OemMinus:
                        e.Handled = e.SuppressKeyPress = true;
                        this.actSelectMarkedSessions("Strikeout");
                        return;
                }
            }
            if (((e.KeyCode == Keys.R) || (e.KeyCode == Keys.U)) && ((e.Modifiers == Keys.None) || (e.Modifiers == Keys.Shift)))
            {
                switch (e.KeyCode)
                {
                    case Keys.R:
                        e.SuppressKeyPress = e.Handled = true;
                        this.miSessionReissueRequests_Click(null, null);
                        return;

                    case Keys.U:
                        e.SuppressKeyPress = e.Handled = true;
                        this.miSessionReissueUnconditionally_Click(null, null);
                        return;
                }
            }
            if (e.Modifiers == Keys.None)
            {
                Keys keys6 = e.KeyCode;
                if (keys6 <= Keys.I)
                {
                    if (keys6 > Keys.Space)
                    {
                        switch (keys6)
                        {
                            case Keys.C:
                                e.Handled = e.SuppressKeyPress = true;
                                this.miSessionSelectChildren_Click(null, null);
                                return;

                            case Keys.D:
                                e.Handled = e.SuppressKeyPress = true;
                                this.miSessionSelectDuplicates_Click(null, null);
                                return;

                            case Keys.E:
                                e.Handled = e.SuppressKeyPress = true;
                                this.actReissueSelected(true);
                                return;

                            case Keys.F:
                            case Keys.G:
                            case Keys.H:
                                return;

                            case Keys.I:
                                e.Handled = e.SuppressKeyPress = true;
                                this.actIndent(1);
                                return;

                            case Keys.Delete:
                                e.Handled = e.SuppressKeyPress = true;
                                this.miSessionRemoveSelected_Click(null, null);
                                return;
                        }
                    }
                    else if (keys6 == Keys.Escape)
                    {
                        e.Handled = e.SuppressKeyPress = true;
                        FiddlerApplication.SuppressReportUpdates = true;
                        this.lvSessions.SelectedItems.Clear();
                        FiddlerApplication.SuppressReportUpdates = false;
                    }
                    else if ((keys6 == Keys.Space) && (this.lvSessions.SelectedCount > 0))
                    {
                        e.Handled = e.SuppressKeyPress = true;
                        this.lvSessions.SelectedItems[0].EnsureVisible();
                    }
                }
                else
                {
                    switch (keys6)
                    {
                        case Keys.Oemplus:
                        {
                            DateTime now = DateTime.Now;
                            e.Handled = e.SuppressKeyPress = true;
                            HTTPRequestHeaders headersRequest = new HTTPRequestHeaders('/' + now.ToString("HH-mm-ss"), new string[] { "Host: SPLITTER", "Date: " + now.ToUniversalTime().ToString("r") });
                            Session session = FiddlerApplication.UI.AddMockSession(headersRequest, null, null, Encoding.ASCII.GetBytes("This Session was generated by the Fiddler user hitting the = key to create a splitting line in the Web Sessions list.\n" + now.ToLongTimeString()));
                            session.oFlags["ui-strikeout"] = "usersplit";
                            session.oFlags["ui-backcolor"] = "Magenta";
                            return;
                        }
                        case Keys.Oemcomma:
                            e.Handled = e.SuppressKeyPress = true;
                            this.actDoSelectNextFindResult(false);
                            return;

                        case Keys.OemMinus:
                        case Keys.Subtract:
                            e.Handled = e.SuppressKeyPress = true;
                            this.actSessionsStrikeout();
                            return;

                        case Keys.OemPeriod:
                        case Keys.F3:
                            e.Handled = e.SuppressKeyPress = true;
                            this.actDoSelectNextFindResult(true);
                            return;

                        case Keys.OemQuestion:
                            e.Handled = e.SuppressKeyPress = true;
                            this.txtExec.Focus();
                            if (string.IsNullOrEmpty(this.txtExec.Text))
                            {
                                this.txtExec.Text = "?";
                                this.txtExec.SelectionStart = 1;
                                this.txtExec.SelectionLength = 0;
                            }
                            return;

                        case Keys.M:
                            e.Handled = e.SuppressKeyPress = true;
                            return;

                        case Keys.N:
                        case Keys.Q:
                        case Keys.R:
                            return;

                        case Keys.O:
                            e.Handled = e.SuppressKeyPress = true;
                            this.actIndent(-1);
                            return;

                        case Keys.P:
                            e.Handled = e.SuppressKeyPress = true;
                            this.miSessionSelectParent_Click(null, null);
                            return;

                        case Keys.S:
                            e.Handled = e.SuppressKeyPress = true;
                            this.actReissueSequentially();
                            return;

                        case Keys.V:
                            e.Handled = e.SuppressKeyPress = true;
                            this.actReissueAndVerify();
                            return;
                    }
                }
            }
        }

        private void lvSessions_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.M)
            {
                e.Handled = e.SuppressKeyPress = true;
                this.actCommentSelectedSessions();
            }
            else if (e.KeyData == (Keys.Shift | Keys.M))
            {
                e.Handled = e.SuppressKeyPress = true;
                this.actAddCommentSession();
            }
            else if (e.Modifiers == Keys.None)
            {
                Keys keyCode = e.KeyCode;
                switch (keyCode)
                {
                    case Keys.Back:
                        e.SuppressKeyPress = e.Handled = true;
                        this.lvSessions.ActivatePreviousItem();
                        return;

                    case Keys.Insert:
                        e.SuppressKeyPress = e.Handled = true;
                        this.actToggleMark();
                        return;
                }
                if (keyCode == Keys.F2)
                {
                    e.SuppressKeyPress = e.Handled = true;
                    this.miSessionUnlock_Click(null, null);
                }
            }
        }

        private void lvSessions_OnSessionsAdded()
        {
            this.UpdateStatusBar(true);
        }

        private void lvSessions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing)
            {
                this.lvSessions.StoreActiveItem();
                this.actRefreshUI(true);
            }
        }

        [STAThread]
        private static void Main(string[] arrArgs)
        {
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(frmViewer.UnhandledExceptionHandler);
            RunMain(arrArgs);
        }

        private void miBreakAtChoice_Check(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Rules.BreakAtAdjusted");
            MenuItem item = sender as MenuItem;
            if (item != null)
            {
                this.miRulesBreakAtNothing.Checked = false;
                this.miRulesBreakAtRequest.Checked = false;
                this.miRulesBreakAtResponse.Checked = false;
                item.Checked = true;
                this._UpdateBreakpointMenu();
            }
        }

        private void miCaptureEnabled_Click(object sender, EventArgs e)
        {
            this.actToggleCapture();
        }

        private void miCaptureRules_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Rules.CustomizeRules");
            try
            {
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.script.delaycreate", true) && !System.IO.File.Exists(CONFIG.GetPath("CustomRules")))
                {
                    FiddlerApplication.Log.LogFormat("Generating user's script file; copying '{0}' to '{1}'.", new object[] { CONFIG.GetPath("SampleRules"), CONFIG.GetPath("CustomRules") });
                    System.IO.File.Copy(CONFIG.GetPath("SampleRules"), CONFIG.GetPath("CustomRules"));
                }
                if ((CONFIG.JSEditor == "notepad.exe") && FiddlerApplication.Prefs.GetBoolPref("fiddler.inspectors.response.AdvertiseFSE", true))
                {
                    DialogResult result = MessageBox.Show("Would you like to download and install the FiddlerScript Editor for syntax-highlighting, code-completion, and more?", "Script Editor", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DialogResult.Yes == result)
                    {
                        Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("SYNTAXVIEWINSTALL"));
                        return;
                    }
                    FiddlerApplication.Prefs.SetBoolPref("fiddler.inspectors.response.AdvertiseFSE", false);
                }
                string arguments = "\"" + CONFIG.GetPath("CustomRules") + "\"";
                using (Process.Start(CONFIG.JSEditor, arguments))
                {
                }
            }
            catch (Exception exception)
            {
                DialogResult result2 = MessageBox.Show("Failed to launch the editor for FiddlerScript.\nJSEditor: " + CONFIG.JSEditor + "\n\n" + exception.Message + "\n\nWould you like to configure the FiddlerScript Editor?", "Editor Cannot Start", MessageBoxButtons.YesNo, MessageBoxIcon.Hand);
                if (DialogResult.Yes == result2)
                {
                    this.actShowOptions("Tools");
                }
            }
        }

        private void miContextSaveAndOpenBody_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.SaveAndOpen");
            this.actSaveAndOpenResponseBodies();
        }

        private void miEditMarkStrike_Click(object sender, EventArgs e)
        {
            this.actSessionsStrikeout();
        }

        private void miEditPaste_Click(object sender, EventArgs e)
        {
            this.actPasteAsSessions();
        }

        private void miEditSelectAll_Click(object sender, EventArgs e)
        {
            this.actSelectAll();
        }

        private void miEditUndelete_Click(object sender, EventArgs e)
        {
            this.actUndeleteSessions();
        }

        private void miEditUnlock_Click(object sender, EventArgs e)
        {
            this.actToggleSessionUnlock();
        }

        private void miExit_Click(object sender, EventArgs e)
        {
            this.actExit();
        }

        private void miFileLoad_Click(object sender, EventArgs e)
        {
            if (this.dlgLoadZip.ShowDialog(this) == DialogResult.OK)
            {
                foreach (string str in this.dlgLoadZip.FileNames)
                {
                    this.actLoadSessionArchive(str);
                }
                try
                {
                    this.dlgLoadZip.InitialDirectory = Path.GetDirectoryName(this.dlgLoadZip.FileNames[0]);
                    this.dlgLoadZip.FileName = string.Empty;
                }
                catch
                {
                }
            }
        }

        private void miFileMinimizeToTray_Click(object sender, EventArgs e)
        {
            this.actMinimizeToTray();
        }

        private void miFileMRUClear_Click(object sender, EventArgs e)
        {
            this.oSAZMRU.PurgeAll();
        }

        private void miFileMRUPrune_Click(object sender, EventArgs e)
        {
            this.oSAZMRU.PruneObsolete();
        }

        private void miFileNew_Click(object sender, EventArgs e)
        {
            Utilities.RunExecutable(Assembly.GetExecutingAssembly().Location, "-viewer");
        }

        private void miFileSaveAllSessions_Click(object sender, EventArgs e)
        {
            this.actSaveAllSessions();
        }

        private void miFileSaveAndOpenBody_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.File.SaveAndOpen");
            this.actSaveAndOpenResponseBodies();
        }

        private void miHelpAbout_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.About");
            frmAbout.DoAboutBox();
        }

        private void miHelpBook_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.OpenBook");
            if (System.IO.File.Exists(CONFIG.GetPath("App") + "Debugging with Fiddler.pdf"))
            {
                Utilities.RunExecutable(CONFIG.GetPath("App") + "Debugging with Fiddler.pdf", "");
            }
            else if (MessageBox.Show("The file 'Debugging with Fiddler.pdf' was not found in the Fiddler installation folder.\n\nWould you like to learn more about the Fiddler book?", "Get the Fiddler Book?", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
            {
                Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("FiddlerBook"));
            }
        }

        private void miHelpCommunity_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.Discussions");
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("FIDDLERDISC"));
        }

        private void miHelpContents_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.OpenHelp");
            this.actGetHelp();
        }

        private void miHelpHTTP_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.HTTPReference");
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("HTTPREFERENCE"));
        }

        private void miHelpPrioritySupport_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.PrioritySupport");
            Utilities.LaunchHyperlink(CONFIG.GetUrl("PrioritySupport"));
        }

        private void miHelpShowFiltered_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.Troubleshoot");
            this.miHelpShowFiltered.Checked = !this.miHelpShowFiltered.Checked;
            if (this.miHelpShowFiltered.Checked)
            {
                if (FiddlerApplication.IsViewerMode)
                {
                    FiddlerApplication.DoNotifyUser("Fiddler is running in View-Only mode, used for viewing traffic captures only. Open a default instance of Fiddler to capture traffic.", "Problem Detected", MessageBoxIcon.Asterisk);
                }
                else if (!FiddlerApplication.oProxy.IsAttached)
                {
                    FiddlerApplication.DoNotifyUser("Fiddler is not currently registered as the system proxy. Please check the 'Capture Traffic' item on the File menu.", "Problem Detected", MessageBoxIcon.Asterisk);
                }
                else
                {
                    string listeningProcess = Winsock.GetListeningProcess(CONFIG.ListenPort);
                    if (!string.IsNullOrEmpty(listeningProcess) && !listeningProcess.EndsWith(Process.GetCurrentProcess().Id.ToString()))
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("Fiddler's configured Listen Port ({0}) is also in use (for at least some IP addresses) by a different process ('{1}').\n\nThis problem may cause some traffic to be missed.", CONFIG.ListenPort, listeningProcess), "Problem Detected", MessageBoxIcon.Asterisk);
                    }
                }
                if (DialogResult.Cancel == MessageBox.Show("Filter troubleshooting is now enabled.\n\nFiddler will show all sessions that Filters would otherwise hide, using a 'strikethrough' font. The Comments column for each filtered session will show which Filter was responsible for hiding the traffic to allow you to adjust your filters accordingly.\n\nFor more information, see " + CONFIG.GetRedirUrl("Filters"), "Troubleshooting Mode", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk))
                {
                    this.miHelpShowFiltered.Checked = false;
                }
                else if (!FiddlerApplication.IsViewerMode)
                {
                    this.actLaunchTroubleshooter();
                }
            }
            FiddlerApplication.Prefs.SetBoolPref("fiddler.filters.ephemeral.debugmode", this.miHelpShowFiltered.Checked);
        }

        private void miHelpUpdates_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(new ThreadStart(this.actCheckForUpdatesVerbose));
            thread.IsBackground = true;
            thread.Start();
        }

        private void miInspectorCopy_Click(object sender, EventArgs e)
        {
            try
            {
                if ((this.mnuInspectorsContext.SourceControl != null) && (this.mnuInspectorsContext.SourceControl is TabControl))
                {
                    TabPage selectedTab = ((TabControl) this.mnuInspectorsContext.SourceControl).SelectedTab;
                    if ((selectedTab != null) && (selectedTab.Tag != null))
                    {
                        ((Inspector2) selectedTab.Tag).CopyAsImage(selectedTab);
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void miInspectorHide_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Inspectors.HideOne");
            if ((this.mnuInspectorsContext.SourceControl != null) && (this.mnuInspectorsContext.SourceControl is TabControl))
            {
                TabPage selectedTab = ((TabControl) this.mnuInspectorsContext.SourceControl).SelectedTab;
                if ((selectedTab != null) && (selectedTab.Tag != null))
                {
                    if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
                    {
                        TabControl sourceControl = this.mnuInspectorsContext.SourceControl as TabControl;
                        foreach (TabPage page2 in sourceControl.TabPages)
                        {
                            if (selectedTab != page2)
                            {
                                sourceControl.TabPages.Remove(page2);
                            }
                        }
                    }
                    else
                    {
                        string fullName = ((Inspector2) selectedTab.Tag).GetType().FullName;
                        if (DialogResult.Yes == MessageBox.Show(string.Format("Are you sure you want to permanently remove the {0} Inspector?\n\n(To restore it later, use about:config)", fullName), "Confirm Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
                        {
                            FiddlerApplication.Prefs.SetStringPref("fiddler.inspectors.hidelist", FiddlerApplication.Prefs.GetStringPref("fiddler.inspectors.hidelist", string.Empty) + ";" + fullName);
                            ((TabControl) this.mnuInspectorsContext.SourceControl).TabPages.Remove(selectedTab);
                        }
                    }
                }
            }
        }

        private void miInspectorProperties_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Inspector.ShowProperties");
            if ((this.mnuInspectorsContext.SourceControl != null) && (this.mnuInspectorsContext.SourceControl is TabControl))
            {
                TabPage selectedTab = ((TabControl) this.mnuInspectorsContext.SourceControl).SelectedTab;
                if ((selectedTab != null) && (selectedTab.Tag != null))
                {
                    ((Inspector2) selectedTab.Tag).ShowAboutBox();
                }
            }
        }

        private void miManipulateGZIP_Click(object sender, EventArgs e)
        {
            this.miManipulateGZIP.Checked = !this.miManipulateGZIP.Checked;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.forcegzip", this.miManipulateGZIP.Checked);
        }

        private void miManipulateIgnoreImages_Click(object sender, EventArgs e)
        {
            this.miManipulateIgnoreImages.Checked = !this.miManipulateIgnoreImages.Checked;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.rules.hideimages", this.miManipulateIgnoreImages.Checked);
        }

        private void miManipulateRequireProxyAuth_Click(object sender, EventArgs e)
        {
            this.miManipulateRequireProxyAuth.Checked = !this.miManipulateRequireProxyAuth.Checked;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ephemeral.rules.requireproxyauth", this.miManipulateRequireProxyAuth.Checked);
        }

        private void miNotifyCapture_Click(object sender, EventArgs e)
        {
            this.actToggleCapture();
        }

        private void miNotifyExit_Click(object sender, EventArgs e)
        {
            this.actExit();
        }

        private void miNotifyRestore_Click(object sender, EventArgs e)
        {
            this.actRestoreWindow();
        }

        private void miReportBug_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Menu.Help.ReportBug");
            try
            {
                using (Process.Start("mailto:fiddler@telerik.com?Subject=Fiddler%20" + Application.ProductVersion))
                {
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Looks like you don't have a mailto: handler installed.\nJust send an email to fiddler@telerik.com\n" + exception.Message, "Oops");
            }
        }

        private void miRulesBreakpointsIgnoreImages_Click(object sender, EventArgs e)
        {
            this.miRulesBreakpointsIgnoreImages.Checked = !this.miRulesBreakpointsIgnoreImages.Checked;
            CONFIG.bBreakOnImages = !this.miRulesBreakpointsIgnoreImages.Checked;
        }

        private void miRulesIgnoreConnects_Click(object sender, EventArgs e)
        {
            this.miRulesIgnoreConnects.Checked = !this.miRulesIgnoreConnects.Checked;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.rules.hideconnects", this.miRulesIgnoreConnects.Checked);
        }

        private void miRulesRemoveEncoding_Click(object sender, EventArgs e)
        {
            this.miRulesRemoveEncoding.Checked = !this.miRulesRemoveEncoding.Checked;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.rules.removeencoding", this.miRulesRemoveEncoding.Checked);
        }

        private void miSessionAbort_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.Abort");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length >= 1)
            {
                foreach (Session session in selectedSessions)
                {
                    session.Abort();
                }
            }
        }

        private void miSessionAddComment_Click(object sender, EventArgs e)
        {
            this.actCommentSelectedSessions();
        }

        private void miSessionCOMETPeek_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.COMETPeek");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                firstSelectedSession.COMETPeek();
                FiddlerApplication.UI.actRefreshUI();
            }
        }

        private void miSessionCopyColumn_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.CopyColumn");
            try
            {
                ListView.SelectedListViewItemCollection selectedItems = this.lvSessions.SelectedItems;
                if (selectedItems.Count >= 1)
                {
                    int subItemIndexFromPoint = this.lvSessions.GetSubItemIndexFromPoint(this.lvSessions.PointToClient(this._ptContextPopup));
                    if (subItemIndexFromPoint >= 0)
                    {
                        StringBuilder builder = new StringBuilder(0x200);
                        foreach (ListViewItem item in selectedItems)
                        {
                            string str = (item.SubItems.Count > subItemIndexFromPoint) ? item.SubItems[subItemIndexFromPoint].Text : string.Empty;
                            builder.AppendLine(str);
                        }
                        Utilities.CopyToClipboard(builder.ToString());
                    }
                }
            }
            catch
            {
            }
        }

        private void miSessionCopyEntire_Click(object sender, EventArgs e)
        {
            this.actSessionCopy();
        }

        private void miSessionCopyHeaders_Click(object sender, EventArgs e)
        {
            this.actSessionCopyHeaders();
        }

        private void miSessionCopyHeadlines_Click(object sender, EventArgs e)
        {
            this.actSessionCopyHeadlines();
        }

        private void miSessionCopyResponseAsDataURI_Click(object sender, EventArgs e)
        {
            try
            {
                Session[] selectedSessions = this.GetSelectedSessions();
                if (selectedSessions.Length >= 1)
                {
                    StringBuilder builder = new StringBuilder(0x200);
                    bool flag = true;
                    foreach (Session session in selectedSessions)
                    {
                        if (session.bHasResponse)
                        {
                            if (!flag)
                            {
                                builder.Append(Environment.NewLine);
                            }
                            builder.Append("data:");
                            builder.Append(string.IsNullOrEmpty(session.oResponse.MIMEType) ? "application/octet-stream" : session.oResponse.MIMEType);
                            builder.Append(";base64,");
                            builder.Append(Convert.ToBase64String(session.responseBodyBytes));
                            flag = false;
                        }
                    }
                    Utilities.CopyToClipboard(builder.ToString());
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception);
            }
        }

        private void miSessionCopySummary_Click(object sender, EventArgs e)
        {
            this.actSessionCopySummary();
        }

        private void miSessionCopyURL_Click(object sender, EventArgs e)
        {
            this.actSessionCopyURL();
        }

        private void miSessionFilter_Popup(object sender, EventArgs e)
        {
            EventHandler handler4 = null;
            EventHandler handler5 = null;
            this.miSessionFilter.MenuItems.Clear();
            Session firstSelectedSession = FiddlerApplication.UI.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                <>c__DisplayClass2b classb;
                int iPID = firstSelectedSession.LocalProcessID;
                if (iPID != 0)
                {
                    EventHandler handler = null;
                    <>c__DisplayClass2b CS$<>8__locals2c = classb;
                    string sProcName = Utilities.TrimAfter(firstSelectedSession.LocalProcess, ':') + ":";
                    if (sProcName.Length > 1)
                    {
                        if (handler == null)
                        {
                            handler = delegate (object s, EventArgs eA) {
                                FilterTargetSystem.AddProcessNameFilter(sProcName);
                                LinkLabel label = CS$<>8__locals2c.<>4__this._AddFilterToGutter(string.Format("Hide '{0}*'", sProcName));
                                label.Tag = sProcName;
                                label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                                    if (ee.Button == MouseButtons.Right)
                                    {
                                        Label label = ss as Label;
                                        FilterTargetSystem.RemoveProcessNameFilter(label.Tag as string);
                                        label.Dispose();
                                        CS$<>8__locals2c.<>4__this._HideFilterGutterIfEmpty();
                                    }
                                };
                            };
                        }
                        this.miSessionFilter.MenuItems.Add(string.Format("Hide '{0}*'", sProcName)).Click += handler;
                    }
                    if (handler4 == null)
                    {
                        handler4 = delegate (object s, EventArgs eA) {
                            FilterTargetSystem.AddHidePIDFilter(iPID);
                            LinkLabel label = this._AddFilterToGutter(string.Format("Hide Process={0}", iPID));
                            label.Tag = iPID;
                            label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                                if (ee.Button == MouseButtons.Right)
                                {
                                    Label label = ss as Label;
                                    FilterTargetSystem.RemovePIDFilter((int) label.Tag);
                                    label.Dispose();
                                    this._HideFilterGutterIfEmpty();
                                }
                            };
                        };
                    }
                    this.miSessionFilter.MenuItems.Add(string.Format("Hide &Process={0}", iPID)).Click += handler4;
                    if (handler5 == null)
                    {
                        handler5 = delegate (object s, EventArgs eA) {
                            FilterTargetSystem.AddExclusiveFilter(iPID);
                            LinkLabel label = this._AddFilterToGutter(string.Format("Hide Process!={0}", iPID));
                            label.Tag = iPID;
                            label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                                if (ee.Button == MouseButtons.Right)
                                {
                                    Label label = ss as Label;
                                    FilterTargetSystem.RemoveExclusiveFilter((int) label.Tag);
                                    label.Dispose();
                                    this._HideFilterGutterIfEmpty();
                                }
                            };
                        };
                    }
                    this.miSessionFilter.MenuItems.Add(string.Format("Show &Only Process={0}", iPID)).Click += handler5;
                }
                string sHost = firstSelectedSession.hostname;
                this.miSessionFilter.MenuItems.Add(string.Format("Hide '{0}'", sHost)).Click += delegate (object s, EventArgs eA) {
                    FilterTargetSystem.AddHideHostNameFilter(sHost);
                    LinkLabel label = this._AddFilterToGutter(string.Format("Hide '{0}'", sHost));
                    label.Tag = sHost;
                    label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                        if (ee.Button == MouseButtons.Right)
                        {
                            Label label = ss as Label;
                            FilterTargetSystem.RemoveHostNameFilter((string) label.Tag);
                            label.Dispose();
                            this._HideFilterGutterIfEmpty();
                        }
                    };
                };
                EventHandler handler2 = null;
                <>c__DisplayClass2b CS$<>8__locals2c = classb;
                string sPath = FilterTargetSystem._GetFirstPathComponent(firstSelectedSession.PathAndQuery);
                if (!string.IsNullOrEmpty(sPath))
                {
                    if (handler2 == null)
                    {
                        handler2 = delegate (object s, EventArgs eA) {
                            FilterTargetSystem.AddHidePathFilter(sPath);
                            LinkLabel label = CS$<>8__locals2c.<>4__this._AddFilterToGutter(string.Format("Hide '{0}'", sPath));
                            label.Tag = sPath;
                            label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                                if (ee.Button == MouseButtons.Right)
                                {
                                    Label label = ss as Label;
                                    FilterTargetSystem.RemoveHidePathFilter((string) label.Tag);
                                    label.Dispose();
                                    CS$<>8__locals2c.<>4__this._HideFilterGutterIfEmpty();
                                }
                            };
                        };
                    }
                    this.miSessionFilter.MenuItems.Add(string.Format("Hide '{0}'", Utilities.PrefixEllipsizeIfNeeded(sPath, 0x20))).Click += handler2;
                }
                <>c__DisplayClass2b CS$<>8__locals2c = classb;
                string sUri = firstSelectedSession.fullUrl;
                this.miSessionFilter.MenuItems.Add("Hide Url...").Click += delegate (object s, EventArgs eA) {
                    sUri = frmPrompt.GetUserString("Hide Sessions with Url...", "Hide all Sessions whose Url contains...", sUri, true);
                    if (!string.IsNullOrEmpty(sUri))
                    {
                        FilterTargetSystem.AddURLContainsFilter(sUri);
                        LinkLabel label = CS$<>8__locals2c.<>4__this._AddFilterToGutter(string.Format("Hide '{0}'", Utilities.PrefixEllipsizeIfNeeded(sUri, 0x10)));
                        label.Tag = sUri;
                        label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                            if (ee.Button == MouseButtons.Right)
                            {
                                Label label = ss as Label;
                                FilterTargetSystem.RemoveURLContainsFilter((string) label.Tag);
                                label.Dispose();
                                CS$<>8__locals2c.<>4__this._HideFilterGutterIfEmpty();
                            }
                        };
                    }
                };
                if (firstSelectedSession.bHasResponse)
                {
                    EventHandler handler3 = null;
                    <>c__DisplayClass2b CS$<>8__locals2c = classb;
                    string sMIME = firstSelectedSession.oResponse.MIMEType;
                    if (!string.IsNullOrEmpty(sMIME))
                    {
                        this.miSessionFilter.MenuItems.Add("-");
                        if (handler3 == null)
                        {
                            handler3 = delegate (object s, EventArgs eA) {
                                FilterTargetSystem.AddMIMEFilter(sMIME);
                                LinkLabel label = CS$<>8__locals2c.<>4__this._AddFilterToGutter(string.Format("Hide '{0}'", sMIME));
                                label.Tag = sMIME;
                                label.MouseClick += delegate (object ss, MouseEventArgs ee) {
                                    if (ee.Button == MouseButtons.Right)
                                    {
                                        Label label = ss as Label;
                                        FilterTargetSystem.RemoveMIMEFilter((string) label.Tag);
                                        label.Dispose();
                                        CS$<>8__locals2c.<>4__this._HideFilterGutterIfEmpty();
                                    }
                                };
                            };
                        }
                        this.miSessionFilter.MenuItems.Add(string.Format("Hide '{0}'", sMIME)).Click += handler3;
                    }
                }
            }
        }

        private void miSessionInspectNewWindow_Click(object sender, EventArgs e)
        {
            this.actInspectInNewWindow();
        }

        private void miSessionListScroll_Click(object sender, EventArgs e)
        {
            CONFIG.bAutoScroll = !this.miSessionListScroll.Checked;
            this.miViewAutoScroll.Checked = this.miSessionListScroll.Checked = CONFIG.bAutoScroll;
        }

        private void miSessionMarkColor_Click(object sender, EventArgs e)
        {
            if ((sender == this.miSessionMarkRed) || (sender == this.miEditMarkRed))
            {
                this.actSessionMark(System.Drawing.Color.Red);
            }
            else if ((sender == this.miSessionMarkBlue) || (sender == this.miEditMarkBlue))
            {
                this.actSessionMark(System.Drawing.Color.Blue);
            }
            else if ((sender == this.miSessionMarkGold) || (sender == this.miEditMarkGold))
            {
                this.actSessionMark(System.Drawing.Color.Gold);
            }
            else if ((sender == this.miSessionMarkGreen) || (sender == this.miEditMarkGreen))
            {
                this.actSessionMark(System.Drawing.Color.Green);
            }
            else if ((sender == this.miSessionMarkOrange) || (sender == this.miEditMarkOrange))
            {
                this.actSessionMark(System.Drawing.Color.Orange);
            }
            else if ((sender == this.miSessionMarkPurple) || (sender == this.miEditMarkPurple))
            {
                this.actSessionMark(System.Drawing.Color.Purple);
            }
            else if ((sender == this.miSessionMarkUnmark) || (sender == this.miEditMarkUnmark))
            {
                this.actSessionMark(System.Drawing.Color.Empty);
            }
        }

        private void miSessionProperties_Click(object sender, EventArgs e)
        {
            this.actViewSessionProperties();
        }

        private void miSessionReissueAndVerify_Click(object sender, EventArgs e)
        {
            this.actReissueAndVerify();
        }

        private void miSessionReissueComposer_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.ReissueComposer");
            Session firstSelectedSession = FiddlerApplication.UI.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                FiddlerApplication.DoComposeByCloning(firstSelectedSession);
            }
        }

        private void miSessionReissueEdited_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.ReissueEdited");
            this.actReissueSelected(true);
        }

        private void miSessionReissueInIE_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.RevisitInBrowser");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length < 1)
            {
                MessageBox.Show("Please select Sessions to revisit.", "Nothing to Do");
            }
            else
            {
                for (int i = 0; i < selectedSessions.Length; i++)
                {
                    Utilities.LaunchBrowser(CONFIG.sDefaultBrowserExe, CONFIG.sDefaultBrowserParams, selectedSessions[i].fullUrl);
                }
            }
        }

        private void miSessionReissueRequests_Click(object sender, EventArgs e)
        {
            this.actReissueSelected(false);
        }

        private void miSessionReissueSequentially_Click(object sender, EventArgs e)
        {
            this.actReissueSequentially();
        }

        private void miSessionReissueUnconditionally_Click(object sender, EventArgs e)
        {
            this.actUnconditionallyReissueSelected();
        }

        private void miSessionRemoveAll_Click(object sender, EventArgs e)
        {
            int num = FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.CtrlX.PromptIfMoreThan", 0);
            if (((num <= 0) || (this.lvSessions.Items.Count < num)) || (DialogResult.No != MessageBox.Show("Remove all " + this.lvSessions.Items.Count.ToString() + " sessions?", "Confirm Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)))
            {
                if (FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.CtrlX.KeepMarked", false))
                {
                    FiddlerApplication.UI.sbpInfo.Text = "Clearing all unmarked sessions";
                    this.TrimSessionList(0);
                    FiddlerApplication.oProxy.PurgeServerPipePool();
                    FiddlerApplication.UI.sbpInfo.Text = "Cleared all unmarked sessions";
                }
                else
                {
                    this.actRemoveAllSessions();
                }
            }
        }

        private void miSessionRemoveSelected_Click(object sender, EventArgs e)
        {
            this.actRemoveSelectedSessions();
        }

        private void miSessionRemoveUnselected_Click(object sender, EventArgs e)
        {
            this.actRemoveUnselectedSessions();
        }

        private void miSessionReplayResponse_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.CloneResponse");
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length == 2)
            {
                Session session;
                Session session2;
                if (selectedSessions[0].state >= selectedSessions[1].state)
                {
                    session = selectedSessions[1];
                    session2 = selectedSessions[0];
                }
                else
                {
                    session = selectedSessions[0];
                    session2 = selectedSessions[1];
                }
                if (session2.bHasResponse && ((session.state == SessionStates.HandTamperRequest) || (session.state == SessionStates.HandTamperResponse)))
                {
                    session.responseBodyBytes = Utilities.Dupe(session2.responseBodyBytes);
                    session.oResponse.headers = (HTTPResponseHeaders) session2.oResponse.headers.Clone();
                    session.state = SessionStates.HandTamperResponse;
                    this.lvSessions.SelectedItems.Clear();
                    session.ViewItem.Selected = session.ViewItem.Focused = true;
                    this.updateSession(session);
                    this.actUpdateInspector(false, true);
                    return;
                }
            }
            MessageBox.Show("You must select two sessions, one of which has a response,\nand one of which is breakpointed awaiting a response.", "Invalid operation");
        }

        private void miSessionSaveEntire_Click(object sender, EventArgs e)
        {
            this.actSaveSessions();
        }

        private void miSessionSaveFullRequest_Click(object sender, EventArgs e)
        {
            this.actSaveRequests();
        }

        private void miSessionSaveFullResponse_Click(object sender, EventArgs e)
        {
            this.actSaveResponses();
        }

        private void miSessionSaveHeaders_Click(object sender, EventArgs e)
        {
            this.actSaveHeaders();
        }

        private void miSessionSaveRequestBody_Click(object sender, EventArgs e)
        {
            this.actSaveSessionRequestBody();
        }

        private void miSessionSaveResponseBody_Click(object sender, EventArgs e)
        {
            this.actSaveSessionResponseBody();
        }

        private void miSessionSaveToZip_Click(object sender, EventArgs e)
        {
            this.actSaveSessionsToZip();
        }

        private void miSessionSelectChildren_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.SelectChildren");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                string fullUrl = firstSelectedSession.fullUrl;
                bool flag = false;
                if (Utilities.IsRedirectStatus(firstSelectedSession.responseCode))
                {
                    string redirectTargetURL = firstSelectedSession.GetRedirectTargetURL();
                    if (!string.IsNullOrEmpty(redirectTargetURL))
                    {
                        fullUrl = Utilities.TrimAfter(redirectTargetURL, '#');
                        flag = true;
                    }
                }
                string str3 = firstSelectedSession.RequestMethod + firstSelectedSession.fullUrl;
                int id = firstSelectedSession.id;
                FiddlerApplication.SuppressReportUpdates = true;
                this.lvSessions.BeginUpdate();
                this.lvSessions.SelectedItems.Clear();
                foreach (ListViewItem item in this.lvSessions.Items)
                {
                    Session tag = (Session) item.Tag;
                    if (tag.id <= id)
                    {
                        continue;
                    }
                    if (((tag != null) && (tag.oRequest != null)) && (tag.oRequest.headers != null))
                    {
                        if (flag)
                        {
                            if (!(tag.fullUrl == fullUrl))
                            {
                                goto Label_0130;
                            }
                            item.Selected = true;
                            item.Focused = true;
                            break;
                        }
                        if (tag.oRequest.headers.ExistsAndEquals("Referer", fullUrl))
                        {
                            item.Selected = true;
                            item.Focused = true;
                        }
                    }
                Label_0130:
                    if (str3.Equals(tag.RequestMethod + tag.fullUrl))
                    {
                        break;
                    }
                }
                firstSelectedSession.ViewItem.Selected = true;
                if (this.lvSessions.SelectedCount > 0)
                {
                    this.lvSessions.SelectedItems[0].EnsureVisible();
                }
                this.lvSessions.EndUpdate();
                this.sbpInfo.Text = string.Format("Found {0} children", this.lvSessions.SelectedCount - 1);
                FiddlerApplication.SuppressReportUpdates = false;
                this.actUpdateInspector(true, true);
            }
        }

        private void miSessionSelectDuplicates_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.List.SelectDuplicates");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                firstSelectedSession.ViewItem.Focused = true;
                string sMatch = firstSelectedSession.RequestMethod + firstSelectedSession.fullUrl;
                this.actSelectSessionsMatchingCriteria(delegate (Session oS) {
                    return Utilities.HasHeaders(oS.oRequest) && sMatch.OICEquals((oS.RequestMethod + oS.fullUrl));
                });
                this.sbpInfo.Text = "Found " + ((this.lvSessions.SelectedCount - 1)).ToString() + " duplicates.";
            }
        }

        private void miSessionSelectMatching_Click(object sender, EventArgs e)
        {
            try
            {
                Session firstSelectedSession = this.GetFirstSelectedSession();
                if (firstSelectedSession != null)
                {
                    int iCol = this.lvSessions.GetSubItemIndexFromPoint(this.lvSessions.PointToClient(this._ptContextPopup));
                    if (iCol < 0)
                    {
                        this.SetStatusText("Unable to determine which column to match against.");
                    }
                    else
                    {
                        int iImageIndex = -1;
                        if (iCol == 0)
                        {
                            iImageIndex = firstSelectedSession.ViewItem.ImageIndex;
                        }
                        string sSearchVal = firstSelectedSession.ViewItem.SubItems[iCol].Text;
                        FiddlerApplication.UI.actSelectSessionsMatchingCriteria(true, 0, delegate (Session oS) {
                            ListViewItem viewItem = oS.ViewItem;
                            if (viewItem == null)
                            {
                                return false;
                            }
                            if (viewItem.SubItems.Count <= iCol)
                            {
                                return false;
                            }
                            if (iImageIndex >= 0)
                            {
                                return viewItem.ImageIndex == iImageIndex;
                            }
                            return string.Equals(viewItem.SubItems[iCol].Text, sSearchVal);
                        });
                    }
                }
            }
            catch
            {
            }
        }

        private void miSessionSelectParent_Click(object sender, EventArgs e)
        {
            FiddlerApplication.oTelemetry.TrackEvent("Commands.Session.SelectParent");
            Session firstSelectedSession = this.GetFirstSelectedSession();
            if (firstSelectedSession != null)
            {
                string fullUrl = firstSelectedSession.fullUrl;
                string str2 = firstSelectedSession.oRequest["Referer"];
                int id = firstSelectedSession.id;
                Session session2 = null;
                FiddlerApplication.SuppressReportUpdates = true;
                this.lvSessions.BeginUpdate();
                this.lvSessions.SelectedItems.Clear();
                foreach (ListViewItem item in this.lvSessions.Items)
                {
                    Session tag = (Session) item.Tag;
                    if ((((tag != null) && (tag.id < id)) && (tag.oRequest != null)) && ((session2 == null) || (session2.id <= tag.id)))
                    {
                        if (tag.fullUrl.Equals(str2))
                        {
                            session2 = tag;
                        }
                        else
                        {
                            string redirectTargetURL = tag.GetRedirectTargetURL();
                            if (!string.IsNullOrEmpty(redirectTargetURL) && (Utilities.TrimAfter(redirectTargetURL, '#') == fullUrl))
                            {
                                session2 = tag;
                            }
                        }
                    }
                }
                this.sbpInfo.Text = string.Empty;
                if (session2 != null)
                {
                    session2.ViewItem.Selected = true;
                    session2.ViewItem.Focused = true;
                    session2.ViewItem.EnsureVisible();
                }
                else
                {
                    this.sbpInfo.Text = "Parent session was not found.";
                }
                this.lvSessions.EndUpdate();
                FiddlerApplication.SuppressReportUpdates = false;
                this.actUpdateInspector(true, true);
            }
        }

        private void miSessionSumAndAverage_Click(object sender, EventArgs e)
        {
            try
            {
                int subItemIndexFromPoint = this.lvSessions.GetSubItemIndexFromPoint(this.lvSessions.PointToClient(this._ptContextPopup));
                if (subItemIndexFromPoint >= 1)
                {
                    int count = this.lvSessions.SelectedItems.Count;
                    if (count >= 1)
                    {
                        double num3 = 0.0;
                        foreach (ListViewItem item in this.lvSessions.SelectedItems)
                        {
                            double result = 0.0;
                            double.TryParse(item.SubItems[subItemIndexFromPoint].Text, out result);
                            num3 += result;
                        }
                        double num5 = num3 / ((double) count);
                        MessageBox.Show(string.Format("Count:\t{0}\nSum:\t{1:#,#.####}\nAverage:\t{2:#,#.####}\n", count, num3, num5), string.Format("Analysis of '{0}'", this.lvSessions.Columns[subItemIndexFromPoint].Text));
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Math is Hard");
            }
        }

        private void miSessionUnlock_Click(object sender, EventArgs e)
        {
            this.actToggleSessionUnlock();
        }

        private void miSessionWinDiff_Click(object sender, EventArgs e)
        {
            if (this.lvSessions.SelectedCount == 2)
            {
                this.actDoCompareSessions((Session) this.lvSessions.SelectedItems[0].Tag, (Session) this.lvSessions.SelectedItems[1].Tag);
            }
        }

        private void miSquish_Click(object sender, EventArgs e)
        {
            this.actToggleSquish();
        }

        private void miToolsBase64_Click(object sender, EventArgs e)
        {
            this.actShowTextWizard(null);
        }

        private void miToolsClearCache_Click(object sender, EventArgs e)
        {
            this.actClearWinINETCache();
        }

        private void miToolsClearCookies_Click(object sender, EventArgs e)
        {
            this.actClearWinINETCookies();
        }

        private void miToolsFind_Click(object sender, EventArgs e)
        {
            this.actDoFind();
        }

        private void miToolsInternetOptions_Click(object sender, EventArgs e)
        {
            this.actLaunchIEProxy();
        }

        private void miToolsOptions_Click(object sender, EventArgs e)
        {
            this.actShowOptions();
        }

        private void miViewAutoScroll_Click(object sender, EventArgs e)
        {
            CONFIG.bAutoScroll = !this.miViewAutoScroll.Checked;
            this.miViewAutoScroll.Checked = this.miSessionListScroll.Checked = CONFIG.bAutoScroll;
        }

        private void miViewBuilder_Click(object sender, EventArgs e)
        {
            UIComposer.EnsureShowing();
        }

        private void miViewInspector_Click(object sender, EventArgs e)
        {
            if (!this.tabsViews.Contains(this.pageInspector))
            {
                this.tabsViews.Controls.Add(this.pageInspector);
            }
            this.tabsViews.SelectedTab = this.pageInspector;
        }

        private void miViewLayout_Click(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;
            if ((item != null) && !item.Checked)
            {
                int iLayoutMode = 0;
                if (sender == this.miViewStacked)
                {
                    iLayoutMode = 1;
                }
                else if (sender == this.miViewWide)
                {
                    iLayoutMode = 2;
                }
                this.actChangeToLayout(iLayoutMode);
            }
        }

        private void miViewRefresh_Click(object sender, EventArgs e)
        {
            this.actRefreshUI();
            foreach (Session session in FiddlerApplication.UI.GetSelectedSessions())
            {
                this._RefreshSessionListViewItem(session, session.ViewItem);
            }
        }

        private void miViewStatistics_Click(object sender, EventArgs e)
        {
            if (!this.tabsViews.Contains(this.pageStatistics))
            {
                this.tabsViews.Controls.Add(this.pageStatistics);
            }
            this.tabsViews.SelectedTab = this.pageStatistics;
        }

        private void miViewStayOnTop_Click(object sender, EventArgs e)
        {
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.stayontop", !this.miViewStayOnTop.Checked);
        }

        private void miViewToolbar_Click(object sender, EventArgs e)
        {
            this.miViewToolbar.Checked = !this.miViewToolbar.Checked;
            FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.toolbar.visible", this.miViewToolbar.Checked);
        }

        private void mnuEdit_Popup(object sender, EventArgs e)
        {
            try
            {
                this.miEditUndelete.Enabled = (this._wrDeletedListViewItems != null) && this._wrDeletedListViewItems.IsAlive;
                this.mnuEditMark.Enabled = 0 < this.lvSessions.SelectedCount;
                this.miEditUnlock.Enabled = this.lvSessions.SelectedCount == 1;
                if (this.miEditUnlock.Enabled)
                {
                    Session firstSelectedSession = this.GetFirstSelectedSession();
                    this.miEditUnlock.Checked = firstSelectedSession.oFlags.ContainsKey("x-Unlocked");
                }
                this.miEditPaste.Enabled = (Clipboard.ContainsText() || Clipboard.ContainsFileDropList()) || Clipboard.ContainsImage();
            }
            catch (Exception)
            {
            }
        }

        private void mnuEditRemove_Popup(object sender, EventArgs e)
        {
            this.miEditRemoveSelected.Enabled = 0 < this.lvSessions.SelectedCount;
            this.miEditRemoveUnselected.Enabled = 0 < this.lvSessions.SelectedCount;
        }

        private void mnuFile_Popup(object sender, EventArgs e)
        {
            this.mnuFileSave.Enabled = 0 < this.lvSessions.Items.Count;
            if (this.mnuFileExport != null)
            {
                this.mnuFileExport.Enabled = this.mnuFileSave.Enabled;
            }
        }

        private void mnuFileMRU_Popup(object sender, EventArgs e)
        {
            EventHandler handler = null;
            try
            {
                MenuItem[] itemArray;
                this.mnuFileMRU.MenuItems.Clear();
                this.oSAZMRU.RefreshList();
                string[] list = this.oSAZMRU.GetList();
                if (list.Length == 0)
                {
                    itemArray = new MenuItem[] { new MenuItem("<None>") };
                    itemArray[0].Enabled = false;
                }
                else
                {
                    itemArray = new MenuItem[3 + list.Length];
                    for (int i = 0; i < list.Length; i++)
                    {
                        if (list[i] != null)
                        {
                            itemArray[i] = new MenuItem(string.Format("&{0:x}. {1}", i, Utilities.CompactPath(list[i], 0x30)));
                            itemArray[i].Tag = list[i];
                            itemArray[i].Select += new EventHandler(this.AssignStatusTextFromMenuItemTag);
                            if (handler == null)
                            {
                                handler = delegate (object o, EventArgs s) {
                                    string sFilename = (o as MenuItem).Tag as string;
                                    if ((!this.actLoadSessionArchive(tag) && !System.IO.File.Exists(tag)) && (DialogResult.Yes == MessageBox.Show("The specified file is not available. It may have been moved or deleted, or may be on an inaccessible drive.\n\nRemove this file from the Recent Archives list?", "File not found", MessageBoxButtons.YesNo, MessageBoxIcon.Question)))
                                    {
                                        this.oSAZMRU.RemoveFile(tag);
                                    }
                                };
                            }
                            itemArray[i].Click += handler;
                        }
                    }
                    itemArray[itemArray.Length - 3] = this.miFileMRUSplit;
                    itemArray[itemArray.Length - 2] = this.miFileMRUPrune;
                    itemArray[itemArray.Length - 1] = this.miFileMRUClear;
                }
                this.mnuFileMRU.MenuItems.AddRange(itemArray);
            }
            catch (Exception)
            {
            }
        }

        private void mnuFileSave_Popup(object sender, EventArgs e)
        {
            this.mnuFileSaveRequest.Enabled = this.mnuFileSaveResponse.Enabled = this.mnuFileSaveSessions.Enabled = 0 < this.lvSessions.SelectedItems.Count;
        }

        private void mnuSessionContext_Popup(object sender, EventArgs e)
        {
            this._ptContextPopup = Cursor.Position;
            this.miSessionRemove.Enabled = this.lvSessions.Items.Count > 0;
            int selectedCount = this.lvSessions.SelectedCount;
            this.miSessionReplay.Enabled = this.miSessionFilter.Enabled = this.miSessionMark.Enabled = this.miSessionCopy.Enabled = this.miSessionRemoveSelected.Enabled = this.miSessionRemoveUnselected.Enabled = this.miSessionSave.Enabled = this.miSessionSaveEntire.Enabled = this.miSessionSaveHeaders.Enabled = this.miSessionSaveRequestBody.Enabled = this.miSessionAddComment.Enabled = this.miSessionSaveResponseBody.Enabled = this.miSessionAbort.Enabled = selectedCount > 0;
            this.miSessionInspectNewWindow.Enabled = this.miSessionSelect.Enabled = selectedCount == 1;
            this.miSessionWinDiff.Enabled = selectedCount == 2;
            this.miSessionProperties.Enabled = (selectedCount == 1) || (selectedCount == 2);
            bool flag = false;
            if (selectedCount > 1)
            {
                int subItemIndexFromPoint = this.lvSessions.GetSubItemIndexFromPoint(this.lvSessions.PointToClient(this._ptContextPopup));
                if (subItemIndexFromPoint > 0)
                {
                    flag = SessionListView.isColumnNumeric(subItemIndexFromPoint) && (subItemIndexFromPoint != 1);
                }
            }
            this.miSessionMath.Visible = flag;
            this.miSessionFilter.Visible = selectedCount == 1;
            this.miSessionFilter.MenuItems.Clear();
            this.miSessionFilter.MenuItems.Add("...");
            bool flag2 = selectedCount == 2;
            if (flag2)
            {
                flag2 = ((this.lvSessions.SelectedItems[0].Tag as Session).state > SessionStates.HandTamperResponse) ^ ((this.lvSessions.SelectedItems[1].Tag as Session).state > SessionStates.HandTamperResponse);
            }
            this.miSessionReplayResponse.Enabled = flag2;
            if (selectedCount == 1)
            {
                Session tag = this.lvSessions.SelectedItems[0].Tag as Session;
                this.miSessionAbort.Enabled = (tag.state < SessionStates.Done) || tag.isAnyFlagSet(SessionFlags.IsWebSocketTunnel | SessionFlags.IsDecryptingTunnel | SessionFlags.IsBlindTunnel);
                this.miSessionUnlock.Enabled = tag.state >= SessionStates.Done;
                this.miSessionUnlock.Checked = tag.oFlags.ContainsKey("X-Unlocked");
                this.miSessionCOMETPeek.Enabled = tag.state == SessionStates.ReadingResponse;
            }
            else
            {
                this.miSessionCOMETPeek.Enabled = this.miSessionUnlock.Enabled = this.miSessionUnlock.Checked = false;
            }
        }

        private void mnuTools_Popup(object sender, EventArgs e)
        {
            this.miToolsCompare.Enabled = 2 == this.lvSessions.SelectedCount;
        }

        private void notifyIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.actRestoreWindow();
            }
        }

        private void OnPrefChange(object sender, PrefChangeEventArgs oPref)
        {
            string str;
            if (!FiddlerApplication.isClosing && ((str = oPref.PrefName) != null))
            {
                if (!(str == "fiddler.ui.rules.removeencoding"))
                {
                    if (!(str == "fiddler.ui.toolbar.visible"))
                    {
                        if (!(str == "fiddler.ui.stayontop"))
                        {
                            if (!(str == "fiddler.ui.sessionlist.updateinterval"))
                            {
                                if (str == "fiddler.ui.ShowMemoryPanel")
                                {
                                    if (oPref.ValueBool)
                                    {
                                        this.sbpMemory.Width = 60;
                                        this._UpdateMemoryPanel();
                                        if (this._taskUpdateMemoryPanel == null)
                                        {
                                            this._taskUpdateMemoryPanel = FiddlerApplication.Janitor.assignWork(new SimpleEventHandler(this._UpdateMemoryPanel), 0x3a98);
                                        }
                                    }
                                    else
                                    {
                                        this.sbpMemory.Width = this.sbpMemory.MinWidth = 0;
                                        FiddlerApplication.Janitor.revokeWork(this._taskUpdateMemoryPanel);
                                        this._taskUpdateMemoryPanel = null;
                                    }
                                }
                            }
                            else
                            {
                                this.lvSessions.uiAsyncUpdateInterval = FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.sessionlist.updateinterval", 80);
                            }
                        }
                        else
                        {
                            this.miViewStayOnTop.Checked = oPref.ValueBool;
                            base.TopMost = this.miViewStayOnTop.Checked;
                        }
                    }
                    else
                    {
                        this.miViewToolbar.Checked = oPref.ValueBool;
                    }
                }
                else
                {
                    this.miRulesRemoveEncoding.Checked = oPref.ValueBool;
                }
            }
        }

        private void oReportingQueueTimer_Tick(object sender, EventArgs e)
        {
            oReportingQueueTimer.Stop();
            this.actUpdateReport();
        }

        private void oTitle_MouseHover(object sender, EventArgs e)
        {
            (sender as Label).Text = string.Format("Fi&lters ({0})", FilterTargetSystem.FilteredCount);
        }

        private static bool PerformUpgradeIfPending()
        {
            try
            {
                RegistryKey oReg = Registry.CurrentUser.OpenSubKey(CONFIG.GetRegPath("Root"), true);
                if (oReg == null)
                {
                    return false;
                }
                bool flag = Utilities.GetRegistryBool(oReg, "UpdatePending", false);
                oReg.DeleteValue("UpdatePending", false);
                oReg.Close();
                if (!flag)
                {
                    return false;
                }
                Process.Start(Path.GetDirectoryName(Application.ExecutablePath) + @"\UpdateFiddler.exe");
                return true;
            }
            catch
            {
                return false;
            }
        }

        internal void RefreshAllItems()
        {
            foreach (Session session in FiddlerApplication.UI.GetAllSessions())
            {
                this._RefreshSessionListViewItem(session, session.ViewItem);
            }
        }

        public void RefreshRange(Session[] oSessions)
        {
            MethodInvoker oDel = null;
            if ((oSessions != null) && (oSessions.Length != 0))
            {
                if (base.InvokeRequired)
                {
                    if (oDel == null)
                    {
                        oDel = delegate {
                            this.RefreshRange(oSessions);
                        };
                    }
                    FiddlerApplication.UIInvokeAsync(oDel, null);
                }
                else
                {
                    try
                    {
                        this.lvSessions.BeginUpdate();
                        FiddlerApplication.SuppressReportUpdates = true;
                        List<int> list = new List<int>();
                        foreach (Session session in oSessions)
                        {
                            if (session.ShouldBeHidden())
                            {
                                list.Add(session.ViewItem.Index);
                                session.ViewItem = null;
                            }
                        }
                        for (int i = list.Count - 1; i >= 0; i--)
                        {
                            FiddlerApplication.UI.lvSessions.Items.RemoveAt(list[i]);
                        }
                        foreach (Session session2 in oSessions)
                        {
                            try
                            {
                                this.finishSession(session2);
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {
                    }
                    this.lvSessions.EndUpdate();
                    FiddlerApplication.SuppressReportUpdates = false;
                }
            }
        }

        [CodeDescription("Register a systemwide hotkey which will invoke the specified ExecAction command. Specify a HotkeyModifiers value and Key value.")]
        public bool RegisterCustomHotkey(HotkeyModifiers hkm, int iKey, string sQuickExecAction)
        {
            if (iKey == 0)
            {
                return false;
            }
            if (string.IsNullOrEmpty(sQuickExecAction))
            {
                return false;
            }
            int key = ((int) hkm) + (iKey << 0x10);
            if (this.dictUserHotkeys == null)
            {
                this.dictUserHotkeys = new Dictionary<int, string>();
            }
            else if (this.dictUserHotkeys.ContainsKey(key))
            {
                this.dictUserHotkeys[key] = sQuickExecAction;
                return true;
            }
            int id = this.dictUserHotkeys.Count + 2;
            bool flag = Utilities.RegisterHotKey(base.Handle, id, (int) hkm, iKey);
            if (flag)
            {
                this.dictUserHotkeys[key] = sQuickExecAction;
            }
            return flag;
        }

        internal void RegisterHotkey()
        {
            if (!CONFIG.bIsViewOnly)
            {
                Utilities.RegisterHotKey(base.Handle, 1, CONFIG.iHotkeyMod, CONFIG.iHotkey);
            }
        }

        [CodeDescription("Remove the named tab in the top-level View")]
        public void RemoveView(string sViewTabName)
        {
            foreach (TabPage page in this.tabsViews.TabPages)
            {
                if (page.Text.OICEquals(sViewTabName))
                {
                    this.tabsViews.TabPages.Remove(page);
                    break;
                }
            }
        }

        [CodeDescription("Resume a session currently paused at a breakpoint.")]
        public void ResumeBreakpointedSession(Session oSession)
        {
            if (oSession == null)
            {
                return;
            }
            switch (oSession.state)
            {
                case SessionStates.HandTamperRequest:
                    this.actUpdateRequest(oSession);
                    if (oSession.ViewItem != null)
                    {
                        oSession.ViewItem.ImageIndex = 0;
                    }
                    break;

                case SessionStates.HandTamperResponse:
                    this.actUpdateResponse(oSession);
                    if (oSession.ViewItem != null)
                    {
                        oSession.ViewItem.ImageIndex = 2;
                    }
                    goto Label_004C;
            }
        Label_004C:
            this.btnTamperSendServer.Enabled = this.btnTamperSendClient.Enabled = false;
            oSession.ThreadResume();
        }

        private static void RunMain(string[] arrArgs)
        {
            Mutex mutex;
            if (arrArgs.Length == 0)
            {
                if (PerformUpgradeIfPending())
                {
                    return;
                }
            }
            else
            {
                if (Environment.CommandLine.OICContains("-dpiAware") && (Environment.OSVersion.Version.Major > 5))
                {
                    SetProcessDPIAware();
                }
                if (Environment.CommandLine.OICContains("-useGDI"))
                {
                    Application.SetCompatibleTextRenderingDefault(false);
                }
            }
            Application.EnableVisualStyles();
            FiddlerApplication._frmSplash = new SplashScreen();
            if (!CONFIG.QuietMode)
            {
                if ((Keys.Shift == Control.ModifierKeys) && (DialogResult.Yes == MessageBox.Show("The SHIFT Key is down. Would you like to start Fiddler with default appearance settings?", "Fiddler Safe Mode", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)))
                {
                    CONFIG.RevertToDefaultLayout();
                }
                FiddlerApplication._frmSplash.Show();
            }
            FiddlerApplication._frmSplash.IndicateProgress("Searching for prior instance...");
            try
            {
                string name = !CONFIG.bIsViewOnly ? (@"Global\FiddlerUser_" + Environment.UserName) : ("FiddlerViewer" + Environment.TickCount.ToString());
                mutex = new Mutex(false, name);
            }
            catch (Exception exception)
            {
                FiddlerApplication._frmSplash.Close();
                FiddlerApplication.DoNotifyUser("Fiddler appears to be running in this user account (mutex fail).\n\n" + Utilities.DescribeException(exception), "Fiddler Startup Aborted", MessageBoxIcon.Hand);
                return;
            }
            using (mutex)
            {
                bool flag = true;
                if (!mutex.WaitOne(200, false))
                {
                    flag = false;
                    bool flag2 = true;
                    FiddlerApplication._frmSplash.Close();
                    IntPtr hWnd = Utilities.FindWindow(null, "Fiddler - HTTP Debugging Proxy");
                    if (IntPtr.Zero == hWnd)
                    {
                        Thread.Sleep(750);
                        hWnd = Utilities.FindWindow(null, "Fiddler - HTTP Debugging Proxy");
                    }
                    if (IntPtr.Zero != hWnd)
                    {
                        Utilities.SendMessage(hWnd, 0x312, IntPtr.Zero, (IntPtr) ((CONFIG.iHotkey << 0x10) + CONFIG.iHotkeyMod));
                        for (int i = 0; i < arrArgs.Length; i++)
                        {
                            Utilities.SendDataStruct lParam = new Utilities.SendDataStruct();
                            lParam.dwData = (IntPtr) 0xeefa;
                            lParam.strData = arrArgs[i];
                            lParam.cbData = Encoding.Unicode.GetByteCount(lParam.strData);
                            Utilities.SendWMCopyMessage(hWnd, 0x4a, IntPtr.Zero, ref lParam);
                        }
                    }
                    else if (DialogResult.Yes == MessageBox.Show("Fiddler appears to be running in this user account. Maybe in a terminal services session?\n\nIf you run two copies of Fiddler at the same time, your settings may be corrupted.\n\nStart Fiddler anyway?", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2))
                    {
                        flag2 = false;
                    }
                    if (flag2)
                    {
                        return;
                    }
                }
                FiddlerApplication._SetXceedLicenseKeys();
                FiddlerApplication._frmMain = new frmViewer();
                FiddlerApplication._frmSplash.IndicateProgress("Loading AutoResponder...");
                FiddlerApplication._AutoResponder = new AutoResponder();
                FiddlerApplication._AutoResponder.LoadRules();
                FiddlerApplication._frmMain.DoPostInitPreLoad();
                FiddlerApplication._frmSplash.IndicateProgress("Creating Proxy...");
                FiddlerApplication.oProxy = new Proxy(true);
                FiddlerApplication.Log.LogString("Fiddler Running...");
                Application.Run(FiddlerApplication._frmMain);
                if (flag)
                {
                    mutex.ReleaseMutex();
                }
            }
        }

        private static void SaveFilesForDiffer(string sFile1, string sFile2, Session oSess1, Session oSess2)
        {
            Utilities.EnsureOverwritable(sFile1);
            Utilities.EnsureOverwritable(sFile2);
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.differ.DecodeFirst", true))
            {
                try
                {
                    oSess1.utilDecodeRequest();
                    oSess1.utilDecodeResponse();
                    oSess2.utilDecodeRequest();
                    oSess2.utilDecodeResponse();
                }
                catch (Exception)
                {
                }
            }
            FiddlerApplication.LogLeakedFile(sFile1);
            FiddlerApplication.LogLeakedFile(sFile2);
            if (!FiddlerApplication.Prefs.GetBoolPref("fiddler.differ.ultradiff", true))
            {
                oSess1.SaveSession(sFile1, false);
                oSess2.SaveSession(sFile2, false);
            }
            else
            {
                FileStream stream = new FileStream(sFile1, FileMode.Create, FileAccess.Write);
                FileStream stream2 = new FileStream(sFile2, FileMode.Create, FileAccess.Write);
                try
                {
                    string str7;
                    string str8;
                    StreamWriter writer = new StreamWriter(stream);
                    StreamWriter writer2 = new StreamWriter(stream2);
                    string requestMethod = oSess1.RequestMethod;
                    string str2 = oSess2.RequestMethod;
                    string fullUrl = oSess1.fullUrl;
                    string str4 = oSess2.fullUrl;
                    string hTTPVersion = oSess1.oRequest.headers.HTTPVersion;
                    string str6 = oSess2.oRequest.headers.HTTPVersion;
                    if (((requestMethod == str2) && (fullUrl == str4)) && (hTTPVersion == str6))
                    {
                        writer.Write("{0} {1} {2}\r\n", requestMethod, fullUrl, hTTPVersion);
                        writer2.Write("{0} {1} {2}\r\n", str2, str4, str6);
                    }
                    else
                    {
                        int length = getFirstMismatchedCharacter(fullUrl, str4);
                        if (length > -1)
                        {
                            fullUrl = fullUrl.Substring(0, length) + "\r\n>>\t" + fullUrl.Substring(length, fullUrl.Length - length);
                            str4 = str4.Substring(0, length) + "\r\n>>\t" + str4.Substring(length, str4.Length - length);
                        }
                        writer.Write("{0}\r\n{1}\r\n{2}\r\n\r\n", requestMethod, fullUrl, hTTPVersion);
                        writer2.Write("{0}\r\n{1}\r\n{2}\r\n\r\n", str2, str4, str6);
                    }
                    GetDiffFormattedHeaders(oSess1.oRequest.headers, oSess2.oRequest.headers, out str7, out str8);
                    writer.WriteLine(str7);
                    writer2.WriteLine(str8);
                    writer.Flush();
                    writer2.Flush();
                    if (oSess1.requestBodyBytes != null)
                    {
                        stream.Write(oSess1.requestBodyBytes, 0, oSess1.requestBodyBytes.Length);
                    }
                    if (oSess2.requestBodyBytes != null)
                    {
                        stream2.Write(oSess2.requestBodyBytes, 0, oSess2.requestBodyBytes.Length);
                    }
                    writer.WriteLine("\r\n------------------------------------------------------------\r\n");
                    writer2.WriteLine("\r\n------------------------------------------------------------\r\n");
                    writer.Flush();
                    writer2.Flush();
                    if (((oSess1.oResponse != null) && (oSess1.oResponse.headers != null)) && ((oSess2.oResponse != null) && (oSess2.oResponse.headers != null)))
                    {
                        hTTPVersion = oSess1.oResponse.headers.HTTPVersion;
                        str6 = oSess2.oResponse.headers.HTTPVersion;
                        string hTTPResponseStatus = oSess1.oResponse.headers.HTTPResponseStatus;
                        string str10 = oSess2.oResponse.headers.HTTPResponseStatus;
                        writer.Write("{0} {1}\r\n", hTTPVersion, hTTPResponseStatus);
                        writer2.Write("{0} {1}\r\n", str6, str10);
                        GetDiffFormattedHeaders(oSess1.oResponse.headers, oSess2.oResponse.headers, out str7, out str8);
                        writer.WriteLine(str7);
                        writer2.WriteLine(str8);
                        writer.Flush();
                        writer2.Flush();
                    }
                    else
                    {
                        if ((oSess1.oResponse != null) && (oSess1.oResponse.headers != null))
                        {
                            byte[] buffer = oSess1.oResponse.headers.ToByteArray(true, true);
                            stream.Write(buffer, 0, buffer.Length);
                        }
                        else
                        {
                            stream.WriteByte(13);
                            stream.WriteByte(10);
                        }
                        if ((oSess2.oResponse != null) && (oSess2.oResponse.headers != null))
                        {
                            byte[] buffer2 = oSess2.oResponse.headers.ToByteArray(true, true);
                            stream2.Write(buffer2, 0, buffer2.Length);
                        }
                        else
                        {
                            stream2.WriteByte(13);
                            stream2.WriteByte(10);
                        }
                    }
                    if (oSess1.responseBodyBytes != null)
                    {
                        stream.Write(oSess1.responseBodyBytes, 0, oSess1.responseBodyBytes.Length);
                    }
                    if (oSess2.responseBodyBytes != null)
                    {
                        stream2.Write(oSess2.responseBodyBytes, 0, oSess2.responseBodyBytes.Length);
                    }
                }
                finally
                {
                    stream.Close();
                    stream2.Close();
                }
            }
        }

        private void sbStatus_MouseMove(object sender, MouseEventArgs e)
        {
            int num = this.sbpCapture.Width + this.sbpProcessFilter.Width;
            int num2 = this.sbpBreakpoints.Width + this.sbpSelCount.Width;
            if ((e.Location.X < (num + num2)) && (!CONFIG.bIsViewOnly || (e.Location.X > num)))
            {
                this.sbStatus.Cursor = Cursors.Hand;
            }
            else
            {
                this.sbStatus.Cursor = Cursors.Default;
            }
        }

        private void sbStatus_PanelClick(object sender, StatusBarPanelClickEventArgs e)
        {
            EventHandler handler = null;
            EventHandler handler2 = null;
            EventHandler handler3 = null;
            EventHandler handler4 = null;
            if (e.Clicks == 1)
            {
                if (((e.StatusBarPanel == this.sbpCapture) && ((e.Button == MouseButtons.Left) || (e.Button == MouseButtons.Right))) && !CONFIG.bIsViewOnly)
                {
                    frmViewer viewer;
                    FiddlerApplication.oTelemetry.TrackEvent("UI.StatusBar.CaptureToggle");
                    bool lockTaken = false;
                    try
                    {
                        System.Threading.Monitor.Enter(viewer = this, ref lockTaken);
                        this.actToggleCapture();
                    }
                    finally
                    {
                        if (lockTaken)
                        {
                            System.Threading.Monitor.Exit(viewer);
                        }
                    }
                }
                else
                {
                    if (e.StatusBarPanel == this.sbpMemory)
                    {
                        if (e.Button == MouseButtons.Left)
                        {
                            this._UpdateMemoryPanel();
                            Utilities.RecoverMemory();
                            this._UpdateMemoryPanel();
                            return;
                        }
                        if (e.Button == MouseButtons.Right)
                        {
                            this.actShowOptions("Performance");
                            return;
                        }
                    }
                    if ((e.StatusBarPanel == this.sbpProcessFilter) && !CONFIG.bIsViewOnly)
                    {
                        if (e.Button == MouseButtons.Right)
                        {
                            FiddlerApplication.oTelemetry.TrackEvent("UI.StatusBar.ProcessFilterClear");
                            CONFIG.iShowProcessFilter = ProcessFilterCategories.All;
                            this.uihlpUpdateProcessFilterStatus();
                            FiddlerToolbar.ClearProcessFilter();
                        }
                        else
                        {
                            ContextMenuStrip strip = new ContextMenuStrip();
                            FiddlerApplication.oTelemetry.TrackEvent("UI.StatusBar.ProcessFilterFlyout");
                            if (handler == null)
                            {
                                handler = delegate (object s, EventArgs ea) {
                                    CONFIG.iShowProcessFilter = ProcessFilterCategories.All;
                                    this.uihlpUpdateProcessFilterStatus();
                                    FiddlerToolbar.ClearProcessFilter();
                                };
                            }
                            strip.Items.Add("All Processes", (Bitmap) this.imglSessionIcons.Images[0x19]).Click += handler;
                            ToolStripItem item = strip.Items.Add("Web Browsers", (Bitmap) this.imglSessionIcons.Images[0x1a]);
                            item.Enabled = CONFIG.bMapSocketToProcess;
                            if (handler2 == null)
                            {
                                handler2 = delegate (object s, EventArgs ea) {
                                    CONFIG.iShowProcessFilter = ProcessFilterCategories.Browsers;
                                    this.uihlpUpdateProcessFilterStatus();
                                    FiddlerToolbar.ClearProcessFilter();
                                };
                            }
                            item.Click += handler2;
                            item = strip.Items.Add("Non-Browser", (Bitmap) this.imglToolbar.Images["builder"]);
                            item.Enabled = CONFIG.bMapSocketToProcess;
                            if (handler3 == null)
                            {
                                handler3 = delegate (object s, EventArgs ea) {
                                    CONFIG.iShowProcessFilter = ProcessFilterCategories.NonBrowsers;
                                    this.uihlpUpdateProcessFilterStatus();
                                    FiddlerToolbar.ClearProcessFilter();
                                };
                            }
                            item.Click += handler3;
                            if (handler4 == null)
                            {
                                handler4 = delegate (object s, EventArgs ea) {
                                    CONFIG.iShowProcessFilter = ProcessFilterCategories.HideAll;
                                    this.uihlpUpdateProcessFilterStatus();
                                    FiddlerToolbar.ClearProcessFilter();
                                };
                            }
                            strip.Items.Add("Hide All", (Bitmap) this.imglSessionIcons.Images[14]).Click += handler4;
                            strip.Show(this.sbStatus, new Point(this.sbpCapture.Width, 0), ToolStripDropDownDirection.AboveRight);
                        }
                    }
                    else
                    {
                        if (e.StatusBarPanel == this.sbpBreakpoints)
                        {
                            frmViewer viewer2;
                            FiddlerApplication.oTelemetry.TrackEvent("UI.StatusBar.BreakpointsAdjust");
                            bool flag2 = false;
                            try
                            {
                                System.Threading.Monitor.Enter(viewer2 = this, ref flag2);
                                MenuItem item2 = null;
                                if (this.miRulesBreakAtNothing.Checked)
                                {
                                    item2 = (e.Button == MouseButtons.Left) ? this.miRulesBreakAtRequest : this.miRulesBreakAtResponse;
                                }
                                if (this.miRulesBreakAtRequest.Checked)
                                {
                                    item2 = (e.Button == MouseButtons.Left) ? this.miRulesBreakAtResponse : this.miRulesBreakAtNothing;
                                }
                                if (this.miRulesBreakAtResponse.Checked)
                                {
                                    item2 = (e.Button == MouseButtons.Left) ? this.miRulesBreakAtNothing : this.miRulesBreakAtNothing;
                                }
                                if (item2 == null)
                                {
                                    return;
                                }
                                this.miRulesBreakAtNothing.Checked = false;
                                this.miRulesBreakAtRequest.Checked = false;
                                this.miRulesBreakAtResponse.Checked = false;
                                item2.Checked = true;
                                this._UpdateBreakpointMenu();
                            }
                            finally
                            {
                                if (flag2)
                                {
                                    System.Threading.Monitor.Exit(viewer2);
                                }
                            }
                        }
                        if (e.StatusBarPanel == this.sbpSelCount)
                        {
                            Session firstSelectedSession = this.GetFirstSelectedSession();
                            if ((firstSelectedSession != null) && (firstSelectedSession.ViewItem != null))
                            {
                                firstSelectedSession.ViewItem.EnsureVisible();
                                firstSelectedSession.ViewItem.Focused = true;
                            }
                        }
                    }
                }
            }
        }

        private static void SetMenuItemCheckedFromPref(MenuItem oMI, string sPref)
        {
            oMI.Checked = FiddlerApplication.Prefs.GetBoolPref(sPref, false);
        }

        [DllImport("user32.dll", SetLastError=true)]
        private static extern bool SetProcessDPIAware();
        public void SetStatusText(string sMessage)
        {
            if (!FiddlerApplication.isClosing)
            {
                if (base.InvokeRequired)
                {
                    base.BeginInvoke(new setStringDelegate(this.SetStatusText), new object[] { sMessage });
                }
                else
                {
                    this.sbpInfo.Text = sMessage;
                }
            }
        }

        [CodeDescription("Set the icon shown in the System Tray")]
        public bool SetTrayIcon(string sFilename)
        {
            try
            {
                if (string.IsNullOrEmpty(sFilename))
                {
                    this.notifyIcon.Icon = (Icon) new ComponentResourceManager(typeof(frmViewer)).GetObject("notifyIcon.Icon");
                    return true;
                }
                sFilename = Utilities.EnsurePathIsAbsolute(CONFIG.GetPath("App"), sFilename);
                if (!System.IO.File.Exists(sFilename))
                {
                    throw new FileNotFoundException("The specified file was not found", sFilename);
                }
                if (sFilename.OICEndsWith(".ico"))
                {
                    this.notifyIcon.Icon = new Icon(sFilename);
                }
                else
                {
                    this.notifyIcon.Icon = Utilities.GetIconFromImage(new Bitmap(sFilename));
                }
                return true;
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Error: Cannot set TrayIcon to '{0}'. Exception: {1}", new object[] { sFilename, Utilities.DescribeException(exception) });
                return false;
            }
        }

        public void ShowAlert(frmAlert oAlert)
        {
            oAlert.StartPosition = FormStartPosition.CenterScreen;
            oAlert.Show(this);
        }

        private void splitterInspector_DoubleClick(object sender, EventArgs e)
        {
            if (DockStyle.Left == this.splitterInspector.Dock)
            {
                if (this.tabsRequest.Width > 0x4b)
                {
                    this.tabsRequest.Width = 0x4b;
                }
                else
                {
                    this.tabsRequest.Width = Math.Max(100, (base.Width - 100) / 2);
                }
            }
            else if (this.tabsRequest.Height > 30)
            {
                this.tabsRequest.Height = 30;
            }
            else
            {
                this.tabsRequest.Height = Math.Max(100, (base.Height - 100) / 2);
            }
        }

        private void splitterMain_DoubleClick(object sender, EventArgs e)
        {
            int num = 0;
            foreach (ColumnHeader header in this.lvSessions.Columns)
            {
                num += header.Width;
            }
            this.pnlSessions.Width = Math.Min((int) (Screen.FromControl(this.pnlSessions).WorkingArea.Width - 40), (int) (num + 20));
        }

        private void tabsRequest_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing && (this.tabsRequest.SelectedIndex >= 0))
            {
                FiddlerApplication.oTelemetry.TrackEvent("Inspectors.Request.Activate-" + this.tabsRequest.SelectedTab.Text);
                this.actUpdateInspector(true, false);
            }
        }

        private void tabsResponse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing && (this.tabsResponse.SelectedIndex >= 0))
            {
                FiddlerApplication.oTelemetry.TrackEvent("Inspectors.Response.Activate-" + this.tabsResponse.SelectedTab.Text);
                this.actUpdateInspector(false, true);
            }
        }

        private void tabsViews_DragOver(object sender, DragEventArgs e)
        {
            try
            {
                Point pt = this.tabsViews.PointToClient(new Point(e.X, e.Y));
                if (pt.Y < this.tabsViews.DisplayRectangle.Top)
                {
                    TabPage page = this._GetTabPageFromPoint(pt);
                    if ((page != null) && (this.tabsViews.SelectedTab != page))
                    {
                        this.tabsViews.SelectedTab = page;
                        if (this.tabsViews.RowCount > 1)
                        {
                            Rectangle tabRect = this.tabsViews.GetTabRect(this.tabsViews.TabPages.IndexOf(page));
                            Point p = new Point(tabRect.Left + (tabRect.Width / 2), tabRect.Top + (tabRect.Height / 2));
                            Cursor.Position = this.tabsViews.PointToScreen(p);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void tabsViews_MouseClick(object sender, MouseEventArgs e)
        {
            if ((e.Button == MouseButtons.Middle) || ((e.Button == MouseButtons.Right) && ((Control.ModifierKeys & Keys.Control) == Keys.Control)))
            {
                try
                {
                    Point pt = new Point(e.X, e.Y);
                    if (pt.Y < this.tabsViews.DisplayRectangle.Top)
                    {
                        TabPage page = this._GetTabPageFromPoint(pt);
                        if (page != null)
                        {
                            FiddlerApplication.oTelemetry.TrackEvent("Tabs.Views.HideOne");
                            if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                            {
                                foreach (TabPage page2 in this.tabsViews.TabPages)
                                {
                                    if (page2 != page)
                                    {
                                        this.tabsViews.TabPages.Remove(page2);
                                    }
                                }
                            }
                            else
                            {
                                this.tabsViews.TabPages.Remove(page);
                            }
                        }
                    }
                }
                catch
                {
                }
            }
        }

        private void tabsViews_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!FiddlerApplication.isClosing)
            {
                if (this.tabsViews.SelectedTab != null)
                {
                    FiddlerApplication.oTelemetry.TrackEvent("UI.Tabs.ActivateView " + this.tabsViews.SelectedTab.Text);
                }
                if (this.pageBuilder == this.tabsViews.SelectedTab)
                {
                    UIComposer.EnsureReady();
                }
                this.actUpdateInspector(true, true, true);
                this.actReportStatistics(true);
            }
        }

        public void TrimSessionList(int iTrimTo)
        {
            if (this.lvSessions.TotalItemCount() > iTrimTo)
            {
                if (base.InvokeRequired)
                {
                    base.Invoke(new trimSessionListDelegate(this.TrimSessionList), new object[] { iTrimTo });
                }
                else
                {
                    this._internalTrimSessionList(iTrimTo, true);
                }
            }
        }

        private void txtExec_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("Fiddler.Session[]"))
            {
                Session[] data = (Session[]) e.Data.GetData("Fiddler.Session[]");
                StringBuilder builder = new StringBuilder();
                foreach (Session session in data)
                {
                    builder.Append(session.fullUrl);
                    builder.Append(" ");
                }
                this.txtExec.SelectedText = builder.ToString();
            }
            else if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] strArray = (string[]) e.Data.GetData("FileDrop", false);
                StringBuilder builder2 = new StringBuilder();
                foreach (string str in strArray)
                {
                    builder2.AppendFormat("\"{0}\" ", str);
                }
                this.txtExec.SelectedText = builder2.ToString();
            }
            else if (e.Data.GetDataPresent(DataFormats.Text))
            {
                this.txtExec.SelectedText = (string) e.Data.GetData(DataFormats.Text);
            }
            Utilities.SetForegroundWindow(base.Handle);
            this.txtExec.Focus();
            this.txtExec.SelectionLength = 0;
        }

        private void txtExec_DragOver(object sender, DragEventArgs e)
        {
            if ((e.Data.GetDataPresent("Fiddler.Session[]") || e.Data.GetDataPresent(DataFormats.FileDrop)) || e.Data.GetDataPresent(DataFormats.Text))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void txtExec_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.I))
            {
                e.SuppressKeyPress = e.Handled = true;
                if (this.lvSessions.SelectedCount >= 1)
                {
                    if (this.lvSessions.SelectedCount == 2)
                    {
                        Session[] selectedSessions = this.GetSelectedSessions();
                        this.txtExec.SelectedText = string.Format("{0} {1} ", selectedSessions[0].fullUrl, selectedSessions[1].fullUrl);
                        this.txtExec.SelectionLength = 0;
                    }
                    else
                    {
                        Session firstSelectedSession = this.GetFirstSelectedSession();
                        this.txtExec.SelectedText = string.Format("{0} ", firstSelectedSession.fullUrl);
                        this.txtExec.SelectionLength = 0;
                    }
                }
            }
            else if ((this.txtExec.Text.Length < 1) && (e.KeyData == (Keys.Shift | Keys.Tab)))
            {
                e.SuppressKeyPress = e.Handled = true;
                this.lvSessions.Focus();
            }
        }

        private bool txtExec_OnExecute(string sCommand)
        {
            FiddlerApplication.oTelemetry.TrackEvent("QuickExec.OnExecute");
            if (sCommand.StartsWith("?", StringComparison.Ordinal))
            {
                if (this.lvSessions.SelectedCount > 0)
                {
                    this.lvSessions.Focus();
                }
                return false;
            }
            if (sCommand.OICStartsWith("~_NOTIFYINSTALL"))
            {
                if (sCommand.OICContains("/Inspectors/syntaxview.dll"))
                {
                    FiddlerApplication.DoNotifyUser("SyntaxView will be available next launch.", "Install Complete");
                }
                if (sCommand.OICContains("/Scripts/RulesTab2.dll"))
                {
                    FiddlerApplication.DoNotifyUser("RulesTab will be available next launch.", "Install Complete");
                }
                return false;
            }
            if (sCommand.OICEquals("toolbar"))
            {
                FiddlerToolbar.Show();
                return false;
            }
            if (sCommand.OICEquals("tearoff"))
            {
                this.actTearoffInspectors();
                return false;
            }
            if (sCommand.OICStartsWith("!composer "))
            {
                string[] sArgs = Utilities.Parameterize(sCommand.Substring("!composer ".Length));
                if (sArgs.Length < 1)
                {
                    return false;
                }
                UIComposer.invokeCommand(sArgs);
                return true;
            }
            if (sCommand.OICEquals("about:cache"))
            {
                FiddlerApplication.Log.LogString(FiddlerApplication.oProxy.ToString());
                FiddlerApplication.Log.LogString(DNSResolver.InspectCache());
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
                return true;
            }
            if (sCommand.OICStartsWith("!threads"))
            {
                return this._QuickExecConfigureThreadPool(sCommand);
            }
            if (sCommand.OICEquals("!memory"))
            {
                this._GenerateMemoryUsageReport();
                return true;
            }
            if (sCommand.OICStartsWithAny(new string[] { "!dns", "!nslookup" }))
            {
                FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.dns");
                string[] strArray2 = Utilities.Parameterize(sCommand);
                string sHostname = (strArray2.Length > 1) ? strArray2[1] : string.Empty;
                FiddlerApplication.Log.LogString(DNSResolver.GetAllInfo(sHostname));
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
                return true;
            }
            if (sCommand.OICStartsWith("!ping"))
            {
                FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.Ping");
                string[] strArray3 = Utilities.Parameterize(sCommand);
                if (strArray3.Length != 2)
                {
                    this.SetStatusText("Syntax: !ping targetHostOrIP");
                    return true;
                }
                Utilities.PingTarget(strArray3[1]);
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
                return true;
            }
            if (sCommand.OICEquals("about:config"))
            {
                AboutConfig.ShowAboutConfigPage();
                return true;
            }
            if (sCommand.OICEquals("about:connectoids") || sCommand.OICEquals("about:network"))
            {
                string str2;
                if (FiddlerApplication.oProxy.oAllConnectoids != null)
                {
                    str2 = FiddlerApplication.oProxy.oAllConnectoids.ToString();
                }
                else
                {
                    str2 = "No connectoids found.";
                }
                FiddlerApplication.Log.LogFormat("-- NetworkInterfaces --\n{0}\n{1}", new object[] { Utilities.GetNetworkInfo(), str2 });
                Utilities.activateTabByTitle("Log", FiddlerApplication.UI.tabsViews);
                return true;
            }
            if (sCommand.OICStartsWith("!listen"))
            {
                FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.AddListener");
                return _QuickExecAddListener(sCommand);
            }
            if (sCommand.OICEquals("!throw"))
            {
                if (DialogResult.No == MessageBox.Show("Are you sure you want to crash?", "GOING DOWN?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2))
                {
                    return true;
                }
                new Thread(delegate (object a) {
                    throw new Exception("User-requested");
                }).Start();
            }
            if (!sCommand.OICEquals("!hang"))
            {
                if (sCommand.OICStartsWith("!gss"))
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    string[] strArray4 = Utilities.Parameterize(sCommand);
                    if (strArray4.Length > 1)
                    {
                        int iMax = int.Parse(strArray4[1]);
                        this.GetSelectedSessions(iMax);
                    }
                    else
                    {
                        this.GetSelectedSessions();
                    }
                    FiddlerApplication.DoNotifyUser(string.Format("Get Selected Sessions took {0}ms", stopwatch.ElapsedMilliseconds), "Stopwatch");
                    return true;
                }
                if (sCommand.OICEquals("!gas"))
                {
                    Stopwatch stopwatch2 = Stopwatch.StartNew();
                    this.GetAllSessions();
                    FiddlerApplication.DoNotifyUser(string.Format("Get All Sessions took {0}ms", stopwatch2.ElapsedMilliseconds), "Stopwatch");
                    return true;
                }
                if (sCommand.OICStartsWith("!lm"))
                {
                    return _QuickExecLogLoadedAssemblies(sCommand);
                }
                if (sCommand.OICStartsWith("!lam"))
                {
                    _QuickExecLogLoadedAuthModules();
                    return true;
                }
                if (sCommand.OICEquals("!spew"))
                {
                    return this._QuickExecToggleDebugSpew();
                }
                if (sCommand.OICStartsWith("!certs"))
                {
                    return _QuickExecCerts(sCommand);
                }
                if (sCommand.OICEquals("!unload"))
                {
                    FiddlerApplication.oExtensions.Dispose();
                    return true;
                }
                if (sCommand.OICEquals("!verify"))
                {
                    FiddlerApplication.oProxy.VerifyAttached();
                    return true;
                }
                if (sCommand.OICStartsWith("!clone"))
                {
                    Session[] selectedSessions = this.GetSelectedSessions();
                    if (selectedSessions.Length > 0)
                    {
                        string[] strArray5 = Utilities.Parameterize(sCommand);
                        int result = 1;
                        if ((strArray5.Length > 1) && !int.TryParse(strArray5[1], out result))
                        {
                            result = 1;
                        }
                        this.lvSessions.BeginUpdate();
                        FiddlerApplication.SuppressReportUpdates = true;
                        for (int i = 0; i < result; i++)
                        {
                            foreach (Session session in selectedSessions)
                            {
                                new Session(session).FinishUISession();
                            }
                        }
                        this.lvSessions.EndUpdate();
                        FiddlerApplication.SuppressReportUpdates = false;
                    }
                    return true;
                }
                if (sCommand.OICStartsWith("!dupe "))
                {
                    string[] strArray6 = Utilities.Parameterize(sCommand);
                    if (strArray6.Length > 1)
                    {
                        this.lvSessions.BeginUpdate();
                        FiddlerApplication.SuppressReportUpdates = true;
                        Stopwatch stopwatch3 = Stopwatch.StartNew();
                        int num4 = int.Parse(strArray6[1]);
                        Session[] allSessions = this.GetAllSessions();
                        for (int j = 0; j < num4; j++)
                        {
                            foreach (Session session3 in allSessions)
                            {
                                session3["ui-strikeout"] = "duped";
                                session3.ViewItem = null;
                                this.finishSession(session3);
                            }
                        }
                        this.lvSessions.EndUpdate();
                        FiddlerApplication.SuppressReportUpdates = false;
                        this.sbpInfo.Text = "Duplicated Session list in " + stopwatch3.ElapsedMilliseconds + "ms.";
                    }
                    return true;
                }
                if (sCommand.OICStartsWith("TELLOG"))
                {
                    if (FiddlerApplication.oTelemetry == null)
                    {
                        FiddlerApplication.DoNotifyUser("Monitor does not exist", "Cannot comply");
                        return true;
                    }
                    FiddlerApplication.oTelemetry.TrackEvent("DEBUG.TestTrackEvent");
                    return true;
                }
                if (sCommand.OICEquals("TELSTOP"))
                {
                    if (FiddlerApplication.oTelemetry == null)
                    {
                        FiddlerApplication.DoNotifyUser("Monitor does not exist", "Cannot comply");
                        return true;
                    }
                    FiddlerApplication.oTelemetry.Stop();
                    return true;
                }
                if (sCommand.OICStartsWith("!fake "))
                {
                    this.lvSessions.BeginUpdate();
                    FiddlerApplication.SuppressReportUpdates = true;
                    string[] strArray7 = Utilities.Parameterize(sCommand);
                    if (strArray7.Length > 1)
                    {
                        int num6 = int.Parse(strArray7[1]);
                        for (int k = 0; k < num6; k++)
                        {
                            this.AddReportedSession(Encoding.ASCII.GetBytes(string.Format("GET /{0} HTTP/1.1\r\nHost: {0}.com\r\n\r\n", k.ToString())), Encoding.ASCII.GetBytes(string.Format("HTTP/1.1 {0} Fake\r\nContent-Length: 0\r\n\r\n", 200 + new Random().Next(400))), null, SessionFlags.ImportedFromOtherTool).ViewItem.ImageIndex = k % FiddlerApplication.UI.imglSessionIcons.Images.Count;
                        }
                    }
                    this.lvSessions.EndUpdate();
                    FiddlerApplication.SuppressReportUpdates = false;
                    return true;
                }
                if (sCommand.OICStartsWith("prefs"))
                {
                    this._QuickExecHandlePrefs(Utilities.Parameterize(sCommand));
                    return true;
                }
                if (sCommand.OICStartsWith("flags "))
                {
                    this._QuickExecHandleFlags(Utilities.Parameterize(sCommand));
                    return true;
                }
                if (sCommand.OICStartsWith("cols "))
                {
                    return this._QuickExecAddColumns(sCommand);
                }
                if (sCommand.OICStartsWith("select "))
                {
                    FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.Select");
                    return this._QuickExecSelectFlagHeaderOrColumn(sCommand);
                }
                if (sCommand.StartsWith(">", StringComparison.Ordinal))
                {
                    long num8;
                    FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.SelectByGTSize");
                    if (long.TryParse(sCommand.Substring(1).Replace("k", "000"), out num8))
                    {
                        this.actSelectSessionsWithResponseSize(true, num8);
                        if (this.lvSessions.SelectedCount > 0)
                        {
                            this.lvSessions.Focus();
                            this.sbpInfo.Text = string.Format("Selected sessions returning >{0:N0} bytes", num8);
                        }
                        else
                        {
                            this.sbpInfo.Text = string.Format("No Sessions returned >{0:N0} bytes", num8);
                        }
                    }
                    else
                    {
                        this.sbpInfo.Text = "Invalid integer for operator";
                    }
                    return true;
                }
                if (sCommand.StartsWith("<", StringComparison.Ordinal))
                {
                    long num9;
                    FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.SelectByLTSize");
                    if (long.TryParse(sCommand.Substring(1).Replace("k", "000"), out num9))
                    {
                        this.actSelectSessionsWithResponseSize(false, num9);
                        if (this.lvSessions.SelectedCount > 0)
                        {
                            this.lvSessions.Focus();
                            this.sbpInfo.Text = string.Format("Selected sessions returning <{0:N0} bytes", num9);
                        }
                        else
                        {
                            this.sbpInfo.Text = string.Format("No Sessions returned <{0:N0} bytes", num9);
                        }
                    }
                    else
                    {
                        this.sbpInfo.Text = "Invalid integer for operator";
                    }
                    return true;
                }
                if (sCommand.StartsWith("=", StringComparison.Ordinal))
                {
                    uint num10;
                    if (uint.TryParse(sCommand.Substring(1), out num10))
                    {
                        FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.SelectByStatus");
                        this.actSelectSessionsWithResponseCode(num10);
                        this.sbpInfo.Text = "Selected sessions returning HTTP/" + num10.ToString() + ".";
                        if (this.lvSessions.SelectedCount > 0)
                        {
                            this.lvSessions.Focus();
                            this.sbpInfo.Text = string.Format("Selected Sessions returning HTTP/{0}.", num10);
                        }
                        else
                        {
                            this.sbpInfo.Text = string.Format("No Sessions returned HTTP/{0}.", num10);
                        }
                    }
                    else
                    {
                        string sMethodToFind = sCommand.Substring(1);
                        this.actSelectSessionsMatchingCriteria(delegate (Session oSess) {
                            return oSess.HTTPMethodIs(sMethodToFind);
                        });
                        FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.SelectByMethod");
                        if (this.lvSessions.SelectedCount > 0)
                        {
                            this.lvSessions.Focus();
                            this.sbpInfo.Text = string.Format("Selected Sessions with HTTP Method: {0}.", sMethodToFind);
                        }
                        else
                        {
                            this.sbpInfo.Text = string.Format("No Sessions used HTTP Method: {0}.", sMethodToFind);
                        }
                    }
                    return true;
                }
                if (sCommand.StartsWith("@", StringComparison.Ordinal))
                {
                    string sPartialValue = sCommand.Substring(1);
                    FiddlerApplication.oTelemetry.TrackEvent("QuickExec.BuiltIns.SelectByHost");
                    this.actSelectSessionsWithRequestHeaderValue("Host", sPartialValue);
                    if (this.lvSessions.SelectedCount > 0)
                    {
                        this.lvSessions.Focus();
                        this.sbpInfo.Text = string.Format("Selected Sessions to Host: {0}", sPartialValue);
                    }
                    else
                    {
                        this.sbpInfo.Text = string.Format("No Sessions to Host: {0}", sPartialValue);
                    }
                    return true;
                }
                EventHandler<QuickExecEventArgs> onQuickExec = this.OnQuickExec;
                if (onQuickExec != null)
                {
                    Delegate[] invocationList = onQuickExec.GetInvocationList();
                    QuickExecEventArgs e = new QuickExecEventArgs(sCommand);
                    foreach (EventHandler<QuickExecEventArgs> handler2 in invocationList)
                    {
                        handler2(this, e);
                        if (e.bHandled)
                        {
                            return e.bAddToHistory;
                        }
                    }
                }
                return FiddlerApplication.oExtensions.DoOnQuickExec(sCommand);
            }
            if (DialogResult.No == MessageBox.Show("Are you sure you want to hang?", "BY THE NECK?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2))
            {
                return true;
            }
        Label_0344:
            goto Label_0344;
        }

        private void txtExec_TextChanged(object sender, EventArgs e)
        {
            SimpleEventHandler workFunction = null;
            if ((this.txtExec.TextLength > 1) && this.txtExec.Text.StartsWith("?", StringComparison.Ordinal))
            {
                if (workFunction == null)
                {
                    workFunction = delegate {
                        FiddlerApplication.UIInvokeAsync(new MethodInvoker(this._QuickExecQuickSearch), null);
                    };
                }
                ScheduledTasks.ScheduleWork("InlineSearch", 15, workFunction);
            }
        }

        private void uihlpUpdateProcessFilterStatus()
        {
            if (!CONFIG.bIsViewOnly)
            {
                switch (CONFIG.iShowProcessFilter)
                {
                    case ProcessFilterCategories.All:
                        this.sbpProcessFilter.Text = "All Processes";
                        this.sbpProcessFilter.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[0x19]);
                        return;

                    case ProcessFilterCategories.Browsers:
                        this.sbpProcessFilter.Text = "Web Browsers";
                        this.sbpProcessFilter.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[0x1a]);
                        return;

                    case ProcessFilterCategories.NonBrowsers:
                        this.sbpProcessFilter.Text = "Non-Browser";
                        this.sbpProcessFilter.Icon = Utilities.GetIconFromImage(this.imglToolbar.Images["builder"]);
                        return;

                    case ProcessFilterCategories.HideAll:
                        this.sbpProcessFilter.Text = "Hide All";
                        this.sbpProcessFilter.Icon = Utilities.GetIconFromImage(this.imglSessionIcons.Images[14]);
                        return;
                }
            }
        }

        private static void UnhandledExceptionHandler(object sender, UnhandledExceptionEventArgs ue)
        {
            Exception exceptionObject = (Exception) ue.ExceptionObject;
            if (CONFIG.bUseEventLogForExceptions)
            {
                _LogExceptionToEventLog(exceptionObject);
            }
            FiddlerApplication.ReportException(exceptionObject);
        }

        internal void UnregisterHotkey()
        {
            if (!CONFIG.bIsViewOnly)
            {
                Utilities.UnregisterHotKey(base.Handle, 1);
            }
        }

        public void UNSTABLE_OfferTab(string sTitle, EventHandler onClick)
        {
            MenuItem item = new MenuItem(sTitle);
            item.Click += onClick;
            this.mnuViewTabs.MenuItems.Add(item);
        }

        public static void UpdateFont(Control c, string sNewFace)
        {
            Font font = c.Font;
            c.Font = new Font(sNewFace, font.Size);
            if (c.HasChildren)
            {
                foreach (Control control in c.Controls)
                {
                    UpdateFont(control, sNewFace);
                }
            }
        }

        [CodeDescription("Rescan the Responses subfolder of the Captures folder and list available files in Fiddler tampering UIs.")]
        public void UpdateLoadFromCbx()
        {
            this.cbxLoadFrom.Items.Clear();
            this.cbxLoadFrom.Items.Add("Choose Response...");
            FiddlerApplication.oAutoResponder.ClearActionsFromUI();
            try
            {
                if (Directory.Exists(CONFIG.GetPath("TemplateResponses")))
                {
                    foreach (FileInfo info in new DirectoryInfo(CONFIG.GetPath("TemplateResponses")).GetFiles())
                    {
                        if (!info.Name.StartsWith("_", StringComparison.Ordinal))
                        {
                            this.cbxLoadFrom.Items.Add(info.Name);
                            FiddlerApplication.oAutoResponder.AddActionsToUI(new string[] { info.Name });
                        }
                    }
                }
                if (Directory.Exists(CONFIG.GetPath("Responses")))
                {
                    foreach (FileInfo info2 in new DirectoryInfo(CONFIG.GetPath("Responses")).GetFiles())
                    {
                        if (!info2.Name.StartsWith("_", StringComparison.Ordinal))
                        {
                            this.cbxLoadFrom.Items.Add(info2.Name);
                            FiddlerApplication.oAutoResponder.AddActionsToUI(new string[] { info2.Name });
                        }
                    }
                }
            }
            catch
            {
            }
            if (this.cbxLoadFrom.Items.Count > 0)
            {
                this.cbxLoadFrom.SelectedIndex = 0;
            }
            this.cbxLoadFrom.Items.Add("Find a file...");
            FiddlerApplication.oAutoResponder.AddActionsToUI(new string[] { "*bpu", "*bpafter", "*exit", "*drop", "*reset", "*delay:100", "*ReplyWithTunnel", "*CORSPreflightAllow", "*flag:ui-backcolor=#FFD700", "*header:HeaderName=NewValue", "*redir:http://www.example.com", "*script:FiddlerScriptFunctionName", "http://www.example.com", AutoResponder.STR_CREATE_NEW, AutoResponder.STR_FIND_FILE });
        }

        public void UpdateResponseDecodeButtonVisibility()
        {
            Session[] selectedSessions = this.GetSelectedSessions();
            if (selectedSessions.Length == 1)
            {
                this._UpdateResponseInfoTipVisibility(selectedSessions[0]);
            }
        }

        public void updateSession(Session oSession)
        {
            ListViewItem viewItem = oSession.ViewItem;
            if (oSession.ShouldBeHidden())
            {
                if (viewItem != null)
                {
                    oSession.ViewItem = null;
                    this.lvSessions.RemoveOrDequeue(viewItem);
                }
            }
            else
            {
                if (viewItem == null)
                {
                    this._coreAddSession(oSession, false);
                    viewItem = oSession.ViewItem;
                }
                try
                {
                    viewItem.SubItems[2].Text = _obtainScheme(oSession);
                    viewItem.SubItems[10].Text = oSession.oFlags["ui-customcolumn"];
                    viewItem.SubItems[9].Text = oSession.oFlags["ui-comments"];
                    SessionListView.FillBoundColumns(oSession, viewItem);
                    switch (oSession.state)
                    {
                        case SessionStates.ReadingResponse:
                        case SessionStates.SendingResponse:
                            if (!oSession.isAnyFlagSet(SessionFlags.IsRPCTunnel))
                            {
                                break;
                            }
                            viewItem.ImageIndex = 0x27;
                            return;

                        case SessionStates.AutoTamperResponseBefore:
                        case SessionStates.AutoTamperResponseAfter:
                        case SessionStates.Done:
                            return;

                        case SessionStates.HandTamperResponse:
                            viewItem.ImageIndex = 3;
                            return;

                        case SessionStates.Aborted:
                            viewItem.ImageIndex = 14;
                            return;

                        case SessionStates.HandTamperRequest:
                            viewItem.ImageIndex = 1;
                            return;

                        default:
                            return;
                    }
                    viewItem.ImageIndex = 2;
                }
                catch (Exception)
                {
                }
            }
        }

        private void UpdateStatusBar(bool bMustRunNow)
        {
            SimpleEventHandler workFunction = null;
            if (!bMustRunNow && (FiddlerApplication.SuppressReportUpdates || (this.lvSessions.SelectedCount == 0)))
            {
                if (workFunction == null)
                {
                    workFunction = delegate {
                        FiddlerApplication.UIInvokeAsync(new MethodInvoker(this._UpdateStatusBar), null);
                    };
                }
                ScheduledTasks.ScheduleWork("UpdateStatusBar", 100, workFunction);
            }
            else
            {
                this._UpdateStatusBar();
            }
        }

        private void UpdateUIFromPrefs()
        {
            SetMenuItemCheckedFromPref(this.miManipulateIgnoreImages, "fiddler.ui.rules.hideimages");
            SetMenuItemCheckedFromPref(this.miRulesIgnoreConnects, "fiddler.ui.rules.hideconnects");
            SetMenuItemCheckedFromPref(this.miRulesRemoveEncoding, "fiddler.ui.rules.removeencoding");
            SetMenuItemCheckedFromPref(this.miViewStayOnTop, "fiddler.ui.stayontop");
            base.TopMost = this.miViewStayOnTop.Checked;
            this.lvSessions.uiAsyncUpdateInterval = FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.sessionlist.updateinterval", 80);
        }

        private void WeakStoreWebSessionsBeforeDelete(object oLVIC)
        {
            ListViewItem[] itemArray;
            ListView.ListViewItemCollection items = oLVIC as ListView.ListViewItemCollection;
            if (items != null)
            {
                itemArray = new ListViewItem[items.Count];
                items.CopyTo(itemArray, 0);
            }
            else
            {
                ListView.SelectedListViewItemCollection items2 = oLVIC as ListView.SelectedListViewItemCollection;
                if (items2 != null)
                {
                    itemArray = new ListViewItem[items2.Count];
                    items2.CopyTo(itemArray, 0);
                }
                else
                {
                    itemArray = oLVIC as ListViewItem[];
                }
            }
            if (itemArray.Length >= 1)
            {
                this._wrDeletedListViewItems = new WeakReference(itemArray);
            }
        }

        private void WhenDetachedUnexpectedly(object sender, EventArgs e)
        {
            MethodInvoker oDel = null;
            if (base.InvokeRequired)
            {
                if (oDel == null)
                {
                    oDel = delegate {
                        this.WhenDetachedUnexpectedly(null, null);
                    };
                }
                FiddlerApplication.UIInvokeAsync(oDel, null);
            }
            else
            {
                if (!FiddlerApplication.isClosing)
                {
                    base.SuspendLayout();
                    this.sbpCapture.Text = string.Empty;
                    this.sbpCapture.Style = StatusBarPanelStyle.OwnerDraw;
                    this.pnlTopNotice.Visible = true;
                    base.ResumeLayout();
                }
                FiddlerApplication.oProxy.Detach(true);
            }
        }

        internal bool WithinLimitRefreshAllItems()
        {
            if (this.lvSessions.TotalItemCount() < FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.AutoRefreshItemCountLimit", 500))
            {
                this.RefreshAllItems();
                return true;
            }
            return false;
        }

        internal bool WithinLimitRefreshBoundColumns()
        {
            if (this.lvSessions.TotalItemCount() > FiddlerApplication.Prefs.GetInt32Pref("fiddler.ui.AutoRefreshItemCountLimit", 500))
            {
                return false;
            }
            foreach (Session session in FiddlerApplication.UI.GetAllSessions())
            {
                SessionListView.FillBoundColumns(session, session.ViewItem);
            }
            return true;
        }

        protected override void WndProc(ref Message m)
        {
            if (((m.Msg == 5) && (1L == ((long) m.WParam))) && (CONFIG.QuietMode || CONFIG.bHideOnMinimize))
            {
                this.actMinimizeToTray();
            }
            else if (m.Msg == 0x4a)
            {
                this.HandleWMCopyData(m);
            }
            else
            {
                if (m.Msg == 0x312)
                {
                    string str;
                    if (m.LParam == ((IntPtr) ((CONFIG.iHotkey << 0x10) + CONFIG.iHotkeyMod)))
                    {
                        this.actRestoreWindow();
                        return;
                    }
                    if (((this.dictUserHotkeys != null) && this.dictUserHotkeys.TryGetValue((int) m.LParam, out str)) && !string.IsNullOrEmpty(str))
                    {
                        this.actQuickExec(str);
                        return;
                    }
                }
                if (m.Msg == 0x11)
                {
                    this.actHandleWindowsShutdown();
                }
                base.WndProc(ref m);
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
            public void Init()
            {
                this.dwLength = 0x40;
            }
        }
    }
}

