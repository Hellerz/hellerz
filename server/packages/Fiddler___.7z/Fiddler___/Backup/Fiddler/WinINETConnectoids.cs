﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    internal class WinINETConnectoids
    {
        internal Dictionary<string, WinINETConnectoid> _oConnectoids = new Dictionary<string, WinINETConnectoid>();

        public WinINETConnectoids()
        {
            foreach (string str in RASInfo.GetConnectionNames())
            {
                if (CONFIG.bDebugSpew)
                {
                    FiddlerApplication.DebugSpew("Collecting information for Connectoid '{0}'", new object[] { str });
                }
                if (!this._oConnectoids.ContainsKey(str))
                {
                    try
                    {
                        WinINETProxyInfo info = WinINETProxyInfo.CreateFromNamedConnection(str);
                        if (info == null)
                        {
                            FiddlerApplication.Log.LogFormat("!WARNING: Failed to get proxy information for Connection '{0}'.", new object[] { str });
                        }
                        else
                        {
                            WinINETConnectoid connectoid = new WinINETConnectoid();
                            connectoid.sConnectionName = str;
                            if ((!string.IsNullOrEmpty(info.sHttpProxy) && !CONFIG.bIsViewOnly) && info.sHttpProxy.Contains(CONFIG.sFiddlerListenHostPort))
                            {
                                FiddlerApplication.Log.LogString("When connecting, upstream proxy settings were already pointed at Fiddler. Clearing upstream proxy.");
                                info.sHttpProxy = info.sHttpsProxy = (string) (info.sFtpProxy = null);
                                info.bUseManualProxies = false;
                                info.bAllowDirect = true;
                            }
                            if (!string.IsNullOrEmpty(info.sPACScriptLocation) && ((info.sPACScriptLocation.OICEquals(("file://" + CONFIG.GetPath("Pac"))) || info.sPACScriptLocation.OICEquals(("file:///" + Utilities.UrlPathEncode(CONFIG.GetPath("Pac").Replace('\\', '/'))))) || info.sPACScriptLocation.OICEquals(("http://" + CONFIG.sFiddlerListenHostPort + "/proxy.pac"))))
                            {
                                FiddlerApplication.Log.LogString("When connecting, upstream proxy script was already pointed at Fiddler. Clearing upstream proxy.");
                                info.sPACScriptLocation = null;
                            }
                            connectoid.oOriginalProxyInfo = info;
                            this._oConnectoids.Add(str, connectoid);
                        }
                    }
                    catch (Exception exception)
                    {
                        FiddlerApplication.Log.LogFormat("!WARNING: Failed to get proxy information for Connection '{0}' due to {1}", new object[] { str, Utilities.DescribeException(exception) });
                    }
                }
            }
        }

        internal WinINETProxyInfo GetDefaultConnectionGatewayInfo()
        {
            string sHookConnectionNamed = CONFIG.sHookConnectionNamed;
            if (string.IsNullOrEmpty(sHookConnectionNamed))
            {
                sHookConnectionNamed = "DefaultLAN";
            }
            if (!this._oConnectoids.ContainsKey(sHookConnectionNamed))
            {
                sHookConnectionNamed = "DefaultLAN";
                if (!this._oConnectoids.ContainsKey(sHookConnectionNamed))
                {
                    FiddlerApplication.Log.LogString("!WARNING: The DefaultLAN Gateway information could not be obtained.");
                    return WinINETProxyInfo.CreateFromStrings(string.Empty, string.Empty);
                }
            }
            return this._oConnectoids[sHookConnectionNamed].oOriginalProxyInfo;
        }

        internal bool HookConnections(WinINETProxyInfo oNewInfo)
        {
            if (CONFIG.bIsViewOnly)
            {
                return false;
            }
            bool flag = false;
            foreach (WinINETConnectoid connectoid in this._oConnectoids.Values)
            {
                if ((CONFIG.bHookAllConnections || (connectoid.sConnectionName == CONFIG.sHookConnectionNamed)) && oNewInfo.SetToWinINET(connectoid.sConnectionName))
                {
                    flag = true;
                    connectoid.bIsHooked = true;
                }
            }
            return flag;
        }

        internal void MarkDefaultLANAsUnhooked()
        {
            foreach (WinINETConnectoid connectoid in this._oConnectoids.Values)
            {
                if (connectoid.sConnectionName == "DefaultLAN")
                {
                    connectoid.bIsHooked = false;
                    break;
                }
            }
        }

        internal bool MarkUnhookedConnections(string sLookFor)
        {
            if (CONFIG.bIsViewOnly)
            {
                return false;
            }
            bool flag = false;
            foreach (WinINETConnectoid connectoid in this._oConnectoids.Values)
            {
                if (!connectoid.bIsHooked)
                {
                    continue;
                }
                WinINETProxyInfo info = WinINETProxyInfo.CreateFromNamedConnection(connectoid.sConnectionName);
                bool flag2 = false;
                if (!info.bUseManualProxies)
                {
                    flag2 = true;
                }
                else
                {
                    string str = info.CalculateProxyString();
                    if ((str != sLookFor) && !str.Contains("http=" + sLookFor))
                    {
                        flag2 = true;
                    }
                }
                if (flag2)
                {
                    connectoid.bIsHooked = false;
                    flag = true;
                }
            }
            return flag;
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("RAS reports {0} Connectoids\n\n", this._oConnectoids.Count);
            foreach (KeyValuePair<string, WinINETConnectoid> pair in this._oConnectoids)
            {
                builder.AppendFormat("-= WinINET settings for '{0}' =-\n{1}\n", pair.Key, pair.Value.oOriginalProxyInfo.ToString());
            }
            return builder.ToString();
        }

        internal bool UnhookAllConnections()
        {
            if (CONFIG.bIsViewOnly)
            {
                return true;
            }
            bool flag = true;
            foreach (WinINETConnectoid connectoid in this._oConnectoids.Values)
            {
                if (connectoid.bIsHooked)
                {
                    if (connectoid.oOriginalProxyInfo.SetToWinINET(connectoid.sConnectionName))
                    {
                        connectoid.bIsHooked = false;
                    }
                    else
                    {
                        flag = true;
                    }
                }
            }
            return flag;
        }
    }
}

