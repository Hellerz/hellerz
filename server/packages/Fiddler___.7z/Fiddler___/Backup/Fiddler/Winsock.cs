﻿namespace Fiddler
{
    using System;
    using System.Diagnostics;
    using System.Runtime.InteropServices;

    internal static class Winsock
    {
        private const int AF_INET = 2;
        private const int AF_INET6 = 0x17;
        private const int ERROR_INSUFFICIENT_BUFFER = 0x7a;
        private const int NO_ERROR = 0;

        private static int FindPIDForConnection(int iTargetPort, uint iAddressType, TcpTableType whichTable)
        {
            IntPtr zero = IntPtr.Zero;
            uint dwTcpTableLength = 0x8000;
            try
            {
                int num3;
                int num4;
                int num5;
                zero = Marshal.AllocHGlobal(0x8000);
                uint num2 = GetExtendedTcpTable(zero, ref dwTcpTableLength, false, iAddressType, whichTable, 0);
                while (0x7a == num2)
                {
                    Marshal.FreeHGlobal(zero);
                    dwTcpTableLength += 0x800;
                    zero = Marshal.AllocHGlobal((int) dwTcpTableLength);
                    num2 = GetExtendedTcpTable(zero, ref dwTcpTableLength, false, iAddressType, whichTable, 0);
                }
                if (num2 != 0)
                {
                    FiddlerApplication.Log.LogFormat("!GetExtendedTcpTable() returned error #0x{0:x} when looking for port {1}", new object[] { num2, iTargetPort });
                    return 0;
                }
                if (iAddressType == 2)
                {
                    num3 = 12;
                    num4 = 12;
                    num5 = 0x18;
                }
                else
                {
                    num3 = 0x18;
                    num4 = 0x20;
                    num5 = 0x38;
                }
                int num6 = ((iTargetPort & 0xff) << 8) + ((iTargetPort & 0xff00) >> 8);
                int num7 = Marshal.ReadInt32(zero);
                if (num7 == 0)
                {
                    return 0;
                }
                IntPtr ptr = (IntPtr) (((long) zero) + num3);
                for (int i = 0; i < num7; i++)
                {
                    if (num6 == Marshal.ReadInt32(ptr))
                    {
                        return Marshal.ReadInt32(ptr, num4);
                    }
                    ptr = (IntPtr) (((long) ptr) + num5);
                }
            }
            finally
            {
                Marshal.FreeHGlobal(zero);
            }
            return 0;
        }

        private static int FindPIDForPort(int iTargetPort)
        {
            int num = 0;
            try
            {
                num = FindPIDForConnection(iTargetPort, 2, TcpTableType.OwnerPidConnections);
                if ((num > 0) || !CONFIG.bEnableIPv6)
                {
                    return num;
                }
                return FindPIDForConnection(iTargetPort, 0x17, TcpTableType.OwnerPidConnections);
            }
            catch (Exception exception)
            {
                FiddlerApplication.Log.LogFormat("Fiddler.Network.TCPTable> Unable to call IPHelperAPI function: {0}", new object[] { exception.Message });
            }
            return 0;
        }

        [DllImport("iphlpapi.dll", SetLastError=true, ExactSpelling=true)]
        private static extern uint GetExtendedTcpTable(IntPtr pTcpTable, ref uint dwTcpTableLength, [MarshalAs(UnmanagedType.Bool)] bool sort, uint ipVersion, TcpTableType tcpTableType, uint reserved);
        internal static string GetListeningProcess(int iPort)
        {
            int processId = 0;
            try
            {
                processId = FindPIDForConnection(iPort, 2, TcpTableType.OwnerPidListener);
                if (processId < 1)
                {
                    processId = FindPIDForConnection(iPort, 0x17, TcpTableType.OwnerPidListener);
                }
                if (processId < 1)
                {
                    return string.Empty;
                }
                string str = Process.GetProcessById(processId).ProcessName.ToLower();
                if (string.IsNullOrEmpty(str))
                {
                    str = "unknown";
                }
                return (str + ":" + processId.ToString());
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        internal static int MapLocalPortToProcessId(int iPort)
        {
            return FindPIDForPort(iPort);
        }

        private enum TcpTableType
        {
            BasicListener,
            BasicConnections,
            BasicAll,
            OwnerPidListener,
            OwnerPidConnections,
            OwnerPidAll,
            OwnerModuleListener,
            OwnerModuleConnections,
            OwnerModuleAll
        }
    }
}

