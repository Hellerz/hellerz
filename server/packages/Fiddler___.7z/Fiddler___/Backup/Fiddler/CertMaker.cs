﻿namespace Fiddler
{
    using System;
    using System.IO;
    using System.Reflection;
    using System.Security.Cryptography.X509Certificates;
    using System.Threading;

    public class CertMaker
    {
        private static object _lockProvider = new object();
        private static ICertificateProvider oCertProvider = null;

        public static bool createRootCert()
        {
            EnsureReady();
            return oCertProvider.CreateRootCertificate();
        }

        public static void DoDispose()
        {
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.CertMaker.CleanupServerCertsOnExit", false))
            {
                removeFiddlerGeneratedCerts(false);
            }
            IDisposable oCertProvider = CertMaker.oCertProvider as IDisposable;
            if (oCertProvider != null)
            {
                oCertProvider.Dispose();
            }
            CertMaker.oCertProvider = null;
        }

        public static void EnsureReady()
        {
            if (oCertProvider == null)
            {
                object obj2;
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(obj2 = _lockProvider, ref lockTaken);
                    if (oCertProvider == null)
                    {
                        oCertProvider = LoadOverrideCertProvider() ?? new DefaultCertificateProvider();
                    }
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(obj2);
                    }
                }
            }
        }

        internal static bool exportRootToDesktop()
        {
            try
            {
                byte[] bytes = getRootCertBytes();
                if (bytes != null)
                {
                    File.WriteAllBytes(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + Path.DirectorySeparatorChar + "FiddlerRoot.cer", bytes);
                    return true;
                }
                FiddlerApplication.DoNotifyUser("The root certificate could not be located.", "Export Failed");
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Certificate Export Failed");
            }
            return false;
        }

        public static X509Certificate2 FindCert(string sHostname)
        {
            EnsureReady();
            return oCertProvider.GetCertificateForHost(sHostname);
        }

        internal static bool flushCertCache()
        {
            EnsureReady();
            ICertificateProvider2 oCertProvider = CertMaker.oCertProvider as ICertificateProvider2;
            if (oCertProvider == null)
            {
                return false;
            }
            return oCertProvider.ClearCertificateCache(false);
        }

        public static string GetCertProviderInfo()
        {
            EnsureReady();
            if (oCertProvider is DefaultCertificateProvider)
            {
                return ((DefaultCertificateProvider) oCertProvider).GetEngineString();
            }
            string location = oCertProvider.GetType().Assembly.Location;
            string path = CONFIG.GetPath("App");
            if (location.StartsWith(path))
            {
                location = location.Substring(path.Length);
            }
            return string.Format("{0} from {1}", oCertProvider, location);
        }

        internal static byte[] getRootCertBytes()
        {
            X509Certificate2 rootCertificate = GetRootCertificate();
            if (rootCertificate == null)
            {
                return null;
            }
            return rootCertificate.Export(X509ContentType.Cert);
        }

        public static X509Certificate2 GetRootCertificate()
        {
            EnsureReady();
            return oCertProvider.GetRootCertificate();
        }

        private static ICertificateProvider LoadOverrideCertProvider()
        {
            Assembly assembly;
            string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.assembly", CONFIG.GetPath("App") + "CertMaker.dll");
            try
            {
                if (!File.Exists(stringPref))
                {
                    FiddlerApplication.Log.LogFormat("Assembly '{0}' was not found. Using default Certificate Generator.", new object[] { stringPref });
                    return null;
                }
                assembly = Assembly.UnsafeLoadFrom(stringPref);
                if (!Utilities.FiddlerMeetsVersionRequirement(assembly, "Certificate Makers"))
                {
                    FiddlerApplication.Log.LogFormat("Assembly '{0}' did not specify a RequiredVersionAttribute. Aborting load of Certificate Generation module.", new object[] { stringPref });
                    return null;
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.LogAddonException(exception, "Failed to load CertMaker: " + stringPref);
                return null;
            }
            foreach (Type type in assembly.GetExportedTypes())
            {
                if ((type.IsClass && !type.IsAbstract) && (type.IsPublic && typeof(ICertificateProvider).IsAssignableFrom(type)))
                {
                    try
                    {
                        return (ICertificateProvider) Activator.CreateInstance(type);
                    }
                    catch (Exception exception2)
                    {
                        FiddlerApplication.DoNotifyUser(string.Format("[Fiddler] Failure loading '{0}' CertMaker from {1}: {2}\n\n{3}\n\n{4}", new object[] { type.Name, stringPref, exception2.Message, exception2.StackTrace, exception2.InnerException }), "Load Error");
                    }
                }
            }
            FiddlerApplication.Log.LogFormat("Assembly '{0}' did not contain a recognized ICertificateProvider.", new object[] { stringPref });
            return null;
        }

        public static bool removeFiddlerGeneratedCerts()
        {
            return removeFiddlerGeneratedCerts(true);
        }

        public static bool removeFiddlerGeneratedCerts(bool bRemoveRoot)
        {
            EnsureReady();
            if (oCertProvider is ICertificateProvider2)
            {
                return (oCertProvider as ICertificateProvider2).ClearCertificateCache(bRemoveRoot);
            }
            return oCertProvider.ClearCertificateCache();
        }

        public static bool rootCertExists()
        {
            try
            {
                X509Certificate2 rootCertificate = GetRootCertificate();
                return (null != rootCertificate);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool rootCertIsMachineTrusted()
        {
            bool flag;
            bool flag2;
            EnsureReady();
            oCertProvider.rootCertIsTrusted(out flag, out flag2);
            return flag2;
        }

        public static bool rootCertIsTrusted()
        {
            bool flag;
            bool flag2;
            EnsureReady();
            return oCertProvider.rootCertIsTrusted(out flag, out flag2);
        }

        internal static bool ShowConfigUI(IntPtr wndOwner)
        {
            EnsureReady();
            ICertificateProviderInfo oCertProvider = CertMaker.oCertProvider as ICertificateProviderInfo;
            if (oCertProvider == null)
            {
                return false;
            }
            oCertProvider.ShowConfigurationUI(wndOwner);
            return true;
        }

        public static bool StoreCert(string sHost, X509Certificate2 oCert)
        {
            if (!oCert.HasPrivateKey)
            {
                throw new ArgumentException("The provided certificate MUST have a private key.", "oCert");
            }
            EnsureReady();
            ICertificateProvider3 oCertProvider = CertMaker.oCertProvider as ICertificateProvider3;
            if (oCertProvider == null)
            {
                return false;
            }
            return oCertProvider.CacheCertificateForHost(sHost, oCert);
        }

        public static void StoreCert(string sHost, string sPFXFilename, string sPFXPassword)
        {
            X509Certificate2 oCert = new X509Certificate2(sPFXFilename, sPFXPassword);
            if (!StoreCert(sHost, oCert))
            {
                throw new InvalidOperationException("The current ICertificateProvider does not support storing custom certificates.");
            }
        }

        public static bool trustRootCert()
        {
            EnsureReady();
            return oCertProvider.TrustRootCertificate();
        }

        internal static bool CanShowConfigUI
        {
            get
            {
                EnsureReady();
                return (oCertProvider is ICertificateProviderInfo);
            }
        }
    }
}

