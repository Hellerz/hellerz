﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading;

    internal class PipePool
    {
        private long lngLastPoolPurge;
        internal static uint MSEC_PIPE_POOLED_LIFETIME = 0x1c138;
        internal static uint MSEC_POOL_CLEANUP_INTERVAL = 0x7530;
        private readonly Dictionary<string, Stack<ServerPipe>> thePool;

        internal PipePool()
        {
            MSEC_PIPE_POOLED_LIFETIME = (uint) FiddlerApplication.Prefs.GetInt32Pref("fiddler.network.timeouts.serverpipe.reuse", 0x1c138);
            this.thePool = new Dictionary<string, Stack<ServerPipe>>();
            FiddlerApplication.Janitor.assignWork(new SimpleEventHandler(this.ScavengeCache), MSEC_POOL_CLEANUP_INTERVAL);
        }

        internal void Clear()
        {
            this.lngLastPoolPurge = DateTime.Now.Ticks;
            if (this.thePool.Count >= 1)
            {
                Dictionary<string, Stack<ServerPipe>> dictionary;
                List<ServerPipe> list = new List<ServerPipe>();
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(dictionary = this.thePool, ref lockTaken);
                Label_0080:
                    foreach (KeyValuePair<string, Stack<ServerPipe>> pair in this.thePool)
                    {
                        Stack<ServerPipe> stack;
                        bool flag = false;
                        try
                        {
                            Monitor.Enter(stack = pair.Value, ref flag);
                            list.AddRange(pair.Value);
                            goto Label_0080;
                        }
                        finally
                        {
                            if (flag)
                            {
                                Monitor.Exit(stack);
                            }
                        }
                    }
                    this.thePool.Clear();
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(dictionary);
                    }
                }
                foreach (ServerPipe pipe in list)
                {
                    pipe.End();
                }
            }
        }

        internal string InspectPool()
        {
            Dictionary<string, Stack<ServerPipe>> dictionary;
            StringBuilder builder = new StringBuilder(0x2000);
            builder.AppendFormat("ServerPipePool\nfiddler.network.timeouts.serverpipe.reuse: {0}ms\nContents\n--------\n", MSEC_PIPE_POOLED_LIFETIME);
            bool lockTaken = false;
            try
            {
                Monitor.Enter(dictionary = this.thePool, ref lockTaken);
                foreach (string str in this.thePool.Keys)
                {
                    Stack<ServerPipe> stack2;
                    Stack<ServerPipe> stack = this.thePool[str];
                    builder.AppendFormat("\t[{0}] entries for '{1}'.\n", stack.Count, str);
                    bool flag = false;
                    try
                    {
                        Monitor.Enter(stack2 = stack, ref flag);
                        foreach (ServerPipe pipe in stack)
                        {
                            builder.AppendFormat("\t\t{0}\n", pipe.ToString());
                        }
                        continue;
                    }
                    finally
                    {
                        if (flag)
                        {
                            Monitor.Exit(stack2);
                        }
                    }
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(dictionary);
                }
            }
            builder.Append("\n--------\n");
            return builder.ToString();
        }

        internal void PoolOrClosePipe(ServerPipe oPipe)
        {
            if (!CONFIG.bReuseServerSockets)
            {
                oPipe.End();
            }
            else if ((oPipe.ReusePolicy == PipeReusePolicy.NoReuse) || (oPipe.ReusePolicy == PipeReusePolicy.MarriedToClientPipe))
            {
                oPipe.End();
            }
            else if (this.lngLastPoolPurge > oPipe.dtConnected.Ticks)
            {
                oPipe.End();
            }
            else if ((oPipe.sPoolKey == null) || (oPipe.sPoolKey.Length < 2))
            {
                oPipe.End();
            }
            else
            {
                Stack<ServerPipe> stack;
                Dictionary<string, Stack<ServerPipe>> dictionary;
                Stack<ServerPipe> stack2;
                oPipe.ulLastPooled = Utilities.GetTickCount();
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(dictionary = this.thePool, ref lockTaken);
                    if (!this.thePool.TryGetValue(oPipe.sPoolKey, out stack))
                    {
                        stack = new Stack<ServerPipe>();
                        this.thePool.Add(oPipe.sPoolKey, stack);
                    }
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(dictionary);
                    }
                }
                bool flag2 = false;
                try
                {
                    Monitor.Enter(stack2 = stack, ref flag2);
                    stack.Push(oPipe);
                }
                finally
                {
                    if (flag2)
                    {
                        Monitor.Exit(stack2);
                    }
                }
            }
        }

        internal void ScavengeCache()
        {
            if (this.thePool.Count >= 1)
            {
                Dictionary<string, Stack<ServerPipe>> dictionary;
                List<ServerPipe> list = new List<ServerPipe>();
                bool lockTaken = false;
                try
                {
                    Monitor.Enter(dictionary = this.thePool, ref lockTaken);
                    List<string> list2 = new List<string>();
                    ulong num = Utilities.GetTickCount() - MSEC_PIPE_POOLED_LIFETIME;
                Label_0128:
                    foreach (KeyValuePair<string, Stack<ServerPipe>> pair in this.thePool)
                    {
                        Stack<ServerPipe> stack2;
                        Stack<ServerPipe> collection = pair.Value;
                        bool flag = false;
                        try
                        {
                            Monitor.Enter(stack2 = collection, ref flag);
                            if (collection.Count > 0)
                            {
                                if (collection.Peek().ulLastPooled < num)
                                {
                                    list.AddRange(collection);
                                    collection.Clear();
                                }
                                else if (collection.Count > 1)
                                {
                                    ServerPipe[] pipeArray = collection.ToArray();
                                    if (pipeArray[pipeArray.Length - 1].ulLastPooled < num)
                                    {
                                        collection.Clear();
                                        for (int i = pipeArray.Length - 1; i >= 0; i--)
                                        {
                                            if (pipeArray[i].ulLastPooled < num)
                                            {
                                                list.Add(pipeArray[i]);
                                            }
                                            else
                                            {
                                                collection.Push(pipeArray[i]);
                                            }
                                        }
                                    }
                                }
                            }
                            if (collection.Count == 0)
                            {
                                list2.Add(pair.Key);
                            }
                            goto Label_0128;
                        }
                        finally
                        {
                            if (flag)
                            {
                                Monitor.Exit(stack2);
                            }
                        }
                    }
                    foreach (string str in list2)
                    {
                        this.thePool.Remove(str);
                    }
                }
                finally
                {
                    if (lockTaken)
                    {
                        Monitor.Exit(dictionary);
                    }
                }
                foreach (BasePipe pipe2 in list)
                {
                    pipe2.End();
                }
            }
        }

        internal ServerPipe TakePipe(string sPoolKey, int iPID, int HackiForSession)
        {
            Stack<ServerPipe> stack;
            ServerPipe pipe;
            Dictionary<string, Stack<ServerPipe>> dictionary;
            Stack<ServerPipe> stack2;
            if (!CONFIG.bReuseServerSockets)
            {
                return null;
            }
            bool lockTaken = false;
            try
            {
                Monitor.Enter(dictionary = this.thePool, ref lockTaken);
                if ((((iPID == 0) || !this.thePool.TryGetValue(string.Format("pid{0}*{1}", iPID, sPoolKey), out stack)) || (stack.Count < 1)) && (!this.thePool.TryGetValue(sPoolKey, out stack) || (stack.Count < 1)))
                {
                    return null;
                }
            }
            finally
            {
                if (lockTaken)
                {
                    Monitor.Exit(dictionary);
                }
            }
            bool flag2 = false;
            try
            {
                Monitor.Enter(stack2 = stack, ref flag2);
                try
                {
                    if (stack.Count == 0)
                    {
                        return null;
                    }
                    return stack.Pop();
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception);
                    return null;
                }
            }
            finally
            {
                if (flag2)
                {
                    Monitor.Exit(stack2);
                }
            }
            return pipe;
        }
    }
}

