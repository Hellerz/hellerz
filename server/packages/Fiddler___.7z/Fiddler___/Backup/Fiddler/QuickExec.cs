﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class QuickExec : TextBox
    {
        private string _sCueText;
        private bool bForceSave;
        private int iCurrentCommand;
        private ContextMenuStrip mnuSuggestions;
        private ExecuteHandler OnExecute;
        private List<string> slCommandHistory = new List<string>();

        public event ExecuteHandler OnExecute
        {
            add
            {
                ExecuteHandler handler2;
                ExecuteHandler onExecute = this.OnExecute;
                do
                {
                    handler2 = onExecute;
                    ExecuteHandler handler3 = (ExecuteHandler) Delegate.Combine(handler2, value);
                    onExecute = Interlocked.CompareExchange<ExecuteHandler>(ref this.OnExecute, handler3, handler2);
                }
                while (onExecute != handler2);
            }
            remove
            {
                ExecuteHandler handler2;
                ExecuteHandler onExecute = this.OnExecute;
                do
                {
                    handler2 = onExecute;
                    ExecuteHandler handler3 = (ExecuteHandler) Delegate.Remove(handler2, value);
                    onExecute = Interlocked.CompareExchange<ExecuteHandler>(ref this.OnExecute, handler3, handler2);
                }
                while (onExecute != handler2);
            }
        }

        public QuickExec()
        {
            base.KeyPress += new KeyPressEventHandler(this.QuickExec_KeyPress);
        }

        private void _AdvanceSelection(bool bSelectToEnd)
        {
            if (this.TextLength >= 1)
            {
                int num = base.SelectionStart + 1;
                for (bool flag = (this.Text.LastIndexOf('/') <= num) && (this.Text.LastIndexOf('\\') <= num); (((num < this.TextLength) && (this.Text[num] != '/')) && (this.Text[num] != '\\')) && (!flag || (this.Text[num] != ' ')); flag = (this.Text.LastIndexOf('/') <= num) && (this.Text.LastIndexOf('\\') <= num))
                {
                    num++;
                }
                while ((num < (this.TextLength - 1)) && (this.Text[num + 1] == this.Text[num]))
                {
                    num++;
                }
                base.SelectionStart = num + 1;
                this.SelectionLength = bSelectToEnd ? (this.TextLength - base.SelectionStart) : 0;
            }
        }

        private void _DoHistoryList()
        {
            ToolStripItemClickedEventHandler handler = null;
            ToolStripDropDownClosedEventHandler handler2 = null;
            string toMatch = this._GetUnselectedText();
            if (this.mnuSuggestions == null)
            {
                this.mnuSuggestions = new ContextMenuStrip();
                this.mnuSuggestions.ShowCheckMargin = this.mnuSuggestions.ShowImageMargin = false;
                int num = 0;
                for (int i = this.slCommandHistory.Count - 1; i >= 0; i--)
                {
                    if (this.slCommandHistory[i].OICStartsWith(toMatch))
                    {
                        this.mnuSuggestions.Items.Insert(0, new ToolStripMenuItem(this.slCommandHistory[i]));
                        num++;
                        if (num == 0x19)
                        {
                            break;
                        }
                    }
                }
                if (num > 0)
                {
                    this.SetText(toMatch);
                    if (handler == null)
                    {
                        handler = delegate (object s, ToolStripItemClickedEventArgs e) {
                            this.SetText(e.ClickedItem.Text);
                        };
                    }
                    this.mnuSuggestions.ItemClicked += handler;
                    this.mnuSuggestions.Show(this, new Point(0, 0), ToolStripDropDownDirection.AboveRight);
                    if (handler2 == null)
                    {
                        handler2 = delegate (object s, ToolStripDropDownClosedEventArgs e) {
                            this.mnuSuggestions = null;
                        };
                    }
                    this.mnuSuggestions.Closed += handler2;
                }
                else
                {
                    this.mnuSuggestions = null;
                    Utilities.PlayNamedSound("SystemAsterisk");
                }
            }
        }

        private void _DoSmartPaste()
        {
            string clipboardAsString = Utilities.GetClipboardAsString();
            this.SelectedText = clipboardAsString;
        }

        private string _GetUnselectedText()
        {
            string text = this.Text;
            if (this.SelectionLength > 0)
            {
                text = text.Remove(base.SelectionStart, this.SelectionLength);
            }
            return text;
        }

        private void _RetreatSelection(bool bSelectToEnd)
        {
            if ((this.TextLength >= 1) && (base.SelectionStart >= 1))
            {
                int num = base.SelectionStart - 1;
                while (((num > 0) && (this.Text[num] != '/')) && ((this.Text[num] != ' ') && (this.Text[num] != '\\')))
                {
                    num--;
                }
                if (base.SelectionStart < 0)
                {
                    base.SelectionStart = 0;
                }
                base.SelectionStart = num;
                this.SelectionLength = bSelectToEnd ? (this.TextLength - base.SelectionStart) : 0;
            }
        }

        private void _ScrollHistoryDown()
        {
            if (this.iCurrentCommand >= (this.slCommandHistory.Count - 1))
            {
                Utilities.PlayNamedSound("SystemAsterisk");
            }
            else
            {
                string sText = string.Empty;
                if (this.TextLength > 0)
                {
                    sText = this._GetUnselectedText();
                    if (this.Text == sText)
                    {
                        sText = string.Empty;
                    }
                }
                if (this.iCurrentCommand >= this.slCommandHistory.Count)
                {
                    this.SetText(sText);
                    this.iCurrentCommand = this.slCommandHistory.Count;
                }
                else
                {
                    string str2;
                    bool flag = false;
                    do
                    {
                        this.iCurrentCommand++;
                        str2 = this.slCommandHistory[this.iCurrentCommand];
                        if (sText.Length < 1)
                        {
                            flag = true;
                            break;
                        }
                        if (str2.OICStartsWith(sText) && !this.Text.Equals(str2))
                        {
                            flag = true;
                            break;
                        }
                    }
                    while (this.iCurrentCommand < (this.slCommandHistory.Count - 1));
                    if (!flag)
                    {
                        this.SetText(sText);
                        this.iCurrentCommand = this.slCommandHistory.Count;
                        Utilities.PlayNamedSound("SystemAsterisk");
                    }
                    else if (sText.Length < 1)
                    {
                        this.SetText(str2);
                    }
                    else
                    {
                        str2 = str2.Substring(sText.Length, str2.Length - sText.Length);
                        this.Text = sText + str2;
                        base.SelectionStart = this.TextLength - str2.Length;
                        this.SelectionLength = str2.Length;
                    }
                }
            }
        }

        private void _ScrollHistoryUp()
        {
            if (this.iCurrentCommand < 1)
            {
                Utilities.PlayNamedSound("SystemAsterisk");
            }
            else
            {
                string str2;
                string toMatch = string.Empty;
                if (this.TextLength > 0)
                {
                    toMatch = this._GetUnselectedText();
                    if (this.Text == toMatch)
                    {
                        toMatch = string.Empty;
                    }
                }
                if (this.iCurrentCommand > this.slCommandHistory.Count)
                {
                    this.iCurrentCommand = this.slCommandHistory.Count;
                }
                bool flag = false;
                do
                {
                    this.iCurrentCommand--;
                    str2 = this.slCommandHistory[this.iCurrentCommand];
                    if (toMatch.Length < 1)
                    {
                        flag = true;
                        break;
                    }
                    if (str2.OICStartsWith(toMatch) && !this.Text.Equals(str2))
                    {
                        flag = true;
                        break;
                    }
                }
                while (this.iCurrentCommand > 0);
                if (!flag)
                {
                    Utilities.PlayNamedSound("SystemAsterisk");
                    this.iCurrentCommand = this.slCommandHistory.Count;
                }
                else if (toMatch.Length < 1)
                {
                    this.SetText(str2);
                }
                else
                {
                    str2 = str2.Substring(toMatch.Length, str2.Length - toMatch.Length);
                    this.Text = toMatch + str2;
                    base.SelectionStart = this.TextLength - str2.Length;
                    this.SelectionLength = str2.Length;
                }
            }
        }

        internal void LoadHistory(string sFile)
        {
            try
            {
                if (File.Exists(sFile))
                {
                    string[] collection = File.ReadAllLines(sFile, Encoding.UTF8);
                    this.slCommandHistory.AddRange(collection);
                    this.iCurrentCommand = this.slCommandHistory.Count;
                }
            }
            catch
            {
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            this.UpdateCueText();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Up:
                case Keys.Oemtilde:
                    this._ScrollHistoryUp();
                    return true;

                case Keys.Down:
                    this._ScrollHistoryDown();
                    return true;

                case Keys.Escape:
                    if (this.SelectedText.Length > 0)
                    {
                        this.SelectedText = string.Empty;
                    }
                    else if (this.TextLength > 0)
                    {
                        base.Clear();
                    }
                    else
                    {
                        FiddlerApplication.UI.lvSessions.Focus();
                    }
                    return true;

                case Keys.Tab:
                    this._AdvanceSelection(true);
                    return true;

                case Keys.Return:
                {
                    string sCommand = this.Text.Trim();
                    if (sCommand.Length < 1)
                    {
                        base.Clear();
                        return true;
                    }
                    if (this.OnExecute != null)
                    {
                        FiddlerApplication.oTelemetry.TrackEvent("QuickExec.CommandEntered");
                        if (this.OnExecute(sCommand))
                        {
                            this.slCommandHistory.Remove(sCommand);
                            this.slCommandHistory.Add(sCommand);
                            this.iCurrentCommand = this.slCommandHistory.Count;
                        }
                    }
                    base.Clear();
                    return true;
                }
                case Keys.F3:
                    if (this.slCommandHistory.Count > 0)
                    {
                        this.SetText(this.slCommandHistory[this.slCommandHistory.Count - 1]);
                    }
                    return true;

                case (Keys.Control | Keys.Back):
                case (Keys.Control | Keys.Left):
                case (Keys.Control | Keys.Shift | Keys.Back):
                case (Keys.Control | Keys.Shift | Keys.Left):
                    this._RetreatSelection((keyData & Keys.Shift) == Keys.Shift);
                    return true;

                case (Keys.Control | Keys.Tab):
                    FiddlerApplication.UI.lvSessions.Focus();
                    return true;

                case (Keys.Shift | Keys.Delete):
                {
                    string sToDelete = this.Text;
                    this.slCommandHistory.RemoveAll(delegate (string s) {
                        return s == sToDelete;
                    });
                    base.Clear();
                    this.iCurrentCommand = this.slCommandHistory.Count;
                    this.bForceSave = true;
                    return true;
                }
                case (Keys.Shift | Keys.Tab):
                    this._RetreatSelection(true);
                    return true;

                case (Keys.Control | Keys.A):
                case (Keys.Control | Keys.Q):
                case (Keys.Alt | Keys.Q):
                    base.SelectAll();
                    return true;

                case (Keys.Control | Keys.Right):
                case (Keys.Control | Keys.Shift | Keys.Right):
                    this._AdvanceSelection((keyData & Keys.Shift) == Keys.Shift);
                    return true;

                case (Keys.Control | Keys.Delete):
                    if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete ALL QuickExec command history?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
                    {
                        this.slCommandHistory.Clear();
                        this.iCurrentCommand = 0;
                        this.bForceSave = true;
                    }
                    return true;

                case (Keys.Control | Keys.V):
                    this._DoSmartPaste();
                    return true;

                case (Keys.Alt | Keys.L):
                    this._DoHistoryList();
                    return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void QuickExec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsControl(e.KeyChar) && !this.Text.StartsWith("?")) && FiddlerApplication.Prefs.GetBoolPref("fiddler.QuickExec.autocomplete", true))
            {
                string toMatch = this._GetUnselectedText() + e.KeyChar;
                if ((base.SelectionStart + this.SelectionLength) == this.TextLength)
                {
                    for (int i = this.slCommandHistory.Count - 1; i >= 0; i--)
                    {
                        if (this.slCommandHistory[i].OICStartsWith(toMatch))
                        {
                            string str2 = this.slCommandHistory[i].Substring(toMatch.Length);
                            this.SetText(toMatch);
                            this.SelectedText = str2;
                            base.SelectionStart = this.TextLength - str2.Length;
                            this.SelectionLength = str2.Length;
                            e.KeyChar = '\0';
                            e.Handled = true;
                            return;
                        }
                    }
                }
            }
        }

        internal void SaveHistory(string sFile)
        {
            try
            {
                if (this.slCommandHistory.Count < 1)
                {
                    if (this.bForceSave)
                    {
                        File.Delete(sFile);
                    }
                }
                else
                {
                    List<string> list = new List<string>();
                    foreach (string str in this.slCommandHistory)
                    {
                        if (!str.StartsWith("`") && (list.IndexOf(str) < 0))
                        {
                            list.Add(str);
                        }
                    }
                    File.WriteAllLines(sFile, list.ToArray(), Encoding.UTF8);
                }
            }
            catch
            {
            }
        }

        private void SetText(string sText)
        {
            this.Text = sText;
            base.SelectionStart = this.TextLength;
        }

        private void UpdateCueText()
        {
            if (base.IsHandleCreated)
            {
                Utilities.SetCueText(this, this.CueText);
            }
        }

        public string CueText
        {
            get
            {
                return this._sCueText;
            }
            set
            {
                this._sCueText = value;
                this.UpdateCueText();
            }
        }
    }
}

