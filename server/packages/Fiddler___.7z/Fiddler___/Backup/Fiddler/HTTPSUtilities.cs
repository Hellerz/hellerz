﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    internal class HTTPSUtilities
    {
        internal static string GetECCCurvesAsString(byte[] eccCurves)
        {
            List<string> list = new List<string>();
            if (eccCurves.Length < 2)
            {
                return string.Empty;
            }
            byte num1 = eccCurves[0];
            byte num4 = eccCurves[1];
            for (int i = 2; i < (eccCurves.Length - 1); i += 2)
            {
                ushort num2 = (ushort) ((eccCurves[i] << 8) | eccCurves[i + 1]);
                switch (num2)
                {
                    case 1:
                        list.Add("sect163k1 [0x1]");
                        break;

                    case 2:
                        list.Add("sect163r1 [0x2]");
                        break;

                    case 3:
                        list.Add("sect163r2 [0x3]");
                        break;

                    case 4:
                        list.Add("sect193r1 [0x4]");
                        break;

                    case 5:
                        list.Add("sect193r2 [0x5]");
                        break;

                    case 6:
                        list.Add("sect233k1 [0x6]");
                        break;

                    case 7:
                        list.Add("sect233r1 [0x7]");
                        break;

                    case 8:
                        list.Add("sect239k1 [0x8]");
                        break;

                    case 9:
                        list.Add("sect283k1 [0x9]");
                        break;

                    case 10:
                        list.Add("sect283r1 [0xA]");
                        break;

                    case 11:
                        list.Add("sect409k1 [0xB]");
                        break;

                    case 12:
                        list.Add("sect409r1 [0xC]");
                        break;

                    case 13:
                        list.Add("sect571k1 [0xD]");
                        break;

                    case 14:
                        list.Add("sect571r1 [0xE]");
                        break;

                    case 15:
                        list.Add("secp160k1 [0xF]");
                        break;

                    case 0x10:
                        list.Add("secp160r1 [0x10]");
                        break;

                    case 0x11:
                        list.Add("secp160r2 [0x11]");
                        break;

                    case 0x12:
                        list.Add("secp192k1 [0x12]");
                        break;

                    case 0x13:
                        list.Add("secp192r1 [0x13]");
                        break;

                    case 20:
                        list.Add("secp224k1 [0x14]");
                        break;

                    case 0x15:
                        list.Add("secp224r1 [0x15]");
                        break;

                    case 0x16:
                        list.Add("secp256k1 [0x16]");
                        break;

                    case 0x17:
                        list.Add("secp256r1 [0x17]");
                        break;

                    case 0x18:
                        list.Add("secp384r1 [0x18]");
                        break;

                    case 0x19:
                        list.Add("secp521r1 [0x19]");
                        break;

                    case 0xff01:
                        list.Add("arbitrary_explicit_prime_curves [0xFF01]");
                        break;

                    case 0xff02:
                        list.Add("arbitrary_explicit_char2_curves [0xFF02]");
                        break;

                    default:
                        list.Add(string.Format("unknown [0x{0:X})", num2));
                        break;
                }
            }
            return string.Join(", ", list.ToArray());
        }

        internal static string GetECCPointFormatsAsString(byte[] eccPoints)
        {
            List<string> list = new List<string>();
            if (eccPoints.Length < 1)
            {
                return string.Empty;
            }
            for (int i = 1; i < eccPoints.Length; i++)
            {
                switch (eccPoints[i])
                {
                    case 0:
                        list.Add("uncompressed [0x0]");
                        break;

                    case 1:
                        list.Add("ansiX962_compressed_prime [0x1]");
                        break;

                    case 2:
                        list.Add("ansiX962_compressed_char2  [0x2]");
                        break;

                    default:
                        list.Add(string.Format("unknown [0x{0:X}]", eccPoints[i]));
                        break;
                }
            }
            return string.Join(", ", list.ToArray());
        }

        internal static string GetExtensionString(byte[] arrData)
        {
            int num2;
            List<string> list = new List<string>();
            for (int i = 0; i < arrData.Length; i += 1 + num2)
            {
                num2 = arrData[i];
                list.Add(Encoding.ASCII.GetString(arrData, i + 1, num2));
            }
            return string.Join(", ", list.ToArray());
        }

        internal static string GetProtocolListAsString(byte[] arrData)
        {
            int num = (arrData[0] << 8) + arrData[1];
            byte[] dst = new byte[num];
            Buffer.BlockCopy(arrData, 2, dst, 0, dst.Length);
            return GetExtensionString(dst);
        }

        internal static string GetSignatureAndHashAlgsAsString(byte[] arrData)
        {
            int num = (arrData[0] << 8) + arrData[1];
            StringBuilder builder = new StringBuilder();
            for (int i = 2; i < (num + 2); i += 2)
            {
                switch (arrData[i])
                {
                    case 0:
                        builder.Append("NoHash");
                        break;

                    case 1:
                        builder.Append("md4");
                        break;

                    case 2:
                        builder.Append("sha1");
                        break;

                    case 3:
                        builder.Append("sha224");
                        break;

                    case 4:
                        builder.Append("sha256");
                        break;

                    case 5:
                        builder.Append("sha384");
                        break;

                    case 6:
                        builder.Append("sha512");
                        break;

                    default:
                        builder.AppendFormat("Unknown[0x{0:x}]", arrData[i]);
                        break;
                }
                builder.AppendFormat("_", new object[0]);
                switch (arrData[i + 1])
                {
                    case 0:
                        builder.Append("NoSig");
                        break;

                    case 1:
                        builder.Append("rsa");
                        break;

                    case 2:
                        builder.Append("dsa");
                        break;

                    case 3:
                        builder.Append("ecdsa");
                        break;

                    default:
                        builder.AppendFormat("Unknown[0x{0:x}]", arrData[i + 1]);
                        break;
                }
                builder.AppendFormat(", ", new object[0]);
            }
            if (builder.Length > 1)
            {
                builder.Length -= 2;
            }
            return builder.ToString();
        }

        internal static string HTTPSVersionToString(int iMajor, int iMinor)
        {
            string str = "Unknown";
            if ((iMajor == 3) && (iMinor == 3))
            {
                str = "TLS/1.2";
            }
            else if ((iMajor == 3) && (iMinor == 2))
            {
                str = "TLS/1.1";
            }
            else if ((iMajor == 3) && (iMinor == 1))
            {
                str = "TLS/1.0";
            }
            else if ((iMajor == 3) && (iMinor == 0))
            {
                str = "SSL/3.0";
            }
            else if ((iMajor == 2) && (iMinor == 0))
            {
                str = "SSL/2.0";
            }
            return string.Format("{0}.{1} ({2})", iMajor, iMinor, str);
        }
    }
}

