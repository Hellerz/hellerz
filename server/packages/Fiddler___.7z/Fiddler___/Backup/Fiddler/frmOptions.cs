﻿namespace Fiddler
{
    using System;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.Security.Authentication;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Windows.Forms;

    internal class frmOptions : Form
    {
        private bool bGatewayTouched;
        private Button btnActions;
        private Button btnApply;
        private Button btnCancel;
        private Button btnChooseCompare;
        private Button btnChooseFSE;
        private Button btnChooseTextEditor;
        private Button btnSetBGColor;
        private Button btnSetFont;
        private CheckBox cbAllowRemote;
        private CheckBox cbAlwaysShowTrayIcon;
        private CheckBox cbAttachOnStartup;
        private CheckBox cbAutoCheckForUpdates;
        private CheckBox cbAutoReloadScript;
        private CheckBox cbBumpPriority;
        private CheckBox cbCaptureCONNECT;
        private CheckBox cbCaptureFTP;
        private CheckBox cbCheckRevocation;
        private CheckBox cbDecryptHTTPS;
        private CheckBox cbEnableHighResTimers;
        private CheckBox cbEnableIPv6;
        private CheckBox cbFIP;
        private CheckBox cbHideOnMinimize;
        private CheckBox cbHookAllConnections;
        private CheckBox cbHookWithPAC;
        private CheckBox cbIgnoreServerCertErrors;
        private CheckBox cbOfferBetaUpdates;
        private CheckBox cbParseWebSocketMessages;
        private CheckBox cbResetSessionIDOnListClear;
        private CheckBox cbReuseClientSockets;
        private CheckBox cbReuseServerSockets;
        private CheckBox cbShowMemoryPanel;
        private CheckBox cbStreamVideo;
        private CheckBox cbUseSmartScroll;
        private ComboBox cbxAbort;
        private ComboBox cbxDecryptList;
        private ComboBox cbxFontSize;
        private ComboBox cbxHotkeyMod;
        private ComboBox cbxHTTPLint;
        private CheckedListBox clbConnections;
        private IContainer components;
        private OpenFileDialog dlgChooseEditor;
        private GroupBox gbAutoFiddles;
        private GroupBox gbScript;
        private Label lblHTTPSDescription;
        private Label lblNotices;
        private Label lblProxyRegistrationHostname;
        private Label lblSkipDecryption;
        private LinkLabel lnkCertMaker;
        private LinkLabel lnkCopyPACURL;
        private LinkLabel lnkFindExtensions;
        private LinkLabel lnkHookup;
        private LinkLabel lnkHTTPSProtocols;
        private LinkLabel lnkOptionsHelp;
        private LinkLabel lnkShowGatewayInfo;
        private ToolStripMenuItem miExportRootCert;
        private ToolStripMenuItem miRemoveCerts;
        private ToolStripMenuItem miResetAllCertificates;
        private ToolStripMenuItem miTrustRootCertificate;
        private ContextMenuStrip mnuHTTPS;
        private NumericUpDown numStreamAndForget;
        private Panel pnlOptionsFooter;
        private RadioButton rdoGatewayManual;
        private RadioButton rdoGatewayNone;
        private RadioButton rdoGatewayWinINET;
        private RadioButton rdoGatewayWPAD;
        private TabPage tabAppearance;
        private TabPage tabConnections;
        private TabPage tabExtensions;
        private TabPage tabGateway;
        private TabPage tabGeneral;
        private TabPage tabHTTPS;
        private TabPage tabPerformance;
        private TabControl tabsOptions;
        private TabPage tabTools;
        private ToolTip toolTip1;
        private TextBox txtCompareTool;
        private RichTextBox txtExtensions;
        private TextBox txtFiddlerBypass;
        private TextBox txtHotkey;
        private TextBox txtListenPort;
        private TextBox txtManualProxyString;
        private TextBox txtProxyExceptionList;
        private TextBox txtScriptEditor;
        private TextBox txtScriptReferences;
        private TextBox txtSkipDecryption;
        private TextBox txtTextEditor;

        internal frmOptions()
        {
            this.InitializeComponent();
            this.lblHTTPSDescription.UseCompatibleTextRendering = false;
            this.txtExtensions.BackColor = CONFIG.colorDisabledEdit;
            Utilities.SetCueText(this.txtManualProxyString, "Proxy string: http=CorpProxy:80;https=SecureProxy:80;ftp=ftpGW:80");
            Utilities.SetCueText(this.txtProxyExceptionList, "Bypass list: <local>;*.extranet.example.com;");
            if (CONFIG.bVersionCheckBlocked)
            {
                this.cbFIP.Visible = false;
            }
        }

        private static int _ColorToInt(Color c)
        {
            return ((c.R + (c.G * 0x100)) + (c.B * 0x10000));
        }

        private void _FillConnectoidList()
        {
            try
            {
                if (FiddlerApplication.oProxy.oAllConnectoids == null)
                {
                    this.clbConnections.Visible = false;
                }
                else
                {
                    foreach (WinINETConnectoid connectoid in FiddlerApplication.oProxy.oAllConnectoids._oConnectoids.Values)
                    {
                        this.clbConnections.Items.Add(connectoid.sConnectionName, connectoid.bIsHooked);
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Could Not Enumerate Connectoids");
            }
        }

        private static string _GetExtensionsList()
        {
            try
            {
                if (FiddlerApplication.oExtensions.Extensions.Count < 1)
                {
                    return "None.";
                }
                StringBuilder builder = new StringBuilder();
                foreach (IFiddlerExtension extension in FiddlerApplication.oExtensions.Extensions.Values)
                {
                    FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(extension.GetType().Assembly.Location);
                    string str = string.Format("(v{0}.{1}.{2}.{3})\tfrom {4}", new object[] { versionInfo.FileMajorPart, versionInfo.FileMinorPart, versionInfo.FileBuildPart, versionInfo.FilePrivatePart, Utilities.CollapsePath(extension.GetType().Assembly.Location) });
                    builder.AppendFormat("{0} {1}\r\n", extension.ToString(), str);
                }
                return builder.ToString();
            }
            catch (Exception exception)
            {
                return string.Format("Failed to enumerate extensions. {0}", Utilities.DescribeException(exception));
            }
        }

        private void _RemoveAllCertificates()
        {
            try
            {
                this.lblNotices.Tag = this.lblNotices.Text;
                this.btnActions.Enabled = false;
                try
                {
                    this.lblNotices.Text = "Clearing Machine Store...";
                    bool flag = false;
                    if (CertMaker.rootCertIsMachineTrusted())
                    {
                        X509Certificate2 rootCertificate = CertMaker.GetRootCertificate();
                        if (rootCertificate != null)
                        {
                            string subject = rootCertificate.Subject;
                            if (!string.IsNullOrEmpty(subject))
                            {
                                flag = Utilities.RunExecutableAndWait(CONFIG.GetPath("App") + "TrustCert.exe", string.Format("-u \"{0}\"", subject));
                            }
                        }
                    }
                    this.lblNotices.Text = "Clear User Store...";
                    if (CertMaker.removeFiddlerGeneratedCerts() || flag)
                    {
                        this.lblNotices.Text = "Done";
                        FiddlerApplication.DoNotifyUser(this, string.Format("Fiddler-generated certificates have been removed from {0}", flag ? "both User and Machine Root storage." : "the Current User storage."), "Success", MessageBoxIcon.Asterisk);
                    }
                }
                catch (Exception exception)
                {
                    FiddlerApplication.ReportException(exception);
                }
            }
            finally
            {
                this.lblNotices.Text = this.lblNotices.Tag as string;
                this.btnActions.Enabled = true;
            }
        }

        private void _TrustRootCertificate()
        {
            DialogResult no = DialogResult.No;
            using (frmAlert alert = new frmAlert("SCARY TEXT AHEAD: Read Carefully!", "To intercept HTTPS traffic, Fiddler generates a unique root certificate.\n\nYou may configure Windows to trust this root certificate to suppress\nsecurity warnings. This is generally safe.\n\nClick 'Yes' to reconfigure Windows' Trusted CA list.\nClick 'No' if this is all geek to you.", "Trust the Fiddler Root certificate?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2, frmAlert.AlertIcon.Insecure))
            {
                alert.TopMost = true;
                alert.StartPosition = FormStartPosition.CenterScreen;
                no = alert.ShowDialog(this);
                alert.Dispose();
            }
            if (DialogResult.Yes == no)
            {
                bool flag = CertMaker.trustRootCert();
                if (!flag)
                {
                    FiddlerApplication.DoNotifyUser(this, "Unable to configure Windows to Trust the Fiddler Root certificate.\n\nThe LOG tab may contain more information.", "Certificate Trust", MessageBoxIcon.Exclamation);
                }
                if (flag && FiddlerApplication.Prefs.GetBoolPref("fiddler.CertMaker.OfferMachineTrust", Utilities.IsWin8OrLater()))
                {
                    string subject = CertMaker.GetRootCertificate().Subject;
                    Utilities.RunExecutable(CONFIG.GetPath("App") + "TrustCert.exe", string.Format("\"{0}\"", subject));
                }
            }
        }

        private void actApplyChanges()
        {
            this.btnApply.Enabled = this.btnCancel.Enabled = false;
            try
            {
                int num;
                CONFIG.bAttachOnBoot = this.cbAttachOnStartup.Checked;
                CONFIG.bVersionCheck = this.cbAutoCheckForUpdates.Checked;
                CONFIG.bEnableAnalytics = this.cbFIP.Checked;
                CONFIG.bAutoLoadScript = this.cbAutoReloadScript.Checked;
                CONFIG.bReuseServerSockets = this.cbReuseServerSockets.Checked;
                CONFIG.bReuseClientSockets = this.cbReuseClientSockets.Checked;
                CONFIG.bHideOnMinimize = this.cbHideOnMinimize.Checked;
                CONFIG.bResetCounterOnClear = this.cbResetSessionIDOnListClear.Checked;
                switch (this.cbxHTTPLint.SelectedIndex)
                {
                    case 0:
                        CONFIG.bReportHTTPErrors = false;
                        CONFIG.bReportHTTPLintErrors = false;
                        FiddlerApplication.Prefs.SetBoolPref("fiddler.Lint.HTTP", false);
                        break;

                    case 1:
                        CONFIG.bReportHTTPErrors = true;
                        CONFIG.bReportHTTPLintErrors = false;
                        FiddlerApplication.Prefs.SetBoolPref("fiddler.Lint.HTTP", false);
                        break;

                    case 2:
                        CONFIG.bReportHTTPErrors = true;
                        CONFIG.bReportHTTPLintErrors = true;
                        FiddlerApplication.Prefs.SetBoolPref("fiddler.Lint.HTTP", true);
                        break;
                }
                CONFIG.JSEditor = this.txtScriptEditor.Text;
                if (this.lnkHTTPSProtocols.Tag != null)
                {
                    string tag = this.lnkHTTPSProtocols.Tag as string;
                    if (!string.IsNullOrEmpty(tag))
                    {
                        SslProtocols protocols = Utilities.ParseSSLProtocolString(tag);
                        if (protocols != SslProtocols.None)
                        {
                            CONFIG.oAcceptedServerHTTPSProtocols = protocols;
                            CONFIG.bMimicClientHTTPSProtocols = tag.OICContains("<client>");
                            FiddlerApplication.Prefs.SetStringPref("fiddler.network.https.SupportedServerProtocolVersions", tag);
                        }
                    }
                    this.lnkHTTPSProtocols.Tag = null;
                }
                if (this.txtCompareTool.Text != CONFIG.GetPath("WINDIFF"))
                {
                    FiddlerApplication.Prefs.SetStringPref("fiddler.config.path.differ", this.txtCompareTool.Text);
                }
                if (this.txtTextEditor.Text != CONFIG.GetPath("TextEditor"))
                {
                    FiddlerApplication.Prefs.SetStringPref("fiddler.config.path.texteditor", this.txtTextEditor.Text);
                }
                CONFIG.bAllowRemoteConnections = this.cbAllowRemote.Checked;
                CONFIG.bHookWithPAC = this.cbHookWithPAC.Checked;
                CONFIG.m_sAdditionalScriptReferences = this.txtScriptReferences.Text.Trim();
                if ((int.TryParse(this.txtListenPort.Text, out num) && (num > 0)) && (num < 0xffff))
                {
                    CONFIG.ListenPort = num;
                }
                if (this.bGatewayTouched)
                {
                    this.applyGatewaySetting();
                }
                CONFIG.bCaptureCONNECT = this.cbCaptureCONNECT.Checked;
                CONFIG.bCaptureFTP = this.cbCaptureFTP.Checked;
                CONFIG.bEnableIPv6 = this.cbEnableIPv6.Checked;
                SessionTimers.EnableHighResolutionTimers = this.cbEnableHighResTimers.Checked;
                CONFIG.sHostsThatBypassFiddler = this.txtFiddlerBypass.Text.Trim();
                CONFIG.bHookAllConnections = this.cbHookAllConnections.Checked;
                this.actApplyHotkeySetting();
                if (this.cbParseWebSocketMessages.Checked)
                {
                    FiddlerApplication.Prefs.RemovePref("fiddler.websocket.ParseMessages");
                }
                else
                {
                    FiddlerApplication.Prefs.SetBoolPref("fiddler.websocket.ParseMessages", false);
                }
                FiddlerApplication.Prefs.SetBoolPref("fiddler.ui.ShowMemoryPanel", this.cbShowMemoryPanel.Checked);
                CONFIG.bMITM_HTTPS = this.cbDecryptHTTPS.Checked;
                CONFIG.IgnoreServerCertErrors = this.cbIgnoreServerCertErrors.Checked;
                FiddlerApplication.Prefs.SetBoolPref("fiddler.network.https.checkcertificaterevocation", this.cbCheckRevocation.Checked);
                CONFIG.DecryptWhichProcesses = (ProcessFilterCategories) this.cbxDecryptList.SelectedIndex;
                FiddlerApplication.Prefs.SetStringPref("fiddler.network.https.NoDecryptionHosts", this.txtSkipDecryption.Text);
                FiddlerApplication.Prefs.SetBoolPref("fiddler.updater.OfferBetaBuilds", this.cbOfferBetaUpdates.Checked);
                switch (this.cbxAbort.SelectedIndex)
                {
                    case 0:
                        FiddlerApplication.Prefs.RemovePref("fiddler.network.streaming.abortifclientaborts");
                        FiddlerApplication.Prefs.SetBoolPref("fiddler.network.streaming.abortorphanstreams", false);
                        break;

                    case 2:
                        FiddlerApplication.Prefs.SetBoolPref("fiddler.network.streaming.abortifclientaborts", true);
                        FiddlerApplication.Prefs.RemovePref("fiddler.network.streaming.abortorphanstreams");
                        break;

                    default:
                        FiddlerApplication.Prefs.RemovePref("fiddler.network.streaming.abortifclientaborts");
                        FiddlerApplication.Prefs.RemovePref("fiddler.network.streaming.abortorphanstreams");
                        break;
                }
                CONFIG.cbAutoStreamAndForget = (int) (this.numStreamAndForget.Value * 1000000M);
                FiddlerApplication.Prefs.SetInt32Pref("fiddler.memory.StreamAndForgetIfOver", CONFIG.cbAutoStreamAndForget);
                CONFIG.bAlwaysShowTrayIcon = this.cbAlwaysShowTrayIcon.Checked;
                CONFIG.bSmartScroll = this.cbUseSmartScroll.Checked;
                CONFIG.bStreamAudioVideo = this.cbStreamVideo.Checked;
                if (this.cbxFontSize.SelectedIndex > -1)
                {
                    float num2 = float.Parse(this.cbxFontSize.Text, NumberStyles.Float, CultureInfo.InvariantCulture);
                    if (CONFIG.flFontSize != num2)
                    {
                        CONFIG.flFontSize = num2;
                        FiddlerApplication._frmMain.actSetFontSize(CONFIG.flFontSize);
                    }
                }
                FiddlerApplication.Prefs.SetBoolPref("fiddler.threads.BumpBasePriority", this.cbBumpPriority.Checked);
                try
                {
                    Process.GetCurrentProcess().PriorityClass = this.cbBumpPriority.Checked ? ProcessPriorityClass.AboveNormal : ProcessPriorityClass.Normal;
                }
                catch
                {
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "ApplySettings Failure");
            }
            base.Close();
        }

        private void actApplyHotkeySetting()
        {
            int iHotkey = CONFIG.iHotkey;
            int iHotkeyMod = CONFIG.iHotkeyMod;
            if (this.txtHotkey.Text.Length == 1)
            {
                CONFIG.iHotkey = this.txtHotkey.Text[0];
            }
            switch (this.cbxHotkeyMod.SelectedIndex)
            {
                case 0:
                    CONFIG.iHotkeyMod = 8;
                    break;

                case 2:
                    CONFIG.iHotkeyMod = 6;
                    break;

                default:
                    CONFIG.iHotkeyMod = 3;
                    break;
            }
            if ((iHotkey != CONFIG.iHotkey) || (iHotkeyMod != CONFIG.iHotkeyMod))
            {
                FiddlerApplication.UI.UnregisterHotkey();
                FiddlerApplication.UI.RegisterHotkey();
            }
        }

        private void applyGatewaySetting()
        {
            this.Text = "Adjusting Gateway...";
            this.Refresh();
            GatewayType upstreamGateway = CONFIG.UpstreamGateway;
            string str = FiddlerApplication.Prefs.GetStringPref("fiddler.network.gateway.proxies", string.Empty).Trim();
            string str2 = FiddlerApplication.Prefs.GetStringPref("fiddler.network.gateway.exceptions", string.Empty).Trim();
            if (this.rdoGatewayNone.Checked)
            {
                CONFIG.UpstreamGateway = GatewayType.None;
            }
            else if (this.rdoGatewayWinINET.Checked)
            {
                CONFIG.UpstreamGateway = GatewayType.System;
            }
            else if (this.rdoGatewayWPAD.Checked)
            {
                CONFIG.UpstreamGateway = GatewayType.WPAD;
            }
            else
            {
                CONFIG.UpstreamGateway = GatewayType.Manual;
            }
            FiddlerApplication.Prefs.SetStringPref("fiddler.network.gateway.proxies", this.txtManualProxyString.Text.Trim());
            FiddlerApplication.Prefs.SetStringPref("fiddler.network.gateway.exceptions", this.txtProxyExceptionList.Text.Trim());
            if (((this.txtManualProxyString.Text.Trim() != str) || (this.txtProxyExceptionList.Text.Trim() != str2)) || (CONFIG.UpstreamGateway != upstreamGateway))
            {
                FiddlerApplication.oProxy.RefreshUpstreamGatewayInformation();
            }
        }

        private void btnActions_Click(object sender, EventArgs e)
        {
            if (!this.mnuHTTPS.Visible)
            {
                this.mnuHTTPS.Show(this.btnActions, new Point(0, this.btnActions.Height));
            }
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            this.actApplyChanges();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnChooseCompare_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == this.dlgChooseEditor.ShowDialog(this))
            {
                this.txtCompareTool.Text = this.dlgChooseEditor.FileName;
            }
        }

        private void btnChooseEditor_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == this.dlgChooseEditor.ShowDialog(this))
            {
                this.txtScriptEditor.Text = this.dlgChooseEditor.FileName;
            }
        }

        private void btnChooseTextEditor_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == this.dlgChooseEditor.ShowDialog(this))
            {
                this.txtTextEditor.Text = this.dlgChooseEditor.FileName;
            }
        }

        private void btnSetBGColor_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();
            dialog.FullOpen = true;
            dialog.AnyColor = false;
            dialog.CustomColors = new int[] { _ColorToInt(CONFIG.colorDisabledEdit), _ColorToInt(Color.FromArgb(0xee, 0xe1, 210)), _ColorToInt(Color.AliceBlue), _ColorToInt(Color.FromArgb(0x41, 0x29, 0x1b)) };
            dialog.Color = CONFIG.colorDisabledEdit;
            if (DialogResult.OK == dialog.ShowDialog(this))
            {
                if (dialog.Color.ToArgb() == -1)
                {
                    FiddlerApplication.DoNotifyUser(this, "Sorry, you cannot set the disabled control color to white.", "Invalid Selection", MessageBoxIcon.Hand);
                }
                else
                {
                    CONFIG.colorDisabledEdit = dialog.Color;
                    this.btnSetBGColor.BackColor = CONFIG.colorDisabledEdit;
                    this.btnSetBGColor.ForeColor = Utilities.GetContrastingTextColor(CONFIG.colorDisabledEdit);
                }
            }
            dialog.Dispose();
        }

        private void btnSetFont_Click(object sender, EventArgs e)
        {
            try
            {
                using (FontDialog dialog = new FontDialog())
                {
                    dialog.FontMustExist = true;
                    dialog.ShowEffects = false;
                    string stringPref = FiddlerApplication.Prefs.GetStringPref("fiddler.ui.font.face", null);
                    if (!string.IsNullOrEmpty(stringPref))
                    {
                        try
                        {
                            dialog.Font = new Font(stringPref, float.Parse(this.cbxFontSize.Text));
                        }
                        catch
                        {
                        }
                    }
                    else
                    {
                        dialog.Font = FiddlerApplication.UI.Font;
                    }
                    dialog.MinSize = 7;
                    dialog.MaxSize = 0x12;
                    if (DialogResult.OK == dialog.ShowDialog())
                    {
                        FiddlerApplication.Prefs.SetStringPref("fiddler.ui.font.face", dialog.Font.Name);
                        float size = dialog.Font.Size;
                        foreach (string str2 in this.cbxFontSize.Items)
                        {
                            if ((0.5 + size) >= float.Parse(str2, NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                this.cbxFontSize.Text = str2;
                            }
                        }
                        float flFontSize = float.Parse(this.cbxFontSize.Text, NumberStyles.Float, CultureInfo.InvariantCulture);
                        if (flFontSize != CONFIG.flFontSize)
                        {
                            FiddlerApplication.UI.actSetFontSize(flFontSize);
                        }
                        FiddlerApplication.UI.ApplyOverrideFont();
                    }
                }
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "Failed to set font");
            }
        }

        private void cbAllowRemote_Click(object sender, EventArgs e)
        {
            if (this.cbAllowRemote.Checked)
            {
                FiddlerApplication.DoNotifyUser(this, "WARNING: This option allows remote clients to 'bounce' traffic through your PC's network connection.\n\nFiddler must be restarted for this change to take effect.\n\nYou may see a prompt from your Firewall requesting permission to Allow Remote Access after restarting Fiddler. If you do not, you may need to reconfigure your firewall manually.", "Enabling Remote Access", MessageBoxIcon.Asterisk);
            }
        }

        private void cbAlwaysShowTrayIcon_CheckedChanged(object sender, EventArgs e)
        {
            FiddlerApplication.UI.notifyIcon.Visible = this.cbAlwaysShowTrayIcon.Checked;
        }

        private void cbCaptureCONNECT_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.cbCaptureCONNECT.Checked)
            {
                this.cbDecryptHTTPS.Enabled = this.cbDecryptHTTPS.Checked = this.cbCheckRevocation.Visible = this.cbIgnoreServerCertErrors.Visible = this.cbIgnoreServerCertErrors.Checked = false;
            }
            else
            {
                this.cbDecryptHTTPS.Enabled = true;
            }
        }

        private void cbDecryptHTTPS_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.cbDecryptHTTPS.Checked)
            {
                this.lnkHTTPSProtocols.Visible = this.miTrustRootCertificate.Enabled = this.miExportRootCert.Enabled = this.lblSkipDecryption.Visible = this.txtSkipDecryption.Visible = this.cbxDecryptList.Visible = this.cbCheckRevocation.Visible = this.cbIgnoreServerCertErrors.Visible = this.cbIgnoreServerCertErrors.Checked = false;
            }
            else
            {
                this.lnkHTTPSProtocols.Visible = this.miTrustRootCertificate.Enabled = this.miExportRootCert.Enabled = this.lblSkipDecryption.Visible = this.txtSkipDecryption.Visible = this.cbxDecryptList.Visible = this.cbIgnoreServerCertErrors.Visible = this.cbCheckRevocation.Visible = true;
            }
            this.miRemoveCerts.Enabled = !this.cbDecryptHTTPS.Checked;
        }

        private void cbDecryptHTTPS_Click(object sender, EventArgs e)
        {
            if (!this.cbDecryptHTTPS.Checked)
            {
                CONFIG.bMITM_HTTPS = false;
            }
            else
            {
                CertMaker.EnsureReady();
                this.ShowCertProvider();
                this.Refresh();
                if ((CertMaker.rootCertExists() || CertMaker.createRootCert()) && !CertMaker.rootCertIsTrusted())
                {
                    this._TrustRootCertificate();
                }
            }
        }

        private void cbFIP_Click(object sender, EventArgs e)
        {
            if (this.cbFIP.Checked && (DialogResult.Cancel == MessageBox.Show(this, "When the Fiddler Improvement Program is enabled, Fiddler will upload anonymous usage and configuration information.\n\nThank you for helping to improve Fiddler!", "Joining the Fiddler Improvement Program", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk)))
            {
                this.cbFIP.Checked = false;
                FiddlerApplication.Prefs.SetBoolPref("fiddler.telemetry.AskPermission", false);
            }
        }

        private void cbIgnoreServerCertErrors_CheckedChanged(object sender, EventArgs e)
        {
            this.cbIgnoreServerCertErrors.ForeColor = this.cbIgnoreServerCertErrors.Checked ? Color.Crimson : SystemColors.ControlText;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void frmOptions_Load(object sender, EventArgs e)
        {
            try
            {
                this.cbAttachOnStartup.Checked = CONFIG.bAttachOnBoot;
                this.cbAutoCheckForUpdates.Checked = CONFIG.bVersionCheck;
                this.cbAutoCheckForUpdates.Enabled = this.cbOfferBetaUpdates.Enabled = !CONFIG.bVersionCheckBlocked;
                this.cbOfferBetaUpdates.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.updater.OfferBetaBuilds", CONFIG.bIsBeta);
                this.cbCheckRevocation.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.network.https.checkcertificaterevocation", false);
                bool boolPref = FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.abortifclientaborts", false);
                bool flag2 = FiddlerApplication.Prefs.GetBoolPref("fiddler.network.streaming.abortorphanstreams", true);
                this.cbxAbort.SelectedIndex = boolPref ? 2 : (flag2 ? 1 : 0);
                this.cbFIP.Checked = CONFIG.bEnableAnalytics;
                this.cbAutoReloadScript.Checked = CONFIG.bAutoLoadScript;
                this.cbHideOnMinimize.Checked = CONFIG.bHideOnMinimize;
                this.cbResetSessionIDOnListClear.Checked = CONFIG.bResetCounterOnClear;
                this.txtScriptEditor.Text = CONFIG.JSEditor;
                this.txtTextEditor.Text = CONFIG.GetPath("TextEditor");
                this.txtCompareTool.Text = CONFIG.GetPath("WINDIFF");
                this.cbAllowRemote.Checked = CONFIG.bAllowRemoteConnections;
                this.cbHookWithPAC.Checked = CONFIG.bHookWithPAC;
                this.cbCaptureCONNECT.Checked = CONFIG.bCaptureCONNECT;
                this.cbCaptureFTP.Checked = CONFIG.bCaptureFTP;
                this.cbEnableIPv6.Checked = CONFIG.bEnableIPv6;
                this.cbEnableHighResTimers.Checked = SessionTimers.EnableHighResolutionTimers;
                this.cbDecryptHTTPS.Checked = CONFIG.bMITM_HTTPS;
                this.cbParseWebSocketMessages.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.websocket.ParseMessages", true);
                this.cbShowMemoryPanel.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.ui.ShowMemoryPanel", IntPtr.Size == 4);
                this.txtSkipDecryption.Text = FiddlerApplication.Prefs.GetStringPref("fiddler.network.https.NoDecryptionHosts", string.Empty);
                try
                {
                    this.cbxDecryptList.SelectedIndex = (int) CONFIG.DecryptWhichProcesses;
                }
                catch
                {
                    this.cbxDecryptList.SelectedIndex = 0;
                }
                this.cbIgnoreServerCertErrors.Checked = CONFIG.IgnoreServerCertErrors;
                this.cbDecryptHTTPS.Enabled = this.cbCaptureCONNECT.Checked;
                this.lnkHTTPSProtocols.Visible = this.miTrustRootCertificate.Enabled = this.miExportRootCert.Enabled = this.lblSkipDecryption.Visible = this.txtSkipDecryption.Visible = this.cbxDecryptList.Visible = this.cbIgnoreServerCertErrors.Visible = this.cbCheckRevocation.Visible = this.cbDecryptHTTPS.Checked;
                this.cbUseSmartScroll.Checked = CONFIG.bSmartScroll;
                this.cbStreamVideo.Checked = CONFIG.bStreamAudioVideo;
                this.cbReuseServerSockets.Checked = CONFIG.bReuseServerSockets;
                this.cbReuseClientSockets.Checked = CONFIG.bReuseClientSockets;
                if (CONFIG.bReportHTTPErrors)
                {
                    bool flag3 = FiddlerApplication.Prefs.GetBoolPref("fiddler.Lint.HTTP", false);
                    this.cbxHTTPLint.SelectedIndex = flag3 ? 2 : 1;
                }
                else
                {
                    this.cbxHTTPLint.SelectedIndex = 0;
                }
                this.txtScriptReferences.Text = CONFIG.m_sAdditionalScriptReferences;
                this.txtListenPort.Text = CONFIG.ListenPort.ToString();
                this.txtListenPort.Enabled = !CONFIG.bUsingPortOverride;
                this.txtFiddlerBypass.Text = CONFIG.sHostsThatBypassFiddler;
                this.txtManualProxyString.Text = FiddlerApplication.Prefs.GetStringPref("fiddler.network.gateway.proxies", string.Empty).Trim();
                this.txtProxyExceptionList.Text = FiddlerApplication.Prefs.GetStringPref("fiddler.network.gateway.exceptions", string.Empty).Trim();
                switch (CONFIG.UpstreamGateway)
                {
                    case GatewayType.None:
                        this.rdoGatewayNone.Checked = true;
                        break;

                    case GatewayType.Manual:
                        this.rdoGatewayManual.Checked = true;
                        break;

                    case GatewayType.System:
                        this.rdoGatewayWinINET.Checked = true;
                        break;

                    case GatewayType.WPAD:
                        this.rdoGatewayWPAD.Checked = true;
                        break;
                }
                this.lnkShowGatewayInfo.Enabled = CONFIG.UpstreamGateway != GatewayType.None;
                this.cbHookAllConnections.Checked = CONFIG.bHookAllConnections;
                this.btnSetBGColor.BackColor = CONFIG.colorDisabledEdit;
                this.btnSetBGColor.ForeColor = Utilities.GetContrastingTextColor(CONFIG.colorDisabledEdit);
                this.cbAlwaysShowTrayIcon.Checked = CONFIG.bAlwaysShowTrayIcon;
                this.cbxFontSize.Text = CONFIG.flFontSize.ToString("##.##");
                this.txtHotkey.Text = new string((char) CONFIG.iHotkey, 1);
                switch (CONFIG.iHotkeyMod)
                {
                    case 6:
                        this.cbxHotkeyMod.SelectedIndex = 2;
                        break;

                    case 8:
                        this.cbxHotkeyMod.SelectedIndex = 0;
                        break;

                    default:
                        this.cbxHotkeyMod.SelectedIndex = 1;
                        break;
                }
                this.txtExtensions.Text = _GetExtensionsList();
                this._FillConnectoidList();
                if (!CONFIG.sFiddlerListenHostPort.StartsWith("127.0.0.1:"))
                {
                    this.lblProxyRegistrationHostname.Text = "Proxy registration address:\n" + CONFIG.sFiddlerListenHostPort;
                    this.lblProxyRegistrationHostname.Visible = true;
                }
                decimal maximum = (decimal) (((double) CONFIG.cbAutoStreamAndForget) / 1000000.0);
                if (maximum > this.numStreamAndForget.Maximum)
                {
                    maximum = this.numStreamAndForget.Maximum;
                }
                if (maximum < 0M)
                {
                    maximum = 0M;
                }
                this.numStreamAndForget.Value = maximum;
                this.cbBumpPriority.Checked = FiddlerApplication.Prefs.GetBoolPref("fiddler.threads.BumpBasePriority", false);
                this.ShowCertProvider();
                this.ShowEnabledHTTPSProtocols(CONFIG.oAcceptedServerHTTPSProtocols, CONFIG.bMimicClientHTTPSProtocols);
            }
            catch (Exception exception)
            {
                FiddlerApplication.ReportException(exception, "LoadSettings Failure");
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmOptions));
            this.lblNotices = new Label();
            this.lblSkipDecryption = new Label();
            this.lblHTTPSDescription = new Label();
            this.cbAutoCheckForUpdates = new CheckBox();
            this.cbAutoReloadScript = new CheckBox();
            this.btnApply = new Button();
            this.btnCancel = new Button();
            this.txtScriptReferences = new TextBox();
            this.cbEnableIPv6 = new CheckBox();
            this.gbScript = new GroupBox();
            this.txtHotkey = new TextBox();
            this.cbxHotkeyMod = new ComboBox();
            this.dlgChooseEditor = new OpenFileDialog();
            this.toolTip1 = new ToolTip(this.components);
            this.cbIgnoreServerCertErrors = new CheckBox();
            this.cbDecryptHTTPS = new CheckBox();
            this.cbCaptureCONNECT = new CheckBox();
            this.cbAttachOnStartup = new CheckBox();
            this.cbxFontSize = new ComboBox();
            this.cbHideOnMinimize = new CheckBox();
            this.cbUseSmartScroll = new CheckBox();
            this.cbStreamVideo = new CheckBox();
            this.txtListenPort = new TextBox();
            this.cbResetSessionIDOnListClear = new CheckBox();
            this.txtFiddlerBypass = new TextBox();
            this.cbHookAllConnections = new CheckBox();
            this.cbAlwaysShowTrayIcon = new CheckBox();
            this.lnkCopyPACURL = new LinkLabel();
            this.cbReuseClientSockets = new CheckBox();
            this.cbReuseServerSockets = new CheckBox();
            this.cbAllowRemote = new CheckBox();
            this.cbHookWithPAC = new CheckBox();
            this.txtSkipDecryption = new TextBox();
            this.cbFIP = new CheckBox();
            this.btnSetBGColor = new Button();
            this.cbxDecryptList = new ComboBox();
            this.cbCaptureFTP = new CheckBox();
            this.txtScriptEditor = new TextBox();
            this.btnChooseFSE = new Button();
            this.txtCompareTool = new TextBox();
            this.btnChooseCompare = new Button();
            this.txtTextEditor = new TextBox();
            this.btnChooseTextEditor = new Button();
            this.lblProxyRegistrationHostname = new Label();
            this.cbEnableHighResTimers = new CheckBox();
            this.cbOfferBetaUpdates = new CheckBox();
            this.btnSetFont = new Button();
            this.cbCheckRevocation = new CheckBox();
            this.lnkCertMaker = new LinkLabel();
            this.tabsOptions = new TabControl();
            this.tabGeneral = new TabPage();
            this.cbxHTTPLint = new ComboBox();
            this.tabHTTPS = new TabPage();
            this.btnActions = new Button();
            this.lnkHTTPSProtocols = new LinkLabel();
            this.tabConnections = new TabPage();
            this.lnkHookup = new LinkLabel();
            this.clbConnections = new CheckedListBox();
            this.tabGateway = new TabPage();
            this.txtProxyExceptionList = new TextBox();
            this.txtManualProxyString = new TextBox();
            this.rdoGatewayManual = new RadioButton();
            this.rdoGatewayWPAD = new RadioButton();
            this.rdoGatewayNone = new RadioButton();
            this.rdoGatewayWinINET = new RadioButton();
            this.lnkShowGatewayInfo = new LinkLabel();
            this.tabAppearance = new TabPage();
            this.tabExtensions = new TabPage();
            this.gbAutoFiddles = new GroupBox();
            this.lnkFindExtensions = new LinkLabel();
            this.txtExtensions = new RichTextBox();
            this.tabPerformance = new TabPage();
            this.cbBumpPriority = new CheckBox();
            this.cbShowMemoryPanel = new CheckBox();
            this.numStreamAndForget = new NumericUpDown();
            this.cbParseWebSocketMessages = new CheckBox();
            this.cbxAbort = new ComboBox();
            this.tabTools = new TabPage();
            this.pnlOptionsFooter = new Panel();
            this.lnkOptionsHelp = new LinkLabel();
            this.mnuHTTPS = new ContextMenuStrip(this.components);
            this.miTrustRootCertificate = new ToolStripMenuItem();
            this.miExportRootCert = new ToolStripMenuItem();
            this.miRemoveCerts = new ToolStripMenuItem();
            this.miResetAllCertificates = new ToolStripMenuItem();
            Label label = new Label();
            Label label2 = new Label();
            Label label3 = new Label();
            Label label4 = new Label();
            Label label5 = new Label();
            Label label6 = new Label();
            Label control = new Label();
            Label label8 = new Label();
            Label label9 = new Label();
            Label label10 = new Label();
            Label label11 = new Label();
            Label label12 = new Label();
            Label label13 = new Label();
            Label label14 = new Label();
            Label label15 = new Label();
            ToolStripSeparator separator = new ToolStripSeparator();
            ToolStripMenuItem item = new ToolStripMenuItem();
            ToolStripSeparator separator2 = new ToolStripSeparator();
            ToolStripMenuItem item2 = new ToolStripMenuItem();
            this.gbScript.SuspendLayout();
            this.tabsOptions.SuspendLayout();
            this.tabGeneral.SuspendLayout();
            this.tabHTTPS.SuspendLayout();
            this.tabConnections.SuspendLayout();
            this.tabGateway.SuspendLayout();
            this.tabAppearance.SuspendLayout();
            this.tabExtensions.SuspendLayout();
            this.gbAutoFiddles.SuspendLayout();
            this.tabPerformance.SuspendLayout();
            this.numStreamAndForget.BeginInit();
            this.tabTools.SuspendLayout();
            this.pnlOptionsFooter.SuspendLayout();
            this.mnuHTTPS.SuspendLayout();
            base.SuspendLayout();
            label.Location = new Point(15, 40);
            label.Name = "lblToolsFSE";
            label.Size = new Size(0x72, 0x12);
            label.TabIndex = 3;
            label.Text = "&FiddlerScript Editor:";
            label.TextAlign = ContentAlignment.MiddleRight;
            label2.Location = new Point(13, 13);
            label2.Name = "lblToolsTextEditor";
            label2.Size = new Size(0x72, 0x12);
            label2.TabIndex = 0;
            label2.Text = "&Text Editor:";
            label2.TextAlign = ContentAlignment.MiddleRight;
            label3.AutoSize = true;
            label3.Location = new Point(0x101, 0x47);
            label3.Name = "lblPerfMB";
            label3.Size = new Size(0x15, 13);
            label3.TabIndex = 4;
            label3.Text = "mb";
            label4.Location = new Point(6, 0x2e);
            label4.Name = "lblScriptRefs";
            label4.Size = new Size(0x57, 0x12);
            label4.TabIndex = 4;
            label4.Text = "Re&ferences:";
            label4.TextAlign = ContentAlignment.MiddleRight;
            label5.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            label5.ForeColor = SystemColors.ControlDarkDark;
            label5.Location = new Point(0x60, 70);
            label5.Name = "lblAssemblyReferences";
            label5.Size = new Size(0x1a7, 0x13);
            label5.TabIndex = 6;
            label5.Text = @"e.g. C:\lib\Utils.dll; c:\lib\myappname.exe";
            label6.Location = new Point(0x45, 0xb6);
            label6.Name = "lblHotkey";
            label6.Size = new Size(0x72, 0x12);
            label6.TabIndex = 10;
            label6.Text = "Systemwide &Hotkey:";
            label6.TextAlign = ContentAlignment.MiddleRight;
            control.AutoSize = true;
            control.Location = new Point(0xf8, 0xab);
            control.Name = "lblFiddlerBypass";
            control.Size = new Size(0xc4, 13);
            control.TabIndex = 15;
            control.Text = "Bypass F&iddler for URLs that start with:";
            this.toolTip1.SetToolTip(control, "Browser-style Proxy Bypass list. Semicolon-delimited. Requires restart. E.g.  *example.*:8081;https://*.fiddler2.com");
            label8.AutoSize = true;
            label8.Location = new Point(7, 0x99);
            label8.Name = "lblOnProtocolViolations";
            label8.Size = new Size(0xb0, 13);
            label8.TabIndex = 8;
            label8.Text = "If protocol &violations are observed:";
            label8.TextAlign = ContentAlignment.MiddleRight;
            label9.Location = new Point(13, 0x36);
            label9.Name = "lblListenPort";
            label9.Size = new Size(0x7d, 14);
            label9.TabIndex = 1;
            label9.Text = "Fiddler &listens on port:";
            label9.TextAlign = ContentAlignment.MiddleRight;
            label10.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            label10.Location = new Point(3, 3);
            label10.Name = "lblExplainConn";
            label10.Size = new Size(520, 0x1d);
            label10.TabIndex = 0;
            label10.Text = "Fiddler can debug traffic from any application that accepts a HTTP Proxy. All WinINET traffic is routed through Fiddler when \"File > Capture Traffic\" is checked.";
            label10.TextAlign = ContentAlignment.MiddleLeft;
            label11.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            label11.Location = new Point(3, 3);
            label11.Name = "lblGatewayIntro";
            label11.Size = new Size(520, 0x1d);
            label11.TabIndex = 0;
            label11.Text = "By default, Fiddler \"chains\" to the system's default proxy (Client -> Fiddler -> Gateway -> Web). These settings allow you to override that behavior.";
            label11.TextAlign = ContentAlignment.MiddleLeft;
            label12.Location = new Point(3, 0x10);
            label12.Name = "lblFontSize";
            label12.Size = new Size(0x38, 0x12);
            label12.TabIndex = 0;
            label12.Text = "&Font size:";
            label12.TextAlign = ContentAlignment.MiddleRight;
            label13.AutoSize = true;
            label13.Location = new Point(13, 0x47);
            label13.Name = "lblStreamAndForget";
            label13.Size = new Size(0x9a, 13);
            label13.TabIndex = 2;
            label13.Text = "Stream and &forget bodies over";
            label14.AutoSize = true;
            label14.Location = new Point(9, 0x63);
            label14.Name = "lblAbortIfAbort";
            label14.Size = new Size(0x9e, 13);
            label14.TabIndex = 5;
            label14.Text = "If client &aborts while streaming:";
            label15.Location = new Point(15, 0x44);
            label15.Name = "lblToolsCompare";
            label15.Size = new Size(0x72, 0x12);
            label15.TabIndex = 6;
            label15.Text = "File &Diff Tool:";
            label15.TextAlign = ContentAlignment.MiddleRight;
            separator.Name = "toolStripMenuItem2";
            separator.Size = new Size(240, 6);
            item.Name = "miOpenCertMgr";
            item.Size = new Size(0xf3, 0x16);
            item.Text = "Open &Windows Certificate Manager";
            item.Click += new EventHandler(this.miOpenCertMgr_Click);
            separator2.Name = "toolStripMenuItem1";
            separator2.Size = new Size(240, 6);
            item2.Name = "miLearnMore";
            item2.Size = new Size(0xf3, 0x16);
            item2.Text = "&Learn More about HTTPS Decryption";
            item2.Click += new EventHandler(this.miLearnMore_Click);
            this.lblNotices.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.lblNotices.ForeColor = Color.DimGray;
            this.lblNotices.Location = new Point(0x3b, 3);
            this.lblNotices.Name = "lblNotices";
            this.lblNotices.Size = new Size(0x1d7, 0x21);
            this.lblNotices.TabIndex = 2;
            this.lblNotices.Text = "Note: Changes may not take effect until Fiddler is restarted.";
            this.lblNotices.TextAlign = ContentAlignment.MiddleLeft;
            this.lblSkipDecryption.AutoSize = true;
            this.lblSkipDecryption.Location = new Point(0x15, 0xc1);
            this.lblSkipDecryption.Name = "lblSkipDecryption";
            this.lblSkipDecryption.Size = new Size(0xc2, 13);
            this.lblSkipDecryption.TabIndex = 7;
            this.lblSkipDecryption.Text = "&Skip decryption for the following hosts:";
            this.lblHTTPSDescription.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.lblHTTPSDescription.Location = new Point(6, 3);
            this.lblHTTPSDescription.Name = "lblHTTPSDescription";
            this.lblHTTPSDescription.Size = new Size(520, 0x15);
            this.lblHTTPSDescription.TabIndex = 0;
            this.lblHTTPSDescription.Text = "Fiddler can decrypt HTTPS sessions by re-signing traffic using self-generated certificates.";
            this.lblHTTPSDescription.TextAlign = ContentAlignment.MiddleLeft;
            this.cbAutoCheckForUpdates.Location = new Point(8, 0x11);
            this.cbAutoCheckForUpdates.Name = "cbAutoCheckForUpdates";
            this.cbAutoCheckForUpdates.Size = new Size(0xf1, 0x12);
            this.cbAutoCheckForUpdates.TabIndex = 0;
            this.cbAutoCheckForUpdates.Text = "Check for &updates on startup";
            this.toolTip1.SetToolTip(this.cbAutoCheckForUpdates, "Fiddler will hit a webservice at fiddler2.com to check for new versions.");
            this.cbAutoReloadScript.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.cbAutoReloadScript.Location = new Point(10, 20);
            this.cbAutoReloadScript.Name = "cbAutoReloadScript";
            this.cbAutoReloadScript.Size = new Size(0x1fd, 0x17);
            this.cbAutoReloadScript.TabIndex = 0;
            this.cbAutoReloadScript.Text = "Automatically reload &script when changed";
            this.toolTip1.SetToolTip(this.cbAutoReloadScript, "Fiddler will automatically reload the script when it detects that the script file has been changed.");
            this.btnApply.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnApply.Location = new Point(0x174, 8);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new Size(0x4e, 0x17);
            this.btnApply.TabIndex = 0;
            this.btnApply.Text = "&OK";
            this.btnApply.Click += new EventHandler(this.btnApply_Click);
            this.btnCancel.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.btnCancel.DialogResult = DialogResult.Cancel;
            this.btnCancel.Location = new Point(0x1ca, 8);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(0x4e, 0x17);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.txtScriptReferences.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.txtScriptReferences.Location = new Point(0x63, 0x2e);
            this.txtScriptReferences.Name = "txtScriptReferences";
            this.txtScriptReferences.Size = new Size(0x1a6, 0x15);
            this.txtScriptReferences.TabIndex = 5;
            this.toolTip1.SetToolTip(this.txtScriptReferences, "List any additional assemblies to reference within FiddlerScript.");
            this.cbEnableIPv6.Location = new Point(8, 60);
            this.cbEnableIPv6.Name = "cbEnableIPv6";
            this.cbEnableIPv6.Size = new Size(0x1fc, 0x12);
            this.cbEnableIPv6.TabIndex = 2;
            this.cbEnableIPv6.Text = "Enable IPv&6 (if available)";
            this.toolTip1.SetToolTip(this.cbEnableIPv6, "Bind Fiddler's listener to the IPv6 adapter on the local host.");
            this.gbScript.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.gbScript.Controls.Add(this.txtScriptReferences);
            this.gbScript.Controls.Add(label4);
            this.gbScript.Controls.Add(this.cbAutoReloadScript);
            this.gbScript.Controls.Add(label5);
            this.gbScript.Location = new Point(3, 8);
            this.gbScript.Name = "gbScript";
            this.gbScript.Size = new Size(0x20f, 0x5c);
            this.gbScript.TabIndex = 0;
            this.gbScript.TabStop = false;
            this.gbScript.Text = "Scripting";
            this.txtHotkey.CharacterCasing = CharacterCasing.Upper;
            this.txtHotkey.Location = new Point(0x169, 0xb6);
            this.txtHotkey.MaxLength = 1;
            this.txtHotkey.Name = "txtHotkey";
            this.txtHotkey.Size = new Size(0x1a, 0x15);
            this.txtHotkey.TabIndex = 12;
            this.txtHotkey.Text = "F";
            this.cbxHotkeyMod.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxHotkeyMod.Items.AddRange(new object[] { "WIN +", "CTRL + ALT +", "CTRL + SHIFT +" });
            this.cbxHotkeyMod.Location = new Point(0xbf, 0xb6);
            this.cbxHotkeyMod.Name = "cbxHotkeyMod";
            this.cbxHotkeyMod.Size = new Size(0x70, 0x15);
            this.cbxHotkeyMod.TabIndex = 11;
            this.dlgChooseEditor.DefaultExt = "exe";
            this.dlgChooseEditor.Filter = "Executables (*.exe)|*.exe|All Files (*.*)|*.*";
            this.dlgChooseEditor.Title = "Select Tool";
            this.cbIgnoreServerCertErrors.AutoSize = true;
            this.cbIgnoreServerCertErrors.Location = new Point(0x18, 0x6a);
            this.cbIgnoreServerCertErrors.Name = "cbIgnoreServerCertErrors";
            this.cbIgnoreServerCertErrors.Size = new Size(0xdb, 0x11);
            this.cbIgnoreServerCertErrors.TabIndex = 4;
            this.cbIgnoreServerCertErrors.Text = "&Ignore server certificate errors (unsafe)";
            this.toolTip1.SetToolTip(this.cbIgnoreServerCertErrors, "Check to suppress the warning shown when a remote server presents an invalid certificate.");
            this.cbIgnoreServerCertErrors.CheckedChanged += new EventHandler(this.cbIgnoreServerCertErrors_CheckedChanged);
            this.cbDecryptHTTPS.Location = new Point(0x18, 0x35);
            this.cbDecryptHTTPS.Name = "cbDecryptHTTPS";
            this.cbDecryptHTTPS.Size = new Size(0x8b, 20);
            this.cbDecryptHTTPS.TabIndex = 2;
            this.cbDecryptHTTPS.Text = "D&ecrypt HTTPS traffic";
            this.toolTip1.SetToolTip(this.cbDecryptHTTPS, "Show HTTPS traffic in plaintext (see 'Actions > Learn more' for details)");
            this.cbDecryptHTTPS.CheckedChanged += new EventHandler(this.cbDecryptHTTPS_CheckedChanged);
            this.cbDecryptHTTPS.Click += new EventHandler(this.cbDecryptHTTPS_Click);
            this.cbCaptureCONNECT.Location = new Point(9, 0x1b);
            this.cbCaptureCONNECT.Name = "cbCaptureCONNECT";
            this.cbCaptureCONNECT.Size = new Size(200, 20);
            this.cbCaptureCONNECT.TabIndex = 1;
            this.cbCaptureCONNECT.Text = "Capture &HTTPS CONNECTs";
            this.toolTip1.SetToolTip(this.cbCaptureCONNECT, "Check to intercept HTTPS and WebSocket Tunneling requests.");
            this.cbCaptureCONNECT.CheckedChanged += new EventHandler(this.cbCaptureCONNECT_CheckedChanged);
            this.cbAttachOnStartup.Location = new Point(0xfb, 0x34);
            this.cbAttachOnStartup.Name = "cbAttachOnStartup";
            this.cbAttachOnStartup.Size = new Size(240, 20);
            this.cbAttachOnStartup.TabIndex = 11;
            this.cbAttachOnStartup.Text = "&Act as system proxy on startup";
            this.toolTip1.SetToolTip(this.cbAttachOnStartup, "When checked, Fiddler will automatically attach to WinINET/IE on startup.");
            this.cbxFontSize.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxFontSize.Items.AddRange(new object[] { "7", "8.25", "9", "10", "11", "12", "14", "16", "18" });
            this.cbxFontSize.Location = new Point(0x44, 0x10);
            this.cbxFontSize.Name = "cbxFontSize";
            this.cbxFontSize.Size = new Size(60, 0x15);
            this.cbxFontSize.TabIndex = 1;
            this.toolTip1.SetToolTip(this.cbxFontSize, "Font size used in Fiddler. (Requires restart for full effect)");
            this.cbHideOnMinimize.Location = new Point(8, 0x2e);
            this.cbHideOnMinimize.Name = "cbHideOnMinimize";
            this.cbHideOnMinimize.Size = new Size(0x206, 0x10);
            this.cbHideOnMinimize.TabIndex = 3;
            this.cbHideOnMinimize.Text = "&Hide Fiddler when minimized";
            this.toolTip1.SetToolTip(this.cbHideOnMinimize, "Hides Fiddler in the System tray when minimized.");
            this.cbUseSmartScroll.Location = new Point(8, 0x5b);
            this.cbUseSmartScroll.Name = "cbUseSmartScroll";
            this.cbUseSmartScroll.Size = new Size(0x206, 0x10);
            this.cbUseSmartScroll.TabIndex = 5;
            this.cbUseSmartScroll.Text = "Use &SmartScroll in Session List";
            this.toolTip1.SetToolTip(this.cbUseSmartScroll, "Disables session list auto-scrolling when session list is scrolled.");
            this.cbStreamVideo.Location = new Point(8, 0x7e);
            this.cbStreamVideo.Name = "cbStreamVideo";
            this.cbStreamVideo.Size = new Size(0x1fc, 0x12);
            this.cbStreamVideo.TabIndex = 5;
            this.cbStreamVideo.Text = "Automatically &stream audio && video";
            this.toolTip1.SetToolTip(this.cbStreamVideo, "Allow audio and video to stream automatically.");
            this.txtListenPort.Location = new Point(0x90, 0x33);
            this.txtListenPort.MaxLength = 5;
            this.txtListenPort.Name = "txtListenPort";
            this.txtListenPort.Size = new Size(0x42, 0x15);
            this.txtListenPort.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtListenPort, "Select the local port on which Fiddler should accept connections.");
            this.cbResetSessionIDOnListClear.Location = new Point(8, 0x71);
            this.cbResetSessionIDOnListClear.Name = "cbResetSessionIDOnListClear";
            this.cbResetSessionIDOnListClear.Size = new Size(0x206, 0x10);
            this.cbResetSessionIDOnListClear.TabIndex = 6;
            this.cbResetSessionIDOnListClear.Text = "&Reset Session ID counter on CTRL+X";
            this.toolTip1.SetToolTip(this.cbResetSessionIDOnListClear, "When CTRL+X is used to clear the session list, the session identifier counter restarts from 0.");
            this.txtFiddlerBypass.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtFiddlerBypass.Location = new Point(0xfb, 0xbb);
            this.txtFiddlerBypass.Multiline = true;
            this.txtFiddlerBypass.Name = "txtFiddlerBypass";
            this.txtFiddlerBypass.ScrollBars = ScrollBars.Both;
            this.txtFiddlerBypass.Size = new Size(270, 0x52);
            this.txtFiddlerBypass.TabIndex = 0x10;
            this.toolTip1.SetToolTip(this.txtFiddlerBypass, "Internet Explorer-style Proxy Bypass list. Semicolon-delimited. Requires restart. E.g.  *example.*:8081;https://*.fiddler2.com");
            this.cbHookAllConnections.Location = new Point(0xfb, 0x49);
            this.cbHookAllConnections.Name = "cbHookAllConnections";
            this.cbHookAllConnections.Size = new Size(160, 20);
            this.cbHookAllConnections.TabIndex = 12;
            this.cbHookAllConnections.Text = "&Monitor all connections";
            this.toolTip1.SetToolTip(this.cbHookAllConnections, "When checked, Fiddler will attach to all WinINET connections.");
            this.cbAlwaysShowTrayIcon.Location = new Point(8, 0x44);
            this.cbAlwaysShowTrayIcon.Name = "cbAlwaysShowTrayIcon";
            this.cbAlwaysShowTrayIcon.Size = new Size(0x206, 0x10);
            this.cbAlwaysShowTrayIcon.TabIndex = 4;
            this.cbAlwaysShowTrayIcon.Text = "&Always show tray icon";
            this.toolTip1.SetToolTip(this.cbAlwaysShowTrayIcon, "Show Fiddler in the System tray at all times.");
            this.cbAlwaysShowTrayIcon.CheckedChanged += new EventHandler(this.cbAlwaysShowTrayIcon_CheckedChanged);
            this.lnkCopyPACURL.AutoSize = true;
            this.lnkCopyPACURL.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkCopyPACURL.Location = new Point(15, 0x4c);
            this.lnkCopyPACURL.Name = "lnkCopyPACURL";
            this.lnkCopyPACURL.Size = new Size(0xc3, 13);
            this.lnkCopyPACURL.TabIndex = 3;
            this.lnkCopyPACURL.TabStop = true;
            this.lnkCopyPACURL.Text = "Copy Browser Proxy Configuration URL";
            this.toolTip1.SetToolTip(this.lnkCopyPACURL, "When a browser (e.g. Firefox) is configured to point at this URL, it will use Fiddler when Fiddler is running, and go direct otherwise.");
            this.lnkCopyPACURL.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkCopyPACURL_LinkClicked);
            this.cbReuseClientSockets.Location = new Point(0x10, 0x94);
            this.cbReuseClientSockets.Name = "cbReuseClientSockets";
            this.cbReuseClientSockets.Size = new Size(0xad, 20);
            this.cbReuseClientSockets.TabIndex = 6;
            this.cbReuseClientSockets.Text = "Reuse client co&nnections";
            this.toolTip1.SetToolTip(this.cbReuseClientSockets, "Allow more than one request from a given client socket.");
            this.cbReuseServerSockets.Location = new Point(0x10, 0xac);
            this.cbReuseServerSockets.Name = "cbReuseServerSockets";
            this.cbReuseServerSockets.Size = new Size(0xb5, 20);
            this.cbReuseServerSockets.TabIndex = 7;
            this.cbReuseServerSockets.Text = "&Reuse server connections";
            this.toolTip1.SetToolTip(this.cbReuseServerSockets, "Enable socket reuse when connecting to remote HTTP servers.");
            this.cbAllowRemote.Location = new Point(0x10, 0x7c);
            this.cbAllowRemote.Name = "cbAllowRemote";
            this.cbAllowRemote.Size = new Size(210, 0x16);
            this.cbAllowRemote.TabIndex = 5;
            this.cbAllowRemote.Text = "Allo&w remote computers to connect";
            this.toolTip1.SetToolTip(this.cbAllowRemote, "Check to permit remote computers to route traffic through Fiddler.");
            this.cbAllowRemote.Click += new EventHandler(this.cbAllowRemote_Click);
            this.cbHookWithPAC.Location = new Point(0x19f, 0x48);
            this.cbHookWithPAC.Name = "cbHookWithPAC";
            this.cbHookWithPAC.Size = new Size(0x6a, 0x16);
            this.cbHookWithPAC.TabIndex = 13;
            this.cbHookWithPAC.Text = "Use &PAC Script";
            this.toolTip1.SetToolTip(this.cbHookWithPAC, "Registers with WinINET as a ProxyAutoConfig script, allowing for simpler Localhost debugging.");
            this.txtSkipDecryption.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtSkipDecryption.Location = new Point(0x18, 0xd1);
            this.txtSkipDecryption.Multiline = true;
            this.txtSkipDecryption.Name = "txtSkipDecryption";
            this.txtSkipDecryption.Size = new Size(0x1f3, 60);
            this.txtSkipDecryption.TabIndex = 8;
            this.toolTip1.SetToolTip(this.txtSkipDecryption, "Semi-colon delimited list of hostnames for which decryption should not occur.");
            this.cbFIP.Location = new Point(8, 0x52);
            this.cbFIP.Name = "cbFIP";
            this.cbFIP.Size = new Size(0x11f, 0x12);
            this.cbFIP.TabIndex = 3;
            this.cbFIP.Text = "Participate in the &Fiddler Improvement Program";
            this.toolTip1.SetToolTip(this.cbFIP, "Fiddler will send anonymized usage data to a web service.");
            this.cbFIP.Click += new EventHandler(this.cbFIP_Click);
            this.btnSetBGColor.Location = new Point(8, 0x92);
            this.btnSetBGColor.Name = "btnSetBGColor";
            this.btnSetBGColor.Size = new Size(0xb2, 0x17);
            this.btnSetBGColor.TabIndex = 7;
            this.btnSetBGColor.Text = "Set Readonly &Color";
            this.toolTip1.SetToolTip(this.btnSetBGColor, "Set the color for uneditable text fields.");
            this.btnSetBGColor.UseVisualStyleBackColor = true;
            this.btnSetBGColor.Click += new EventHandler(this.btnSetBGColor_Click);
            this.cbxDecryptList.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxDecryptList.FormattingEnabled = true;
            this.cbxDecryptList.Items.AddRange(new object[] { "...from all processes", "...from browsers only", "...from non-browsers only", "...from remote clients only" });
            this.cbxDecryptList.Location = new Point(0x18, 0x4f);
            this.cbxDecryptList.Name = "cbxDecryptList";
            this.cbxDecryptList.Size = new Size(210, 0x15);
            this.cbxDecryptList.TabIndex = 3;
            this.toolTip1.SetToolTip(this.cbxDecryptList, "Select which process types will have HTTPS traffic decrypted.");
            this.cbCaptureFTP.Location = new Point(0x10, 100);
            this.cbCaptureFTP.Name = "cbCaptureFTP";
            this.cbCaptureFTP.Size = new Size(210, 0x16);
            this.cbCaptureFTP.TabIndex = 4;
            this.cbCaptureFTP.Text = "Captur&e FTP requests";
            this.toolTip1.SetToolTip(this.cbCaptureFTP, "Capture FTP requests");
            this.txtScriptEditor.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.txtScriptEditor.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            this.txtScriptEditor.AutoCompleteSource = AutoCompleteSource.FileSystem;
            this.txtScriptEditor.Location = new Point(0x83, 0x27);
            this.txtScriptEditor.Name = "txtScriptEditor";
            this.txtScriptEditor.Size = new Size(0x16f, 0x15);
            this.txtScriptEditor.TabIndex = 4;
            this.toolTip1.SetToolTip(this.txtScriptEditor, "Choose the program you'd like to use to edit your FiddlerScript.\n A syntax-highlighting editor is available from Fiddler2.com.");
            this.btnChooseFSE.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.btnChooseFSE.Location = new Point(500, 40);
            this.btnChooseFSE.Name = "btnChooseFSE";
            this.btnChooseFSE.Size = new Size(0x1c, 20);
            this.btnChooseFSE.TabIndex = 5;
            this.btnChooseFSE.Text = "...";
            this.toolTip1.SetToolTip(this.btnChooseFSE, "Click to browse for an editor.");
            this.btnChooseFSE.UseVisualStyleBackColor = true;
            this.btnChooseFSE.Click += new EventHandler(this.btnChooseEditor_Click);
            this.txtCompareTool.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.txtCompareTool.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            this.txtCompareTool.AutoCompleteSource = AutoCompleteSource.FileSystem;
            this.txtCompareTool.Location = new Point(0x83, 0x42);
            this.txtCompareTool.Name = "txtCompareTool";
            this.txtCompareTool.Size = new Size(0x16f, 0x15);
            this.txtCompareTool.TabIndex = 7;
            this.toolTip1.SetToolTip(this.txtCompareTool, "Choose the program you'd like to use to compare files (e.g. WinMerge, WinDiff, Odd, etc).");
            this.btnChooseCompare.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.btnChooseCompare.Location = new Point(500, 0x43);
            this.btnChooseCompare.Name = "btnChooseCompare";
            this.btnChooseCompare.Size = new Size(0x1c, 20);
            this.btnChooseCompare.TabIndex = 8;
            this.btnChooseCompare.Text = "...";
            this.toolTip1.SetToolTip(this.btnChooseCompare, "Click to browse for a tool.");
            this.btnChooseCompare.UseVisualStyleBackColor = true;
            this.btnChooseCompare.Click += new EventHandler(this.btnChooseCompare_Click);
            this.txtTextEditor.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.txtTextEditor.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            this.txtTextEditor.AutoCompleteSource = AutoCompleteSource.FileSystem;
            this.txtTextEditor.Location = new Point(0x83, 11);
            this.txtTextEditor.Name = "txtTextEditor";
            this.txtTextEditor.Size = new Size(0x16f, 0x15);
            this.txtTextEditor.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtTextEditor, "Choose the Text Editor you'd like to use (e.g. NotePad++, EditPadPro, etc).");
            this.btnChooseTextEditor.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.btnChooseTextEditor.Location = new Point(500, 11);
            this.btnChooseTextEditor.Name = "btnChooseTextEditor";
            this.btnChooseTextEditor.Size = new Size(0x1c, 20);
            this.btnChooseTextEditor.TabIndex = 2;
            this.btnChooseTextEditor.Text = "...";
            this.toolTip1.SetToolTip(this.btnChooseTextEditor, "Click to browse for an editor.");
            this.btnChooseTextEditor.UseVisualStyleBackColor = true;
            this.btnChooseTextEditor.Click += new EventHandler(this.btnChooseTextEditor_Click);
            this.lblProxyRegistrationHostname.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.lblProxyRegistrationHostname.Location = new Point(15, 0xc3);
            this.lblProxyRegistrationHostname.Name = "lblProxyRegistrationHostname";
            this.lblProxyRegistrationHostname.Size = new Size(0xd3, 0x4a);
            this.lblProxyRegistrationHostname.TabIndex = 0x12;
            this.lblProxyRegistrationHostname.Text = "Fiddler registers using address: xxxxxxxxxxxxx";
            this.toolTip1.SetToolTip(this.lblProxyRegistrationHostname, "The preference fiddler.network.proxy.RegistrationHostName is set.");
            this.lblProxyRegistrationHostname.Visible = false;
            this.cbEnableHighResTimers.Location = new Point(8, 0x68);
            this.cbEnableHighResTimers.Name = "cbEnableHighResTimers";
            this.cbEnableHighResTimers.Size = new Size(0x1fc, 0x12);
            this.cbEnableHighResTimers.TabIndex = 4;
            this.cbEnableHighResTimers.Text = "Enable high-resolution &timers";
            this.toolTip1.SetToolTip(this.cbEnableHighResTimers, "Configure Windows for 1ms timer resolution (reduces battery life)");
            this.cbOfferBetaUpdates.Location = new Point(8, 0x26);
            this.cbOfferBetaUpdates.Name = "cbOfferBetaUpdates";
            this.cbOfferBetaUpdates.Size = new Size(0xf1, 0x12);
            this.cbOfferBetaUpdates.TabIndex = 1;
            this.cbOfferBetaUpdates.Text = "Offer upgrade to &Beta versions";
            this.toolTip1.SetToolTip(this.cbOfferBetaUpdates, "Check this box to have Fiddler notify you when an updated Beta version is available.");
            this.btnSetFont.Location = new Point(0x97, 15);
            this.btnSetFont.Name = "btnSetFont";
            this.btnSetFont.Size = new Size(0x5f, 0x17);
            this.btnSetFont.TabIndex = 2;
            this.btnSetFont.Text = "Choose Fo&nt...";
            this.toolTip1.SetToolTip(this.btnSetFont, "You may select an override font to apply to most controls");
            this.btnSetFont.UseVisualStyleBackColor = true;
            this.btnSetFont.Click += new EventHandler(this.btnSetFont_Click);
            this.cbCheckRevocation.Location = new Point(0x18, 130);
            this.cbCheckRevocation.Name = "cbCheckRevocation";
            this.cbCheckRevocation.Size = new Size(0xb8, 20);
            this.cbCheckRevocation.TabIndex = 5;
            this.cbCheckRevocation.Text = "Check for certificate re&vocation";
            this.toolTip1.SetToolTip(this.cbCheckRevocation, "Check to validate remote certificates have not been revoked");
            this.lnkCertMaker.LinkArea = new LinkArea(0x27, 0x44);
            this.lnkCertMaker.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkCertMaker.Location = new Point(0x10b, 0x52);
            this.lnkCertMaker.Name = "lnkCertMaker";
            this.lnkCertMaker.Size = new Size(0x100, 0x54);
            this.lnkCertMaker.TabIndex = 9;
            this.lnkCertMaker.TabStop = true;
            this.lnkCertMaker.Text = "Fiddler generates certificates using:\r\nDefault Certificate Generator";
            this.toolTip1.SetToolTip(this.lnkCertMaker, "A certificate-generating plugin is loaded.");
            this.lnkCertMaker.UseCompatibleTextRendering = true;
            this.lnkCertMaker.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkCertMaker_LinkClicked);
            this.tabsOptions.Controls.Add(this.tabGeneral);
            this.tabsOptions.Controls.Add(this.tabHTTPS);
            this.tabsOptions.Controls.Add(this.tabConnections);
            this.tabsOptions.Controls.Add(this.tabGateway);
            this.tabsOptions.Controls.Add(this.tabAppearance);
            this.tabsOptions.Controls.Add(this.tabExtensions);
            this.tabsOptions.Controls.Add(this.tabPerformance);
            this.tabsOptions.Controls.Add(this.tabTools);
            this.tabsOptions.Dock = DockStyle.Fill;
            this.tabsOptions.Location = new Point(0, 0);
            this.tabsOptions.Name = "tabsOptions";
            this.tabsOptions.SelectedIndex = 0;
            this.tabsOptions.Size = new Size(0x21e, 0x12d);
            this.tabsOptions.TabIndex = 0;
            this.tabsOptions.SelectedIndexChanged += new EventHandler(this.tabsOptions_SelectedIndexChanged);
            this.tabsOptions.HelpRequested += new HelpEventHandler(this.tabsOptions_HelpRequested);
            this.tabGeneral.BackColor = SystemColors.Window;
            this.tabGeneral.Controls.Add(label8);
            this.tabGeneral.Controls.Add(this.cbxHTTPLint);
            this.tabGeneral.Controls.Add(this.cbOfferBetaUpdates);
            this.tabGeneral.Controls.Add(this.cbEnableHighResTimers);
            this.tabGeneral.Controls.Add(this.cbFIP);
            this.tabGeneral.Controls.Add(this.cbStreamVideo);
            this.tabGeneral.Controls.Add(this.cbEnableIPv6);
            this.tabGeneral.Controls.Add(this.cbxHotkeyMod);
            this.tabGeneral.Controls.Add(label6);
            this.tabGeneral.Controls.Add(this.cbAutoCheckForUpdates);
            this.tabGeneral.Controls.Add(this.txtHotkey);
            this.tabGeneral.Location = new Point(4, 0x16);
            this.tabGeneral.Name = "tabGeneral";
            this.tabGeneral.Size = new Size(0x216, 0x113);
            this.tabGeneral.TabIndex = 0;
            this.tabGeneral.Text = "General";
            this.cbxHTTPLint.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxHTTPLint.FormattingEnabled = true;
            this.cbxHTTPLint.Items.AddRange(new object[] { "Do nothing", "Warn on critical errors", "Warn on all errors" });
            this.cbxHTTPLint.Location = new Point(0xbf, 150);
            this.cbxHTTPLint.Name = "cbxHTTPLint";
            this.cbxHTTPLint.Size = new Size(0xc4, 0x15);
            this.cbxHTTPLint.TabIndex = 9;
            this.tabHTTPS.BackColor = SystemColors.Window;
            this.tabHTTPS.Controls.Add(this.btnActions);
            this.tabHTTPS.Controls.Add(this.lnkHTTPSProtocols);
            this.tabHTTPS.Controls.Add(this.lnkCertMaker);
            this.tabHTTPS.Controls.Add(this.cbCheckRevocation);
            this.tabHTTPS.Controls.Add(this.txtSkipDecryption);
            this.tabHTTPS.Controls.Add(this.cbxDecryptList);
            this.tabHTTPS.Controls.Add(this.lblSkipDecryption);
            this.tabHTTPS.Controls.Add(this.lblHTTPSDescription);
            this.tabHTTPS.Controls.Add(this.cbIgnoreServerCertErrors);
            this.tabHTTPS.Controls.Add(this.cbDecryptHTTPS);
            this.tabHTTPS.Controls.Add(this.cbCaptureCONNECT);
            this.tabHTTPS.Location = new Point(4, 0x16);
            this.tabHTTPS.Name = "tabHTTPS";
            this.tabHTTPS.Padding = new Padding(3);
            this.tabHTTPS.Size = new Size(0x216, 0x113);
            this.tabHTTPS.TabIndex = 3;
            this.tabHTTPS.Text = "HTTPS";
            this.btnActions.Image = (Image) manager.GetObject("btnActions.Image");
            this.btnActions.ImageAlign = ContentAlignment.MiddleLeft;
            this.btnActions.Location = new Point(0x1c6, 0x18);
            this.btnActions.Name = "btnActions";
            this.btnActions.Size = new Size(0x45, 0x19);
            this.btnActions.TabIndex = 10;
            this.btnActions.Text = "&Actions";
            this.btnActions.TextAlign = ContentAlignment.MiddleLeft;
            this.btnActions.TextImageRelation = TextImageRelation.ImageBeforeText;
            this.btnActions.UseVisualStyleBackColor = true;
            this.btnActions.Click += new EventHandler(this.btnActions_Click);
            this.lnkHTTPSProtocols.AutoSize = true;
            this.lnkHTTPSProtocols.LinkArea = new LinkArea(11, 12);
            this.lnkHTTPSProtocols.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkHTTPSProtocols.Location = new Point(0x15, 0xa2);
            this.lnkHTTPSProtocols.Name = "lnkHTTPSProtocols";
            this.lnkHTTPSProtocols.Size = new Size(110, 0x12);
            this.lnkHTTPSProtocols.TabIndex = 6;
            this.lnkHTTPSProtocols.TabStop = true;
            this.lnkHTTPSProtocols.Text = "Protocols: ssl3, tls1.0";
            this.lnkHTTPSProtocols.UseCompatibleTextRendering = true;
            this.lnkHTTPSProtocols.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkHTTPSProtocols_LinkClicked);
            this.tabConnections.BackColor = SystemColors.Window;
            this.tabConnections.Controls.Add(this.lblProxyRegistrationHostname);
            this.tabConnections.Controls.Add(this.cbCaptureFTP);
            this.tabConnections.Controls.Add(this.cbHookWithPAC);
            this.tabConnections.Controls.Add(this.cbAllowRemote);
            this.tabConnections.Controls.Add(this.cbReuseClientSockets);
            this.tabConnections.Controls.Add(this.cbReuseServerSockets);
            this.tabConnections.Controls.Add(this.lnkCopyPACURL);
            this.tabConnections.Controls.Add(this.cbHookAllConnections);
            this.tabConnections.Controls.Add(this.txtFiddlerBypass);
            this.tabConnections.Controls.Add(control);
            this.tabConnections.Controls.Add(this.txtListenPort);
            this.tabConnections.Controls.Add(label9);
            this.tabConnections.Controls.Add(this.cbAttachOnStartup);
            this.tabConnections.Controls.Add(this.lnkHookup);
            this.tabConnections.Controls.Add(label10);
            this.tabConnections.Controls.Add(this.clbConnections);
            this.tabConnections.Location = new Point(4, 0x16);
            this.tabConnections.Name = "tabConnections";
            this.tabConnections.Padding = new Padding(3);
            this.tabConnections.Size = new Size(0x216, 0x113);
            this.tabConnections.TabIndex = 2;
            this.tabConnections.Text = "Connections";
            this.lnkHookup.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lnkHookup.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkHookup.Location = new Point(0x1b2, 0x20);
            this.lnkHookup.Name = "lnkHookup";
            this.lnkHookup.Size = new Size(0x62, 0x10);
            this.lnkHookup.TabIndex = 0x11;
            this.lnkHookup.TabStop = true;
            this.lnkHookup.Text = "Learn more...";
            this.lnkHookup.TextAlign = ContentAlignment.TopRight;
            this.lnkHookup.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkHookup_LinkClicked);
            this.clbConnections.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.clbConnections.CheckOnClick = true;
            this.clbConnections.Enabled = false;
            this.clbConnections.FormattingEnabled = true;
            this.clbConnections.Location = new Point(0xfb, 100);
            this.clbConnections.Name = "clbConnections";
            this.clbConnections.Size = new Size(270, 0x44);
            this.clbConnections.TabIndex = 14;
            this.tabGateway.BackColor = SystemColors.Window;
            this.tabGateway.Controls.Add(this.txtProxyExceptionList);
            this.tabGateway.Controls.Add(this.txtManualProxyString);
            this.tabGateway.Controls.Add(this.rdoGatewayManual);
            this.tabGateway.Controls.Add(this.rdoGatewayWPAD);
            this.tabGateway.Controls.Add(this.rdoGatewayNone);
            this.tabGateway.Controls.Add(this.rdoGatewayWinINET);
            this.tabGateway.Controls.Add(this.lnkShowGatewayInfo);
            this.tabGateway.Controls.Add(label11);
            this.tabGateway.Location = new Point(4, 0x16);
            this.tabGateway.Name = "tabGateway";
            this.tabGateway.Size = new Size(0x216, 0x113);
            this.tabGateway.TabIndex = 6;
            this.tabGateway.Text = "Gateway";
            this.txtProxyExceptionList.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.txtProxyExceptionList.Enabled = false;
            this.txtProxyExceptionList.Location = new Point(0x29, 140);
            this.txtProxyExceptionList.Name = "txtProxyExceptionList";
            this.txtProxyExceptionList.Size = new Size(0x1d1, 0x15);
            this.txtProxyExceptionList.TabIndex = 5;
            this.txtManualProxyString.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            this.txtManualProxyString.Enabled = false;
            this.txtManualProxyString.Location = new Point(0x29, 0x71);
            this.txtManualProxyString.Name = "txtManualProxyString";
            this.txtManualProxyString.Size = new Size(0x1d1, 0x15);
            this.txtManualProxyString.TabIndex = 4;
            this.rdoGatewayManual.AutoSize = true;
            this.rdoGatewayManual.Location = new Point(20, 0x5c);
            this.rdoGatewayManual.Name = "rdoGatewayManual";
            this.rdoGatewayManual.Size = new Size(0xa2, 0x11);
            this.rdoGatewayManual.TabIndex = 3;
            this.rdoGatewayManual.Text = "&Manual Proxy Configuration:";
            this.rdoGatewayManual.UseVisualStyleBackColor = true;
            this.rdoGatewayManual.CheckedChanged += new EventHandler(this.rdoGatewayManual_CheckedChanged);
            this.rdoGatewayWPAD.AutoSize = true;
            this.rdoGatewayWPAD.Location = new Point(20, 0x45);
            this.rdoGatewayWPAD.Name = "rdoGatewayWPAD";
            this.rdoGatewayWPAD.Size = new Size(0xd8, 0x11);
            this.rdoGatewayWPAD.TabIndex = 2;
            this.rdoGatewayWPAD.Text = "Automatically Detect Proxy using &WPAD";
            this.rdoGatewayWPAD.UseVisualStyleBackColor = true;
            this.rdoGatewayNone.AutoSize = true;
            this.rdoGatewayNone.Location = new Point(20, 0xa6);
            this.rdoGatewayNone.Name = "rdoGatewayNone";
            this.rdoGatewayNone.Size = new Size(0x45, 0x11);
            this.rdoGatewayNone.TabIndex = 6;
            this.rdoGatewayNone.Text = "&No Proxy";
            this.rdoGatewayNone.UseVisualStyleBackColor = true;
            this.rdoGatewayWinINET.AutoSize = true;
            this.rdoGatewayWinINET.Checked = true;
            this.rdoGatewayWinINET.Location = new Point(20, 0x2e);
            this.rdoGatewayWinINET.Name = "rdoGatewayWinINET";
            this.rdoGatewayWinINET.Size = new Size(190, 0x11);
            this.rdoGatewayWinINET.TabIndex = 1;
            this.rdoGatewayWinINET.TabStop = true;
            this.rdoGatewayWinINET.Text = "Use &System Proxy (recommended)";
            this.rdoGatewayWinINET.UseVisualStyleBackColor = true;
            this.lnkShowGatewayInfo.AutoSize = true;
            this.lnkShowGatewayInfo.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkShowGatewayInfo.Location = new Point(0x11, 0xd1);
            this.lnkShowGatewayInfo.Name = "lnkShowGatewayInfo";
            this.lnkShowGatewayInfo.Size = new Size(0x8e, 13);
            this.lnkShowGatewayInfo.TabIndex = 7;
            this.lnkShowGatewayInfo.TabStop = true;
            this.lnkShowGatewayInfo.Text = "Show Current Gateway Info";
            this.lnkShowGatewayInfo.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkShowGatewayInfo_LinkClicked);
            this.tabAppearance.BackColor = SystemColors.Window;
            this.tabAppearance.Controls.Add(this.btnSetFont);
            this.tabAppearance.Controls.Add(this.btnSetBGColor);
            this.tabAppearance.Controls.Add(this.cbAlwaysShowTrayIcon);
            this.tabAppearance.Controls.Add(this.cbResetSessionIDOnListClear);
            this.tabAppearance.Controls.Add(this.cbUseSmartScroll);
            this.tabAppearance.Controls.Add(this.cbxFontSize);
            this.tabAppearance.Controls.Add(this.cbHideOnMinimize);
            this.tabAppearance.Controls.Add(label12);
            this.tabAppearance.Location = new Point(4, 0x16);
            this.tabAppearance.Name = "tabAppearance";
            this.tabAppearance.Padding = new Padding(3);
            this.tabAppearance.Size = new Size(0x216, 0x113);
            this.tabAppearance.TabIndex = 4;
            this.tabAppearance.Text = "Appearance";
            this.tabExtensions.BackColor = SystemColors.Window;
            this.tabExtensions.Controls.Add(this.gbAutoFiddles);
            this.tabExtensions.Controls.Add(this.gbScript);
            this.tabExtensions.Location = new Point(4, 0x16);
            this.tabExtensions.Name = "tabExtensions";
            this.tabExtensions.Size = new Size(0x216, 0x113);
            this.tabExtensions.TabIndex = 1;
            this.tabExtensions.Text = "Extensions";
            this.gbAutoFiddles.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.gbAutoFiddles.Controls.Add(this.lnkFindExtensions);
            this.gbAutoFiddles.Controls.Add(this.txtExtensions);
            this.gbAutoFiddles.Location = new Point(3, 0x6a);
            this.gbAutoFiddles.Name = "gbAutoFiddles";
            this.gbAutoFiddles.Size = new Size(0x211, 0xa6);
            this.gbAutoFiddles.TabIndex = 1;
            this.gbAutoFiddles.TabStop = false;
            this.gbAutoFiddles.Text = "Extensions";
            this.lnkFindExtensions.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.lnkFindExtensions.AutoSize = true;
            this.lnkFindExtensions.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkFindExtensions.Location = new Point(0x192, 0x90);
            this.lnkFindExtensions.Name = "lnkFindExtensions";
            this.lnkFindExtensions.Size = new Size(0x79, 13);
            this.lnkFindExtensions.TabIndex = 1;
            this.lnkFindExtensions.TabStop = true;
            this.lnkFindExtensions.Text = "Find more extensions...";
            this.lnkFindExtensions.TextAlign = ContentAlignment.TopRight;
            this.lnkFindExtensions.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkFindExtensions_LinkClicked);
            this.txtExtensions.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.txtExtensions.BorderStyle = BorderStyle.FixedSingle;
            this.txtExtensions.Font = new Font("Tahoma", 6.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtExtensions.Location = new Point(5, 14);
            this.txtExtensions.Name = "txtExtensions";
            this.txtExtensions.ReadOnly = true;
            this.txtExtensions.Size = new Size(0x206, 130);
            this.txtExtensions.TabIndex = 0;
            this.txtExtensions.Text = "";
            this.txtExtensions.WordWrap = false;
            this.tabPerformance.BackColor = SystemColors.Window;
            this.tabPerformance.Controls.Add(this.cbBumpPriority);
            this.tabPerformance.Controls.Add(this.cbShowMemoryPanel);
            this.tabPerformance.Controls.Add(label3);
            this.tabPerformance.Controls.Add(label13);
            this.tabPerformance.Controls.Add(this.numStreamAndForget);
            this.tabPerformance.Controls.Add(this.cbParseWebSocketMessages);
            this.tabPerformance.Controls.Add(this.cbxAbort);
            this.tabPerformance.Controls.Add(label14);
            this.tabPerformance.Location = new Point(4, 0x16);
            this.tabPerformance.Name = "tabPerformance";
            this.tabPerformance.Padding = new Padding(3);
            this.tabPerformance.Size = new Size(0x216, 0x113);
            this.tabPerformance.TabIndex = 7;
            this.tabPerformance.Text = "Performance";
            this.cbBumpPriority.AutoSize = true;
            this.cbBumpPriority.Location = new Point(8, 0x86);
            this.cbBumpPriority.Name = "cbBumpPriority";
            this.cbBumpPriority.Size = new Size(0xc5, 0x11);
            this.cbBumpPriority.TabIndex = 7;
            this.cbBumpPriority.Text = "Run Fiddler at AboveNormal &Priority";
            this.cbBumpPriority.UseVisualStyleBackColor = true;
            this.cbShowMemoryPanel.AutoSize = true;
            this.cbShowMemoryPanel.Location = new Point(8, 15);
            this.cbShowMemoryPanel.Name = "cbShowMemoryPanel";
            this.cbShowMemoryPanel.Size = new Size(0xb9, 0x11);
            this.cbShowMemoryPanel.TabIndex = 0;
            this.cbShowMemoryPanel.Text = "Show &Memory panel in status bar";
            this.cbShowMemoryPanel.UseVisualStyleBackColor = true;
            this.numStreamAndForget.DecimalPlaces = 2;
            this.numStreamAndForget.Location = new Point(0xaf, 0x45);
            int[] bits = new int[4];
            bits[0] = 0x346dc;
            bits[3] = 0x20000;
            this.numStreamAndForget.Maximum = new decimal(bits);
            this.numStreamAndForget.Name = "numStreamAndForget";
            this.numStreamAndForget.Size = new Size(0x4a, 0x15);
            this.numStreamAndForget.TabIndex = 3;
            this.numStreamAndForget.TextAlign = HorizontalAlignment.Right;
            this.numStreamAndForget.ThousandsSeparator = true;
            int[] numArray2 = new int[4];
            numArray2[0] = 0x346dc;
            numArray2[3] = 0x20000;
            this.numStreamAndForget.Value = new decimal(numArray2);
            this.cbParseWebSocketMessages.AutoSize = true;
            this.cbParseWebSocketMessages.Location = new Point(8, 0x26);
            this.cbParseWebSocketMessages.Name = "cbParseWebSocketMessages";
            this.cbParseWebSocketMessages.Size = new Size(160, 0x11);
            this.cbParseWebSocketMessages.TabIndex = 1;
            this.cbParseWebSocketMessages.Text = "Parse &WebSocket Messages";
            this.cbParseWebSocketMessages.UseVisualStyleBackColor = true;
            this.cbxAbort.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbxAbort.FormattingEnabled = true;
            this.cbxAbort.Items.AddRange(new object[] { "finish downloading anyway", "finish if Session is visible", "close the server connection" });
            this.cbxAbort.Location = new Point(0xaf, 0x60);
            this.cbxAbort.Name = "cbxAbort";
            this.cbxAbort.Size = new Size(0xd6, 0x15);
            this.cbxAbort.TabIndex = 6;
            this.tabTools.BackColor = SystemColors.Window;
            this.tabTools.Controls.Add(this.txtTextEditor);
            this.tabTools.Controls.Add(label2);
            this.tabTools.Controls.Add(this.btnChooseTextEditor);
            this.tabTools.Controls.Add(this.txtCompareTool);
            this.tabTools.Controls.Add(label15);
            this.tabTools.Controls.Add(this.btnChooseCompare);
            this.tabTools.Controls.Add(this.txtScriptEditor);
            this.tabTools.Controls.Add(label);
            this.tabTools.Controls.Add(this.btnChooseFSE);
            this.tabTools.Location = new Point(4, 0x16);
            this.tabTools.Name = "tabTools";
            this.tabTools.Padding = new Padding(3);
            this.tabTools.Size = new Size(0x216, 0x113);
            this.tabTools.TabIndex = 5;
            this.tabTools.Text = "Tools";
            this.pnlOptionsFooter.Controls.Add(this.lnkOptionsHelp);
            this.pnlOptionsFooter.Controls.Add(this.btnCancel);
            this.pnlOptionsFooter.Controls.Add(this.btnApply);
            this.pnlOptionsFooter.Controls.Add(this.lblNotices);
            this.pnlOptionsFooter.Dock = DockStyle.Bottom;
            this.pnlOptionsFooter.Location = new Point(0, 0x12d);
            this.pnlOptionsFooter.Name = "pnlOptionsFooter";
            this.pnlOptionsFooter.Size = new Size(0x21e, 0x24);
            this.pnlOptionsFooter.TabIndex = 1;
            this.lnkOptionsHelp.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.lnkOptionsHelp.LinkBehavior = LinkBehavior.HoverUnderline;
            this.lnkOptionsHelp.Location = new Point(3, 3);
            this.lnkOptionsHelp.Name = "lnkOptionsHelp";
            this.lnkOptionsHelp.Size = new Size(0x27, 0x21);
            this.lnkOptionsHelp.TabIndex = 3;
            this.lnkOptionsHelp.TabStop = true;
            this.lnkOptionsHelp.Text = "Help";
            this.lnkOptionsHelp.TextAlign = ContentAlignment.MiddleCenter;
            this.lnkOptionsHelp.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lnkOptionsHelp_LinkClicked);
            this.mnuHTTPS.Items.AddRange(new ToolStripItem[] { this.miTrustRootCertificate, this.miExportRootCert, separator, item, item2, separator2, this.miRemoveCerts, this.miResetAllCertificates });
            this.mnuHTTPS.Name = "mnuHTTPS";
            this.mnuHTTPS.ShowImageMargin = false;
            this.mnuHTTPS.Size = new Size(0xf4, 170);
            this.miTrustRootCertificate.Enabled = false;
            this.miTrustRootCertificate.Name = "miTrustRootCertificate";
            this.miTrustRootCertificate.Size = new Size(0xf3, 0x16);
            this.miTrustRootCertificate.Text = "&Trust Root Certificate";
            this.miTrustRootCertificate.Click += new EventHandler(this.miTrustRootCertificate_Click);
            this.miExportRootCert.Enabled = false;
            this.miExportRootCert.Name = "miExportRootCert";
            this.miExportRootCert.Size = new Size(0xf3, 0x16);
            this.miExportRootCert.Text = "E&xport Root Certificate to Desktop";
            this.miExportRootCert.Click += new EventHandler(this.miExportRootCert_Click);
            this.miRemoveCerts.Enabled = false;
            this.miRemoveCerts.Name = "miRemoveCerts";
            this.miRemoveCerts.Size = new Size(0xf3, 0x16);
            this.miRemoveCerts.Text = "&Remove Interception Certificates";
            this.miRemoveCerts.Click += new EventHandler(this.miRemoveCerts_Click);
            this.miResetAllCertificates.Name = "miResetAllCertificates";
            this.miResetAllCertificates.Size = new Size(0xf3, 0x16);
            this.miResetAllCertificates.Text = "Reset All Certificates";
            this.miResetAllCertificates.Click += new EventHandler(this.miResetAllCertificates_Click);
            this.AutoScaleBaseSize = new Size(5, 14);
            base.CancelButton = this.btnCancel;
            base.ClientSize = new Size(0x21e, 0x151);
            base.Controls.Add(this.tabsOptions);
            base.Controls.Add(this.pnlOptionsFooter);
            this.Font = new Font("Tahoma", 8.25f);
            base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            base.HelpButton = true;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            this.MinimumSize = new Size(0x22e, 350);
            base.Name = "frmOptions";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Fiddler Options";
            base.Load += new EventHandler(this.frmOptions_Load);
            this.gbScript.ResumeLayout(false);
            this.gbScript.PerformLayout();
            this.tabsOptions.ResumeLayout(false);
            this.tabGeneral.ResumeLayout(false);
            this.tabGeneral.PerformLayout();
            this.tabHTTPS.ResumeLayout(false);
            this.tabHTTPS.PerformLayout();
            this.tabConnections.ResumeLayout(false);
            this.tabConnections.PerformLayout();
            this.tabGateway.ResumeLayout(false);
            this.tabGateway.PerformLayout();
            this.tabAppearance.ResumeLayout(false);
            this.tabExtensions.ResumeLayout(false);
            this.gbAutoFiddles.ResumeLayout(false);
            this.gbAutoFiddles.PerformLayout();
            this.tabPerformance.ResumeLayout(false);
            this.tabPerformance.PerformLayout();
            this.numStreamAndForget.EndInit();
            this.tabTools.ResumeLayout(false);
            this.tabTools.PerformLayout();
            this.pnlOptionsFooter.ResumeLayout(false);
            this.mnuHTTPS.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void lnkCertMaker_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CertMaker.ShowConfigUI(base.Handle);
        }

        private void lnkCopyPACURL_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string str;
            if (FiddlerApplication.Prefs.GetBoolPref("fiddler.proxy.pacfile.usefileprotocol", true))
            {
                str = "file:///" + Utilities.UrlPathEncode(CONFIG.GetPath("Pac").Replace('\\', '/'));
            }
            else
            {
                str = "http://" + CONFIG.sFiddlerListenHostPort + "/proxy.pac";
            }
            Utilities.CopyToClipboard(str);
        }

        private void lnkFindExtensions_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("FIDDLEREXTENSIONS"));
        }

        private void lnkHookup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("HOOKUP"));
        }

        private void lnkHTTPSProtocols_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string sPrompt = "Select the HTTPS protocol versions allowable for server connections.\nValid tokens are: <client>; ";
            sPrompt = sPrompt + "ssl2; ssl3; tls1.0; tls1.1; tls1.2";
            string tag = null;
            if (this.lnkHTTPSProtocols.Tag != null)
            {
                tag = (string) this.lnkHTTPSProtocols.Tag;
            }
            if (string.IsNullOrEmpty(tag))
            {
                tag = Utilities.SslProtocolsToString(CONFIG.oAcceptedServerHTTPSProtocols);
                if (CONFIG.bMimicClientHTTPSProtocols)
                {
                    tag = "<client>;" + tag;
                }
            }
            string str3 = frmPrompt.GetUserString("HTTPS Protocols", sPrompt, tag, true, frmPrompt.PromptIcon.Default);
            if (!string.IsNullOrEmpty(str3))
            {
                SslProtocols oEnabled = Utilities.ParseSSLProtocolString(str3);
                if (oEnabled != SslProtocols.None)
                {
                    this.ShowEnabledHTTPSProtocols(oEnabled, str3.OICContains("<client>"));
                    this.lnkHTTPSProtocols.Tag = str3;
                }
            }
        }

        private void lnkOptionsHelp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("OPTIONSHELP"));
        }

        private void lnkShowGatewayInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FiddlerApplication.oProxy.ShowGatewayInformation();
        }

        private void miExportRootCert_Click(object sender, EventArgs e)
        {
            if (CertMaker.exportRootToDesktop())
            {
                string sMessage = "The file FiddlerRoot.cer has been exported to your desktop.";
                FiddlerApplication.DoNotifyUser(this, sMessage, "Success", MessageBoxIcon.Asterisk);
            }
        }

        private void miLearnMore_Click(object sender, EventArgs e)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("HTTPSDECRYPTION"));
        }

        private void miOpenCertMgr_Click(object sender, EventArgs e)
        {
            Utilities.RunExecutable("mmc.exe", "certmgr.msc");
        }

        private void miRemoveCerts_Click(object sender, EventArgs e)
        {
            this._RemoveAllCertificates();
        }

        private void miResetAllCertificates_Click(object sender, EventArgs e)
        {
            string text = this.lblNotices.Text;
            this.lblNotices.Text = "Removing old certificates...";
            this.cbDecryptHTTPS.Checked = false;
            this.cbDecryptHTTPS_Click(null, null);
            this._RemoveAllCertificates();
            this.lblNotices.Text = "Creating new certificates...";
            this.cbDecryptHTTPS.Checked = true;
            this.cbDecryptHTTPS_Click(null, null);
            this.lblNotices.Text = text;
        }

        private void miTrustRootCertificate_Click(object sender, EventArgs e)
        {
            this._TrustRootCertificate();
        }

        private void rdoGatewayManual_CheckedChanged(object sender, EventArgs e)
        {
            this.txtManualProxyString.Enabled = this.txtProxyExceptionList.Enabled = this.rdoGatewayManual.Checked;
        }

        internal void SelectTab(string sTabName)
        {
            foreach (TabPage page in this.tabsOptions.TabPages)
            {
                if (page.Text.OICEquals(sTabName))
                {
                    this.tabsOptions.SelectedTab = page;
                    break;
                }
            }
        }

        private void ShowCertProvider()
        {
            try
            {
                string certProviderInfo = CertMaker.GetCertProviderInfo();
                if (!string.IsNullOrEmpty(certProviderInfo))
                {
                    string str2 = "Certificates generated by ";
                    this.lnkCertMaker.Text = str2 + certProviderInfo;
                    if (CertMaker.CanShowConfigUI)
                    {
                        this.lnkCertMaker.LinkArea = new LinkArea(str2.Length, this.lnkCertMaker.Text.Length - str2.Length);
                        this.toolTip1.SetToolTip(this.lnkCertMaker, "Click to configure the Certificate Generator.");
                    }
                    else
                    {
                        this.lnkCertMaker.LinkArea = new LinkArea(0, 0);
                        this.toolTip1.SetToolTip(this.lnkCertMaker, "This Certificate Generator does not expose a configuration user-interface.");
                    }
                    this.lnkCertMaker.Visible = true;
                }
            }
            catch (Exception exception)
            {
                this.lnkCertMaker.Visible = false;
                FiddlerApplication.Log.LogFormat("Failed to get Certificate Generator information. {0}", new object[] { Utilities.DescribeException(exception) });
            }
        }

        private void ShowEnabledHTTPSProtocols(SslProtocols oEnabled, bool bMimicClient)
        {
            string str = Utilities.SslProtocolsToString(oEnabled);
            if (bMimicClient)
            {
                str = "<client>; " + str;
            }
            this.lnkHTTPSProtocols.Text = "Protocols: " + str;
            this.lnkHTTPSProtocols.LinkArea = new LinkArea("Protocols: ".Length, str.Length);
        }

        private void tabsOptions_HelpRequested(object sender, HelpEventArgs hlpevent)
        {
            Utilities.LaunchHyperlink(CONFIG.GetRedirUrl("OPTIONSHELP"));
        }

        private void tabsOptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.tabsOptions.SelectedTab == this.tabGateway)
            {
                this.bGatewayTouched = true;
            }
        }
    }
}

