﻿namespace Fiddler
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    internal static class FilterTargetSystem
    {
        private static ReaderWriterLockSlim _RWLockRules = new ReaderWriterLockSlim();
        private static bool bWatchingRequestHeaders = false;
        private static int iHidden;
        private static int iPIDShowOnly = -1;
        private static List<string> listBlockHostNames = new List<string>();
        private static List<string> listBlockMIMEs = new List<string>();
        private static List<string> listBlockPaths = new List<string>();
        private static List<int> listBlockPids = new List<int>();
        private static List<string> listBlockProcessNames = new List<string>();
        private static List<string> listBlockURLContains = new List<string>();

        private static void _DetachRequestHeadersEventIfUnneeded()
        {
            if (bWatchingRequestHeaders)
            {
                try
                {
                    GetReaderLock();
                    if (((((listBlockURLContains.Count + listBlockPids.Count) + listBlockHostNames.Count) + listBlockPaths.Count) < 1) && (-1 == iPIDShowOnly))
                    {
                        FiddlerApplication.RequestHeadersAvailable -= new SessionStateHandler(FilterTargetSystem.FiddlerApplication_RequestHeadersAvailable);
                        bWatchingRequestHeaders = false;
                    }
                }
                finally
                {
                    FreeReaderLock();
                }
            }
        }

        private static void _DetachResponseHeadersEventIfUnneeded()
        {
            try
            {
                GetReaderLock();
                if (listBlockMIMEs.Count < 1)
                {
                    FiddlerApplication.ResponseHeadersAvailable -= new SessionStateHandler(FilterTargetSystem.FiddlerApplication_ResponseHeadersAvailable);
                }
            }
            finally
            {
                FreeReaderLock();
            }
        }

        private static void _EnsureWatchingRequestHeaders()
        {
            if (!bWatchingRequestHeaders)
            {
                bWatchingRequestHeaders = true;
                FiddlerApplication.RequestHeadersAvailable += new SessionStateHandler(FilterTargetSystem.FiddlerApplication_RequestHeadersAvailable);
            }
        }

        internal static string _GetFirstPathComponent(string sPath)
        {
            int iMaxLength = Utilities.IndexOfNth(sPath, 2, '/');
            if (iMaxLength > 1)
            {
                sPath = '/' + Utilities.TrimBefore(Utilities.TrimTo(sPath, iMaxLength + 1), "/");
                return sPath;
            }
            iMaxLength = sPath.IndexOf('?');
            if (iMaxLength > 0)
            {
                sPath = '/' + Utilities.TrimBefore(Utilities.TrimTo(sPath, iMaxLength), "/");
                return sPath;
            }
            if (!sPath.StartsWith("/"))
            {
                sPath = string.Empty;
            }
            return sPath;
        }

        internal static void AddExclusiveFilter(int iPID)
        {
            try
            {
                GetWriterLock();
                iPIDShowOnly = iPID;
                _EnsureWatchingRequestHeaders();
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return s.LocalProcessID != iPID;
            }));
        }

        internal static void AddHideHostNameFilter(string sHost)
        {
            try
            {
                GetWriterLock();
                if (!listBlockHostNames.Contains(sHost))
                {
                    listBlockHostNames.Add(sHost);
                    _EnsureWatchingRequestHeaders();
                }
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return s.HostnameIs(sHost);
            }));
        }

        internal static void AddHidePathFilter(string sPath)
        {
            try
            {
                sPath = sPath.ToLower();
                GetWriterLock();
                if (!listBlockPaths.Contains(sPath))
                {
                    listBlockPaths.Add(sPath);
                    _EnsureWatchingRequestHeaders();
                }
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return s.PathAndQuery.OICStartsWith(sPath);
            }));
        }

        internal static void AddHidePIDFilter(int iPid)
        {
            try
            {
                GetWriterLock();
                if (!listBlockPids.Contains(iPid))
                {
                    listBlockPids.Add(iPid);
                    _EnsureWatchingRequestHeaders();
                }
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return s.LocalProcessID == iPid;
            }));
        }

        internal static void AddMIMEFilter(string sMIME)
        {
            sMIME = sMIME.ToLower();
            try
            {
                GetWriterLock();
                if (!listBlockMIMEs.Contains(sMIME))
                {
                    listBlockMIMEs.Add(sMIME);
                    if (listBlockMIMEs.Count == 1)
                    {
                        FiddlerApplication.ResponseHeadersAvailable += new SessionStateHandler(FilterTargetSystem.FiddlerApplication_ResponseHeadersAvailable);
                    }
                }
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return Utilities.HasHeaders(s.oResponse) && sMIME.OICEquals(s.oResponse.MIMEType);
            }));
        }

        internal static void AddProcessNameFilter(string sProcessName)
        {
            sProcessName = sProcessName.ToLower();
            try
            {
                GetWriterLock();
                if (!listBlockProcessNames.Contains(sProcessName))
                {
                    listBlockProcessNames.Add(sProcessName);
                    _EnsureWatchingRequestHeaders();
                }
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return s.LocalProcess.OICStartsWith(sProcessName);
            }));
        }

        internal static void AddURLContainsFilter(string sUriPart)
        {
            try
            {
                GetWriterLock();
                if (!listBlockURLContains.Contains(sUriPart))
                {
                    listBlockURLContains.Add(sUriPart);
                    _EnsureWatchingRequestHeaders();
                }
            }
            finally
            {
                FreeWriterLock();
            }
            FiddlerApplication.UI.lvSessions.FlushUpdates();
            Interlocked.Add(ref iHidden, FiddlerApplication.UI.actRemoveSessionsMatchingCriteria(delegate (Session s) {
                return s.fullUrl.OICContains(sUriPart);
            }));
        }

        private static void FiddlerApplication_RequestHeadersAvailable(Session oS)
        {
            try
            {
                GetReaderLock();
                if ((iPIDShowOnly > -1) && (oS.LocalProcessID != iPIDShowOnly))
                {
                    oS["ui-hide"] = "FTS>OnlyProcessID";
                    Interlocked.Increment(ref iHidden);
                }
                else
                {
                    if (listBlockProcessNames.Count > 0)
                    {
                        string item = Utilities.TrimAfter(oS.LocalProcess, ':') + ":";
                        if (listBlockProcessNames.Contains(item))
                        {
                            oS["ui-hide"] = "FTS>ProcessName";
                            Interlocked.Increment(ref iHidden);
                            return;
                        }
                    }
                    if (listBlockPids.Contains(oS.LocalProcessID))
                    {
                        oS["ui-hide"] = "FTS>ProcessID";
                        Interlocked.Increment(ref iHidden);
                    }
                    else if (listBlockHostNames.Contains(oS.hostname))
                    {
                        oS["ui-hide"] = "FTS>Hostname";
                        Interlocked.Increment(ref iHidden);
                    }
                    else if ((listBlockPaths.Count > 0) && listBlockPaths.Contains(_GetFirstPathComponent(oS.PathAndQuery).ToLower()))
                    {
                        oS["ui-hide"] = "FTS>Path";
                        Interlocked.Increment(ref iHidden);
                    }
                    else if (listBlockURLContains.Count > 0)
                    {
                        foreach (string str2 in listBlockURLContains)
                        {
                            if (oS.fullUrl.OICContains(str2))
                            {
                                oS["ui-hide"] = "FTS>UriContains";
                                Interlocked.Increment(ref iHidden);
                                return;
                            }
                        }
                    }
                }
            }
            finally
            {
                FreeReaderLock();
            }
        }

        private static void FiddlerApplication_ResponseHeadersAvailable(Session oS)
        {
            if (Utilities.HasHeaders(oS.oResponse))
            {
                string item = oS.oResponse.MIMEType.ToLower();
                try
                {
                    GetReaderLock();
                    if (listBlockMIMEs.Contains(item))
                    {
                        oS["ui-hide"] = "FTS>ContentType";
                        Interlocked.Increment(ref iHidden);
                    }
                }
                finally
                {
                    FreeReaderLock();
                }
            }
        }

        private static void FreeReaderLock()
        {
            _RWLockRules.ExitReadLock();
        }

        private static void FreeWriterLock()
        {
            _RWLockRules.ExitWriteLock();
        }

        private static void GetReaderLock()
        {
            _RWLockRules.EnterReadLock();
        }

        private static void GetWriterLock()
        {
            _RWLockRules.EnterWriteLock();
        }

        internal static void RemoveExclusiveFilter(int iPID)
        {
            try
            {
                GetWriterLock();
                iPIDShowOnly = -1;
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachRequestHeadersEventIfUnneeded();
        }

        internal static void RemoveHidePathFilter(string sPath)
        {
            try
            {
                GetWriterLock();
                if (listBlockPaths.Contains(sPath))
                {
                    listBlockPaths.Remove(sPath);
                }
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachRequestHeadersEventIfUnneeded();
        }

        internal static void RemoveHostNameFilter(string sHost)
        {
            try
            {
                GetWriterLock();
                if (listBlockHostNames.Contains(sHost))
                {
                    listBlockHostNames.Remove(sHost);
                }
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachRequestHeadersEventIfUnneeded();
        }

        internal static void RemoveMIMEFilter(string sMIME)
        {
            try
            {
                GetWriterLock();
                if (listBlockMIMEs.Contains(sMIME))
                {
                    listBlockMIMEs.Remove(sMIME);
                }
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachResponseHeadersEventIfUnneeded();
        }

        internal static void RemovePIDFilter(int iPid)
        {
            try
            {
                GetWriterLock();
                if (listBlockPids.Contains(iPid))
                {
                    listBlockPids.Remove(iPid);
                }
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachRequestHeadersEventIfUnneeded();
        }

        internal static void RemoveProcessNameFilter(string sProcessName)
        {
            sProcessName = sProcessName.ToLower();
            try
            {
                GetWriterLock();
                if (listBlockProcessNames.Contains(sProcessName))
                {
                    listBlockProcessNames.Remove(sProcessName);
                }
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachRequestHeadersEventIfUnneeded();
        }

        internal static void RemoveURLContainsFilter(string sUriPart)
        {
            try
            {
                GetWriterLock();
                if (listBlockURLContains.Contains(sUriPart))
                {
                    listBlockURLContains.Remove(sUriPart);
                }
            }
            finally
            {
                FreeWriterLock();
            }
            _DetachRequestHeadersEventIfUnneeded();
        }

        internal static int FilteredCount
        {
            get
            {
                return iHidden;
            }
        }
    }
}

