﻿namespace Fiddler
{
    using System;

    public interface IWSMInspector : IBaseInspector2
    {
        void AssignMessage(WebSocketMessage oWSM);
    }
}

