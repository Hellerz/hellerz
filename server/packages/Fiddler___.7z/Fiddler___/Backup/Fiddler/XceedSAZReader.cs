﻿namespace Fiddler
{
    using System;
    using System.IO;
    using Xceed.FileSystem;
    using Xceed.Zip;

    internal class XceedSAZReader : ISAZReader2, ISAZReader
    {
        private string _EncryptionMethod;
        private string _EncryptionStrength;
        private ZipArchive _oZip;
        private string _sFilename;
        private GetPasswordDelegate fnPasswordCallback;

        internal XceedSAZReader(string sFilename)
        {
            this._sFilename = sFilename;
            this._oZip = new ZipArchive(new DiskFile(sFilename));
            this._oZip.BeginUpdate();
            if (!this._oZip.GetFolder("raw").Exists)
            {
                throw new Exception("The selected file is not a Fiddler-generated .SAZ archive of Web Sessions.");
            }
        }

        public void Close()
        {
            this._oZip.EndUpdate();
            this._oZip = null;
        }

        public byte[] GetFileBytes(string sFilename)
        {
            Stream stream;
            ZippedFile file = (ZippedFile) this._oZip.GetFile(sFilename);
            if (!file.Exists)
            {
                return Utilities.emptyByteArray;
            }
            byte[] arrBytes = new byte[file.Size];
        Label_002D:
            try
            {
                stream = file.OpenRead();
            }
            catch (InvalidDecryptionPasswordException)
            {
                if (string.IsNullOrEmpty(this._EncryptionMethod))
                {
                    this._EncryptionMethod = file.EncryptionMethod.ToString();
                    this._EncryptionStrength = file.EncryptionStrength.ToString();
                }
                string passwordFromManager = this.GetPasswordFromManager(sFilename);
                if (string.IsNullOrEmpty(passwordFromManager))
                {
                    throw new OperationCanceledException("Password required.");
                }
                this._oZip.DefaultDecryptionPassword = passwordFromManager;
                goto Label_002D;
            }
            Utilities.ReadEntireStream(stream, arrBytes);
            stream.Close();
            return arrBytes;
        }

        public Stream GetFileStream(string sFilename)
        {
            AbstractFile file = this._oZip.GetFile(sFilename);
            if (!file.Exists)
            {
                return null;
            }
            Stream stream = null;
        Label_0019:
            try
            {
                stream = file.OpenRead();
            }
            catch (InvalidDecryptionPasswordException)
            {
                string passwordFromManager = this.GetPasswordFromManager(sFilename);
                if (string.IsNullOrEmpty(passwordFromManager))
                {
                    throw new OperationCanceledException("Password required.");
                }
                this._oZip.DefaultDecryptionPassword = passwordFromManager;
                goto Label_0019;
            }
            return stream;
        }

        private string GetPasswordFromManager(string sFilename)
        {
            if (this.fnPasswordCallback != null)
            {
                return this.fnPasswordCallback(this.Filename, sFilename);
            }
            return frmPrompt.GetUserString("Password-Protected Session Archive", "Enter the password to decrypt this Session Archive. Leave blank to cancel.", string.Empty, false, frmPrompt.PromptIcon.Password);
        }

        public string[] GetRequestFileList()
        {
            AbstractFolder folder = this._oZip.GetFolder("raw");
            if (!folder.Exists)
            {
                return new string[0];
            }
            AbstractFile[] files = folder.GetFiles(false, new object[] { "*_c.txt" });
            string[] strArray = new string[files.Length];
            for (int i = 0; i < strArray.Length; i++)
            {
                strArray[i] = files[i].FullName;
            }
            return strArray;
        }

        public string Comment
        {
            get
            {
                return this._oZip.Comment;
            }
        }

        public string EncryptionMethod
        {
            get
            {
                return this._EncryptionMethod;
            }
        }

        public string EncryptionStrength
        {
            get
            {
                return this._EncryptionStrength;
            }
        }

        public string Filename
        {
            get
            {
                return this._sFilename;
            }
        }

        public GetPasswordDelegate PasswordCallback
        {
            get
            {
                return this.fnPasswordCallback;
            }
            set
            {
                this.fnPasswordCallback = value;
            }
        }
    }
}

